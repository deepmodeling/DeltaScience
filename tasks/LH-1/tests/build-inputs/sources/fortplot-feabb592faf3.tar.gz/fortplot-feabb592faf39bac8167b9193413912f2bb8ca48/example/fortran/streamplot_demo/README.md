title: Streamplot Demo
