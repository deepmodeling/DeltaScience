title: Basic Plots
