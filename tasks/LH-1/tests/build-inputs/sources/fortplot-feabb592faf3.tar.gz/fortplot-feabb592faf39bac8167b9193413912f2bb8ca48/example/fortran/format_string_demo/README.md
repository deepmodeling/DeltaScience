title: Format String Demo
