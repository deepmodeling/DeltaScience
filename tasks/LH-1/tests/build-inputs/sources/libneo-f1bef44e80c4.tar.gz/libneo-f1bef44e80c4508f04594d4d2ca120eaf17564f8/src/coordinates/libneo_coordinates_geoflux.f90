module libneo_coordinates_geoflux
    use, intrinsic :: iso_fortran_env, only: dp => real64
    use libneo_coordinates_base, only: coordinate_system_t
    use geoflux_coordinates, only: geoflux_to_cyl, assign_geoflux_to_cyl_jacobian, &
                                   cyl_to_geoflux
    use cylindrical_cartesian, only: cyl_to_cart
    implicit none
    private

    public :: geoflux_coordinate_system_t, make_geoflux_coordinate_system

    type, extends(coordinate_system_t) :: geoflux_coordinate_system_t
    contains
        procedure :: evaluate_cart => geoflux_evaluate_cart
        procedure :: evaluate_cyl => geoflux_evaluate_cyl
        procedure :: covariant_basis => geoflux_covariant_basis
        procedure :: metric_tensor => geoflux_metric_tensor
        procedure :: christoffel => geoflux_christoffel
        procedure :: from_cyl => geoflux_from_cyl
    end type geoflux_coordinate_system_t

contains

    subroutine make_geoflux_coordinate_system(cs)
        class(coordinate_system_t), allocatable, intent(out) :: cs
        allocate(geoflux_coordinate_system_t :: cs)
    end subroutine make_geoflux_coordinate_system

    subroutine geoflux_evaluate_cyl(self, u, x)
        class(geoflux_coordinate_system_t), intent(in) :: self
        real(dp), intent(in) :: u(3)
        real(dp), intent(out) :: x(3)

        associate(dummy => self)
        end associate

        call geoflux_to_cyl(u, x)
    end subroutine geoflux_evaluate_cyl

    subroutine geoflux_evaluate_cart(self, u, x)
        class(geoflux_coordinate_system_t), intent(in) :: self
        real(dp), intent(in) :: u(3)
        real(dp), intent(out) :: x(3)

        real(dp) :: xcyl(3)

        call self%evaluate_cyl(u, xcyl)
        call cyl_to_cart(xcyl, x)
    end subroutine geoflux_evaluate_cart

    subroutine geoflux_covariant_basis(self, u, e_cov)
        class(geoflux_coordinate_system_t), intent(in) :: self
        real(dp), intent(in) :: u(3)
        real(dp), intent(out) :: e_cov(3, 3)

        real(dp) :: s, theta, phi
        real(dp) :: R
        real(dp) :: jac_cyl(3, 3)
        real(dp) :: cos_phi, sin_phi
        real(dp) :: xgeo(3), xcyl(3)

        associate(dummy => self)
        end associate

        s = u(1)
        theta = u(2)
        phi = u(3)

        xgeo = [s, theta, phi]
        call geoflux_to_cyl(xgeo, xcyl)
        R = xcyl(1)
        call assign_geoflux_to_cyl_jacobian(s, theta, jac_cyl)

        cos_phi = cos(phi)
        sin_phi = sin(phi)

        e_cov(1, 1) = jac_cyl(1, 1)*cos_phi
        e_cov(2, 1) = jac_cyl(1, 1)*sin_phi
        e_cov(3, 1) = jac_cyl(3, 1)

        e_cov(1, 2) = jac_cyl(1, 2)*cos_phi
        e_cov(2, 2) = jac_cyl(1, 2)*sin_phi
        e_cov(3, 2) = jac_cyl(3, 2)

        e_cov(1, 3) = jac_cyl(1, 3)*cos_phi - R*sin_phi
        e_cov(2, 3) = jac_cyl(1, 3)*sin_phi + R*cos_phi
        e_cov(3, 3) = jac_cyl(3, 3)
    end subroutine geoflux_covariant_basis

    subroutine geoflux_metric_tensor(self, u, g, ginv, sqrtg)
        class(geoflux_coordinate_system_t), intent(in) :: self
        real(dp), intent(in) :: u(3)
        real(dp), intent(out) :: g(3, 3), ginv(3, 3), sqrtg

        real(dp) :: e_cov(3, 3)
        real(dp) :: det
        integer :: i, j

        call self%covariant_basis(u, e_cov)

        do i = 1, 3
            do j = 1, 3
                g(i, j) = dot_product(e_cov(:, i), e_cov(:, j))
            end do
        end do

        det = g(1,1)*(g(2,2)*g(3,3) - g(2,3)*g(3,2)) &
            - g(1,2)*(g(2,1)*g(3,3) - g(2,3)*g(3,1)) &
            + g(1,3)*(g(2,1)*g(3,2) - g(2,2)*g(3,1))

        sqrtg = sqrt(abs(det))

        ginv(1,1) = (g(2,2)*g(3,3) - g(2,3)*g(3,2))/det
        ginv(1,2) = (g(1,3)*g(3,2) - g(1,2)*g(3,3))/det
        ginv(1,3) = (g(1,2)*g(2,3) - g(1,3)*g(2,2))/det
        ginv(2,1) = (g(2,3)*g(3,1) - g(2,1)*g(3,3))/det
        ginv(2,2) = (g(1,1)*g(3,3) - g(1,3)*g(3,1))/det
        ginv(2,3) = (g(1,3)*g(2,1) - g(1,1)*g(2,3))/det
        ginv(3,1) = (g(2,1)*g(3,2) - g(2,2)*g(3,1))/det
        ginv(3,2) = (g(1,2)*g(3,1) - g(1,1)*g(3,2))/det
        ginv(3,3) = (g(1,1)*g(2,2) - g(1,2)*g(2,1))/det
    end subroutine geoflux_metric_tensor

    subroutine geoflux_christoffel(self, u, Gamma)
        !> The geoflux chart maps through a GEQDSK flux-surface geometry whose
        !> metric is built numerically, so the Christoffel symbols come from
        !> central differences of geoflux_metric_tensor, self-consistent with
        !> the metric the orbit push actually uses.
        class(geoflux_coordinate_system_t), intent(in) :: self
        real(dp), intent(in) :: u(3)
        real(dp), intent(out) :: Gamma(3, 3, 3)

        call self%christoffel_fd(u, Gamma)
    end subroutine geoflux_christoffel

    subroutine geoflux_from_cyl(self, xcyl, u, ierr)
        class(geoflux_coordinate_system_t), intent(in) :: self
        real(dp), intent(in) :: xcyl(3)
        real(dp), intent(out) :: u(3)
        integer, intent(out) :: ierr

        associate(dummy => self)
        end associate

        call cyl_to_geoflux(xcyl, u)
        ierr = 0
    end subroutine geoflux_from_cyl

end module libneo_coordinates_geoflux
