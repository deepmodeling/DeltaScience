add_library(magfie STATIC
    # BDIVFREE
    amn_mod.f90
    bdivfree.f90
    bdivfree_mod.f90
    inthecore_mod.f90
    theta_rz_mod.f90
    input_files.f90
    field_eq_mod.f90
    extract_fluxcoord_mod.f90
    field_divB0.f90
    period_mod.f90
    field_c_mod.f90
    field_mod.f90
    spline5_RZ.f90
    field_mesh3d.f90
    magfield_mod.f90
    polylag_3.f90
    magfie_cyl.f90
    geoflux_field.f90
    coil_tools.f90
    analytical_gs_solver.f90
    analytical_tokamak_field.f90
    # Moved from neo core
    magfie_vmec.f90
)
target_link_libraries(magfie PRIVATE
    neo
    neo_util
    vmec_support
    coordinates
    hdf5_tools
    BLAS::BLAS
    LAPACK::LAPACK
    fortnum
)

target_link_libraries(magfie PRIVATE fortio::fortio)
set_property(TARGET magfie PROPERTY
    INTERFACE_INCLUDE_DIRECTORIES ${CMAKE_Fortran_MODULE_DIRECTORY})
add_library(LIBNEO::magfie ALIAS magfie)
