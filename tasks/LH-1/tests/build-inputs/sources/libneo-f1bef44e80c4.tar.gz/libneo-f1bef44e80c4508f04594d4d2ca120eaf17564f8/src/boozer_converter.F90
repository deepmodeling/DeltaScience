module boozer_sub
    use spl_three_to_five_sub
    use interpolate, only: BatchSplineData1D, BatchSplineData3D, &
                           construct_batch_splines_1d, construct_batch_splines_3d, &
                           evaluate_batch_splines_1d_der2, &
                           evaluate_batch_splines_1d_der3, &
                           evaluate_batch_spline_1d_scalar_cubic_der, &
                           evaluate_batch_spline_1d_pair_cubic_der, &
                           evaluate_batch_spline_1d_scalar_quintic_der, &
                           evaluate_batch_spline_1d_pair_quintic_der, &
                           evaluate_batch_splines_3d_der, &
                           evaluate_batch_splines_3d_der_nq1_o355, &
                           evaluate_batch_splines_3d_der2, &
                           evaluate_batch_splines_3d_der2_rmix, &
                           evaluate_batch_spline_3d_scalar_cubic_der, &
                           evaluate_batch_spline_3d_scalar_quintic_der, &
                           evaluate_batch_spline_3d_scalar_cubic_der2, &
                           evaluate_batch_spline_3d_scalar_cubic_der2_rmix, &
                           evaluate_batch_splines_3d_der3, &
                           destroy_batch_splines_1d, destroy_batch_splines_3d
    use, intrinsic :: iso_fortran_env, only: dp => real64

    implicit none
    private

    ! Public API
    public :: get_boozer_coordinates
    public :: splint_boozer_coord
    public :: splint_boozer_coord_device
    public :: splint_boozer_rk_device, boozer_rk_device_supported
    public :: reset_boozer_batch_splines
    public :: vmec_to_boozer, boozer_to_vmec
    public :: delthe_delphi_BV
    public :: delthe_delphi_BV_d2
    public :: delthe_delphi_BV_d3
    public :: build_boozer_from_chartmap
    public :: sync_boozer_state, boozer_state
    public :: BOOZER_SECDERS_RADIAL_MIXED

    ! Constants
    real(dp), parameter :: TWOPI = 2.0_dp*3.14159265358979_dp
    integer, parameter :: MAX_FIELD3D_QUANTITIES = 3
    integer, parameter :: BOOZER_SECDERS_RADIAL_MIXED = 3


    ! Device-accessible Boozer runtime state shared by host and OpenACC code.
    ! sync_boozer_state copies the libneo globals into this object so that
    ! splint_boozer_coord can run device-resident.
    type :: boozer_state_t
        real(dp) :: torflux = 0.0_dp
        integer :: nper = 1
        logical :: use_B_r = .false.
        integer :: num_quantities = 0
    end type boozer_state_t

    type(boozer_state_t), save :: boozer_state
    !$acc declare create(boozer_state)

    ! Batch spline data for 3D field quantities (Bmod, sqrt_g_ss, optionally B_r)
    type(BatchSplineData3D), save :: field3d_batch_spline = BatchSplineData3D( &
        order=[0, 0, 0], num_points=[0, 0, 0], periodic=.false., &
        h_step=1.0_dp, x_min=1.0_dp, inv_h_step=1.0_dp, period=1.0_dp, &
        num_quantities=0)
    logical, save :: field3d_batch_spline_ready = .false.
    integer, save :: field3d_num_quantities = 0
    real(dp), allocatable, save :: bmod_grid(:, :, :)
    real(dp), allocatable, save :: br_grid(:, :, :)
    real(dp), allocatable, save :: sqrt_g_ss_grid(:, :, :)

    ! Compact value tables for the native canonical RK path. The four field
    ! quantities are B, dB/ds, dB/dtheta, dB/dzeta; the six profiles are
    ! A_phi, dA_phi/ds, B_theta, dB_theta/ds, B_phi, dB_phi/ds.

    ! Batch spline for A_phi (vector potential)
    type(BatchSplineData1D), save :: aphi_batch_spline = BatchSplineData1D( &
        order=0, num_points=0, periodic=.false., x_min=1.0_dp, &
        h_step=1.0_dp, inv_h_step=1.0_dp, period=1.0_dp, num_quantities=0)
    logical, save :: aphi_batch_spline_ready = .false.

    ! Batch spline for B_theta, B_phi covariant components
    type(BatchSplineData1D), save :: bcovar_tp_batch_spline = BatchSplineData1D( &
        order=0, num_points=0, periodic=.false., x_min=1.0_dp, &
        h_step=1.0_dp, inv_h_step=1.0_dp, period=1.0_dp, num_quantities=0)
    logical, save :: bcovar_tp_batch_spline_ready = .false.

    ! These descriptors are module globals so GPU-callable field evaluation can
    ! address them without passing a large spline bundle through every layer.
    ! The construction routines attach the allocatable coefficient components.
    !$acc declare create(field3d_batch_spline, aphi_batch_spline, &
    !$acc&               bcovar_tp_batch_spline)

    ! Batch splines for angle transformations (VMEC <-> Boozer).
    ! delt_delp_V holds (theta_B-theta_V, phi_B-phi_V) on the VMEC-angle grid;
    ! delt_delp_B holds the same differences on the Boozer-angle grid.
    type(BatchSplineData3D), save :: delt_delp_V_batch_spline
    logical, save :: delt_delp_V_batch_spline_ready = .false.
    real(dp), allocatable, save :: delt_delp_V_grid(:, :, :, :)

    type(BatchSplineData3D), save :: delt_delp_B_batch_spline
    logical, save :: delt_delp_B_batch_spline_ready = .false.
    real(dp), allocatable, save :: delt_delp_B_grid(:, :, :, :)

contains

    !> Initialize Boozer coordinates using VMEC field (backward compatibility)
    subroutine get_boozer_coordinates(vmec_file, &
                                      radial_spline_order, &
                                      angular_spline_order, &
                                      grid_refinment)
        use new_vmec_stuff_mod, only: netcdffile, ns_s, ns_tp, multharm
        use spline_vmec_sub, only: spline_vmec_data

        character(len=*), intent(in), optional :: vmec_file
        integer, intent(in), optional :: radial_spline_order, angular_spline_order, grid_refinment

        if (.not. present(vmec_file)) then
            ! No-argument entry: VMEC is assumed already splined by the caller.
            call reset_boozer_batch_splines()
            call get_boozer_coordinates_impl()
            call sync_boozer_state()
            return
        end if

        netcdffile = vmec_file
        if (present(radial_spline_order)) then
            ns_s = radial_spline_order
        else
            ns_s = 5
        end if
        if (present(angular_spline_order)) then
            ns_tp = angular_spline_order
        else
            ns_tp = 5
        end if
        if (present(grid_refinment)) then
            multharm = grid_refinment
        else
            ! Quintic splines on a multharm=5 angular grid put the interpolation
            ! floor (~2e-6 relative for |B|) at the VMEC->Boozer transform-fidelity
            ! level; finer grids are dominated by the transform difference, not the
            ! spline. See test/source/bench_boozer_resolution.f90. Matches the
            ! new_vmec_stuff_mod module default.
            multharm = 5
        end if

        call spline_vmec_data()

        call reset_boozer_batch_splines()
        call get_boozer_coordinates_impl()
        call sync_boozer_state()

    end subroutine get_boozer_coordinates

    !> Copy scalar Boozer field parameters and the field3d quantity count from
    !> the libneo modules into the shared runtime state. Host-only; call after
    !> field init and before any OpenACC tracing kernel.
    subroutine sync_boozer_state()
        use vector_potentail_mod, only: torflux
        use new_vmec_stuff_mod, only: nper
        use boozer_coordinates_mod, only: use_B_r

        boozer_state%torflux = torflux
        boozer_state%nper = nper
        boozer_state%use_B_r = use_B_r
        boozer_state%num_quantities = field3d_num_quantities
        !$acc update device(boozer_state)
        if (aphi_batch_spline_ready) then
            !$acc update device(aphi_batch_spline)
            !$acc enter data attach(aphi_batch_spline%coeff)
        end if
        if (bcovar_tp_batch_spline_ready) then
            !$acc update device(bcovar_tp_batch_spline)
            !$acc enter data attach(bcovar_tp_batch_spline%coeff)
        end if
        if (field3d_batch_spline_ready) then
            !$acc update device(field3d_batch_spline)
            !$acc enter data attach(field3d_batch_spline%coeff)
        end if
    end subroutine sync_boozer_state

    subroutine get_boozer_coordinates_impl

        use vector_potentail_mod, only: ns, hs
        use new_vmec_stuff_mod, only: n_theta, n_phi, h_theta, h_phi, ns_s, ns_tp
        use boozer_coordinates_mod, only: ns_s_B, ns_tp_B, ns_B, n_theta_B, n_phi_B, &
                                          hs_B, h_theta_B, h_phi_B, use_B_r

        implicit none

        ns_s_B = ns_s
        ns_tp_B = ns_tp
        ns_B = ns
        n_theta_B = n_theta
        n_phi_B = n_phi

        hs_B = hs*real(ns - 1, dp)/real(ns_B - 1, dp)
        h_theta_B = h_theta*real(n_theta - 1, dp)/real(n_theta_B - 1, dp)
        h_phi_B = h_phi*real(n_phi - 1, dp)/real(n_phi_B - 1, dp)

        call compute_boozer_data

        call build_boozer_aphi_batch_spline
        call build_boozer_bcovar_tp_batch_spline
        call build_boozer_field3d_batch_spline
        call build_boozer_delt_delp_batch_splines

    end subroutine get_boozer_coordinates_impl

    subroutine splint_boozer_coord(r, vartheta_B, varphi_B, mode_secders, &
                                   A_theta, A_phi, dA_theta_dr, dA_phi_dr, &
                                   d2A_phi_dr2, d3A_phi_dr3, &
                                   B_vartheta_B, dB_vartheta_B, d2B_vartheta_B, &
                                   B_varphi_B, dB_varphi_B, d2B_varphi_B, &
                                   Bmod_B, dBmod_B, d2Bmod_B, &
                                   B_r, dB_r, d2B_r, sqrt_g_ss_B)
        use chamb_mod, only: rnegflag
        use diag_mod, only: dodiag, icounter

        integer, intent(in) :: mode_secders
        real(dp), intent(in) :: r, vartheta_B, varphi_B
        real(dp), intent(out) :: A_phi, A_theta, dA_phi_dr, dA_theta_dr
        real(dp), intent(out) :: d2A_phi_dr2, d3A_phi_dr3
        real(dp), intent(out) :: B_vartheta_B, dB_vartheta_B, d2B_vartheta_B
        real(dp), intent(out) :: B_varphi_B, dB_varphi_B, d2B_varphi_B
        real(dp), intent(out) :: Bmod_B, B_r
        real(dp), intent(out), optional :: sqrt_g_ss_B
        real(dp), intent(out) :: dBmod_B(3), dB_r(3)
        real(dp), intent(out) :: d2Bmod_B(6), d2B_r(6)
        real(dp) :: r_eval

        if (dodiag) then
!$omp atomic
            icounter = icounter + 1
        end if
        r_eval = r
        if (r_eval .le. 0.0_dp) then
            rnegflag = .true.
            r_eval = abs(r_eval)
        end if
        if (.not. aphi_batch_spline_ready) &
            error stop "splint_boozer_coord: Aphi batch spline not initialized"
        if (.not. field3d_batch_spline_ready) &
            error stop "splint_boozer_coord: Bmod/Br batch spline not initialized"
        if (.not. bcovar_tp_batch_spline_ready) &
            error stop "splint_boozer_coord: Bcovar_tp batch spline not initialized"

        if (present(sqrt_g_ss_B)) then
            call splint_boozer_coord_device(r_eval, vartheta_B, varphi_B, mode_secders, &
                                            A_theta, A_phi, dA_theta_dr, dA_phi_dr, &
                                            d2A_phi_dr2, d3A_phi_dr3, &
                                            B_vartheta_B, dB_vartheta_B, &
                                            d2B_vartheta_B, B_varphi_B, &
                                            dB_varphi_B, d2B_varphi_B, Bmod_B, &
                                            dBmod_B, d2Bmod_B, B_r, dB_r, d2B_r, &
                                            sqrt_g_ss_B)
        else
            call splint_boozer_coord_device(r_eval, vartheta_B, varphi_B, mode_secders, &
                                            A_theta, A_phi, dA_theta_dr, dA_phi_dr, &
                                            d2A_phi_dr2, d3A_phi_dr3, &
                                            B_vartheta_B, dB_vartheta_B, &
                                            d2B_vartheta_B, B_varphi_B, &
                                            dB_varphi_B, d2B_varphi_B, Bmod_B, &
                                            dBmod_B, d2Bmod_B, B_r, dB_r, d2B_r)
        end if
    end subroutine splint_boozer_coord

    !> Device-callable spline evaluator. The host wrapper above verifies that
    !> all resident spline tables are initialized before entering a GPU region.
    subroutine splint_boozer_coord_device(r, vartheta_B, varphi_B, mode_secders, &
                                   A_theta, A_phi, dA_theta_dr, dA_phi_dr, &
                                   d2A_phi_dr2, d3A_phi_dr3, &
                                   B_vartheta_B, dB_vartheta_B, d2B_vartheta_B, &
                                   B_varphi_B, dB_varphi_B, d2B_varphi_B, &
                                   Bmod_B, dBmod_B, d2Bmod_B, &
                                   B_r, dB_r, d2B_r, sqrt_g_ss_B)
        !$acc routine seq

        implicit none

        integer, intent(in) :: mode_secders

        real(dp), intent(in) :: r, vartheta_B, varphi_B
        real(dp), intent(out) :: A_phi, A_theta, dA_phi_dr, dA_theta_dr
        real(dp), intent(out) :: d2A_phi_dr2, d3A_phi_dr3
        real(dp), intent(out) :: B_vartheta_B, dB_vartheta_B, d2B_vartheta_B
        real(dp), intent(out) :: B_varphi_B, dB_varphi_B, d2B_varphi_B
        real(dp), intent(out) :: Bmod_B, B_r
        real(dp), intent(out), optional :: sqrt_g_ss_B
        real(dp), intent(out) :: dBmod_B(3), dB_r(3)
        real(dp), intent(out) :: d2Bmod_B(6), d2B_r(6)

        integer :: i_br
        real(dp) :: r_eval, rho_tor, drhods, drhods2, d2rhods2m
        real(dp) :: qua, dqua_dr, dqua_dt, dqua_dp
        real(dp) :: d2qua_dr2, d2qua_drdt, d2qua_drdp, d2qua_dt2, &
                    d2qua_dtdp, d2qua_dp2
        real(dp) :: x_eval(3)
        real(dp) :: y_eval(MAX_FIELD3D_QUANTITIES)
        real(dp) :: dy_eval(3, MAX_FIELD3D_QUANTITIES)
        real(dp) :: d2y_eval(6, MAX_FIELD3D_QUANTITIES)
        real(dp) :: theta_wrapped, phi_wrapped
        real(dp) :: y1d(2), dy1d(2), d2y1d(2), d3y1d(1)

        r_eval = abs(r)

        A_theta = boozer_state%torflux*r_eval
        dA_theta_dr = boozer_state%torflux

        ! Interpolate A_phi over s (batch spline 1D)
        if (mode_secders > 0) then
            ! Need third derivative - use der3 which computes all in one pass
            call evaluate_batch_splines_1d_der3(aphi_batch_spline, r_eval, &
                                                y1d(1:1), dy1d(1:1), &
                                                d2y1d(1:1), d3y1d)
            d3A_phi_dr3 = d3y1d(1)
        else
            call evaluate_batch_splines_1d_der2(aphi_batch_spline, r_eval, y1d(1:1), &
                                                dy1d(1:1), d2y1d(1:1))
            d3A_phi_dr3 = 0.0_dp
        end if
        A_phi = y1d(1)
        dA_phi_dr = dy1d(1)
        d2A_phi_dr2 = d2y1d(1)

        ! Interpolation of mod-B (and B_r if use_B_r)
        rho_tor = sqrt(r_eval)
        theta_wrapped = modulo(vartheta_B, TWOPI)
        phi_wrapped = modulo(varphi_B, TWOPI/real(boozer_state%nper, dp))

        x_eval(1) = rho_tor
        x_eval(2) = theta_wrapped
        x_eval(3) = phi_wrapped

        i_br = boozer_state%num_quantities

        ! Chain rule coefficients for rho -> s conversion
        drhods = 0.5_dp/rho_tor
        drhods2 = drhods**2
        d2rhods2m = drhods2/rho_tor  ! -d2rho/ds2 (negative of second derivative)

        if (mode_secders == 2 .or. &
                mode_secders == BOOZER_SECDERS_RADIAL_MIXED) then
            if (mode_secders == BOOZER_SECDERS_RADIAL_MIXED) then
                d2y_eval(4:6, :) = 0.0_dp
                if (boozer_state%num_quantities == 1 .and. &
                        all(field3d_batch_spline%order == [3, 3, 3])) then
                    call evaluate_batch_spline_3d_scalar_cubic_der2_rmix( &
                        field3d_batch_spline, x_eval, y_eval(1), dy_eval(:, 1), &
                        d2y_eval(1:3, 1))
                else
                    call evaluate_batch_splines_3d_der2_rmix( &
                        field3d_batch_spline, x_eval, &
                        y_eval(1:boozer_state%num_quantities), &
                        dy_eval(:, 1:boozer_state%num_quantities), &
                        d2y_eval(1:3, 1:boozer_state%num_quantities))
                end if
            else
                if (boozer_state%num_quantities == 1 .and. &
                    all(field3d_batch_spline%order == [3, 3, 3])) then
                    call evaluate_batch_spline_3d_scalar_cubic_der2( &
                        field3d_batch_spline, x_eval, y_eval(1), dy_eval(:, 1), &
                        d2y_eval(:, 1))
                else
                    call evaluate_batch_splines_3d_der2(field3d_batch_spline, x_eval, &
                                                        y_eval(1:boozer_state%num_quantities), &
                                                        dy_eval(:, 1:boozer_state%num_quantities), &
                                                        d2y_eval(:, 1:boozer_state%num_quantities))
                end if
            end if

            ! Extract Bmod (quantity 1)
            qua = y_eval(1)
            dqua_dr = dy_eval(1, 1)
            dqua_dt = dy_eval(2, 1)
            dqua_dp = dy_eval(3, 1)

            d2qua_dr2 = d2y_eval(1, 1)
            d2qua_drdt = d2y_eval(2, 1)
            d2qua_drdp = d2y_eval(3, 1)
            d2qua_dt2 = d2y_eval(4, 1)
            d2qua_dtdp = d2y_eval(5, 1)
            d2qua_dp2 = d2y_eval(6, 1)

            d2qua_dr2 = d2qua_dr2*drhods2 - dqua_dr*d2rhods2m
            dqua_dr = dqua_dr*drhods
            d2qua_drdt = d2qua_drdt*drhods
            d2qua_drdp = d2qua_drdp*drhods

            Bmod_B = qua

            dBmod_B(1) = dqua_dr
            dBmod_B(2) = dqua_dt
            dBmod_B(3) = dqua_dp

            d2Bmod_B(1) = d2qua_dr2
            d2Bmod_B(2) = d2qua_drdt
            d2Bmod_B(3) = d2qua_drdp
            d2Bmod_B(4) = d2qua_dt2
            d2Bmod_B(5) = d2qua_dtdp
            d2Bmod_B(6) = d2qua_dp2

            if (present(sqrt_g_ss_B) .and. boozer_state%use_B_r) &
                sqrt_g_ss_B = y_eval(2)

            ! Extract B_r (if present)
            if (boozer_state%use_B_r) then
                qua = y_eval(i_br)
                dqua_dr = dy_eval(1, i_br)
                dqua_dt = dy_eval(2, i_br)
                dqua_dp = dy_eval(3, i_br)

                d2qua_dr2 = d2y_eval(1, i_br)
                d2qua_drdt = d2y_eval(2, i_br)
                d2qua_drdp = d2y_eval(3, i_br)
                d2qua_dt2 = d2y_eval(4, i_br)
                d2qua_dtdp = d2y_eval(5, i_br)
                d2qua_dp2 = d2y_eval(6, i_br)

                d2qua_dr2 = d2qua_dr2*drhods2 - dqua_dr*d2rhods2m
                dqua_dr = dqua_dr*drhods
                d2qua_drdt = d2qua_drdt*drhods
                d2qua_drdp = d2qua_drdp*drhods

                B_r = qua*drhods

                dB_r(1) = dqua_dr*drhods - qua*d2rhods2m
                dB_r(2) = dqua_dt*drhods
                dB_r(3) = dqua_dp*drhods

                d2B_r(1) = d2qua_dr2*drhods - 2.0_dp*dqua_dr*d2rhods2m + &
                           qua*drhods*(3.0_dp/4.0_dp)/r_eval**2
                d2B_r(2) = d2qua_drdt*drhods - dqua_dt*d2rhods2m
                d2B_r(3) = d2qua_drdp*drhods - dqua_dp*d2rhods2m
                d2B_r(4) = d2qua_dt2*drhods
                d2B_r(5) = d2qua_dtdp*drhods
                d2B_r(6) = d2qua_dp2*drhods
            else
                B_r = 0.0_dp
                dB_r = 0.0_dp
                d2B_r = 0.0_dp
            end if
        else
            if (boozer_state%num_quantities == 1 .and. &
                all(field3d_batch_spline%order == [3, 3, 3])) then
                call evaluate_batch_spline_3d_scalar_cubic_der( &
                    field3d_batch_spline, x_eval, y_eval(1), dy_eval(:, 1))
            else if (boozer_state%num_quantities == 1 .and. &
                all(field3d_batch_spline%order == [3, 5, 5])) then
                call evaluate_batch_splines_3d_der_nq1_o355( &
                    field3d_batch_spline, x_eval, y_eval(1:1), dy_eval(:, 1:1))
            else
                call evaluate_batch_splines_3d_der(field3d_batch_spline, x_eval, &
                                                   y_eval(1:boozer_state%num_quantities), &
                                                   dy_eval(:, 1:boozer_state%num_quantities))
            end if

            Bmod_B = y_eval(1)
            dBmod_B(1) = dy_eval(1, 1)*drhods
            dBmod_B(2) = dy_eval(2, 1)
            dBmod_B(3) = dy_eval(3, 1)

            if (present(sqrt_g_ss_B) .and. boozer_state%use_B_r) &
                sqrt_g_ss_B = y_eval(2)

            d2Bmod_B = 0.0_dp

            if (mode_secders == 1 .and. .not. (boozer_state%num_quantities == 1 .and. &
                all(field3d_batch_spline%order == [3, 3, 3]))) then
                call evaluate_batch_splines_3d_der2(field3d_batch_spline, x_eval, &
                                                    y_eval(1:boozer_state%num_quantities), &
                                                    dy_eval(:, &
                                                            1:boozer_state%num_quantities), &
                                                    d2y_eval(:, &
                                                             1:boozer_state%num_quantities))
                d2Bmod_B(1) = d2y_eval(1, 1)*drhods2 - dy_eval(1, 1)*d2rhods2m
            end if

            if (boozer_state%use_B_r) then
                qua = y_eval(i_br)
                dqua_dr = dy_eval(1, i_br)
                dqua_dt = dy_eval(2, i_br)
                dqua_dp = dy_eval(3, i_br)

                dqua_dr = dqua_dr*drhods
                B_r = qua*drhods

                dB_r(1) = dqua_dr*drhods - qua*d2rhods2m
                dB_r(2) = dqua_dt*drhods
                dB_r(3) = dqua_dp*drhods

                d2B_r = 0.0_dp
                if (mode_secders == 1) then
                    d2qua_dr2 = d2y_eval(1, i_br)*drhods2 - dy_eval(1, i_br)*d2rhods2m
                    d2B_r(1) = d2qua_dr2*drhods - 2.0_dp*dqua_dr*d2rhods2m + &
                               qua*drhods*(3.0_dp/4.0_dp)/r_eval**2
                end if
            else
                B_r = 0.0_dp
                dB_r = 0.0_dp
                d2B_r = 0.0_dp
            end if
        end if

        ! Interpolation of B_\vartheta and B_\varphi (flux functions)
        call evaluate_batch_splines_1d_der2(bcovar_tp_batch_spline, rho_tor, y1d, &
                                            dy1d, d2y1d)
        B_vartheta_B = y1d(1)
        dB_vartheta_B = dy1d(1)
        B_varphi_B = y1d(2)
        dB_varphi_B = dy1d(2)
        dB_vartheta_B = dB_vartheta_B*drhods
        dB_varphi_B = dB_varphi_B*drhods
        if (mode_secders > 0) then
            d2B_vartheta_B = d2y1d(1)*drhods2 - dy1d(1)*d2rhods2m
            d2B_varphi_B = d2y1d(2)*drhods2 - dy1d(2)*d2rhods2m
        else
            d2B_vartheta_B = 0.0_dp
            d2B_varphi_B = 0.0_dp
        end if

    end subroutine splint_boozer_coord_device

    logical function boozer_rk_device_supported()
        use boozer_rk_tables, only: rk_tables_ready

        if (rk_tables_ready) then
            boozer_rk_device_supported = .true.
            return
        end if
        boozer_rk_device_supported = aphi_batch_spline_ready .and. &
            bcovar_tp_batch_spline_ready .and. field3d_batch_spline_ready
        if (.not. boozer_rk_device_supported) return
        boozer_rk_device_supported = field3d_num_quantities == 1 .and. &
            (all(field3d_batch_spline%order == [3, 3, 3]) .or. &
             all(field3d_batch_spline%order == [5, 5, 5])) .and. &
            (aphi_batch_spline%order == 3 .or. aphi_batch_spline%order == 5) .and. &
            (bcovar_tp_batch_spline%order == 3 .or. &
             bcovar_tp_batch_spline%order == 5)
    end function boozer_rk_device_supported

    !> Minimal Boozer data needed by the canonical RK right-hand side.
    !> Production chartmaps use splint_boozer_rk_table_device; this fallback
    !> preserves the generic VMEC path and its independently tested evaluator.
    subroutine splint_boozer_rk_device(r, vartheta_B, varphi_B, aphi, daphi, &
            btheta, dbtheta, bphi, dbphi, bmod, dbmod)
        !$acc routine seq
        real(dp), intent(in) :: r, vartheta_B, varphi_B
        real(dp), intent(out) :: aphi, daphi
        real(dp), intent(out) :: btheta, dbtheta, bphi, dbphi
        real(dp), intent(out) :: bmod, dbmod(3)

        real(dp) :: atheta, datheta, d2aphi, d3aphi
        real(dp) :: d2btheta, d2bphi, br
        real(dp) :: d2bmod(6), dbr(3), d2br(6)

        call splint_boozer_coord_device(abs(r), vartheta_B, varphi_B, 0, &
            atheta, aphi, datheta, daphi, d2aphi, d3aphi, &
            btheta, dbtheta, d2btheta, bphi, dbphi, d2bphi, &
            bmod, dbmod, d2bmod, br, dbr, d2br)
    end subroutine splint_boozer_rk_device

    !> Computes deltheta_BV = vartheta_B - theta_V and delphi_BV = varphi_B - varphi_V
    !> together with their first derivatives over the angles.
    !> isw=0: arguments are VMEC angles (r, theta, varphi)
    !> isw=1: arguments are Boozer angles (r, vartheta_B, varphi_B)
    subroutine delthe_delphi_BV(isw, r, vartheta, varphi, deltheta_BV, delphi_BV, &
                                ddeltheta_BV, ddelphi_BV)
        use boozer_coordinates_mod, only: use_del_tp_B
        use chamb_mod, only: rnegflag

        integer, intent(in) :: isw
        real(dp), intent(in) :: r, vartheta, varphi
        real(dp), intent(out) :: deltheta_BV, delphi_BV
        real(dp), dimension(2), intent(out) :: ddeltheta_BV, ddelphi_BV

        real(dp) :: rho_tor, x_eval(3), y_eval(2), dy_eval(3, 2)
        real(dp) :: r_local

        r_local = r
        if (r_local <= 0.0_dp) then
            rnegflag = .true.
            r_local = abs(r_local)
        end if

        rho_tor = sqrt(r_local)
        x_eval(1) = rho_tor
        x_eval(2) = vartheta
        x_eval(3) = varphi

        if (isw .eq. 0) then
            if (.not. delt_delp_V_batch_spline_ready) then
                ! No VMEC<->Boozer angle map loaded -- the field is Boozer-native
                ! (e.g. loaded from a Boozer chartmap, which stores no VMEC angles).
                ! The theta_B-theta_V / phi_B-phi_V correction is then identically
                ! zero, so return it instead of aborting (the chartmap CP/CPP path
                ! reaches here for near-axis points).
                deltheta_BV = 0.0_dp
                delphi_BV = 0.0_dp
                ddeltheta_BV = 0.0_dp
                ddelphi_BV = 0.0_dp
                return
            end if
            call evaluate_batch_splines_3d_der(delt_delp_V_batch_spline, x_eval, &
                                               y_eval, dy_eval)
        elseif (isw .eq. 1) then
            if (.not. use_del_tp_B) then
                print *, 'delthe_delphi_BV : Boozer data is not loaded'
                return
            end if
            if (.not. delt_delp_B_batch_spline_ready) then
                error stop "delthe_delphi_BV: B batch spline not initialized"
            end if
            call evaluate_batch_splines_3d_der(delt_delp_B_batch_spline, x_eval, &
                                               y_eval, dy_eval)
        else
            print *, 'delthe_delphi_BV : unknown value of switch isw'
            return
        end if

        deltheta_BV = y_eval(1)
        delphi_BV = y_eval(2)

        ddeltheta_BV(1) = dy_eval(2, 1)
        ddelphi_BV(1) = dy_eval(2, 2)

        ddeltheta_BV(2) = dy_eval(3, 1)
        ddelphi_BV(2) = dy_eval(3, 2)

    end subroutine delthe_delphi_BV

    !> Boozer-side angle-map deltas with first AND second derivatives w.r.t.
    !> (s, vartheta_B, varphi_B). Returns the full 3-component gradient and the
    !> packed Hessian (ss, st, sp, tt, tp, pp). Used by the curvilinear 6D
    !> metric (boozer_field_metric) for the analytic dg_B/d2g_B pullback.
    subroutine delthe_delphi_BV_d2(s, vartheta_B, varphi_B, deltheta_BV, delphi_BV, &
                                   ddeltheta_BV, ddelphi_BV, &
                                   d2deltheta_BV, d2delphi_BV)
        use boozer_coordinates_mod, only: use_del_tp_B

        real(dp), intent(in) :: s, vartheta_B, varphi_B
        real(dp), intent(out) :: deltheta_BV, delphi_BV
        real(dp), dimension(3), intent(out) :: ddeltheta_BV, ddelphi_BV
        real(dp), dimension(6), intent(out) :: d2deltheta_BV, d2delphi_BV

        real(dp) :: r_eval, rho_tor, drhods, d2rhods2
        real(dp) :: x_eval(3), y_eval(2), dy_eval(3, 2), d2y_eval(6, 2)
        integer :: q

        if (.not. use_del_tp_B) then
            error stop "delthe_delphi_BV_d2: requires use_del_tp_B = .true."
        end if
        if (.not. delt_delp_B_batch_spline_ready) then
            error stop "delthe_delphi_BV_d2: B batch spline not initialized"
        end if

        r_eval = abs(s)
        rho_tor = sqrt(r_eval)
        x_eval(1) = rho_tor
        x_eval(2) = vartheta_B
        x_eval(3) = varphi_B

        ! drho/ds = 0.5/rho,  d2rho/ds2 = -0.25/rho**3
        drhods = 0.5_dp/rho_tor
        d2rhods2 = -0.25_dp/rho_tor**3

        call evaluate_batch_splines_3d_der2(delt_delp_B_batch_spline, x_eval, &
                                            y_eval, dy_eval, d2y_eval)

        ! Convert the radial slots (rho -> s) for each quantity. The packed index
        ! convention from der2 is (rr, rt, rp, tt, tp, pp); slots 1,2,3 touch rho.
        do q = 1, 2
            ! Second derivatives first (they reference the rho first derivative).
            d2y_eval(1, q) = d2y_eval(1, q)*drhods**2 + dy_eval(1, q)*d2rhods2
            d2y_eval(2, q) = d2y_eval(2, q)*drhods
            d2y_eval(3, q) = d2y_eval(3, q)*drhods
            dy_eval(1, q) = dy_eval(1, q)*drhods
        end do

        deltheta_BV = y_eval(1)
        delphi_BV = y_eval(2)
        ddeltheta_BV = dy_eval(:, 1)
        ddelphi_BV = dy_eval(:, 2)
        d2deltheta_BV = d2y_eval(:, 1)
        d2delphi_BV = d2y_eval(:, 2)
    end subroutine delthe_delphi_BV_d2

    !> Boozer-side angle-map deltas with first, second AND third derivatives
    !> w.r.t. (s, vartheta_B, varphi_B). d3 packed
    !> (sss, sst, ssp, stt, stp, spp, ttt, ttp, tpp, ppp). Feeds the analytic
    !> d2g_B pullback in boozer_field_metric (the angle Jacobian's second
    !> derivative).
    subroutine delthe_delphi_BV_d3(s, vartheta_B, varphi_B, deltheta_BV, delphi_BV, &
                                   ddeltheta_BV, ddelphi_BV, &
                                   d2deltheta_BV, d2delphi_BV, &
                                   d3deltheta_BV, d3delphi_BV)
        use boozer_coordinates_mod, only: use_del_tp_B

        real(dp), intent(in) :: s, vartheta_B, varphi_B
        real(dp), intent(out) :: deltheta_BV, delphi_BV
        real(dp), dimension(3), intent(out) :: ddeltheta_BV, ddelphi_BV
        real(dp), dimension(6), intent(out) :: d2deltheta_BV, d2delphi_BV
        real(dp), dimension(10), intent(out) :: d3deltheta_BV, d3delphi_BV

        real(dp) :: r_eval, rho_tor, drhods, d2rhods2, d3rhods3
        real(dp) :: x_eval(3), y_eval(2), dy_eval(3, 2), d2y_eval(6, 2), d3y_eval(10, 2)
        real(dp) :: d3out(10, 2)
        integer :: q

        if (.not. use_del_tp_B) then
            error stop "delthe_delphi_BV_d3: requires use_del_tp_B = .true."
        end if
        if (.not. delt_delp_B_batch_spline_ready) then
            error stop "delthe_delphi_BV_d3: B batch spline not initialized"
        end if

        r_eval = abs(s)
        rho_tor = sqrt(r_eval)
        x_eval(1) = rho_tor
        x_eval(2) = vartheta_B
        x_eval(3) = varphi_B

        ! rho = sqrt(s): drho/ds = 0.5/rho, d2rho/ds2 = -0.25/rho**3,
        ! d3rho/ds3 = 0.375/rho**5.
        drhods = 0.5_dp/rho_tor
        d2rhods2 = -0.25_dp/rho_tor**3
        d3rhods3 = 0.375_dp/rho_tor**5

        call evaluate_batch_splines_3d_der3(delt_delp_B_batch_spline, x_eval, &
                                            y_eval, dy_eval, d2y_eval, d3y_eval)

        ! Chain rho -> s for the third derivatives FIRST: they reference the
        ! rho-space first and second derivatives, which the d2/d1 chain overwrites.
        ! d3 packed in (sss,sst,ssp,stt,stp,spp,ttt,ttp,tpp,ppp); the rho-space
        ! d3y is (rrr,rrt,rrp,rtt,rtp,rpp,ttt,ttp,tpp,ppp), d2y is (rr,rt,rp,...).
        do q = 1, 2
            d3out(1, q) = d3y_eval(1, q)*drhods**3 &
                          + 3.0_dp*drhods*d2rhods2*d2y_eval(1, q) &
                          + d3rhods3*dy_eval(1, q)
            d3out(2, q) = d3y_eval(2, q)*drhods**2 + d2rhods2*d2y_eval(2, q)
            d3out(3, q) = d3y_eval(3, q)*drhods**2 + d2rhods2*d2y_eval(3, q)
            d3out(4, q) = d3y_eval(4, q)*drhods
            d3out(5, q) = d3y_eval(5, q)*drhods
            d3out(6, q) = d3y_eval(6, q)*drhods
            d3out(7, q) = d3y_eval(7, q)
            d3out(8, q) = d3y_eval(8, q)
            d3out(9, q) = d3y_eval(9, q)
            d3out(10, q) = d3y_eval(10, q)
        end do

        do q = 1, 2
            d2y_eval(1, q) = d2y_eval(1, q)*drhods**2 + dy_eval(1, q)*d2rhods2
            d2y_eval(2, q) = d2y_eval(2, q)*drhods
            d2y_eval(3, q) = d2y_eval(3, q)*drhods
            dy_eval(1, q) = dy_eval(1, q)*drhods
        end do

        deltheta_BV = y_eval(1)
        delphi_BV = y_eval(2)
        ddeltheta_BV = dy_eval(:, 1)
        ddelphi_BV = dy_eval(:, 2)
        d2deltheta_BV = d2y_eval(:, 1)
        d2delphi_BV = d2y_eval(:, 2)
        d3deltheta_BV = d3out(:, 1)
        d3delphi_BV = d3out(:, 2)
    end subroutine delthe_delphi_BV_d3

    !> Convert VMEC angles (r, theta, varphi) to Boozer angles (vartheta_B, varphi_B)
    subroutine vmec_to_boozer(r, theta, varphi, vartheta_B, varphi_B)
        use new_vmec_stuff_mod, only: nper

        real(dp), intent(in) :: r, theta, varphi
        real(dp), intent(out) :: vartheta_B, varphi_B

        real(dp) :: deltheta_BV, delphi_BV
        real(dp), dimension(2) :: ddeltheta_BV, ddelphi_BV

        call delthe_delphi_BV(0, r, theta, varphi, deltheta_BV, delphi_BV, &
                              ddeltheta_BV, ddelphi_BV)

        vartheta_B = modulo(theta + deltheta_BV, TWOPI)
        varphi_B = modulo(varphi + delphi_BV, TWOPI/real(nper, dp))

    end subroutine vmec_to_boozer

    !> Convert Boozer angles (r, vartheta_B, varphi_B) to VMEC angles (theta, varphi)
    !> by Newton iteration on the VMEC-angle transform.
    subroutine boozer_to_vmec(r, vartheta_B, varphi_B, theta, varphi)
        use boozer_coordinates_mod, only: use_del_tp_B

        real(dp), intent(in) :: r, vartheta_B, varphi_B
        real(dp), intent(out) :: theta, varphi

        real(dp), parameter :: epserr = 1.0e-14_dp
        integer, parameter :: niter = 100

        integer :: iter
        real(dp) :: deltheta_BV, delphi_BV
        real(dp) :: f1, f2, f11, f12, f21, f22, delthe, delphi, det
        real(dp), dimension(2) :: ddeltheta_BV, ddelphi_BV

        if (use_del_tp_B) then
            call delthe_delphi_BV(1, r, vartheta_B, varphi_B, deltheta_BV, delphi_BV, &
                                  ddeltheta_BV, ddelphi_BV)

            theta = vartheta_B - deltheta_BV
            varphi = varphi_B - delphi_BV
        else
            theta = vartheta_B
            varphi = varphi_B
        end if

        do iter = 1, niter
            call delthe_delphi_BV(0, r, theta, varphi, deltheta_BV, delphi_BV, &
                                  ddeltheta_BV, ddelphi_BV)

            f1 = theta + deltheta_BV - vartheta_B
            f2 = varphi + delphi_BV - varphi_B
            f11 = 1.0_dp + ddeltheta_BV(1)
            f12 = ddeltheta_BV(2)
            f21 = ddelphi_BV(1)
            f22 = 1.0_dp + ddelphi_BV(2)

            det = f11*f22 - f12*f21
            delthe = (f2*f12 - f1*f22)/det
            delphi = (f1*f21 - f2*f11)/det

            theta = theta + delthe
            varphi = varphi + delphi
            if (abs(delthe) + abs(delphi) .lt. epserr) exit
        end do

    end subroutine boozer_to_vmec

    subroutine compute_boozer_data
        ! Computes Boozer coordinate transformations and magnetic field data
        use boozer_coordinates_mod, only: ns_s_B, ns_tp_B, ns_B, n_theta_B, n_phi_B, &
                                          hs_B, h_theta_B, h_phi_B, &
                                          s_Bcovar_tp_B, &
                                          use_B_r, use_del_tp_B
        use binsrc_sub, only: binsrc
        use plag_coeff_sub, only: plag_coeff
        use spline_vmec_sub

        implicit none

        real(dp), parameter :: s_min = 1.0e-6_dp, rho_min = sqrt(s_min)

        integer :: i, i_rho, i_theta, i_phi, npoilag, nder, nshift
        integer :: ibeg, iend, nqua
        real(dp) :: s, theta, varphi, A_theta, A_phi
        real(dp) :: dA_theta_ds, dA_phi_ds, aiota
        real(dp) :: sqg, alam, dl_ds, dl_dt, dl_dp
        real(dp) :: Bctrvr_vartheta, Bctrvr_varphi
        real(dp) :: Bcovar_r, Bcovar_vartheta, Bcovar_varphi
        real(dp) :: Bcovar_vartheta_B, Bcovar_varphi_B
        real(dp) :: denomjac, G00, Gbeg, aper
        real(dp) :: per_theta, per_phi, gridcellnum
        real(dp), allocatable :: wint_t(:), wint_p(:), theta_V(:), theta_B(:)
        real(dp), allocatable :: phi_V(:), phi_B(:), aiota_arr(:), rho_tor(:)
        real(dp), allocatable :: Bcovar_theta_V(:, :), Bcovar_varphi_V(:, :)
        real(dp), allocatable :: bmod_Vg(:, :), alam_2D(:, :)
        real(dp), allocatable :: sqrt_g_ss(:, :)
        real(dp), allocatable :: deltheta_BV_Vg(:, :), delphi_BV_Vg(:, :)
        real(dp), allocatable :: splcoe_t(:, :)
        real(dp), allocatable :: splcoe_p(:, :), coef(:, :)
        real(dp), allocatable :: perqua_t(:, :), perqua_p(:, :)
        real(dp), allocatable :: perqua_2D(:, :, :), Gfunc(:, :, :)
        real(dp), allocatable :: Bcovar_symfl(:, :, :, :)

        ! sqrt(g^ss) is perqua quantity 7, built only for use_B_r callers; SIMPLE
        ! drops it so its one-time field setup carries no unused metric grid.
        nqua = 6
        if (use_B_r) nqua = 7
        gridcellnum = real((n_theta_B - 1)*(n_phi_B - 1), dp)

        npoilag = ns_tp_B + 1
        nder = 0
        nshift = npoilag/2

        print *, 'Transforming to Boozer coordinates'

        if (use_B_r) then
            print *, 'B_r is computed'
        else
            print *, 'B_r is not computed'
        end if

        G00 = 0.0_dp

        allocate (rho_tor(ns_B))
        allocate (aiota_arr(1))
        allocate (Gfunc(1, 1, 1))
        allocate (Bcovar_symfl(1, 1, 1, 1))
        if (use_B_r) then
            deallocate (aiota_arr, Gfunc, Bcovar_symfl)
            allocate (aiota_arr(ns_B))
            allocate (Gfunc(ns_B, n_theta_B, n_phi_B))
            allocate (Bcovar_symfl(3, ns_B, n_theta_B, n_phi_B))
        end if

        allocate (Bcovar_theta_V(n_theta_B, n_phi_B))
        allocate (Bcovar_varphi_V(n_theta_B, n_phi_B))
        allocate (bmod_Vg(n_theta_B, n_phi_B))
        allocate (alam_2D(n_theta_B, n_phi_B))
        if (use_B_r) allocate (sqrt_g_ss(n_theta_B, n_phi_B))
        allocate (deltheta_BV_Vg(n_theta_B, n_phi_B))
        allocate (delphi_BV_Vg(n_theta_B, n_phi_B))
        allocate (wint_t(0:ns_tp_B), wint_p(0:ns_tp_B))
        allocate (coef(0:nder, npoilag))
        allocate (theta_V(2 - n_theta_B:2*n_theta_B - 1))
        allocate (theta_B(2 - n_theta_B:2*n_theta_B - 1))
        allocate (phi_V(2 - n_phi_B:2*n_phi_B - 1))
        allocate (phi_B(2 - n_phi_B:2*n_phi_B - 1))
        allocate (perqua_t(nqua, 2 - n_theta_B:2*n_theta_B - 1))
        allocate (perqua_p(nqua, 2 - n_phi_B:2*n_phi_B - 1))
        allocate (perqua_2D(nqua, n_theta_B, n_phi_B))

        allocate (splcoe_t(0:ns_tp_B, n_theta_B))
        allocate (splcoe_p(0:ns_tp_B, n_phi_B))

! allocate data arrays for Boozer data:
        if (.not. allocated(s_Bcovar_tp_B)) &
            allocate (s_Bcovar_tp_B(2, ns_s_B + 1, ns_B))

        ! Allocate module-level grids
        call ensure_grid_3d(bmod_grid, ns_B, n_theta_B, n_phi_B)
        if (use_B_r) call ensure_grid_3d(sqrt_g_ss_grid, ns_B, n_theta_B, n_phi_B)
        if (use_B_r) call ensure_grid_3d(br_grid, ns_B, n_theta_B, n_phi_B)
        call ensure_grid_4d(delt_delp_V_grid, ns_B, n_theta_B, n_phi_B, 2)
        if (use_del_tp_B) call ensure_grid_4d(delt_delp_B_grid, ns_B, n_theta_B, &
                                              n_phi_B, 2)

        do i = 0, ns_tp_B
            wint_t(i) = h_theta_B**(i + 1)/real(i + 1, dp)
            wint_p(i) = h_phi_B**(i + 1)/real(i + 1, dp)
        end do

        ! Set theta_V and phi_V linear, with value 0 at index 1 and stepsize h.
        ! Then expand this in both directions beyond 1:n_theta_B.
        do i_theta = 1, n_theta_B
            theta_V(i_theta) = real(i_theta - 1, dp)*h_theta_B
        end do
        per_theta = real(n_theta_B - 1, dp)*h_theta_B
        theta_V(2 - n_theta_B:0) = theta_V(1:n_theta_B - 1) - per_theta
        theta_V(n_theta_B + 1:2*n_theta_B - 1) = theta_V(2:n_theta_B) + per_theta

        do i_phi = 1, n_phi_B
            phi_V(i_phi) = real(i_phi - 1, dp)*h_phi_B
        end do
        per_phi = real(n_phi_B - 1, dp)*h_phi_B
        phi_V(2 - n_phi_B:0) = phi_V(1:n_phi_B - 1) - per_phi
        phi_V(n_phi_B + 1:2*n_phi_B - 1) = phi_V(2:n_phi_B) + per_phi

        do i_rho = 1, ns_B
            rho_tor(i_rho) = max(real(i_rho - 1, dp)*hs_B, rho_min)
            s = rho_tor(i_rho)**2

            do i_theta = 1, n_theta_B
                theta = real(i_theta - 1, dp)*h_theta_B
                do i_phi = 1, n_phi_B
                    varphi = real(i_phi - 1, dp)*h_phi_B

                    call vmec_field_evaluate(s, theta, varphi, &
                                             A_theta, A_phi, dA_theta_ds, &
                                             dA_phi_ds, aiota, &
                                             sqg, alam, dl_ds, &
                                             dl_dt, dl_dp, &
                                             Bctrvr_vartheta, &
                                             Bctrvr_varphi, &
                                             Bcovar_r, Bcovar_vartheta, &
                                             Bcovar_varphi)

                    alam_2D(i_theta, i_phi) = alam
                    bmod_Vg(i_theta, i_phi) = &
                        sqrt(Bctrvr_vartheta*Bcovar_vartheta &
                             + Bctrvr_varphi*Bcovar_varphi)
                    Bcovar_theta_V(i_theta, i_phi) = Bcovar_vartheta*(1.0_dp + dl_dt)
                    Bcovar_varphi_V(i_theta, i_phi) = &
                        Bcovar_varphi + Bcovar_vartheta*dl_dp
                    if (use_B_r) sqrt_g_ss(i_theta, i_phi) = &
                        get_sqrt_g_ss_contravariant(s, theta, varphi)

                    perqua_2D(4, i_theta, i_phi) = Bcovar_r
                    perqua_2D(5, i_theta, i_phi) = Bcovar_vartheta
                    perqua_2D(6, i_theta, i_phi) = Bcovar_varphi
                end do
            end do

! covariant components $B_\vartheta$ and $B_\varphi$ of Boozer coordinates:
            Bcovar_vartheta_B = sum(Bcovar_theta_V(2:n_theta_B, 2:n_phi_B))/gridcellnum
            Bcovar_varphi_B = sum(Bcovar_varphi_V(2:n_theta_B, 2:n_phi_B))/gridcellnum
            s_Bcovar_tp_B(1, 1, i_rho) = Bcovar_vartheta_B
            s_Bcovar_tp_B(2, 1, i_rho) = Bcovar_varphi_B

            denomjac = 1.0_dp/(aiota*Bcovar_vartheta_B + Bcovar_varphi_B)
            Gbeg = G00 + Bcovar_vartheta_B*denomjac*alam_2D(1, 1)

            splcoe_t(0, :) = Bcovar_theta_V(:, 1)

            call spl_per(ns_tp_B, n_theta_B, h_theta_B, splcoe_t)

            delphi_BV_Vg(1, 1) = 0.0_dp
            do i_theta = 1, n_theta_B - 1
                delphi_BV_Vg(i_theta + 1, 1) = &
                    delphi_BV_Vg(i_theta, 1) &
                    + sum(wint_t*splcoe_t(:, i_theta))
            end do
            ! Remove linear increasing component from delphi_BV_Vg
            aper = (delphi_BV_Vg(n_theta_B, 1) &
                    - delphi_BV_Vg(1, 1))/real(n_theta_B - 1, dp)
            do i_theta = 2, n_theta_B
                delphi_BV_Vg(i_theta, 1) = &
                    delphi_BV_Vg(i_theta, 1) - aper*real(i_theta - 1, dp)
            end do

            do i_theta = 1, n_theta_B
                splcoe_p(0, :) = Bcovar_varphi_V(i_theta, :)

                call spl_per(ns_tp_B, n_phi_B, h_phi_B, splcoe_p)

                do i_phi = 1, n_phi_B - 1
                    delphi_BV_Vg(i_theta, i_phi + 1) = &
                        delphi_BV_Vg(i_theta, i_phi) &
                        + sum(wint_p*splcoe_p(:, i_phi))
                end do
                aper = (delphi_BV_Vg(i_theta, n_phi_B) &
                        - delphi_BV_Vg(i_theta, 1))/real(n_phi_B - 1, dp)
                do i_phi = 2, n_phi_B
                    delphi_BV_Vg(i_theta, i_phi) = &
                        delphi_BV_Vg(i_theta, i_phi) &
                        - aper*real(i_phi - 1, dp)
                end do
            end do

! difference between Boozer and VMEC toroidal angle,
! $\Delta \varphi_{BV}=\varphi_B-\varphi=G$:
            delphi_BV_Vg = denomjac*delphi_BV_Vg + Gbeg
! difference between Boozer and VMEC poloidal angle,
! $\Delta \vartheta_{BV}=\vartheta_B-\theta$:
            deltheta_BV_Vg = aiota*delphi_BV_Vg + alam_2D

            delt_delp_V_grid(i_rho, :, :, 1) = deltheta_BV_Vg
            delt_delp_V_grid(i_rho, :, :, 2) = delphi_BV_Vg

! At this point, all quantities are specified on
! equidistant grid in VMEC angles $(\theta,\varphi)$

! Re-interpolate to equidistant grid in $(\vartheta_B,\varphi)$:

            do i_phi = 1, n_phi_B
                perqua_t(1, 1:n_theta_B) = deltheta_BV_Vg(:, i_phi)
                perqua_t(2, 1:n_theta_B) = delphi_BV_Vg(:, i_phi)
                perqua_t(3, 1:n_theta_B) = bmod_Vg(:, i_phi)
                perqua_t(4:6, 1:n_theta_B) = perqua_2D(4:6, :, i_phi)
                if (use_B_r) perqua_t(7, 1:n_theta_B) = sqrt_g_ss(:, i_phi)
                ! Extend range of theta values
                perqua_t(:, 2 - n_theta_B:0) = perqua_t(:, 1:n_theta_B - 1)
                perqua_t(:, n_theta_B + 1:2*n_theta_B - 1) = perqua_t(:, 2:n_theta_B)
                theta_B = theta_V + perqua_t(1, :)
                do i_theta = 1, n_theta_B

                    call binsrc(theta_B, 2 - n_theta_B, 2*n_theta_B - 1, &
                                theta_V(i_theta), i)

                    ibeg = i - nshift
                    iend = ibeg + ns_tp_B

                    call plag_coeff(npoilag, nder, theta_V(i_theta), &
                                    theta_B(ibeg:iend), coef)

                    perqua_2D(:, i_theta, i_phi) = matmul(perqua_t(:, ibeg:iend), &
                                                          coef(0, :))
                end do
            end do

! End re-interpolate to equidistant grid in $(\vartheta_B,\varphi)$

! Re-interpolate to equidistant grid in $(\vartheta_B,\varphi_B)$:

            do i_theta = 1, n_theta_B
                perqua_p(:, 1:n_phi_B) = perqua_2D(:, i_theta, :)
                perqua_p(:, 2 - n_phi_B:0) = perqua_p(:, 1:n_phi_B - 1)
                ! Extend range of phi values
                perqua_p(:, n_phi_B + 1:2*n_phi_B - 1) = perqua_p(:, 2:n_phi_B)
                phi_B = phi_V + perqua_p(2, :)
                do i_phi = 1, n_phi_B

                    call binsrc(phi_B, 2 - n_phi_B, 2*n_phi_B - 1, phi_V(i_phi), i)

                    ibeg = i - nshift
                    iend = ibeg + ns_tp_B

                    call plag_coeff(npoilag, nder, phi_V(i_phi), phi_B(ibeg:iend), coef)

                    perqua_2D(:, i_theta, i_phi) = matmul(perqua_p(:, ibeg:iend), &
                                                          coef(0, :))
                end do
            end do

            if (use_del_tp_B) then
                delt_delp_B_grid(i_rho, :, :, 1) = perqua_2D(1, :, :)
                delt_delp_B_grid(i_rho, :, :, 2) = perqua_2D(2, :, :)
            end if
            bmod_grid(i_rho, :, :) = perqua_2D(3, :, :)
            if (use_B_r) sqrt_g_ss_grid(i_rho, :, :) = perqua_2D(7, :, :)

! End re-interpolate to equidistant grid in $(\vartheta_B,\varphi_B)$

            if (use_B_r) then
                aiota_arr(i_rho) = aiota
                Gfunc(i_rho, :, :) = perqua_2D(2, :, :)
! covariant components $B_k$ in symmetry flux coordinates on equidistant grid of
! Boozer coordinates:
                Bcovar_symfl(:, i_rho, :, :) = perqua_2D(4:6, :, :)
            end if

        end do

        if (use_B_r) then
            call compute_br_from_symflux(rho_tor, aiota_arr, Gfunc, Bcovar_symfl)
            deallocate (aiota_arr, Gfunc, Bcovar_symfl)
        end if

        if (use_B_r) deallocate (sqrt_g_ss)
        deallocate (Bcovar_theta_V, Bcovar_varphi_V, bmod_Vg, alam_2D, &
                    deltheta_BV_Vg, delphi_BV_Vg, &
                    wint_t, wint_p, coef, theta_V, theta_B, phi_V, phi_B, &
                    perqua_t, perqua_p, perqua_2D)

        print *, 'done'

    end subroutine compute_boozer_data

    !> Original VMEC field evaluation using global splines (boozer_converter interface)
    subroutine vmec_field_evaluate(s, theta, varphi, &
                                   A_theta, A_phi, dA_theta_ds, dA_phi_ds, aiota, &
                                   sqg, alam, dl_ds, dl_dt, dl_dp, &
                                   Bctrvr_vartheta, Bctrvr_varphi, &
                                   Bcovar_r, Bcovar_vartheta, Bcovar_varphi)
        use spline_vmec_sub, only: vmec_field
        real(dp), intent(in) :: s, theta, varphi
        real(dp), intent(out) :: A_theta, A_phi, dA_theta_ds, dA_phi_ds
        real(dp), intent(out) :: aiota, sqg, alam
        real(dp), intent(out) :: dl_ds, dl_dt, dl_dp
        real(dp), intent(out) :: Bctrvr_vartheta, Bctrvr_varphi
        real(dp), intent(out) :: Bcovar_r, Bcovar_vartheta, Bcovar_varphi

        ! Call the existing VMEC routine
        call vmec_field(s, theta, varphi, &
                        A_theta, A_phi, dA_theta_ds, dA_phi_ds, aiota, &
                        sqg, alam, dl_ds, dl_dt, dl_dp, &
                        Bctrvr_vartheta, Bctrvr_varphi, &
                        Bcovar_r, Bcovar_vartheta, Bcovar_varphi)
    end subroutine vmec_field_evaluate

    !> Computes sqrt(g^{ss}) which is the same for Boozer (s, theta_B, varphi_B)
    !> and VMEC (s, theta, varphi) coordinates
    function get_sqrt_g_ss_contravariant(s, theta, varphi) result(sqrt_g_ss)
        use spline_vmec_sub, only: splint_vmec_data
        use spline_vmec_sub, only: metric_tensor_vmec
        real(dp), intent(in) :: s, theta, varphi
        real(dp) :: sqrt_g_ss

        real(dp) :: dummy(10)
        real(dp) :: R, dR_ds, dR_dtheta, dR_dphi
        real(dp) :: dZ_ds, dZ_dtheta, dZ_dphi

        real(dp) :: g_vmec(3, 3), sqrt_g_vmec

        call splint_vmec_data(s, theta, varphi, &
                              dummy(1), dummy(2), dummy(3), dummy(4), dummy(5), &
                              R, &
                              dummy(6), dummy(7), &
                              dR_ds, dR_dtheta, dR_dphi, &
                              dZ_ds, dZ_dtheta, dZ_dphi, &
                              dummy(8), dummy(9), dummy(10))
        call metric_tensor_vmec(R, dR_ds, dR_dtheta, dR_dphi, &
                                dZ_ds, dZ_dtheta, dZ_dphi, g_vmec, sqrt_g_vmec)

        !> contravariant metric component g^{ss} via cofactors of covariant components
        sqrt_g_ss = sqrt(g_vmec(2, 2)*g_vmec(3, 3) - g_vmec(2, 3)**2) &
                    /abs(sqrt_g_vmec)
    end function get_sqrt_g_ss_contravariant

    !> Compute radial covariant magnetic field B_rho from symmetry flux coordinates
    subroutine compute_br_from_symflux(rho_tor, aiota_arr, Gfunc, Bcovar_symfl)
        use boozer_coordinates_mod, only: ns_B, n_theta_B, n_phi_B
        use plag_coeff_sub, only: plag_coeff

        real(dp), intent(in) :: rho_tor(:)
        real(dp), intent(in) :: aiota_arr(:)
        real(dp), intent(in) :: Gfunc(:, :, :)
        real(dp), intent(in) :: Bcovar_symfl(:, :, :, :)

        integer, parameter :: NPOILAG = 5
        integer, parameter :: NDER = 1

        integer :: i_rho, i_phi, ibeg, iend, nshift
        real(dp) :: coef(0:NDER, NPOILAG)

        nshift = NPOILAG/2

        do i_rho = 1, ns_B
            ibeg = i_rho - nshift
            iend = ibeg + NPOILAG - 1
            if (ibeg < 1) then
                ibeg = 1
                iend = ibeg + NPOILAG - 1
            else if (iend > ns_B) then
                iend = ns_B
                ibeg = iend - NPOILAG + 1
            end if

            call plag_coeff(NPOILAG, NDER, rho_tor(i_rho), rho_tor(ibeg:iend), coef)

            ! Compute B_rho (we spline covariant component B_rho instead of B_s)
            do i_phi = 1, n_phi_B
                br_grid(i_rho, :, i_phi) = &
                    2.0_dp*rho_tor(i_rho)*Bcovar_symfl(1, i_rho, :, i_phi) &
                    - matmul(coef(1, :)*aiota_arr(ibeg:iend), Gfunc(ibeg:iend, &
                                                                    :, i_phi)) &
                    *Bcovar_symfl(2, i_rho, :, i_phi) &
                    - matmul(coef(1, :), Gfunc(ibeg:iend, :, i_phi)) &
                    *Bcovar_symfl(3, i_rho, :, i_phi)
            end do
        end do

    end subroutine compute_br_from_symflux

    !> Ensure 3D grid is allocated with correct dimensions
    subroutine ensure_grid_3d(grid, n1, n2, n3)
        real(dp), allocatable, intent(inout) :: grid(:, :, :)
        integer, intent(in) :: n1, n2, n3

        if (.not. allocated(grid)) then
            allocate (grid(n1, n2, n3))
        else if (any(shape(grid) /= [n1, n2, n3])) then
            deallocate (grid)
            allocate (grid(n1, n2, n3))
        end if
    end subroutine ensure_grid_3d

    !> Ensure 4D grid is allocated with correct dimensions
    subroutine ensure_grid_4d(grid, n1, n2, n3, n4)
        real(dp), allocatable, intent(inout) :: grid(:, :, :, :)
        integer, intent(in) :: n1, n2, n3, n4

        if (.not. allocated(grid)) then
            allocate (grid(n1, n2, n3, n4))
        else if (any(shape(grid) /= [n1, n2, n3, n4])) then
            deallocate (grid)
            allocate (grid(n1, n2, n3, n4))
        end if
    end subroutine ensure_grid_4d

    subroutine reset_boozer_batch_splines
        use boozer_rk_tables, only: rk_field_table, rk_profile_table, &
            rk_num_points, rk_x_min, rk_h_step, rk_inv_h_step, rk_period, &
            rk_inv_period, rk_tables_ready

        if (allocated(rk_field_table)) then
            !$acc exit data delete(rk_field_table)
            deallocate (rk_field_table)
        end if
        if (allocated(rk_profile_table)) then
            !$acc exit data delete(rk_profile_table)
            deallocate (rk_profile_table)
        end if
        rk_tables_ready = .false.
        rk_num_points = 0
        rk_x_min = 0.0_dp
        rk_h_step = 0.0_dp
        rk_inv_h_step = 0.0_dp
        rk_period = 0.0_dp
        rk_inv_period = 0.0_dp
        !$acc update device(rk_num_points, rk_x_min, rk_h_step, &
        !$acc& rk_inv_h_step, rk_period, rk_inv_period, rk_tables_ready)
        if (aphi_batch_spline_ready) then
            call destroy_batch_splines_1d(aphi_batch_spline)
            aphi_batch_spline_ready = .false.
        end if
        if (bcovar_tp_batch_spline_ready) then
            call destroy_batch_splines_1d(bcovar_tp_batch_spline)
            bcovar_tp_batch_spline_ready = .false.
        end if
        if (field3d_batch_spline_ready) then
            call destroy_batch_splines_3d(field3d_batch_spline)
            field3d_batch_spline_ready = .false.
            field3d_num_quantities = 0
        end if
        if (allocated(bmod_grid)) deallocate (bmod_grid)
        if (allocated(sqrt_g_ss_grid)) deallocate (sqrt_g_ss_grid)
        if (allocated(br_grid)) deallocate (br_grid)
        if (delt_delp_V_batch_spline_ready) then
            call destroy_batch_splines_3d(delt_delp_V_batch_spline)
            delt_delp_V_batch_spline_ready = .false.
        end if
        if (allocated(delt_delp_V_grid)) deallocate (delt_delp_V_grid)
        if (delt_delp_B_batch_spline_ready) then
            call destroy_batch_splines_3d(delt_delp_B_batch_spline)
            delt_delp_B_batch_spline_ready = .false.
        end if
        if (allocated(delt_delp_B_grid)) deallocate (delt_delp_B_grid)
    end subroutine reset_boozer_batch_splines

    subroutine build_boozer_aphi_batch_spline
        use vector_potentail_mod, only: ns, hs, sA_phi
        use new_vmec_stuff_mod, only: ns_A

        integer :: order

        if (aphi_batch_spline_ready) then
            call destroy_batch_splines_1d(aphi_batch_spline)
            aphi_batch_spline_ready = .false.
        end if

        order = ns_A
        if (order < 3 .or. order > 5) then
            error stop "build_boozer_aphi_batch_spline: spline order must be 3..5"
        end if

        aphi_batch_spline%order = order
        aphi_batch_spline%num_points = ns
        aphi_batch_spline%periodic = .false.
        aphi_batch_spline%x_min = 0.0_dp
        aphi_batch_spline%h_step = hs
        aphi_batch_spline%num_quantities = 1

        allocate (aphi_batch_spline%coeff(1, 0:order, ns))
        aphi_batch_spline%coeff(1, 0:order, :) = sA_phi(1:order + 1, :)

        aphi_batch_spline_ready = .true.
    end subroutine build_boozer_aphi_batch_spline

    subroutine build_boozer_bcovar_tp_batch_spline
        use boozer_coordinates_mod, only: ns_s_B, ns_B, hs_B, s_Bcovar_tp_B

        integer :: order
        real(dp) :: x_min, x_max
        real(dp), allocatable :: y_batch(:, :)

        if (bcovar_tp_batch_spline_ready) then
            call destroy_batch_splines_1d(bcovar_tp_batch_spline)
            bcovar_tp_batch_spline_ready = .false.
        end if

        order = ns_s_B
        if (order < 3 .or. order > 5) then
            error stop "build_boozer_bcovar_tp_batch_spline: spline order must be 3..5"
        end if

        x_min = 0.0_dp
        x_max = hs_B*real(ns_B - 1, dp)

        allocate (y_batch(ns_B, 2))
        y_batch(:, 1) = s_Bcovar_tp_B(1, 1, :)
        y_batch(:, 2) = s_Bcovar_tp_B(2, 1, :)

        call construct_batch_splines_1d(x_min, x_max, y_batch, order, .false., &
                                        bcovar_tp_batch_spline)
        bcovar_tp_batch_spline_ready = .true.
        deallocate (y_batch)
    end subroutine build_boozer_bcovar_tp_batch_spline

    subroutine build_boozer_field3d_batch_spline
        ! Combined 3D field batch spline: Bmod, sqrt_g_ss, optionally Br
        use boozer_coordinates_mod, only: ns_s_B, ns_tp_B, ns_B, n_theta_B, n_phi_B, &
                                          hs_B, h_theta_B, h_phi_B, use_B_r

        real(dp) :: x_min(3), x_max(3)
        real(dp), allocatable :: y_batch(:, :, :, :)
        integer :: order(3), nq, i_br, i_sqrt_g_ss
        logical :: periodic(3)

        if (.not. allocated(bmod_grid)) then
            error stop "build_boozer_field3d_batch_spline: bmod_grid not allocated"
        end if
        if (use_B_r .and. .not. allocated(sqrt_g_ss_grid)) then
            error stop "build_boozer_field3d_batch_spline: sqrt_g_ss_grid not allocated"
        end if
        if (use_B_r .and. .not. allocated(br_grid)) then
            error stop "build_boozer_field3d_batch_spline: br_grid not allocated"
        end if

        if (field3d_batch_spline_ready) then
            call destroy_batch_splines_3d(field3d_batch_spline)
            field3d_batch_spline_ready = .false.
            field3d_num_quantities = 0
        end if

        order = [ns_s_B, ns_tp_B, ns_tp_B]
        if (any(order < 3) .or. any(order > 5)) then
            error stop "build_boozer_field3d_batch_spline: spline order must be 3..5"
        end if

        x_min = [0.0_dp, 0.0_dp, 0.0_dp]
        x_max(1) = hs_B*real(ns_B - 1, dp)
        x_max(2) = h_theta_B*real(n_theta_B - 1, dp)
        x_max(3) = h_phi_B*real(n_phi_B - 1, dp)

        periodic = [.false., .true., .true.]

        ! sqrt_g_ss and B_r are only consumed by use_B_r callers (e.g. RABE's
        ! nabla_s). SIMPLE leaves use_B_r off and gets the lean single-quantity
        ! Bmod spline, so its hot field eval stays at the pre-extraction cost.
        nq = 1  ! Bmod
        if (use_B_r) then
            nq = nq + 1
            i_sqrt_g_ss = nq
            nq = nq + 1
            i_br = nq
        end if

        allocate (y_batch(ns_B, n_theta_B, n_phi_B, nq))
        y_batch(:, :, :, 1) = bmod_grid(:, :, :)
        if (use_B_r) then
            y_batch(:, :, :, i_sqrt_g_ss) = sqrt_g_ss_grid(:, :, :)
            y_batch(:, :, :, i_br) = br_grid(:, :, :)
        end if

        call construct_batch_splines_3d(x_min, x_max, y_batch, order, periodic, &
                                        field3d_batch_spline)
        field3d_batch_spline_ready = .true.
        field3d_num_quantities = nq
        deallocate (y_batch)
    end subroutine build_boozer_field3d_batch_spline

    subroutine build_boozer_delt_delp_batch_splines
        ! Build angle-transform splines from the 4D grids filled in
        ! compute_boozer_data. The V grid is always built; the Boozer-angle B
        ! grid is built only when use_del_tp_B is set.
        use boozer_coordinates_mod, only: ns_s_B, ns_tp_B, ns_B, n_theta_B, n_phi_B, &
                                          hs_B, h_theta_B, h_phi_B, use_del_tp_B

        integer :: order(3)
        real(dp) :: x_min(3), x_max(3)
        logical :: periodic(3)
        real(dp), allocatable :: y_batch(:, :, :, :)

        if (.not. allocated(delt_delp_V_grid)) then
            error stop &
                "build_boozer_delt_delp_batch_splines: delt_delp_V_grid not allocated"
        end if

        if (delt_delp_V_batch_spline_ready) then
            call destroy_batch_splines_3d(delt_delp_V_batch_spline)
            delt_delp_V_batch_spline_ready = .false.
        end if

        order = [ns_s_B, ns_tp_B, ns_tp_B]
        if (any(order < 3) .or. any(order > 5)) then
            error stop "build_boozer_delt_delp_batch_splines: order must be 3..5"
        end if

        x_min = [0.0_dp, 0.0_dp, 0.0_dp]
        x_max(1) = hs_B*real(ns_B - 1, dp)
        x_max(2) = h_theta_B*real(n_theta_B - 1, dp)
        x_max(3) = h_phi_B*real(n_phi_B - 1, dp)

        periodic = [.false., .true., .true.]

        allocate (y_batch(ns_B, n_theta_B, n_phi_B, 2))
        y_batch(:, :, :, 1) = delt_delp_V_grid(:, :, :, 1)
        y_batch(:, :, :, 2) = delt_delp_V_grid(:, :, :, 2)

        call construct_batch_splines_3d(x_min, x_max, y_batch, order, periodic, &
                                        delt_delp_V_batch_spline)
        delt_delp_V_batch_spline_ready = .true.

        if (use_del_tp_B) then
            if (.not. allocated(delt_delp_B_grid)) then
                error stop &
            "build_boozer_delt_delp_batch_splines: delt_delp_B_grid not allocated"
            end if

            if (delt_delp_B_batch_spline_ready) then
                call destroy_batch_splines_3d(delt_delp_B_batch_spline)
                delt_delp_B_batch_spline_ready = .false.
            end if

            y_batch(:, :, :, 1) = delt_delp_B_grid(:, :, :, 1)
            y_batch(:, :, :, 2) = delt_delp_B_grid(:, :, :, 2)

            call construct_batch_splines_3d(x_min, x_max, y_batch, order, periodic, &
                                            delt_delp_B_batch_spline)
            delt_delp_B_batch_spline_ready = .true.
        end if

        deallocate (y_batch)
    end subroutine build_boozer_delt_delp_batch_splines

    subroutine build_boozer_from_chartmap(d, radial_spline_order, &
            angular_spline_order, rk_only)
        !> Populate the module-level Boozer batch splines from an already-parsed
        !> chartmap record, bypassing the VMEC-based compute_boozer_data path.
        use vector_potentail_mod, only: torflux, ns, hs
        use new_vmec_stuff_mod, only: nper, rmajor, ns_A, vmec_B_scale, vmec_RZ_scale
        use boozer_coordinates_mod, only: ns_s_B, ns_tp_B, ns_B, n_theta_B, &
                                          n_phi_B, hs_B, h_theta_B, h_phi_B, &
                                          use_B_r, use_del_tp_B
        use boozer_chartmap_types, only: boozer_chartmap_data_t
        use boozer_rk_tables, only: rk_field_table, rk_profile_table, &
            rk_num_points, rk_x_min, rk_h_step, rk_inv_h_step, rk_period, &
            rk_inv_period, rk_tables_ready

        type(boozer_chartmap_data_t), intent(inout) :: d
        integer, intent(in), optional :: radial_spline_order, angular_spline_order
        logical, intent(in), optional :: rk_only
        real(dp), allocatable :: y_aphi(:, :), y_bcovar(:, :), y_bmod(:, :, :, :)
        real(dp) :: s_min, s_max
        real(dp) :: b_scale, rz_scale, covar_scale, flux_scale
        integer :: spline_order, field_radial_order, field_angular_order
        integer :: i_s, i_theta, i_phi, iq, table_index
        integer :: order_3d(3)
        logical :: periodic_3d(3), compact_only
        real(dp) :: x_min_3d(3), x_max_3d(3)

        call reset_boozer_batch_splines

        compact_only = .false.
        if (present(rk_only)) compact_only = rk_only
        if (compact_only .and. .not. d%has_rk_tables) &
            error stop 'RK-only chartmap loading requires compact RK tables'

        field_radial_order = 5
        field_angular_order = 5
        if (present(radial_spline_order)) field_radial_order = radial_spline_order
        if (present(angular_spline_order)) field_angular_order = angular_spline_order
        if (field_radial_order < 3 .or. field_radial_order > 5 .or. &
                field_angular_order < 3 .or. field_angular_order > 5) then
            error stop 'Boozer chartmap spline orders must be between 3 and 5'
        end if

        ! Apply the VMEC scaling knobs so a chartmap behaves like a VMEC run
        ! (matches boozer_chartmap_field_t and test_chartmap_scaling). Base files
        ! are exported at scale 1, so this is a no-op by default. A_theta scales
        ! with the toroidal flux below.
        b_scale = vmec_B_scale
        rz_scale = vmec_RZ_scale
        covar_scale = b_scale*rz_scale
        flux_scale = covar_scale*rz_scale
        d%A_phi = flux_scale*d%A_phi
        d%B_theta = covar_scale*d%B_theta
        d%B_phi = covar_scale*d%B_phi
        d%Bmod = b_scale*d%Bmod
        if (d%has_rk_tables) then
            d%rk_field = b_scale*d%rk_field
            d%rk_profiles(:, 1:2) = flux_scale*d%rk_profiles(:, 1:2)
            d%rk_profiles(:, 3:6) = covar_scale*d%rk_profiles(:, 3:6)
        end if

        ! Set global parameters used by splint_boozer_coord.
        torflux = flux_scale*d%torflux
        nper = d%nfp
        rmajor = d%rmajor*rz_scale

        ! Set boozer_coordinates_mod parameters
        ns_s_B = field_radial_order
        ns_tp_B = field_angular_order
        ns_B = d%n_rho
        n_theta_B = d%n_theta
        n_phi_B = d%n_phi
        hs_B = d%rho(2) - d%rho(1)
        h_theta_B = d%h_theta
        h_phi_B = d%h_phi
        use_B_r = .false.
        use_del_tp_B = .false.

        ! Set vector_potentail_mod parameters for A_phi spline
        ns = d%n_s
        s_min = d%s(1)
        s_max = d%s(d%n_s)
        hs = (s_max - s_min)/real(ns - 1, dp)
        ns_A = field_radial_order

        if (.not. compact_only) then
        spline_order = ns_A
        allocate (y_aphi(ns, 1))
        y_aphi(:, 1) = d%A_phi
            call construct_batch_splines_1d(s_min, s_max, y_aphi, spline_order, &
                .false., aphi_batch_spline)
        aphi_batch_spline_ready = .true.
        deallocate (y_aphi)

        ! Build B_theta, B_phi batch spline over rho_tor
        spline_order = ns_s_B
        allocate (y_bcovar(d%n_rho, 2))
        y_bcovar(:, 1) = d%B_theta
        y_bcovar(:, 2) = d%B_phi
        call construct_batch_splines_1d(d%rho(1), d%rho(d%n_rho), y_bcovar, &
                spline_order, .false., &
                bcovar_tp_batch_spline)
        bcovar_tp_batch_spline_ready = .true.
        deallocate (y_bcovar)

        ! Build the 3D field batch spline over (rho_tor, theta_B, phi_B). The
        ! reader appended exact endpoint planes for the periodic spline. The
        ! chartmap stores Bmod only and leaves use_B_r off, so the field spline
        ! carries the single Bmod quantity.
        order_3d = [ns_s_B, ns_tp_B, ns_tp_B]
        periodic_3d = [.false., .true., .true.]
        x_min_3d = [d%rho(1), 0.0_dp, 0.0_dp]
        x_max_3d = [d%rho(d%n_rho), h_theta_B*real(d%n_theta - 1, dp), &
                    h_phi_B*real(d%n_phi - 1, dp)]

        allocate (y_bmod(d%n_rho, d%n_theta, d%n_phi, 1))
        y_bmod(:, :, :, 1) = d%Bmod
        call construct_batch_splines_3d(x_min_3d, x_max_3d, y_bmod, order_3d, &
                                        periodic_3d, field3d_batch_spline)
        field3d_batch_spline_ready = .true.
        field3d_num_quantities = 1
        deallocate (y_bmod)
        end if

        if (d%has_rk_tables) then
            allocate (rk_field_table(2*d%n_s*d%n_theta*d%n_phi))
            allocate (rk_profile_table(6*d%n_s))
            do i_phi = 1, d%n_phi
                do i_theta = 1, d%n_theta
                    do i_s = 1, d%n_s
                        do iq = 1, 2
                            table_index = iq + 2*((i_s - 1) + d%n_s* &
                                ((i_theta - 1) + d%n_theta*(i_phi - 1)))
                            rk_field_table(table_index) = &
                                d%rk_field(i_s, i_theta, i_phi, iq)
                        end do
                    end do
                end do
            end do
            do i_s = 1, d%n_s
                do iq = 1, 6
                    table_index = iq + 6*(i_s - 1)
                    rk_profile_table(table_index) = d%rk_profiles(i_s, iq)
                end do
            end do
            rk_num_points = [d%n_s, d%n_theta, d%n_phi]
            rk_x_min = [d%s(1), 0.0_dp, 0.0_dp]
            rk_h_step = [hs, h_theta_B, h_phi_B]
            rk_inv_h_step = 1.0_dp/rk_h_step
            rk_period = rk_h_step*real(rk_num_points - 1, dp)
            rk_inv_period = 1.0_dp/rk_period
            !$acc update device(rk_num_points, rk_x_min, rk_h_step, &
            !$acc& rk_inv_h_step, rk_period, rk_inv_period)
            !$acc enter data copyin(rk_field_table, rk_profile_table)
            rk_tables_ready = .true.
            !$acc update device(rk_tables_ready)
        end if

        call sync_boozer_state

        print *, '  nfp=', d%nfp, ' ns=', d%n_rho, ' ntheta_spline=', &
            d%n_theta, ' nphi_spline=', d%n_phi
        print *, '  torflux=', torflux
        print *, '  native canonical RK tables=', rk_tables_ready
        print *, '  compact RK-only load=', compact_only
        print *, '  Boozer spline orders=', ns_s_B, ns_tp_B
    end subroutine build_boozer_from_chartmap


end module boozer_sub
