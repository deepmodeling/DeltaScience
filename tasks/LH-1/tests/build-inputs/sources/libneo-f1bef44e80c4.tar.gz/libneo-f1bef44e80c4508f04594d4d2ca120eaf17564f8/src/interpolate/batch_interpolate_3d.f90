module batch_interpolate_3d
    use, intrinsic :: iso_fortran_env, only: dp => real64
    use batch_interpolate_types, only: BatchSplineData3D
    use spline_build_lines, only: spl_build_line_inplace, &
                                  spl_three_per_line, spl_three_reg_line, &
                                  spl_four_per_line, spl_four_reg_line, &
                                  spl_five_per_line, spl_five_reg_line
    use spl_three_to_five_sub, only: spl_per, spl_reg
#ifdef _OPENACC
    use openacc, only: acc_is_present
#endif

    implicit none
    private

    ! Maximum sizes for work arrays to avoid heap allocation in hot loops
    integer, parameter :: MAX_QUANTITIES = 8
    integer, parameter :: MAX_ORDER = 8

    ! Export batch spline construction/destruction routines
    public :: construct_batch_splines_3d
    public :: construct_batch_splines_3d_lines
    public :: construct_batch_splines_3d_resident
    public :: construct_batch_splines_3d_resident_device
    public :: destroy_batch_splines_3d
    public :: destroy_batch_splines_3d_device_only

#ifdef LIBNEO_ENABLE_SPLINE_ORACLE
    public :: construct_batch_splines_3d_legacy
#endif

    ! Export batch spline evaluation routines
    public :: evaluate_batch_splines_3d
    public :: evaluate_batch_splines_3d_der
    public :: evaluate_batch_splines_3d_der2
    public :: evaluate_batch_spline_3d_scalar_cubic_der
    public :: evaluate_batch_splines_3d_der_nq1_o355
    public :: evaluate_batch_spline_3d_scalar_quintic_der
    public :: evaluate_batch_spline_3d_scalar_cubic_der2
    public :: evaluate_batch_spline_3d_scalar_cubic_der2_rmix
    public :: evaluate_batch_splines_3d_der3
    public :: evaluate_batch_splines_3d_der2_rmix
    public :: evaluate_batch_splines_3d_many
    public :: evaluate_batch_splines_3d_many_resident
    public :: evaluate_batch_splines_3d_many_der
    public :: evaluate_batch_splines_3d_many_der2
    public :: evaluate_batch_splines_3d_many_der2_mask
contains

    recursive subroutine construct_batch_splines_3d(x_min, x_max, y_batch, order, periodic, spl)
        real(dp), intent(in) :: x_min(:), x_max(:)
        real(dp), intent(in) :: y_batch(:, :, :, :)  ! (n1, n2, n3, n_quantities)
        integer, intent(in) :: order(3)
        logical, intent(in) :: periodic(3)
        type(BatchSplineData3D), intent(inout) :: spl

#ifdef _OPENACC
        ! Use GPU construction by default (3-9x faster than CPU)
        call construct_batch_splines_3d_resident_device(x_min, x_max, y_batch, &
                                                        order, periodic, spl, &
                                                        update_host=.true., &
                                                        assume_y_present=.false.)
#else
        call construct_batch_splines_3d_legacy(x_min, x_max, y_batch, order, &
                                               periodic, spl)
#endif
    end subroutine construct_batch_splines_3d

    recursive subroutine construct_batch_splines_3d_legacy(x_min, x_max, y_batch, order, &
                                                 periodic, spl)
        real(dp), intent(in) :: x_min(:), x_max(:)
        real(dp), intent(in) :: y_batch(:, :, :, :)  ! (n1, n2, n3, n_quantities)
        integer, intent(in) :: order(3)
        logical, intent(in) :: periodic(3)
        type(BatchSplineData3D), intent(inout) :: spl

        real(dp), dimension(:, :), allocatable  :: splcoe
        integer :: i1, i2, i3, iq  ! Loop indices
        integer :: k2, k3          ! Loop indices for polynomial order
        integer :: n1, n2, n3, n_quantities, istat
        integer :: N1_order, N2_order, N3_order
        logical :: needs_alloc

        n1 = size(y_batch, 1)
        n2 = size(y_batch, 2)
        n3 = size(y_batch, 3)
        n_quantities = size(y_batch, 4)
        N1_order = order(1)
        N2_order = order(2)
        N3_order = order(3)

        ! Validate input
        if (n1 < 2 .or. n2 < 2 .or. n3 < 2) then
            error stop &
                "construct_batch_splines_3d: Need at least 2 points in each dimension"
        end if
        if (n_quantities < 1) then
            error stop "construct_batch_splines_3d: Need at least 1 quantity"
        end if
        if (N1_order < 3 .or. N1_order > 5 .or. &
            N2_order < 3 .or. N2_order > 5 .or. &
            N3_order < 3 .or. N3_order > 5) then
            error stop "construct_batch_splines_3d: Orders must be between 3 and 5"
        end if

        ! Store metadata
        spl%order = order
        spl%num_points = [n1, n2, n3]
        spl%periodic = periodic
        spl%h_step = [(x_max(1) - x_min(1))/dble(n1 - 1), &
                      (x_max(2) - x_min(2))/dble(n2 - 1), &
                      (x_max(3) - x_min(3))/dble(n3 - 1)]
        spl%inv_h_step = 1.0_dp/spl%h_step
        spl%period = spl%h_step*real(spl%num_points - 1, dp)
        spl%x_min = x_min
        spl%num_quantities = n_quantities

        ! GCC OpenACC bug workaround: reuse existing allocation if possible
        needs_alloc = .true.
        if (allocated(spl%coeff)) then
            if (size(spl%coeff, 1) == n_quantities .and. &
                size(spl%coeff, 2) == N1_order + 1 .and. &
                size(spl%coeff, 3) == N2_order + 1 .and. &
                size(spl%coeff, 4) == N3_order + 1 .and. &
                size(spl%coeff, 5) == n1 .and. &
                size(spl%coeff, 6) == n2 .and. &
                size(spl%coeff, 7) == n3) then
                needs_alloc = .false.
            else
                deallocate (spl%coeff)
            end if
        end if

        ! Allocate batch coefficients with cache-friendly layout
        if (needs_alloc) then
            allocate (spl%coeff(n_quantities, 0:N1_order, 0:N2_order, 0:N3_order, &
                                n1, n2, n3), stat=istat)
            if (istat /= 0) then
                error stop "construct_batch_splines_3d: Allocation failed for coeff"
            end if
        end if

        ! Build each quantity in place, directly into spl%coeff(iq,...), so no
        ! full-size temporary coefficient array is held (it doubled peak memory:
        ! ~24 GB for the reactor chartmap and caused OOM during field loading).
        do iq = 1, n_quantities
            ! Spline over x3 first
            allocate (splcoe(0:N3_order, n3), stat=istat)
            if (istat /= 0) then
                error stop "construct_batch_splines_3d: Allocation failed for splcoe"
            end if

            do i2 = 1, n2
                do i1 = 1, n1
                    splcoe(0, :) = y_batch(i1, i2, :, iq)
                    if (periodic(3)) then
                        call spl_per(N3_order, n3, spl%h_step(3), splcoe)
                    else
                        call spl_reg(N3_order, n3, spl%h_step(3), splcoe)
                    end if
                    spl%coeff(iq, 0, 0, :, i1, i2, :) = splcoe
                end do
            end do
            deallocate (splcoe)

            ! Spline over x2 second
            allocate (splcoe(0:N2_order, n2), stat=istat)
            if (istat /= 0) then
                error stop "construct_batch_splines_3d: Allocation failed for splcoe"
            end if

            do i3 = 1, n3
                do i1 = 1, n1
                    do k3 = 0, N3_order
                        splcoe(0, :) = spl%coeff(iq, 0, 0, k3, i1, :, i3)
                        if (periodic(2)) then
                            call spl_per(N2_order, n2, spl%h_step(2), splcoe)
                        else
                            call spl_reg(N2_order, n2, spl%h_step(2), splcoe)
                        end if
                        spl%coeff(iq, 0, :, k3, i1, :, i3) = splcoe
                    end do
                end do
            end do
            deallocate (splcoe)

            ! Spline over x1 last - store in STANDARD order for consistency
            allocate (splcoe(0:N1_order, n1), stat=istat)
            if (istat /= 0) then
                error stop "construct_batch_splines_3d: Allocation failed for splcoe"
            end if

            do i3 = 1, n3
                do i2 = 1, n2
                    do k3 = 0, N3_order
                        do k2 = 0, N2_order
                            splcoe(0, :) = spl%coeff(iq, 0, k2, k3, :, i2, i3)
                            if (periodic(1)) then
                                call spl_per(N1_order, n1, spl%h_step(1), splcoe)
                            else
                                call spl_reg(N1_order, n1, spl%h_step(1), splcoe)
                            end if
                            spl%coeff(iq, :, k2, k3, :, i2, i3) = splcoe
                        end do
                    end do
                end do
            end do
            deallocate (splcoe)
        end do
    end subroutine construct_batch_splines_3d_legacy

    recursive subroutine construct_batch_splines_3d_lines(x_min, x_max, y_batch, order, &
                                                periodic, spl)
        real(dp), intent(in) :: x_min(3), x_max(3)
        real(dp), intent(in) :: y_batch(:, :, :, :)  ! (n1, n2, n3, n_quantities)
        integer, intent(in) :: order(3)
        logical, intent(in) :: periodic(3)
        type(BatchSplineData3D), intent(out) :: spl

        integer :: n1, n2, n3, n_quantities
        integer :: N1_order, N2_order, N3_order
        integer :: istat
        integer :: i1, i2, i3, iq, k1, k2, k3
        integer :: line, line2, line3
        real(dp), allocatable :: work3(:, :, :)
        real(dp), allocatable :: work2(:, :, :)
        real(dp), allocatable :: work1(:, :, :)
        real(dp) :: h1, h2, h3

        n1 = size(y_batch, 1)
        n2 = size(y_batch, 2)
        n3 = size(y_batch, 3)
        n_quantities = size(y_batch, 4)
        N1_order = order(1)
        N2_order = order(2)
        N3_order = order(3)

        if (n1 < 2 .or. n2 < 2 .or. n3 < 2) then
            error stop "construct_batch_splines_3d_lines: Need at least 2 points"
        end if
        if (n_quantities < 1) then
            error stop "construct_batch_splines_3d_lines: Need at least 1 quantity"
        end if
        if (any(order < 3) .or. any(order > 5)) then
            error stop "construct_batch_splines_3d_lines: Order must be between 3 and 5"
        end if
        if (N1_order == 3) then
            if (periodic(1) .and. n1 < 3) then
                error stop &
                    "construct_batch_splines_3d_lines: Need at least 3 points "// &
                    "for periodic order(1)=3"
            end if
        else if (N1_order == 4) then
            if (n1 < 5) then
                error stop &
                    "construct_batch_splines_3d_lines: Need at least 5 points "// &
                    "for order(1)=4"
            end if
        else
            if (n1 < 6) then
                error stop &
                    "construct_batch_splines_3d_lines: Need at least 6 points "// &
                    "for order(1)=5"
            end if
        end if
        if (N2_order == 3) then
            if (periodic(2) .and. n2 < 3) then
                error stop &
                    "construct_batch_splines_3d_lines: Need at least 3 points "// &
                    "for periodic order(2)=3"
            end if
        else if (N2_order == 4) then
            if (n2 < 5) then
                error stop &
                    "construct_batch_splines_3d_lines: Need at least 5 points "// &
                    "for order(2)=4"
            end if
        else
            if (n2 < 6) then
                error stop &
                    "construct_batch_splines_3d_lines: Need at least 6 points "// &
                    "for order(2)=5"
            end if
        end if
        if (N3_order == 3) then
            if (periodic(3) .and. n3 < 3) then
                error stop &
                    "construct_batch_splines_3d_lines: Need at least 3 points "// &
                    "for periodic order(3)=3"
            end if
        else if (N3_order == 4) then
            if (n3 < 5) then
                error stop &
                    "construct_batch_splines_3d_lines: Need at least 5 points "// &
                    "for order(3)=4"
            end if
        else
            if (n3 < 6) then
                error stop &
                    "construct_batch_splines_3d_lines: Need at least 6 points "// &
                    "for order(3)=5"
            end if
        end if

        spl%order = order
        spl%num_points = [n1, n2, n3]
        spl%periodic = periodic
        spl%h_step = [(x_max(1) - x_min(1))/dble(n1 - 1), &
                      (x_max(2) - x_min(2))/dble(n2 - 1), &
                      (x_max(3) - x_min(3))/dble(n3 - 1)]
        spl%inv_h_step = 1.0_dp/spl%h_step
        spl%period = spl%h_step*real(spl%num_points - 1, dp)
        spl%x_min = x_min
        spl%num_quantities = n_quantities

        allocate (spl%coeff(n_quantities, 0:N1_order, 0:N2_order, 0:N3_order, &
                            n1, n2, n3), stat=istat)
        if (istat /= 0) then
            error stop "construct_batch_splines_3d_lines: Allocation failed for coeff"
        end if

        allocate (work3(n3, n1*n2*n_quantities, 0:N3_order), stat=istat)
        if (istat /= 0) then
            error stop "construct_batch_splines_3d_lines: Allocation failed for work3"
        end if
        allocate (work2(n2, n1*n3*n_quantities, 0:N2_order), stat=istat)
        if (istat /= 0) then
            error stop "construct_batch_splines_3d_lines: Allocation failed for work2"
        end if
        allocate (work1(n1, n2*n3*n_quantities, 0:N1_order), stat=istat)
        if (istat /= 0) then
            error stop "construct_batch_splines_3d_lines: Allocation failed for work1"
        end if

        do iq = 1, n_quantities
            do i2 = 1, n2
                do i1 = 1, n1
                    line = i1 + (i2 - 1)*n1 + (iq - 1)*n1*n2
                    work3(:, line, 0) = y_batch(i1, i2, :, iq)
                end do
            end do
        end do

#ifdef _OPENMP
    !$omp parallel do default(none) &
    !$omp& shared(work3, n1, n2, n3, n_quantities, N3_order, periodic, spl) &
    !$omp& private(line)
#endif
        do line = 1, n1*n2*n_quantities
            if (N3_order == 3) then
                if (periodic(3)) then
                    call spl_three_per_line(n3, spl%h_step(3), work3(:, line, 0), &
                                            work3(:, line, 1), work3(:, line, 2), &
                                            work3(:, line, 3))
                else
                    call spl_three_reg_line(n3, spl%h_step(3), work3(:, line, 0), &
                                            work3(:, line, 1), work3(:, line, 2), &
                                            work3(:, line, 3))
                end if
            else if (N3_order == 4) then
                if (periodic(3)) then
                    call spl_four_per_line(n3, spl%h_step(3), work3(:, line, 0), &
                                           work3(:, line, 1), work3(:, line, 2), &
                                           work3(:, line, 3), work3(:, line, 4))
                else
                    call spl_four_reg_line(n3, spl%h_step(3), work3(:, line, 0), &
                                           work3(:, line, 1), work3(:, line, 2), &
                                           work3(:, line, 3), work3(:, line, 4))
                end if
            else
                if (periodic(3)) then
                    call spl_five_per_line(n3, spl%h_step(3), work3(:, line, 0), &
                                           work3(:, line, 1), work3(:, line, 2), &
                                           work3(:, line, 3), work3(:, line, 4), &
                                           work3(:, line, 5))
                else
                    call spl_five_reg_line(n3, spl%h_step(3), work3(:, line, 0), &
                                           work3(:, line, 1), work3(:, line, 2), &
                                           work3(:, line, 3), work3(:, line, 4), &
                                           work3(:, line, 5))
                end if
            end if
        end do
#ifdef _OPENMP
    !$omp end parallel do
#endif

        do k3 = 0, N3_order
            do iq = 1, n_quantities
                do i3 = 1, n3
                    do i1 = 1, n1
                        line2 = i1 + (i3 - 1)*n1 + (iq - 1)*n1*n3
                        do i2 = 1, n2
                            line3 = i1 + (i2 - 1)*n1 + (iq - 1)*n1*n2
                            work2(i2, line2, 0) = work3(i3, line3, k3)
                        end do
                    end do
                end do
            end do

#ifdef _OPENMP
    !$omp parallel do default(none) &
    !$omp& shared(work2, n1, n2, n3, n_quantities, N2_order, periodic, spl) &
    !$omp& private(line)
#endif
            do line = 1, n1*n3*n_quantities
                if (N2_order == 3) then
                    if (periodic(2)) then
                        call spl_three_per_line(n2, spl%h_step(2), work2(:, line, 0), &
                                                work2(:, line, 1), work2(:, line, 2), &
                                                work2(:, line, 3))
                    else
                        call spl_three_reg_line(n2, spl%h_step(2), work2(:, line, 0), &
                                                work2(:, line, 1), work2(:, line, 2), &
                                                work2(:, line, 3))
                    end if
                else if (N2_order == 4) then
                    if (periodic(2)) then
                        call spl_four_per_line(n2, spl%h_step(2), work2(:, line, 0), &
                                               work2(:, line, 1), work2(:, line, 2), &
                                               work2(:, line, 3), work2(:, line, 4))
                    else
                        call spl_four_reg_line(n2, spl%h_step(2), work2(:, line, 0), &
                                               work2(:, line, 1), work2(:, line, 2), &
                                               work2(:, line, 3), work2(:, line, 4))
                    end if
                else
                    if (periodic(2)) then
                        call spl_five_per_line(n2, spl%h_step(2), work2(:, line, 0), &
                                               work2(:, line, 1), work2(:, line, 2), &
                                               work2(:, line, 3), work2(:, line, 4), &
                                               work2(:, line, 5))
                    else
                        call spl_five_reg_line(n2, spl%h_step(2), work2(:, line, 0), &
                                               work2(:, line, 1), work2(:, line, 2), &
                                               work2(:, line, 3), work2(:, line, 4), &
                                               work2(:, line, 5))
                    end if
                end if
            end do
#ifdef _OPENMP
    !$omp end parallel do
#endif

            do k2 = 0, N2_order
                do iq = 1, n_quantities
                    do i3 = 1, n3
                        do i2 = 1, n2
                            line = i2 + (i3 - 1)*n2 + (iq - 1)*n2*n3
                            do i1 = 1, n1
                                line2 = i1 + (i3 - 1)*n1 + (iq - 1)*n1*n3
                                work1(i1, line, 0) = work2(i2, line2, k2)
                            end do
                        end do
                    end do
                end do

#ifdef _OPENMP
    !$omp parallel do default(none) &
    !$omp& shared(work1, n1, n2, n3, n_quantities, N1_order, periodic, spl) &
    !$omp& private(line)
#endif
                do line = 1, n2*n3*n_quantities
                    if (N1_order == 3) then
                        if (periodic(1)) then
                            call spl_three_per_line(n1, spl%h_step(1), work1(:, &
                                                                             line, 0), &
                                                    work1(:, line, 1), work1(:, &
                                                                             line, 2), &
                                                    work1(:, line, 3))
                        else
                            call spl_three_reg_line(n1, spl%h_step(1), work1(:, &
                                                                             line, 0), &
                                                    work1(:, line, 1), work1(:, &
                                                                             line, 2), &
                                                    work1(:, line, 3))
                        end if
                    else if (N1_order == 4) then
                        if (periodic(1)) then
                            call spl_four_per_line(n1, spl%h_step(1), work1(:, &
                                                                            line, 0), &
                                                   work1(:, line, 1), work1(:, &
                                                                            line, 2), &
                                                   work1(:, line, 3), work1(:, line, 4))
                        else
                            call spl_four_reg_line(n1, spl%h_step(1), work1(:, &
                                                                            line, 0), &
                                                   work1(:, line, 1), work1(:, &
                                                                            line, 2), &
                                                   work1(:, line, 3), work1(:, line, 4))
                        end if
                    else
                        if (periodic(1)) then
                            call spl_five_per_line(n1, spl%h_step(1), work1(:, &
                                                                            line, 0), &
                                                   work1(:, line, 1), work1(:, &
                                                                            line, 2), &
                                                   work1(:, line, 3), work1(:, &
                                                                            line, 4), &
                                                   work1(:, line, 5))
                        else
                            call spl_five_reg_line(n1, spl%h_step(1), work1(:, &
                                                                            line, 0), &
                                                   work1(:, line, 1), work1(:, &
                                                                            line, 2), &
                                                   work1(:, line, 3), work1(:, &
                                                                            line, 4), &
                                                   work1(:, line, 5))
                        end if
                    end if
                end do
#ifdef _OPENMP
    !$omp end parallel do
#endif

                do iq = 1, n_quantities
                    do i3 = 1, n3
                        do i2 = 1, n2
                            line = i2 + (i3 - 1)*n2 + (iq - 1)*n2*n3
                            do i1 = 1, n1
                                do k1 = 0, N1_order
                                    spl%coeff(iq, k1, k2, k3, i1, i2, i3) = &
                                        work1(i1, line, k1)
                                end do
                            end do
                        end do
                    end do
                end do
            end do
        end do

        deallocate (work1)
        deallocate (work2)
        deallocate (work3)
    end subroutine construct_batch_splines_3d_lines

    recursive subroutine construct_batch_splines_3d_resident(x_min, x_max, y_batch, order, &
                                                   periodic, spl)
        real(dp), intent(in) :: x_min(:), x_max(:)
        real(dp), intent(in) :: y_batch(:, :, :, :)  ! (n1, n2, n3, n_quantities)
        integer, intent(in) :: order(:)
        logical, intent(in) :: periodic(:)
        type(BatchSplineData3D), intent(inout) :: spl

        call construct_batch_splines_3d(x_min, x_max, y_batch, order, periodic, spl)
    end subroutine construct_batch_splines_3d_resident

    recursive subroutine construct_batch_splines_3d_resident_device(x_min, x_max, y_batch, &
                                                          order, periodic, spl, &
                                                          update_host, &
                                                          assume_y_present)
        real(dp), intent(in) :: x_min(:), x_max(:)
        real(dp), intent(in) :: y_batch(:, :, :, :)  ! (n1, n2, n3, n_quantities)
        integer, intent(in) :: order(3)
        logical, intent(in) :: periodic(3)
        type(BatchSplineData3D), intent(inout) :: spl
        logical, intent(in), optional :: update_host
        logical, intent(in), optional :: assume_y_present

        integer :: n1, n2, n3, n_quantities
        logical :: do_update, do_assume_present

        do_update = .true.
        if (present(update_host)) do_update = update_host
        do_assume_present = .false.
        if (present(assume_y_present)) do_assume_present = assume_y_present

        n1 = size(y_batch, 1)
        n2 = size(y_batch, 2)
        n3 = size(y_batch, 3)
        n_quantities = size(y_batch, 4)

#ifdef _OPENACC
        call construct_batch_splines_3d_resident_device_impl(x_min, x_max, n1, n2, &
                                                             n3, &
                                                             n_quantities, &
                                                             y_batch, &
                                                             order, periodic, spl, &
                                                             do_update, &
                                                             do_assume_present)
#else
        call construct_batch_splines_3d_resident(x_min, x_max, y_batch, order, &
                                                 periodic, spl)
#endif
    end subroutine construct_batch_splines_3d_resident_device

    recursive subroutine construct_batch_splines_3d_resident_device_impl(x_min, x_max, n1, n2, &
                                                               n3, n_quantities, &
                                                               y_batch, &
                                                               order, periodic, &
                                                               spl, &
                                                               do_update, &
                                                               do_assume_present)
        real(dp), intent(in) :: x_min(3), x_max(3)
        integer, intent(in) :: n1, n2, n3, n_quantities
        real(dp), intent(in) :: y_batch(n1, n2, n3, n_quantities)
        integer, intent(in) :: order(3)
        logical, intent(in) :: periodic(3)
        type(BatchSplineData3D), intent(inout) :: spl
        logical, intent(in) :: do_update
        logical, intent(in) :: do_assume_present

        integer :: istat
        integer :: N1_order, N2_order, N3_order
        integer :: order1, order2, order3
        integer :: i1, i2, i3, iq, k1, k2, k3
        integer :: line, line2, line3
        ! Work arrays - allocated fresh each call to avoid GCC OpenACC memory issues
        real(dp), allocatable :: work3(:, :, :)
        real(dp), allocatable :: work2(:, :, :)
        real(dp), allocatable :: work1(:, :, :)
        real(dp) :: h1, h2, h3
        logical :: periodic1, periodic2, periodic3

        N1_order = order(1)
        N2_order = order(2)
        N3_order = order(3)
        order1 = N1_order
        order2 = N2_order
        order3 = N3_order
        periodic1 = periodic(1)
        periodic2 = periodic(2)
        periodic3 = periodic(3)

        if (n1 < 2 .or. n2 < 2 .or. n3 < 2) then
            error stop "construct_batch_splines_3d_resident_device:"// &
                " Need at least 2 points"
        end if
        if (n_quantities < 1) then
            error stop "construct_batch_splines_3d_resident_device:"// &
                " Need at least 1 quantity"
        end if
        if (any(order < 3) .or. any(order > 5)) then
            error stop "construct_batch_splines_3d_resident_device:"// &
                " Order must be between 3 and 5"
        end if
        if (N1_order == 3) then
            if (periodic(1) .and. n1 < 3) then
                error stop "construct_batch_splines_3d_resident_device:"// &
                    " Need at least 3 points for periodic order(1)=3"
            end if
        else if (N1_order == 4) then
            if (n1 < 5) then
                error stop "construct_batch_splines_3d_resident_device:"// &
                    " Need at least 5 points for order(1)=4"
            end if
        else
            if (n1 < 6) then
                error stop "construct_batch_splines_3d_resident_device:"// &
                    " Need at least 6 points for order(1)=5"
            end if
        end if
        if (N2_order == 3) then
            if (periodic(2) .and. n2 < 3) then
                error stop "construct_batch_splines_3d_resident_device:"// &
                    " Need at least 3 points for periodic order(2)=3"
            end if
        else if (N2_order == 4) then
            if (n2 < 5) then
                error stop "construct_batch_splines_3d_resident_device:"// &
                    " Need at least 5 points for order(2)=4"
            end if
        else
            if (n2 < 6) then
                error stop "construct_batch_splines_3d_resident_device:"// &
                    " Need at least 6 points for order(2)=5"
            end if
        end if
        if (N3_order == 3) then
            if (periodic(3) .and. n3 < 3) then
                error stop "construct_batch_splines_3d_resident_device:"// &
                    " Need at least 3 points for periodic order(3)=3"
            end if
        else if (N3_order == 4) then
            if (n3 < 5) then
                error stop "construct_batch_splines_3d_resident_device:"// &
                    " Need at least 5 points for order(3)=4"
            end if
        else
            if (n3 < 6) then
                error stop "construct_batch_splines_3d_resident_device:"// &
                    " Need at least 6 points for order(3)=5"
            end if
        end if

        spl%order = order
        spl%num_points = [n1, n2, n3]
        spl%periodic = periodic
        spl%h_step = [(x_max(1) - x_min(1))/dble(n1 - 1), &
                      (x_max(2) - x_min(2))/dble(n2 - 1), &
                      (x_max(3) - x_min(3))/dble(n3 - 1)]
        spl%inv_h_step = 1.0_dp/spl%h_step
        spl%period = spl%h_step*real(spl%num_points - 1, dp)
        spl%x_min = x_min
        spl%num_quantities = n_quantities

        ! Always allocate fresh - no reuse to avoid GCC OpenACC memory issues
#ifdef _OPENACC
        if (allocated(spl%coeff)) then
            if (acc_is_present(spl%coeff)) then
                !$acc exit data delete(spl%coeff)
                !$acc wait
            end if
            deallocate (spl%coeff)
        end if
#else
        if (allocated(spl%coeff)) deallocate (spl%coeff)
#endif
        allocate (spl%coeff(n_quantities, 0:N1_order, 0:N2_order, 0:N3_order, &
                            n1, n2, n3), stat=istat)
        if (istat /= 0) then
            error stop "construct_batch_splines_3d_resident_device:"// &
                " Allocation failed for coeff"
        end if
        !$acc enter data create(spl%coeff)

        allocate (work3(n3, n1*n2*n_quantities, 0:N3_order), stat=istat)
        if (istat /= 0) then
            error stop "construct_batch_splines_3d_resident_device:"// &
                " Allocation failed for work3"
        end if
        allocate (work2(n2, n1*n3*n_quantities, 0:N2_order), stat=istat)
        if (istat /= 0) then
            error stop "construct_batch_splines_3d_resident_device:"// &
                " Allocation failed for work2"
        end if
        allocate (work1(n1, n2*n3*n_quantities, 0:N1_order), stat=istat)
        if (istat /= 0) then
            error stop "construct_batch_splines_3d_resident_device:"// &
                " Allocation failed for work1"
        end if

        h1 = spl%h_step(1)
        h2 = spl%h_step(2)
        h3 = spl%h_step(3)

#ifdef _OPENACC
        block
            !$acc enter data create(work3, work2, work1)

            ! Copy input data to work3
            !$acc parallel present(work3) &
            !$acc&    present_or_copyin(y_batch(1:n1, 1:n2, 1:n3, 1:n_quantities)) &
            !$acc&    firstprivate(n1, n2, n_quantities)
            !$acc loop gang
            do iq = 1, n_quantities
                !$acc loop worker
                do i2 = 1, n2
                    !$acc loop vector collapse(2)
                    do i1 = 1, n1
                        do i3 = 1, n3
                            line = i1 + (i2 - 1)*n1 + (iq - 1)*n1*n2
                            work3(i3, line, 0) = y_batch(i1, i2, i3, iq)
                        end do
                    end do
                end do
            end do
            !$acc end parallel
            !$acc wait

            !$acc parallel loop gang present(work3) &
            !$acc&    firstprivate(order3, periodic3, n3, h3)
            do line = 1, n1*n2*n_quantities
                call spl_build_line_inplace(order3, periodic3, n3, h3, work3, &
                                            line)
            end do
            !$acc wait

            do k3 = 0, N3_order
                !$acc parallel loop collapse(3) gang present(work2, work3) &
                !$acc&    firstprivate(n1, n2, n3, n_quantities, k3)
                do iq = 1, n_quantities
                    do i3 = 1, n3
                        do i1 = 1, n1
                            line2 = i1 + (i3 - 1)*n1 + (iq - 1)*n1*n3
                            !$acc loop vector
                            do i2 = 1, n2
                                line3 = i1 + (i2 - 1)*n1 + (iq - 1)*n1*n2
                                work2(i2, line2, 0) = work3(i3, line3, k3)
                            end do
                        end do
                    end do
                end do
                !$acc wait

                !$acc parallel loop gang present(work2) &
                !$acc&    firstprivate(order2, periodic2, n2, h2)
                do line = 1, n1*n3*n_quantities
                    call spl_build_line_inplace(order2, periodic2, n2, h2, &
                                                work2, line)
                end do
                !$acc wait

                do k2 = 0, N2_order
                    !$acc parallel loop collapse(3) gang present(work1, work2) &
                    !$acc&    firstprivate(n1, n2, n3, n_quantities, k2)
                    do iq = 1, n_quantities
                        do i3 = 1, n3
                            do i2 = 1, n2
                                line = i2 + (i3 - 1)*n2 + (iq - 1)*n2*n3
                                !$acc loop vector
                                do i1 = 1, n1
                                    line2 = i1 + (i3 - 1)*n1 + (iq - 1)*n1*n3
                                    work1(i1, line, 0) = work2(i2, line2, k2)
                                end do
                            end do
                        end do
                    end do
                    !$acc wait

                    !$acc parallel loop gang present(work1) &
                    !$acc&    firstprivate(order1, periodic1, n1, h1)
                    do line = 1, n2*n3*n_quantities
                        call spl_build_line_inplace(order1, periodic1, n1, h1, &
                                                    work1, line)
                    end do
                    !$acc wait

                    !$acc parallel loop collapse(4) gang present(work1, spl%coeff) &
                    !$acc&    firstprivate(n1, n2, n3, n_quantities, N1_order)
                    do iq = 1, n_quantities
                        do i3 = 1, n3
                            do i2 = 1, n2
                                do i1 = 1, n1
                                    line = i2 + (i3 - 1)*n2 + (iq - 1)*n2*n3
                                    !$acc loop vector
                                    do k1 = 0, N1_order
                                        spl%coeff(iq, k1, k2, k3, i1, i2, i3) = &
                                            work1(i1, line, k1)
                                    end do
                                end do
                            end do
                        end do
                    end do
                end do
            end do

            !$acc exit data delete(work3, work2, work1)
            !$acc wait
        end block
#endif
        if (do_update) then
            !$acc update self(spl%coeff(1:n_quantities, 0:N1_order, 0:N2_order, &
            !$acc&                        0:N3_order, 1:n1, 1:n2, 1:n3))
        end if
    end subroutine construct_batch_splines_3d_resident_device_impl

    recursive subroutine destroy_batch_splines_3d(spl)
        type(BatchSplineData3D), intent(inout) :: spl

#ifdef _OPENACC
        if (allocated(spl%coeff)) then
            if (acc_is_present(spl%coeff)) then
                !$acc exit data delete(spl%coeff)
                !$acc wait
            end if
        end if
#endif
        if (allocated(spl%coeff)) deallocate (spl%coeff)
    end subroutine destroy_batch_splines_3d

    recursive subroutine destroy_batch_splines_3d_device_only(spl)
        type(BatchSplineData3D), intent(inout) :: spl

#ifdef _OPENACC
        if (allocated(spl%coeff)) then
            if (acc_is_present(spl%coeff)) then
                !$acc exit data delete(spl%coeff)
                !$acc wait
            end if
        end if
#endif
    end subroutine destroy_batch_splines_3d_device_only

    recursive subroutine evaluate_batch_splines_3d(spl, x, y_batch)
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)  ! (n_quantities)

        real(dp) :: x_arr(3, 1)
        real(dp) :: y_arr(spl%num_quantities, 1)

        x_arr(:, 1) = x
        call evaluate_batch_splines_3d_many(spl, x_arr, y_arr)
        y_batch(1:spl%num_quantities) = y_arr(:, 1)
    end subroutine evaluate_batch_splines_3d

    recursive subroutine evaluate_batch_splines_3d_many(spl, x, y_batch)
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(:, :)
        real(dp), intent(out) :: y_batch(:, :)  ! (n_quantities, n_points)

        integer :: ipt, iq, k1, k2, k3, i1, i2, i3, k_wrap
        integer :: nq, order1, order2, order3
        integer :: num_points(3)
        logical :: periodic(3)
        real(dp) :: xj1, xj2, xj3
        real(dp) :: x_norm1, x_norm2, x_norm3
        real(dp) :: x_local1, x_local2, x_local3
        real(dp) :: x_min(3), h_step(3), period(3)
        real(dp) :: t, w, v, w2, yq

        if (size(x, 1) /= 3) then
            error stop "evaluate_batch_splines_3d_many: First dimension of x must be 3"
        end if
        if (size(y_batch, 1) < spl%num_quantities) then
            error stop "evaluate_batch_splines_3d_many: First dimension too small"
        end if
        if (size(y_batch, 2) /= size(x, 2)) then
            error stop "evaluate_batch_splines_3d_many: y_batch second dim mismatch"
        end if

#ifdef _OPENACC
        if (acc_is_present(spl%coeff)) then
            !$acc data copyin(x) copy(y_batch)
            call evaluate_batch_splines_3d_many_resident(spl, x, y_batch)
            !$acc end data
            return
        end if
#endif

        nq = spl%num_quantities
        num_points = spl%num_points
        order1 = spl%order(1)
        order2 = spl%order(2)
        order3 = spl%order(3)
        periodic = spl%periodic
        x_min = spl%x_min
        h_step = spl%h_step
        period(1) = h_step(1)*real(num_points(1) - 1, dp)
        period(2) = h_step(2)*real(num_points(2) - 1, dp)
        period(3) = h_step(3)*real(num_points(3) - 1, dp)

        do ipt = 1, size(x, 2)
            include "spline3d_many_point_body.inc"
        end do
    end subroutine evaluate_batch_splines_3d_many

    recursive subroutine evaluate_batch_splines_3d_many_resident(spl, x, y_batch)
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(:, :)
        real(dp), intent(inout) :: y_batch(:, :)

        integer :: ipt, iq, k1, k2, k3, i1, i2, i3, k_wrap
        integer :: nq, order1, order2, order3
        integer :: num_points(3)
        logical :: periodic(3)
        real(dp) :: xj1, xj2, xj3
        real(dp) :: x_norm1, x_norm2, x_norm3
        real(dp) :: x_local1, x_local2, x_local3
        real(dp) :: x_min(3), h_step(3), period(3)
        real(dp) :: t, w, v, w2, yq

        if (size(x, 1) /= 3) then
            error stop "evaluate_batch_splines_3d_many_resident: x first dim must be 3"
        end if
        if (size(y_batch, 1) < spl%num_quantities) then
            error stop "evaluate_batch_splines_3d_many_resident: y_batch dim1 too small"
        end if
        if (size(y_batch, 2) /= size(x, 2)) then
            error stop "evaluate_batch_splines_3d_many_resident: y_batch dim2 mismatch"
        end if

        nq = spl%num_quantities
        num_points = spl%num_points
        order1 = spl%order(1)
        order2 = spl%order(2)
        order3 = spl%order(3)
        periodic = spl%periodic
        x_min = spl%x_min
        h_step = spl%h_step
        period(1) = h_step(1)*real(num_points(1) - 1, dp)
        period(2) = h_step(2)*real(num_points(2) - 1, dp)
        period(3) = h_step(3)*real(num_points(3) - 1, dp)

        !$acc parallel loop present(spl%coeff, x, y_batch) &
        !$acc& private(ipt, iq, k1, k2, k3, i1, i2, i3, k_wrap) &
        !$acc& private(xj1, xj2, xj3, x_norm1, x_norm2, x_norm3) &
        !$acc& private(x_local1, x_local2, x_local3, t, w, v, w2, yq)
        do ipt = 1, size(x, 2)
            include "spline3d_many_point_body.inc"
        end do
        !$acc end parallel loop
    end subroutine evaluate_batch_splines_3d_many_resident

    recursive subroutine evaluate_batch_splines_3d_many_der(spl, x, y_batch, dy_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(:, :)           ! (3, npts)
        real(dp), intent(out) :: y_batch(:, :)    ! (nq, npts)
        real(dp), intent(out) :: dy_batch(:, :, :) ! (3, nq, npts)

        integer :: ipt, npts

        npts = size(x, 2)
        do ipt = 1, npts
            call evaluate_batch_splines_3d_der_core(spl, x(:, ipt), &
                                                    y_batch(:, ipt), &
                                                    dy_batch(:, :, ipt))
        end do
    end subroutine evaluate_batch_splines_3d_many_der

    recursive subroutine evaluate_batch_splines_3d_many_der2(spl, x, y_batch, dy_batch, d2y_batch)
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(:, :)            ! (3, npts)
        real(dp), intent(out) :: y_batch(:, :)     ! (nq, npts)
        real(dp), intent(out) :: dy_batch(:, :, :)  ! (3, nq, npts)
        real(dp), intent(out) :: d2y_batch(:, :, :) ! (6, nq, npts)

        integer :: ipt, npts

        npts = size(x, 2)
        do ipt = 1, npts
            call evaluate_batch_splines_3d_der2_core( &
                spl, x(:, ipt), y_batch(:, ipt), dy_batch(:, :, ipt), &
                d2y_batch(:, :, ipt) &
                )
        end do
    end subroutine evaluate_batch_splines_3d_many_der2

    recursive subroutine evaluate_batch_splines_3d_many_der2_mask(spl, x, mask, y_batch, dy_batch, d2y_batch)
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(:,:)             ! (3, npts)
        logical, intent(in) :: mask(:)
        real(dp), intent(inout) :: y_batch(:,:)     ! (nq, npts)
        real(dp), intent(inout) :: dy_batch(:,:,:)  ! (3, nq, npts)
        real(dp), intent(inout) :: d2y_batch(:,:,:) ! (6, nq, npts)

        integer :: ipt, npts

        npts = size(x, 2)
        if (size(mask) /= npts) then
            error stop "evaluate_batch_splines_3d_many_der2_mask: mask size mismatch"
        end if

        do ipt = 1, npts
            if (.not. mask(ipt)) cycle
            call evaluate_batch_splines_3d_der2_core(spl, x(:, ipt), &
                y_batch(:, ipt), dy_batch(:, :, ipt), d2y_batch(:, :, ipt))
        end do
    end subroutine evaluate_batch_splines_3d_many_der2_mask

    recursive subroutine evaluate_batch_splines_3d_der(spl, x, y_batch, dy_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)     ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)  ! (3, n_quantities)

        ! Call the single-point core directly. Routing one point through
        ! evaluate_batch_splines_3d_many_der cost three automatic arrays and two
        ! array copies per call, for a routine that only loops over the core
        ! anyway. evaluate_batch_splines_3d_der2 has always called its core
        ! directly; this makes the first-derivative entry point match.
        call evaluate_batch_splines_3d_der_core(spl, x, y_batch, dy_batch)
    end subroutine evaluate_batch_splines_3d_der

    ! Dispatch to the specialised first-derivative kernel, mirroring how
    ! evaluate_batch_splines_3d_der2_core selects among its variants. The
    ! single-quantity case is the common one in orbit tracing (|B| alone), and
    ! the general kernel below indexes coeff arrays whose leading dimension is
    ! MAX_QUANTITIES, so with num_quantities = 1 every access is stride-8 and
    ! the !$omp simd loops have a single iteration. The nq1 kernel drops that
    ! leading dimension.
    !
    ! The nq1 kernel performs the same Horner recurrences in the same order as
    ! the general one, so for num_quantities = 1 it is bit-identical. That is
    ! asserted in test/interpolate/test_batch_spline_3d_der_nq1.f90.
    recursive subroutine evaluate_batch_splines_3d_der_core(spl, x, y_batch, dy_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)     ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)  ! (3, n_quantities)

        if (spl%num_quantities == 1) then
            call evaluate_batch_splines_3d_der_core_nq1(spl, x, y_batch, dy_batch)
            return
        end if

        call evaluate_batch_splines_3d_der_core_general(spl, x, y_batch, dy_batch)
    end subroutine evaluate_batch_splines_3d_der_core

    ! Single-quantity first-derivative kernel. Same algorithm and same operation
    ! order as evaluate_batch_splines_3d_der_core_general, with the quantity
    ! dimension removed so the coefficient sweeps are contiguous.
    recursive subroutine evaluate_batch_splines_3d_der_core_nq1(spl, x, y_batch, &
                                                                dy_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)     ! (1)
        real(dp), intent(out) :: dy_batch(:, :)  ! (3, 1)

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: coeff_23(0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_23_dx1(0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_3(0:MAX_ORDER)
        real(dp) :: coeff_3_dx1(0:MAX_ORDER)
        real(dp) :: coeff_3_dx2(0:MAX_ORDER)
        real(dp) :: yv, dy1, dy2, dy3

        integer :: interval_index(3), k1, k2, k3, j
        integer :: i1, i2, i3
        integer :: N1, N2, N3

        N1 = spl%order(1)
        N2 = spl%order(2)
        N3 = spl%order(3)

        do j = 1, 3
            if (spl%periodic(j)) then
                xj = modulo(x(j) - spl%x_min(j), &
                            spl%h_step(j)*(spl%num_points(j) - 1)) + spl%x_min(j)
            else
                xj = x(j)
            end if
            x_norm(j) = (xj - spl%x_min(j))/spl%h_step(j)
            interval_index(j) = max(0, min(spl%num_points(j) - 2, int(x_norm(j))))
            x_local(j) = (x_norm(j) - dble(interval_index(j)))*spl%h_step(j)
        end do
        i1 = interval_index(1) + 1
        i2 = interval_index(2) + 1
        i3 = interval_index(3) + 1

        ! First reduction over x1: value.
        do k3 = 0, N3
            do k2 = 0, N2
                coeff_23(k2, k3) = spl%coeff(1, N1, k2, k3, i1, i2, i3)
            end do
        end do

        do k1 = N1 - 1, 0, -1
            do k3 = 0, N3
                do k2 = 0, N2
                    coeff_23(k2, k3) = spl%coeff(1, k1, k2, k3, i1, i2, i3) + &
                                       x_local(1)*coeff_23(k2, k3)
                end do
            end do
        end do

        ! First reduction over x1: d/dx1.
        do k3 = 0, N3
            do k2 = 0, N2
                coeff_23_dx1(k2, k3) = N1*spl%coeff(1, N1, k2, k3, i1, i2, i3)
            end do
        end do

        do k1 = N1 - 1, 1, -1
            do k3 = 0, N3
                do k2 = 0, N2
                    coeff_23_dx1(k2, k3) = k1*spl%coeff(1, k1, k2, k3, &
                                                        i1, i2, i3) + &
                                           x_local(1)*coeff_23_dx1(k2, k3)
                end do
            end do
        end do

        ! Second reduction over x2.
        do k3 = 0, N3
            coeff_3(k3) = coeff_23(N2, k3)
            coeff_3_dx1(k3) = coeff_23_dx1(N2, k3)
            coeff_3_dx2(k3) = N2*coeff_23(N2, k3)
        end do

        do k2 = N2 - 1, 0, -1
            do k3 = 0, N3
                coeff_3(k3) = coeff_23(k2, k3) + x_local(2)*coeff_3(k3)
                coeff_3_dx1(k3) = coeff_23_dx1(k2, k3) + x_local(2)*coeff_3_dx1(k3)
            end do
        end do

        do k2 = N2 - 1, 1, -1
            do k3 = 0, N3
                coeff_3_dx2(k3) = k2*coeff_23(k2, k3) + x_local(2)*coeff_3_dx2(k3)
            end do
        end do

        ! Third reduction over x3.
        yv = coeff_3(N3)
        dy1 = coeff_3_dx1(N3)
        dy2 = coeff_3_dx2(N3)
        dy3 = N3*coeff_3(N3)

        do k3 = N3 - 1, 0, -1
            yv = coeff_3(k3) + x_local(3)*yv
            dy1 = coeff_3_dx1(k3) + x_local(3)*dy1
            dy2 = coeff_3_dx2(k3) + x_local(3)*dy2
        end do

        do k3 = N3 - 1, 1, -1
            dy3 = k3*coeff_3(k3) + x_local(3)*dy3
        end do

        y_batch(1) = yv
        dy_batch(1, 1) = dy1
        dy_batch(2, 1) = dy2
        dy_batch(3, 1) = dy3

    end subroutine evaluate_batch_splines_3d_der_core_nq1

    recursive subroutine evaluate_batch_splines_3d_der_core_general(spl, x, y_batch, &
                                                                    dy_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)     ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)  ! (3, n_quantities)

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3)
        ! Fixed-size arrays to avoid heap allocation (stack only)
        real(dp) :: coeff_23(MAX_QUANTITIES, 0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_23_dx1(MAX_QUANTITIES, 0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_3(MAX_QUANTITIES, 0:MAX_ORDER)
        real(dp) :: coeff_3_dx1(MAX_QUANTITIES, 0:MAX_ORDER)
        real(dp) :: coeff_3_dx2(MAX_QUANTITIES, 0:MAX_ORDER)

        integer :: interval_index(3), k1, k2, k3, j, iq
        integer :: i1, i2, i3
        integer :: N1, N2, N3, NQ

        N1 = spl%order(1)
        N2 = spl%order(2)
        N3 = spl%order(3)
        NQ = spl%num_quantities

        do j = 1, 3
            if (spl%periodic(j)) then
                xj = modulo(x(j) - spl%x_min(j), &
                            spl%h_step(j)*(spl%num_points(j) - 1)) + spl%x_min(j)
            else
                xj = x(j)
            end if
            x_norm(j) = (xj - spl%x_min(j))/spl%h_step(j)
            interval_index(j) = max(0, min(spl%num_points(j) - 2, int(x_norm(j))))
            x_local(j) = (x_norm(j) - dble(interval_index(j)))*spl%h_step(j)
        end do
        i1 = interval_index(1) + 1
        i2 = interval_index(2) + 1
        i3 = interval_index(3) + 1

        ! First reduction: interpolation over x1 for value using backward Horner
        ! Initialize with highest order
        do k3 = 0, N3
            do k2 = 0, N2
    !$omp simd
                do iq = 1, spl%num_quantities
                    coeff_23(iq, k2, k3) = spl%coeff(iq, N1, k2, k3, i1, i2, i3)
                end do
            end do
        end do

        ! Apply backward Horner for value
        do k1 = N1 - 1, 0, -1
            do k3 = 0, N3
                do k2 = 0, N2
    !$omp simd
                    do iq = 1, spl%num_quantities
                        coeff_23(iq, k2, k3) = spl%coeff(iq, k1, k2, k3, &
                                                         i1, i2, i3) + &
                                               x_local(1)*coeff_23(iq, k2, k3)
                    end do
                end do
            end do
        end do

        ! First derivative over x1 using backward Horner for derivative
        do k3 = 0, N3
            do k2 = 0, N2
    !$omp simd
                do iq = 1, spl%num_quantities
                    coeff_23_dx1(iq, k2, k3) = N1*spl%coeff(iq, N1, k2, k3, &
                                                            i1, i2, i3)
                end do
            end do
        end do

        do k1 = N1 - 1, 1, -1
            do k3 = 0, N3
                do k2 = 0, N2
    !$omp simd
                    do iq = 1, spl%num_quantities
                        coeff_23_dx1(iq, k2, k3) = k1*spl%coeff(iq, k1, k2, k3, &
                                                                i1, i2, i3) + &
                                                   x_local(1)*coeff_23_dx1(iq, k2, k3)
                    end do
                end do
            end do
        end do

        ! Second reduction: interpolation over x2
        ! Initialize with highest order
        do k3 = 0, N3
    !$omp simd
            do iq = 1, spl%num_quantities
                coeff_3(iq, k3) = coeff_23(iq, N2, k3)
                coeff_3_dx1(iq, k3) = coeff_23_dx1(iq, N2, k3)
                coeff_3_dx2(iq, k3) = N2*coeff_23(iq, N2, k3)
            end do
        end do

        ! Apply Horner for value and dx1
        do k2 = N2 - 1, 0, -1
            do k3 = 0, N3
    !$omp simd
                do iq = 1, spl%num_quantities
                    coeff_3(iq, k3) = coeff_23(iq, k2, k3) + &
                                      x_local(2)*coeff_3(iq, k3)
                    coeff_3_dx1(iq, k3) = coeff_23_dx1(iq, k2, k3) + &
                                          x_local(2)*coeff_3_dx1(iq, k3)
                end do
            end do
        end do

        ! Derivative over x2
        do k2 = N2 - 1, 1, -1
            do k3 = 0, N3
    !$omp simd
                do iq = 1, spl%num_quantities
                    coeff_3_dx2(iq, k3) = k2*coeff_23(iq, k2, k3) + &
                                          x_local(2)*coeff_3_dx2(iq, k3)
                end do
            end do
        end do

        ! Third reduction: interpolation over x3
        ! Initialize with highest order
    !$omp simd
        do iq = 1, spl%num_quantities
            y_batch(iq) = coeff_3(iq, N3)
            dy_batch(1, iq) = coeff_3_dx1(iq, N3)
            dy_batch(2, iq) = coeff_3_dx2(iq, N3)
            dy_batch(3, iq) = N3*coeff_3(iq, N3)
        end do

        ! Apply Horner for all
        do k3 = N3 - 1, 0, -1
    !$omp simd
            do iq = 1, spl%num_quantities
                y_batch(iq) = coeff_3(iq, k3) + x_local(3)*y_batch(iq)
                dy_batch(1, iq) = coeff_3_dx1(iq, k3) + x_local(3)*dy_batch(1, iq)
                dy_batch(2, iq) = coeff_3_dx2(iq, k3) + x_local(3)*dy_batch(2, iq)
            end do
        end do

        ! Derivative over x3
        do k3 = N3 - 1, 1, -1
    !$omp simd
            do iq = 1, spl%num_quantities
                dy_batch(3, iq) = k3*coeff_3(iq, k3) + x_local(3)*dy_batch(3, iq)
            end do
        end do

    end subroutine evaluate_batch_splines_3d_der_core_general

    recursive subroutine evaluate_batch_splines_3d_der2(spl, x, y_batch, dy_batch, d2y_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)      ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)   ! (3, n_quantities)
        real(dp), intent(out) :: d2y_batch(:, :)  ! (6, n_quantities)
        call evaluate_batch_splines_3d_der2_core(spl, x, y_batch, dy_batch, d2y_batch)
    end subroutine evaluate_batch_splines_3d_der2

    !> Allocation-free value/gradient evaluator for a scalar cubic field
    !> spline. This is the RK hot-path counterpart of the Hessian evaluator.
    !NVF$ INLINE
    subroutine evaluate_batch_spline_3d_scalar_cubic_der(spl, x, y, dy)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y
        real(dp), intent(out) :: dy(3)

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: x1, x2, x3
        real(dp) :: c0, c1, c2, c3
        real(dp) :: v2(0:3), d1_2(0:3)
        real(dp) :: v3(0:3), d1_3(0:3), d2_3(0:3)
        integer :: interval_index(3), i1, i2, i3
        integer :: j, k2, k3

        do j = 1, 3
            if (spl%periodic(j)) then
                xj = x(j)
                if (xj < spl%x_min(j) .or. xj >= spl%x_min(j) + spl%period(j)) then
                    xj = modulo(xj - spl%x_min(j), spl%period(j)) + spl%x_min(j)
                end if
            else
                xj = x(j)
            end if
            x_norm(j) = (xj - spl%x_min(j))*spl%inv_h_step(j)
            interval_index(j) = max(0, min(spl%num_points(j) - 2, int(x_norm(j))))
            x_local(j) = (x_norm(j) - real(interval_index(j), dp))*spl%h_step(j)
        end do

        x1 = x_local(1)
        x2 = x_local(2)
        x3 = x_local(3)
        i1 = interval_index(1) + 1
        i2 = interval_index(2) + 1
        i3 = interval_index(3) + 1

        do k3 = 0, 3
            do k2 = 0, 3
                c0 = spl%coeff(1, 0, k2, k3, i1, i2, i3)
                c1 = spl%coeff(1, 1, k2, k3, i1, i2, i3)
                c2 = spl%coeff(1, 2, k2, k3, i1, i2, i3)
                c3 = spl%coeff(1, 3, k2, k3, i1, i2, i3)
                v2(k2) = ((c3*x1 + c2)*x1 + c1)*x1 + c0
                d1_2(k2) = (3.0_dp*c3*x1 + 2.0_dp*c2)*x1 + c1
            end do

            v3(k3) = ((v2(3)*x2 + v2(2))*x2 + v2(1))*x2 + v2(0)
            d1_3(k3) = ((d1_2(3)*x2 + d1_2(2))*x2 + d1_2(1))*x2 + d1_2(0)
            d2_3(k3) = (3.0_dp*v2(3)*x2 + 2.0_dp*v2(2))*x2 + v2(1)
        end do

        y = ((v3(3)*x3 + v3(2))*x3 + v3(1))*x3 + v3(0)
        dy(1) = ((d1_3(3)*x3 + d1_3(2))*x3 + d1_3(1))*x3 + d1_3(0)
        dy(2) = ((d2_3(3)*x3 + d2_3(2))*x3 + d2_3(1))*x3 + d2_3(0)
        dy(3) = (3.0_dp*v3(3)*x3 + 2.0_dp*v3(2))*x3 + v3(1)
    end subroutine evaluate_batch_spline_3d_scalar_cubic_der

    !> Allocation-free value/gradient evaluator for a scalar quintic field
    !> spline. The fixed order and quantity count keep the device working set
    !> independent of the generic batch evaluator's maximum dimensions.
    !NVF$ INLINE
    subroutine evaluate_batch_spline_3d_scalar_quintic_der(spl, x, y, dy)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y
        real(dp), intent(out) :: dy(3)

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: value_x1, derivative_x1
        real(dp) :: value_x2(0:5), derivative_x1_x2(0:5)
        real(dp) :: value_x3(0:5), derivative_x1_x3(0:5)
        real(dp) :: derivative_x2_x3(0:5)
        integer :: interval_index(3), i1, i2, i3
        integer :: j, k1, k2, k3

        do j = 1, 3
            if (spl%periodic(j)) then
                xj = x(j)
                if (xj < spl%x_min(j) .or. xj >= spl%x_min(j) + spl%period(j)) then
                    xj = modulo(xj - spl%x_min(j), spl%period(j)) + spl%x_min(j)
                end if
            else
                xj = x(j)
            end if
            x_norm(j) = (xj - spl%x_min(j))*spl%inv_h_step(j)
            interval_index(j) = max(0, min(spl%num_points(j) - 2, int(x_norm(j))))
            x_local(j) = (x_norm(j) - real(interval_index(j), dp))*spl%h_step(j)
        end do

        i1 = interval_index(1) + 1
        i2 = interval_index(2) + 1
        i3 = interval_index(3) + 1

        do k3 = 0, 5
            do k2 = 0, 5
                value_x1 = spl%coeff(1, 5, k2, k3, i1, i2, i3)
                derivative_x1 = 5.0_dp*value_x1
                do k1 = 4, 1, -1
                    value_x1 = spl%coeff(1, k1, k2, k3, i1, i2, i3) + &
                        x_local(1)*value_x1
                    derivative_x1 = real(k1, dp)* &
                        spl%coeff(1, k1, k2, k3, i1, i2, i3) + &
                        x_local(1)*derivative_x1
                end do
                value_x2(k2) = spl%coeff(1, 0, k2, k3, i1, i2, i3) + &
                    x_local(1)*value_x1
                derivative_x1_x2(k2) = derivative_x1
            end do

            value_x3(k3) = value_x2(5)
            derivative_x1_x3(k3) = derivative_x1_x2(5)
            derivative_x2_x3(k3) = 5.0_dp*value_x2(5)
            do k2 = 4, 1, -1
                value_x3(k3) = value_x2(k2) + x_local(2)*value_x3(k3)
                derivative_x1_x3(k3) = derivative_x1_x2(k2) + &
                    x_local(2)*derivative_x1_x3(k3)
                derivative_x2_x3(k3) = real(k2, dp)*value_x2(k2) + &
                    x_local(2)*derivative_x2_x3(k3)
            end do
            value_x3(k3) = value_x2(0) + x_local(2)*value_x3(k3)
            derivative_x1_x3(k3) = derivative_x1_x2(0) + &
                x_local(2)*derivative_x1_x3(k3)
        end do

        y = value_x3(5)
        dy(1) = derivative_x1_x3(5)
        dy(2) = derivative_x2_x3(5)
        dy(3) = 5.0_dp*value_x3(5)
        do k3 = 4, 1, -1
            y = value_x3(k3) + x_local(3)*y
            dy(1) = derivative_x1_x3(k3) + x_local(3)*dy(1)
            dy(2) = derivative_x2_x3(k3) + x_local(3)*dy(2)
            dy(3) = real(k3, dp)*value_x3(k3) + x_local(3)*dy(3)
        end do
        y = value_x3(0) + x_local(3)*y
        dy(1) = derivative_x1_x3(0) + x_local(3)*dy(1)
        dy(2) = derivative_x2_x3(0) + x_local(3)*dy(2)
    end subroutine evaluate_batch_spline_3d_scalar_quintic_der

    recursive subroutine evaluate_batch_splines_3d_der_nq1_o355( &
            spl, x, y_batch, dy_batch)
        ! Value and gradient for the production scalar [3,5,5] spline. This is
        ! the first-derivative subset of the independently checked radial-mixed
        ! Hessian evaluator below.
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)
        real(dp), intent(out) :: dy_batch(:, :)

        integer, parameter :: N2 = 5, N3 = 5
        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3), inv_h_step(3)
        real(dp) :: x1, x2, x3, c, c23, c23_dx1
        integer :: interval_index(3), i1, i2, i3, k2, k3, j
        real(dp) :: coeff_3(0:N3), coeff_3_dx1(0:N3), coeff_3_dx2(0:N3)

        x_min = spl%x_min
        h_step = spl%h_step
        inv_h_step = spl%inv_h_step
        period = spl%period

#include "spline3d_o555_point_setup.inc"

        do k3 = 0, N3
            do k2 = N2, 0, -1
                c = spl%coeff(1, 3, k2, k3, i1, i2, i3)
                c23 = c
                c23_dx1 = 3.0_dp*c

                c = spl%coeff(1, 2, k2, k3, i1, i2, i3)
                c23 = c + x1*c23
                c23_dx1 = 2.0_dp*c + x1*c23_dx1

                c = spl%coeff(1, 1, k2, k3, i1, i2, i3)
                c23 = c + x1*c23
                c23_dx1 = c + x1*c23_dx1

                c = spl%coeff(1, 0, k2, k3, i1, i2, i3)
                c23 = c + x1*c23

                if (k2 == N2) then
                    coeff_3(k3) = c23
                    coeff_3_dx1(k3) = c23_dx1
                    coeff_3_dx2(k3) = real(N2, dp)*c23
                else
                    coeff_3(k3) = c23 + x2*coeff_3(k3)
                    coeff_3_dx1(k3) = c23_dx1 + x2*coeff_3_dx1(k3)
                    if (k2 > 0) then
                        coeff_3_dx2(k3) = real(k2, dp)*c23 + &
                            x2*coeff_3_dx2(k3)
                    end if
                end if
            end do
        end do

        y_batch(1) = coeff_3(N3)
        dy_batch(1, 1) = coeff_3_dx1(N3)
        dy_batch(2, 1) = coeff_3_dx2(N3)
        dy_batch(3, 1) = real(N3, dp)*coeff_3(N3)
        do k3 = N3 - 1, 1, -1
            y_batch(1) = coeff_3(k3) + x3*y_batch(1)
            dy_batch(1, 1) = coeff_3_dx1(k3) + x3*dy_batch(1, 1)
            dy_batch(2, 1) = coeff_3_dx2(k3) + x3*dy_batch(2, 1)
            dy_batch(3, 1) = real(k3, dp)*coeff_3(k3) + &
                x3*dy_batch(3, 1)
        end do
        y_batch(1) = coeff_3(0) + x3*y_batch(1)
        dy_batch(1, 1) = coeff_3_dx1(0) + x3*dy_batch(1, 1)
        dy_batch(2, 1) = coeff_3_dx2(0) + x3*dy_batch(2, 1)
    end subroutine evaluate_batch_splines_3d_der_nq1_o355

    !> Allocation-free value/gradient/Hessian evaluator for the production
    !> scalar cubic field spline. Keeping the polynomial order and quantity
    !> count fixed avoids the MAX_ORDER/MAX_QUANTITIES work arrays used by the
    !> general evaluator in every GPU thread.
    !NVF$ INLINE
    subroutine evaluate_batch_spline_3d_scalar_cubic_der2(spl, x, y, dy, d2y)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y
        real(dp), intent(out) :: dy(3)
        real(dp), intent(out) :: d2y(6)

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: x1, x2, x3
        real(dp) :: c0, c1, c2, c3
        real(dp) :: v2(0:3), d1_2(0:3), d11_2(0:3)
        real(dp) :: v3(0:3), d1_3(0:3), d2_3(0:3)
        real(dp) :: d11_3(0:3), d12_3(0:3), d22_3(0:3)
        integer :: interval_index(3), i1, i2, i3
        integer :: j, k2, k3

        do j = 1, 3
            if (spl%periodic(j)) then
                xj = x(j)
                if (xj < spl%x_min(j) .or. xj >= spl%x_min(j) + spl%period(j)) then
                    xj = modulo(xj - spl%x_min(j), spl%period(j)) + spl%x_min(j)
                end if
            else
                xj = x(j)
            end if
            x_norm(j) = (xj - spl%x_min(j))*spl%inv_h_step(j)
            interval_index(j) = max(0, min(spl%num_points(j) - 2, int(x_norm(j))))
            x_local(j) = (x_norm(j) - real(interval_index(j), dp))*spl%h_step(j)
        end do

        x1 = x_local(1)
        x2 = x_local(2)
        x3 = x_local(3)
        i1 = interval_index(1) + 1
        i2 = interval_index(2) + 1
        i3 = interval_index(3) + 1

        ! Collapse x1 and x2 one x3 plane at a time. This requires 36 local
        ! doubles instead of the general scalar evaluator's 297.
        do k3 = 0, 3
            do k2 = 0, 3
                c0 = spl%coeff(1, 0, k2, k3, i1, i2, i3)
                c1 = spl%coeff(1, 1, k2, k3, i1, i2, i3)
                c2 = spl%coeff(1, 2, k2, k3, i1, i2, i3)
                c3 = spl%coeff(1, 3, k2, k3, i1, i2, i3)
                v2(k2) = ((c3*x1 + c2)*x1 + c1)*x1 + c0
                d1_2(k2) = (3.0_dp*c3*x1 + 2.0_dp*c2)*x1 + c1
                d11_2(k2) = 6.0_dp*c3*x1 + 2.0_dp*c2
            end do

            v3(k3) = ((v2(3)*x2 + v2(2))*x2 + v2(1))*x2 + v2(0)
            d1_3(k3) = ((d1_2(3)*x2 + d1_2(2))*x2 + d1_2(1))*x2 + d1_2(0)
            d2_3(k3) = (3.0_dp*v2(3)*x2 + 2.0_dp*v2(2))*x2 + v2(1)
            d11_3(k3) = ((d11_2(3)*x2 + d11_2(2))*x2 + d11_2(1))*x2 + d11_2(0)
            d12_3(k3) = (3.0_dp*d1_2(3)*x2 + 2.0_dp*d1_2(2))*x2 + d1_2(1)
            d22_3(k3) = 6.0_dp*v2(3)*x2 + 2.0_dp*v2(2)
        end do

        y = ((v3(3)*x3 + v3(2))*x3 + v3(1))*x3 + v3(0)
        dy(1) = ((d1_3(3)*x3 + d1_3(2))*x3 + d1_3(1))*x3 + d1_3(0)
        dy(2) = ((d2_3(3)*x3 + d2_3(2))*x3 + d2_3(1))*x3 + d2_3(0)
        dy(3) = (3.0_dp*v3(3)*x3 + 2.0_dp*v3(2))*x3 + v3(1)

        d2y(1) = ((d11_3(3)*x3 + d11_3(2))*x3 + d11_3(1))*x3 + d11_3(0)
        d2y(2) = ((d12_3(3)*x3 + d12_3(2))*x3 + d12_3(1))*x3 + d12_3(0)
        d2y(3) = (3.0_dp*d1_3(3)*x3 + 2.0_dp*d1_3(2))*x3 + d1_3(1)
        d2y(4) = ((d22_3(3)*x3 + d22_3(2))*x3 + d22_3(1))*x3 + d22_3(0)
        d2y(5) = (3.0_dp*d2_3(3)*x3 + 2.0_dp*d2_3(2))*x3 + d2_3(1)
        d2y(6) = 6.0_dp*v3(3)*x3 + 2.0_dp*v3(2)
    end subroutine evaluate_batch_spline_3d_scalar_cubic_der2

    !> Allocation-free radial-mixed Hessian evaluator for a scalar cubic
    !> spline. This is the exact (11,12,13) subset of the full specialized
    !> evaluator above and avoids the MAX_ORDER work arrays in the generic
    !> radial-mixed path.
    !NVF$ INLINE
    subroutine evaluate_batch_spline_3d_scalar_cubic_der2_rmix( &
            spl, x, y, dy, d2y)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y
        real(dp), intent(out) :: dy(3)
        real(dp), intent(out) :: d2y(3)

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: x1, x2, x3
        real(dp) :: c0, c1, c2, c3
        real(dp) :: v2(0:3), d1_2(0:3), d11_2(0:3)
        real(dp) :: v3(0:3), d1_3(0:3), d2_3(0:3)
        real(dp) :: d11_3(0:3), d12_3(0:3)
        integer :: interval_index(3), i1, i2, i3
        integer :: j, k2, k3

        do j = 1, 3
            if (spl%periodic(j)) then
                xj = x(j)
                if (xj < spl%x_min(j) .or. &
                        xj >= spl%x_min(j) + spl%period(j)) then
                    xj = modulo(xj - spl%x_min(j), spl%period(j)) + &
                        spl%x_min(j)
                end if
            else
                xj = x(j)
            end if
            x_norm(j) = (xj - spl%x_min(j))*spl%inv_h_step(j)
            interval_index(j) = max(0, min(spl%num_points(j) - 2, &
                int(x_norm(j))))
            x_local(j) = (x_norm(j) - real(interval_index(j), dp))* &
                spl%h_step(j)
        end do

        x1 = x_local(1)
        x2 = x_local(2)
        x3 = x_local(3)
        i1 = interval_index(1) + 1
        i2 = interval_index(2) + 1
        i3 = interval_index(3) + 1

        do k3 = 0, 3
            do k2 = 0, 3
                c0 = spl%coeff(1, 0, k2, k3, i1, i2, i3)
                c1 = spl%coeff(1, 1, k2, k3, i1, i2, i3)
                c2 = spl%coeff(1, 2, k2, k3, i1, i2, i3)
                c3 = spl%coeff(1, 3, k2, k3, i1, i2, i3)
                v2(k2) = ((c3*x1 + c2)*x1 + c1)*x1 + c0
                d1_2(k2) = (3.0_dp*c3*x1 + 2.0_dp*c2)*x1 + c1
                d11_2(k2) = 6.0_dp*c3*x1 + 2.0_dp*c2
            end do

            v3(k3) = ((v2(3)*x2 + v2(2))*x2 + v2(1))*x2 + v2(0)
            d1_3(k3) = ((d1_2(3)*x2 + d1_2(2))*x2 + d1_2(1))*x2 + &
                d1_2(0)
            d2_3(k3) = (3.0_dp*v2(3)*x2 + 2.0_dp*v2(2))*x2 + v2(1)
            d11_3(k3) = ((d11_2(3)*x2 + d11_2(2))*x2 + d11_2(1))*x2 + &
                d11_2(0)
            d12_3(k3) = (3.0_dp*d1_2(3)*x2 + 2.0_dp*d1_2(2))*x2 + &
                d1_2(1)
        end do

        y = ((v3(3)*x3 + v3(2))*x3 + v3(1))*x3 + v3(0)
        dy(1) = ((d1_3(3)*x3 + d1_3(2))*x3 + d1_3(1))*x3 + d1_3(0)
        dy(2) = ((d2_3(3)*x3 + d2_3(2))*x3 + d2_3(1))*x3 + d2_3(0)
        dy(3) = (3.0_dp*v3(3)*x3 + 2.0_dp*v3(2))*x3 + v3(1)
        d2y(1) = ((d11_3(3)*x3 + d11_3(2))*x3 + d11_3(1))*x3 + &
            d11_3(0)
        d2y(2) = ((d12_3(3)*x3 + d12_3(2))*x3 + d12_3(1))*x3 + &
            d12_3(0)
        d2y(3) = (3.0_dp*d1_3(3)*x3 + 2.0_dp*d1_3(2))*x3 + d1_3(1)
    end subroutine evaluate_batch_spline_3d_scalar_cubic_der2_rmix

    recursive subroutine evaluate_batch_splines_3d_der3(spl, x, y_batch, dy_batch, &
                                                        d2y_batch, d3y_batch)
        !$acc routine seq
        !> Value, first, second and third derivatives of a 3D tensor-product
        !> batch spline. d2y packed (11,12,13,22,23,33); d3y packed
        !> (111,112,113,122,123,133,222,223,233,333) in the spline's own
        !> coordinates. General per-order basis-derivative evaluation (not the
        !> optimized Horner cores); used off the hot path for third-derivative
        !> needs such as the curvilinear metric d2g pullback.
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)       ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)    ! (3, n_quantities)
        real(dp), intent(out) :: d2y_batch(:, :)   ! (6, n_quantities)
        real(dp), intent(out) :: d3y_batch(:, :)   ! (10, n_quantities)

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3), inv_h_step(3)
        real(dp) :: x1, x2, x3
        real(dp) :: b0(0:MAX_ORDER, 3), b1(0:MAX_ORDER, 3)
        real(dp) :: b2(0:MAX_ORDER, 3), b3(0:MAX_ORDER, 3)
        integer :: interval_index(3), i1, i2, i3, j, q, nq
        integer :: N1, N2, N3, k1, k2, k3
        real(dp) :: c

        x_min = spl%x_min
        h_step = spl%h_step
        inv_h_step = spl%inv_h_step
        period = spl%period

        include "spline3d_o555_point_setup.inc"

        N1 = spl%order(1); N2 = spl%order(2); N3 = spl%order(3)
        nq = spl%num_quantities

        ! Per-dimension monomial basis and its first three derivatives at x_local.
        call basis_d3(x1, N1, b0(:, 1), b1(:, 1), b2(:, 1), b3(:, 1))
        call basis_d3(x2, N2, b0(:, 2), b1(:, 2), b2(:, 2), b3(:, 2))
        call basis_d3(x3, N3, b0(:, 3), b1(:, 3), b2(:, 3), b3(:, 3))

        y_batch(1:nq) = 0.0_dp
        dy_batch(:, 1:nq) = 0.0_dp
        d2y_batch(:, 1:nq) = 0.0_dp
        d3y_batch(:, 1:nq) = 0.0_dp

        do k3 = 0, N3
            do k2 = 0, N2
                do k1 = 0, N1
                    do q = 1, nq
                        c = spl%coeff(q, k1, k2, k3, i1, i2, i3)
                        if (c == 0.0_dp) cycle
                        y_batch(q) = y_batch(q) + c*b0(k1, 1)*b0(k2, 2)*b0(k3, 3)
                        dy_batch(1, q) = dy_batch(1, q) + c*b1(k1, 1)*b0(k2, 2)*b0(k3, 3)
                        dy_batch(2, q) = dy_batch(2, q) + c*b0(k1, 1)*b1(k2, 2)*b0(k3, 3)
                        dy_batch(3, q) = dy_batch(3, q) + c*b0(k1, 1)*b0(k2, 2)*b1(k3, 3)
                        d2y_batch(1, q) = d2y_batch(1, q) + c*b2(k1, 1)*b0(k2, 2)*b0(k3, 3)
                        d2y_batch(2, q) = d2y_batch(2, q) + c*b1(k1, 1)*b1(k2, 2)*b0(k3, 3)
                        d2y_batch(3, q) = d2y_batch(3, q) + c*b1(k1, 1)*b0(k2, 2)*b1(k3, 3)
                        d2y_batch(4, q) = d2y_batch(4, q) + c*b0(k1, 1)*b2(k2, 2)*b0(k3, 3)
                        d2y_batch(5, q) = d2y_batch(5, q) + c*b0(k1, 1)*b1(k2, 2)*b1(k3, 3)
                        d2y_batch(6, q) = d2y_batch(6, q) + c*b0(k1, 1)*b0(k2, 2)*b2(k3, 3)
                        d3y_batch(1, q) = d3y_batch(1, q) + c*b3(k1, 1)*b0(k2, 2)*b0(k3, 3)
                        d3y_batch(2, q) = d3y_batch(2, q) + c*b2(k1, 1)*b1(k2, 2)*b0(k3, 3)
                        d3y_batch(3, q) = d3y_batch(3, q) + c*b2(k1, 1)*b0(k2, 2)*b1(k3, 3)
                        d3y_batch(4, q) = d3y_batch(4, q) + c*b1(k1, 1)*b2(k2, 2)*b0(k3, 3)
                        d3y_batch(5, q) = d3y_batch(5, q) + c*b1(k1, 1)*b1(k2, 2)*b1(k3, 3)
                        d3y_batch(6, q) = d3y_batch(6, q) + c*b1(k1, 1)*b0(k2, 2)*b2(k3, 3)
                        d3y_batch(7, q) = d3y_batch(7, q) + c*b0(k1, 1)*b3(k2, 2)*b0(k3, 3)
                        d3y_batch(8, q) = d3y_batch(8, q) + c*b0(k1, 1)*b2(k2, 2)*b1(k3, 3)
                        d3y_batch(9, q) = d3y_batch(9, q) + c*b0(k1, 1)*b1(k2, 2)*b2(k3, 3)
                        d3y_batch(10, q) = d3y_batch(10, q) + c*b0(k1, 1)*b0(k2, 2)*b3(k3, 3)
                    end do
                end do
            end do
        end do

    contains

        subroutine basis_d3(xv, nord, vb0, vb1, vb2, vb3)
            !$acc routine seq
            real(dp), intent(in) :: xv
            integer, intent(in) :: nord
            real(dp), intent(out) :: vb0(0:MAX_ORDER), vb1(0:MAX_ORDER)
            real(dp), intent(out) :: vb2(0:MAX_ORDER), vb3(0:MAX_ORDER)
            integer :: kk

            vb0 = 0.0_dp; vb1 = 0.0_dp; vb2 = 0.0_dp; vb3 = 0.0_dp
            vb0(0) = 1.0_dp
            do kk = 1, nord
                vb0(kk) = xv*vb0(kk - 1)
            end do
            do kk = 1, nord
                vb1(kk) = real(kk, dp)*vb0(kk - 1)
            end do
            do kk = 2, nord
                vb2(kk) = real(kk*(kk - 1), dp)*vb0(kk - 2)
            end do
            do kk = 3, nord
                vb3(kk) = real(kk*(kk - 1)*(kk - 2), dp)*vb0(kk - 3)
            end do
        end subroutine basis_d3
    end subroutine evaluate_batch_splines_3d_der3

    recursive subroutine evaluate_batch_splines_3d_der2_rmix(spl, x, y_batch, dy_batch, &
                                                   d2y_batch_rmix)
        !$acc routine seq
        ! Evaluate a 3D batch spline at point x, returning:
        ! - y_batch: value
        ! - dy_batch: first derivatives (dx1, dx2, dx3)
        ! - d2y_batch_rmix: only second derivatives involving x1:
        !   (d2/dx1^2, d2/dx1dx2, d2/dx1dx3)
        !
        ! Intended for hot Newton paths that only need radial/mixed radial
        ! second derivatives.
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)           ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)        ! (3, n_quantities)
        real(dp), intent(out) :: d2y_batch_rmix(:, :)  ! (3, n_quantities)
        real(dp) :: d2y_full(6, MAX_QUANTITIES)

#ifndef _OPENACC
        if (size(d2y_batch_rmix, 1) /= 3) then
            error stop &
                "evaluate_batch_splines_3d_der2_rmix: d2y_batch_rmix "// &
                "first dim must be 3"
        end if
#endif

        if (spl%num_quantities == 1) then
            call evaluate_batch_splines_3d_der2_core_rmix_nq1(spl, x, y_batch, &
                                                              dy_batch, &
                                                              d2y_batch_rmix)
        else
            if (spl%order(1) == 5 .and. spl%order(2) == 5 .and. spl%order(3) == 5) then
                call evaluate_batch_splines_3d_der2_core_rmix_o555(spl, x, y_batch, &
                                                                   dy_batch, &
                                                                   d2y_batch_rmix)
            else
                call evaluate_batch_splines_3d_der2_core(spl, x, y_batch, &
                                                        dy_batch, &
                                                        d2y_full(:, 1:size(y_batch)))
                d2y_batch_rmix(:, :) = d2y_full(1:3, 1:size(y_batch))
            end if
        end if
    end subroutine evaluate_batch_splines_3d_der2_rmix

    recursive subroutine evaluate_batch_splines_3d_der2_core_rmix_general(spl, x, y_batch, &
                                                                dy_batch, &
                                                                d2y_rmix)
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)      ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)   ! (3, n_quantities)
        real(dp), intent(out) :: d2y_rmix(:, :)   ! (3, n_quantities)

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3), inv_h_step(3)
        integer :: interval_index(3), j
        integer :: i1, i2, i3
        integer :: k1, k2, k3, iq
        integer :: N1, N2, N3, NQ

        real(dp) :: coeff_23(MAX_QUANTITIES, 0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_23_dx1(MAX_QUANTITIES, 0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_23_dx1x1(MAX_QUANTITIES, 0:MAX_ORDER, 0:MAX_ORDER)

        real(dp) :: coeff_3(MAX_QUANTITIES, 0:MAX_ORDER)
        real(dp) :: coeff_3_dx1(MAX_QUANTITIES, 0:MAX_ORDER)
        real(dp) :: coeff_3_dx2(MAX_QUANTITIES, 0:MAX_ORDER)
        real(dp) :: coeff_3_dx1x1(MAX_QUANTITIES, 0:MAX_ORDER)
        real(dp) :: coeff_3_dx1x2(MAX_QUANTITIES, 0:MAX_ORDER)

        real(dp) :: dx1x3(MAX_QUANTITIES)

        N1 = spl%order(1)
        N2 = spl%order(2)
        N3 = spl%order(3)
        NQ = spl%num_quantities

        x_min = spl%x_min
        h_step = spl%h_step
        inv_h_step = spl%inv_h_step
        period = spl%period

        do j = 1, 3
            if (spl%periodic(j)) then
                xj = x(j)
                if (xj < x_min(j) .or. xj >= x_min(j) + period(j)) then
                    xj = modulo(xj - x_min(j), period(j)) + x_min(j)
                end if
            else
                xj = x(j)
            end if
            x_norm(j) = (xj - x_min(j))*inv_h_step(j)
            interval_index(j) = max(0, min(spl%num_points(j) - 2, int(x_norm(j))))
            x_local(j) = (x_norm(j) - real(interval_index(j), dp))*h_step(j)
        end do

        i1 = interval_index(1) + 1
        i2 = interval_index(2) + 1
        i3 = interval_index(3) + 1

        ! Reduction over x1: value, dx1, dx1x1
        do k3 = 0, N3
            do k2 = 0, N2
    !$omp simd
                do iq = 1, NQ
                    coeff_23(iq, k2, k3) = spl%coeff(iq, N1, k2, k3, i1, i2, i3)
                    coeff_23_dx1(iq, k2, k3) = real(N1, dp)*coeff_23(iq, k2, k3)
                    coeff_23_dx1x1(iq, k2, k3) = real(N1*(N1 - 1), &
                                                      dp)*coeff_23(iq, k2, k3)
                end do
            end do
        end do

        do k1 = N1 - 1, 1, -1
            do k3 = 0, N3
                do k2 = 0, N2
    !$omp simd
                    do iq = 1, NQ
                        coeff_23_dx1x1(iq, k2, k3) = real(k1*(k1 - 1), dp)* &
                                                     spl%coeff(iq, k1, k2, k3, i1, &
                                                               i2, i3) + &
                                                     x_local(1)*coeff_23_dx1x1(iq, k2, &
                                                                               k3)
                        coeff_23_dx1(iq, k2, k3) = real(k1, dp)* &
                                                   spl%coeff(iq, k1, k2, k3, i1, &
                                                             i2, i3) + &
                                                   x_local(1)*coeff_23_dx1(iq, k2, k3)
                        coeff_23(iq, k2, k3) = spl%coeff(iq, k1, k2, k3, i1, i2, i3) + &
                                               x_local(1)*coeff_23(iq, k2, k3)
                    end do
                end do
            end do
        end do

        ! k1 = 0 update (no new derivative contributions)
        do k3 = 0, N3
            do k2 = 0, N2
    !$omp simd
                do iq = 1, NQ
                    coeff_23(iq, k2, k3) = spl%coeff(iq, 0, k2, k3, i1, i2, i3) + &
                                           x_local(1)*coeff_23(iq, k2, k3)
                    coeff_23_dx1(iq, k2, k3) = x_local(1)*coeff_23_dx1(iq, k2, k3)
                    coeff_23_dx1x1(iq, k2, k3) = x_local(1)*coeff_23_dx1x1(iq, k2, k3)
                end do
            end do
        end do

        ! Reduction over x2: value, dx1, dx1x1, dx2, dx1x2
        do k3 = 0, N3
    !$omp simd
            do iq = 1, NQ
                coeff_3(iq, k3) = coeff_23(iq, N2, k3)
                coeff_3_dx1(iq, k3) = coeff_23_dx1(iq, N2, k3)
                coeff_3_dx1x1(iq, k3) = coeff_23_dx1x1(iq, N2, k3)
                coeff_3_dx2(iq, k3) = real(N2, dp)*coeff_3(iq, k3)
                coeff_3_dx1x2(iq, k3) = real(N2, dp)*coeff_3_dx1(iq, k3)
            end do
        end do

        do k2 = N2 - 1, 1, -1
            do k3 = 0, N3
    !$omp simd
                do iq = 1, NQ
                    coeff_3_dx1x2(iq, k3) = real(k2, dp)*coeff_23_dx1(iq, k2, k3) + &
                                            x_local(2)*coeff_3_dx1x2(iq, k3)
                    coeff_3_dx2(iq, k3) = real(k2, dp)*coeff_23(iq, k2, k3) + &
                                          x_local(2)*coeff_3_dx2(iq, k3)
                    coeff_3_dx1x1(iq, k3) = coeff_23_dx1x1(iq, k2, k3) + &
                                            x_local(2)*coeff_3_dx1x1(iq, k3)
                    coeff_3_dx1(iq, k3) = coeff_23_dx1(iq, k2, k3) + &
                                          x_local(2)*coeff_3_dx1(iq, k3)
                    coeff_3(iq, k3) = coeff_23(iq, k2, k3) + x_local(2)*coeff_3(iq, k3)
                end do
            end do
        end do

        ! k2 = 0 update
        do k3 = 0, N3
    !$omp simd
            do iq = 1, NQ
                coeff_3_dx1x2(iq, k3) = x_local(2)*coeff_3_dx1x2(iq, k3)
                coeff_3_dx2(iq, k3) = x_local(2)*coeff_3_dx2(iq, k3)
                coeff_3_dx1x1(iq, k3) = coeff_23_dx1x1(iq, 0, k3) + &
                                        x_local(2)*coeff_3_dx1x1(iq, k3)
                coeff_3_dx1(iq, k3) = coeff_23_dx1(iq, 0, k3) + &
                                      x_local(2)*coeff_3_dx1(iq, k3)
                coeff_3(iq, k3) = coeff_23(iq, 0, k3) + x_local(2)*coeff_3(iq, k3)
            end do
        end do

        ! Reduction over x3: value, dx1, dx2, dx3 and rmix second derivatives
    !$omp simd
        do iq = 1, NQ
            y_batch(iq) = coeff_3(iq, N3)
            dy_batch(1, iq) = coeff_3_dx1(iq, N3)
            dy_batch(2, iq) = coeff_3_dx2(iq, N3)
            dy_batch(3, iq) = real(N3, dp)*coeff_3(iq, N3)
            d2y_rmix(1, iq) = coeff_3_dx1x1(iq, N3)
            d2y_rmix(2, iq) = coeff_3_dx1x2(iq, N3)
            dx1x3(iq) = real(N3, dp)*coeff_3_dx1(iq, N3)
            d2y_rmix(3, iq) = dx1x3(iq)
        end do

        do k3 = N3 - 1, 1, -1
    !$omp simd
            do iq = 1, NQ
                dx1x3(iq) = real(k3, dp)*coeff_3_dx1(iq, k3) + x_local(3)*dx1x3(iq)
                dy_batch(3, iq) = real(k3, dp)*coeff_3(iq, k3) + &
                                  x_local(3)*dy_batch(3, iq)

                d2y_rmix(1, iq) = coeff_3_dx1x1(iq, k3) + x_local(3)*d2y_rmix(1, iq)
                d2y_rmix(2, iq) = coeff_3_dx1x2(iq, k3) + x_local(3)*d2y_rmix(2, iq)
                d2y_rmix(3, iq) = dx1x3(iq)

                dy_batch(1, iq) = coeff_3_dx1(iq, k3) + x_local(3)*dy_batch(1, iq)
                dy_batch(2, iq) = coeff_3_dx2(iq, k3) + x_local(3)*dy_batch(2, iq)
                y_batch(iq) = coeff_3(iq, k3) + x_local(3)*y_batch(iq)
            end do
        end do

        ! k3 = 0 update
    !$omp simd
        do iq = 1, NQ
            dy_batch(3, iq) = x_local(3)*dy_batch(3, iq)
            dx1x3(iq) = x_local(3)*dx1x3(iq)
            d2y_rmix(3, iq) = dx1x3(iq)

            d2y_rmix(1, iq) = coeff_3_dx1x1(iq, 0) + x_local(3)*d2y_rmix(1, iq)
            d2y_rmix(2, iq) = coeff_3_dx1x2(iq, 0) + x_local(3)*d2y_rmix(2, iq)
            dy_batch(1, iq) = coeff_3_dx1(iq, 0) + x_local(3)*dy_batch(1, iq)
            dy_batch(2, iq) = coeff_3_dx2(iq, 0) + x_local(3)*dy_batch(2, iq)
            y_batch(iq) = coeff_3(iq, 0) + x_local(3)*y_batch(iq)
        end do
    end subroutine evaluate_batch_splines_3d_der2_core_rmix_general

    recursive subroutine evaluate_batch_splines_3d_der2_core(spl, x, y_batch, dy_batch, &
                                                   d2y_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)      ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)   ! (3, n_quantities)
        real(dp), intent(out) :: d2y_batch(:, :)  ! (6, n_quantities)

        if (spl%num_quantities == 1) then
            call evaluate_batch_splines_3d_der2_core_nq1(spl, x, y_batch, &
                                                         dy_batch, d2y_batch)
            return
        end if

        if (spl%order(1) == 5 .and. spl%order(2) == 5 .and. spl%order(3) == 5) then
            call evaluate_batch_splines_3d_der2_core_o555(spl, x, y_batch, &
                                                          dy_batch, d2y_batch)
            return
        end if

        call evaluate_batch_splines_3d_der2_core_general(spl, x, y_batch, &
                                                         dy_batch, d2y_batch)
    end subroutine evaluate_batch_splines_3d_der2_core

    recursive subroutine evaluate_batch_splines_3d_der2_core_nq1(spl, x, y_batch, &
                                                       dy_batch, d2y_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)      ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)   ! (3, n_quantities)
        real(dp), intent(out) :: d2y_batch(:, :)  ! (6, n_quantities)

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3), inv_h_step(3)
        real(dp) :: x1, x2, x3

        real(dp) :: coeff_23(0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_23_dx1(0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_23_dx1x1(0:MAX_ORDER, 0:MAX_ORDER)

        real(dp) :: coeff_3(0:MAX_ORDER)
        real(dp) :: coeff_3_dx1(0:MAX_ORDER)
        real(dp) :: coeff_3_dx2(0:MAX_ORDER)
        real(dp) :: coeff_3_dx1x1(0:MAX_ORDER)
        real(dp) :: coeff_3_dx1x2(0:MAX_ORDER)
        real(dp) :: coeff_3_dx2x2(0:MAX_ORDER)

        integer :: interval_index(3), k1, k2, k3, j
        integer :: N1, N2, N3
        integer :: i1, i2, i3
        real(dp) :: c

        N1 = spl%order(1)
        N2 = spl%order(2)
        N3 = spl%order(3)

        if (N1 == 3 .and. N2 == 5 .and. N3 == 5) then
            call evaluate_batch_splines_3d_der2_core_nq1_o355( &
                spl, x, y_batch, dy_batch, d2y_batch)
            return
        end if

        if (N1 == 5 .and. N2 == 5 .and. N3 == 5) then
            call evaluate_batch_splines_3d_der2_core_nq1_o555( &
                spl, x, y_batch, dy_batch, d2y_batch)
            return
        end if

        x_min = spl%x_min
        h_step = spl%h_step
        inv_h_step = spl%inv_h_step
        period = spl%period

        include "spline3d_o555_point_setup.inc"

        ! First reduction: x1 interpolation (value, dx1, dx1x1)
        do k3 = 0, N3
            do k2 = 0, N2
                c = spl%coeff(1, N1, k2, k3, i1, i2, i3)
                coeff_23(k2, k3) = c
                coeff_23_dx1(k2, k3) = N1*c
                coeff_23_dx1x1(k2, k3) = N1*(N1 - 1)*c
            end do
        end do

        do k1 = N1 - 1, 2, -1
            do k3 = 0, N3
    !$omp simd
                do k2 = 0, N2
                    c = spl%coeff(1, k1, k2, k3, i1, i2, i3)
                    coeff_23(k2, k3) = c + x1*coeff_23(k2, k3)
                    coeff_23_dx1(k2, k3) = k1*c + x1*coeff_23_dx1(k2, k3)
                    coeff_23_dx1x1(k2, k3) = k1*(k1 - 1)*c + &
                                             x1*coeff_23_dx1x1(k2, k3)
                end do
            end do
        end do

        if (N1 > 1) then
            k1 = 1
            do k3 = 0, N3
    !$omp simd
                do k2 = 0, N2
                    c = spl%coeff(1, k1, k2, k3, i1, i2, i3)
                    coeff_23(k2, k3) = c + x1*coeff_23(k2, k3)
                    coeff_23_dx1(k2, k3) = k1*c + x1*coeff_23_dx1(k2, k3)
                end do
            end do
        end if

        k1 = 0
        do k3 = 0, N3
    !$omp simd
            do k2 = 0, N2
                c = spl%coeff(1, k1, k2, k3, i1, i2, i3)
                coeff_23(k2, k3) = c + x1*coeff_23(k2, k3)
            end do
        end do

        ! Second reduction: x2 interpolation (value, dx1, dx1x1, dx2, dx1x2, dx2x2)
        do k3 = 0, N3
            coeff_3(k3) = coeff_23(N2, k3)
            coeff_3_dx1(k3) = coeff_23_dx1(N2, k3)
            coeff_3_dx1x1(k3) = coeff_23_dx1x1(N2, k3)
            coeff_3_dx2(k3) = N2*coeff_3(k3)
            coeff_3_dx1x2(k3) = N2*coeff_3_dx1(k3)
            coeff_3_dx2x2(k3) = N2*(N2 - 1)*coeff_3(k3)
        end do

        do k2 = N2 - 1, 2, -1
    !$omp simd
            do k3 = 0, N3
                coeff_3(k3) = coeff_23(k2, k3) + x2*coeff_3(k3)
                coeff_3_dx1(k3) = coeff_23_dx1(k2, k3) + x2*coeff_3_dx1(k3)
                coeff_3_dx1x1(k3) = coeff_23_dx1x1(k2, k3) + &
                                    x2*coeff_3_dx1x1(k3)
                coeff_3_dx2(k3) = k2*coeff_23(k2, k3) + x2*coeff_3_dx2(k3)
                coeff_3_dx1x2(k3) = k2*coeff_23_dx1(k2, k3) + &
                                    x2*coeff_3_dx1x2(k3)
                coeff_3_dx2x2(k3) = k2*(k2 - 1)*coeff_23(k2, k3) + &
                                    x2*coeff_3_dx2x2(k3)
            end do
        end do

        if (N2 > 1) then
            k2 = 1
    !$omp simd
            do k3 = 0, N3
                coeff_3(k3) = coeff_23(k2, k3) + x2*coeff_3(k3)
                coeff_3_dx1(k3) = coeff_23_dx1(k2, k3) + x2*coeff_3_dx1(k3)
                coeff_3_dx1x1(k3) = coeff_23_dx1x1(k2, k3) + &
                                    x2*coeff_3_dx1x1(k3)
                coeff_3_dx2(k3) = k2*coeff_23(k2, k3) + x2*coeff_3_dx2(k3)
                coeff_3_dx1x2(k3) = k2*coeff_23_dx1(k2, k3) + &
                                    x2*coeff_3_dx1x2(k3)
            end do
        end if

        k2 = 0
    !$omp simd
        do k3 = 0, N3
            coeff_3(k3) = coeff_23(k2, k3) + x2*coeff_3(k3)
            coeff_3_dx1(k3) = coeff_23_dx1(k2, k3) + x2*coeff_3_dx1(k3)
            coeff_3_dx1x1(k3) = coeff_23_dx1x1(k2, k3) + x2*coeff_3_dx1x1(k3)
        end do

        ! Third reduction: x3 interpolation
        y_batch(1) = coeff_3(N3)
        dy_batch(1, 1) = coeff_3_dx1(N3)
        dy_batch(2, 1) = coeff_3_dx2(N3)
        dy_batch(3, 1) = N3*coeff_3(N3)
        d2y_batch(1, 1) = coeff_3_dx1x1(N3)
        d2y_batch(2, 1) = coeff_3_dx1x2(N3)
        d2y_batch(3, 1) = N3*coeff_3_dx1(N3)
        d2y_batch(4, 1) = coeff_3_dx2x2(N3)
        d2y_batch(5, 1) = N3*coeff_3_dx2(N3)
        d2y_batch(6, 1) = N3*(N3 - 1)*coeff_3(N3)

        do k3 = N3 - 1, 2, -1
            y_batch(1) = coeff_3(k3) + x3*y_batch(1)
            dy_batch(1, 1) = coeff_3_dx1(k3) + x3*dy_batch(1, 1)
            dy_batch(2, 1) = coeff_3_dx2(k3) + x3*dy_batch(2, 1)
            dy_batch(3, 1) = k3*coeff_3(k3) + x3*dy_batch(3, 1)
            d2y_batch(1, 1) = coeff_3_dx1x1(k3) + x3*d2y_batch(1, 1)
            d2y_batch(2, 1) = coeff_3_dx1x2(k3) + x3*d2y_batch(2, 1)
            d2y_batch(3, 1) = k3*coeff_3_dx1(k3) + x3*d2y_batch(3, 1)
            d2y_batch(4, 1) = coeff_3_dx2x2(k3) + x3*d2y_batch(4, 1)
            d2y_batch(5, 1) = k3*coeff_3_dx2(k3) + x3*d2y_batch(5, 1)
            d2y_batch(6, 1) = k3*(k3 - 1)*coeff_3(k3) + x3*d2y_batch(6, 1)
        end do

        if (N3 > 1) then
            k3 = 1
            y_batch(1) = coeff_3(k3) + x3*y_batch(1)
            dy_batch(1, 1) = coeff_3_dx1(k3) + x3*dy_batch(1, 1)
            dy_batch(2, 1) = coeff_3_dx2(k3) + x3*dy_batch(2, 1)
            dy_batch(3, 1) = k3*coeff_3(k3) + x3*dy_batch(3, 1)
            d2y_batch(1, 1) = coeff_3_dx1x1(k3) + x3*d2y_batch(1, 1)
            d2y_batch(2, 1) = coeff_3_dx1x2(k3) + x3*d2y_batch(2, 1)
            d2y_batch(3, 1) = k3*coeff_3_dx1(k3) + x3*d2y_batch(3, 1)
            d2y_batch(4, 1) = coeff_3_dx2x2(k3) + x3*d2y_batch(4, 1)
            d2y_batch(5, 1) = k3*coeff_3_dx2(k3) + x3*d2y_batch(5, 1)
        end if

        k3 = 0
        y_batch(1) = coeff_3(k3) + x3*y_batch(1)
        dy_batch(1, 1) = coeff_3_dx1(k3) + x3*dy_batch(1, 1)
        dy_batch(2, 1) = coeff_3_dx2(k3) + x3*dy_batch(2, 1)
        d2y_batch(1, 1) = coeff_3_dx1x1(k3) + x3*d2y_batch(1, 1)
        d2y_batch(2, 1) = coeff_3_dx1x2(k3) + x3*d2y_batch(2, 1)
        d2y_batch(4, 1) = coeff_3_dx2x2(k3) + x3*d2y_batch(4, 1)
    end subroutine evaluate_batch_splines_3d_der2_core_nq1

    recursive subroutine evaluate_batch_splines_3d_der2_core_rmix_nq1(spl, x, y_batch, &
                                                            dy_batch, d2y_rmix)
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)      ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)   ! (3, n_quantities)
        real(dp), intent(out) :: d2y_rmix(:, :)   ! (3, n_quantities)

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3), inv_h_step(3)
        real(dp) :: x1, x2, x3

        real(dp) :: coeff_23(0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_23_dx1(0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_23_dx1x1(0:MAX_ORDER, 0:MAX_ORDER)

        real(dp) :: coeff_3(0:MAX_ORDER)
        real(dp) :: coeff_3_dx1(0:MAX_ORDER)
        real(dp) :: coeff_3_dx2(0:MAX_ORDER)
        real(dp) :: coeff_3_dx1x1(0:MAX_ORDER)
        real(dp) :: coeff_3_dx1x2(0:MAX_ORDER)

        integer :: interval_index(3), k1, k2, k3, j
        integer :: N1, N2, N3
        integer :: i1, i2, i3
        real(dp) :: c

        N1 = spl%order(1)
        N2 = spl%order(2)
        N3 = spl%order(3)

        if (N1 == 3 .and. N2 == 5 .and. N3 == 5) then
            call evaluate_batch_splines_3d_der2_core_rmix_nq1_o355( &
                spl, x, y_batch, dy_batch, d2y_rmix)
            return
        end if

        if (N1 == 5 .and. N2 == 5 .and. N3 == 5) then
            call evaluate_batch_splines_3d_der2_core_rmix_nq1_o555(spl, x, y_batch, &
                                                                   dy_batch, d2y_rmix)
            return
        end if

        x_min = spl%x_min
        h_step = spl%h_step
        inv_h_step = spl%inv_h_step
        period = spl%period

        include "spline3d_o555_point_setup.inc"

        ! First reduction: x1 interpolation (value, dx1, dx1x1)
        do k3 = 0, N3
            do k2 = 0, N2
                c = spl%coeff(1, N1, k2, k3, i1, i2, i3)
                coeff_23(k2, k3) = c
                coeff_23_dx1(k2, k3) = N1*c
                coeff_23_dx1x1(k2, k3) = N1*(N1 - 1)*c
            end do
        end do

        do k1 = N1 - 1, 2, -1
            do k3 = 0, N3
    !$omp simd
                do k2 = 0, N2
                    c = spl%coeff(1, k1, k2, k3, i1, i2, i3)
                    coeff_23(k2, k3) = c + x1*coeff_23(k2, k3)
                    coeff_23_dx1(k2, k3) = k1*c + x1*coeff_23_dx1(k2, k3)
                    coeff_23_dx1x1(k2, k3) = k1*(k1 - 1)*c + x1*coeff_23_dx1x1(k2, k3)
                end do
            end do
        end do

        if (N1 > 1) then
            k1 = 1
            do k3 = 0, N3
    !$omp simd
                do k2 = 0, N2
                    c = spl%coeff(1, k1, k2, k3, i1, i2, i3)
                    coeff_23(k2, k3) = c + x1*coeff_23(k2, k3)
                    coeff_23_dx1(k2, k3) = k1*c + x1*coeff_23_dx1(k2, k3)
                end do
            end do
        end if

        k1 = 0
        do k3 = 0, N3
    !$omp simd
            do k2 = 0, N2
                c = spl%coeff(1, k1, k2, k3, i1, i2, i3)
                coeff_23(k2, k3) = c + x1*coeff_23(k2, k3)
            end do
        end do

        ! Second reduction: x2 interpolation (value, dx1, dx1x1, dx2, dx1x2)
        do k3 = 0, N3
            coeff_3(k3) = coeff_23(N2, k3)
            coeff_3_dx1(k3) = coeff_23_dx1(N2, k3)
            coeff_3_dx1x1(k3) = coeff_23_dx1x1(N2, k3)
            coeff_3_dx2(k3) = N2*coeff_3(k3)
            coeff_3_dx1x2(k3) = N2*coeff_3_dx1(k3)
        end do

        do k2 = N2 - 1, 2, -1
    !$omp simd
            do k3 = 0, N3
                c = coeff_23(k2, k3)
                coeff_3(k3) = c + x2*coeff_3(k3)
                coeff_3_dx1(k3) = coeff_23_dx1(k2, k3) + x2*coeff_3_dx1(k3)
                coeff_3_dx1x1(k3) = coeff_23_dx1x1(k2, k3) + x2*coeff_3_dx1x1(k3)
                coeff_3_dx2(k3) = k2*c + x2*coeff_3_dx2(k3)
                coeff_3_dx1x2(k3) = k2*coeff_23_dx1(k2, k3) + x2*coeff_3_dx1x2(k3)
            end do
        end do

        if (N2 > 1) then
            k2 = 1
    !$omp simd
            do k3 = 0, N3
                c = coeff_23(k2, k3)
                coeff_3(k3) = c + x2*coeff_3(k3)
                coeff_3_dx1(k3) = coeff_23_dx1(k2, k3) + x2*coeff_3_dx1(k3)
                coeff_3_dx1x1(k3) = coeff_23_dx1x1(k2, k3) + x2*coeff_3_dx1x1(k3)
                coeff_3_dx2(k3) = k2*c + x2*coeff_3_dx2(k3)
                coeff_3_dx1x2(k3) = k2*coeff_23_dx1(k2, k3) + x2*coeff_3_dx1x2(k3)
            end do
        end if

        k2 = 0
    !$omp simd
        do k3 = 0, N3
            coeff_3(k3) = coeff_23(k2, k3) + x2*coeff_3(k3)
            coeff_3_dx1(k3) = coeff_23_dx1(k2, k3) + x2*coeff_3_dx1(k3)
            coeff_3_dx1x1(k3) = coeff_23_dx1x1(k2, k3) + x2*coeff_3_dx1x1(k3)
        end do

        ! Third reduction: x3 interpolation (value, dx1, dx2, dx3, dx1x1, dx1x2, dx1x3)
        y_batch(1) = coeff_3(N3)
        dy_batch(1, 1) = coeff_3_dx1(N3)
        dy_batch(2, 1) = coeff_3_dx2(N3)
        dy_batch(3, 1) = N3*coeff_3(N3)
        d2y_rmix(1, 1) = coeff_3_dx1x1(N3)
        d2y_rmix(2, 1) = coeff_3_dx1x2(N3)
        d2y_rmix(3, 1) = N3*coeff_3_dx1(N3)

        do k3 = N3 - 1, 2, -1
            y_batch(1) = coeff_3(k3) + x3*y_batch(1)
            dy_batch(1, 1) = coeff_3_dx1(k3) + x3*dy_batch(1, 1)
            dy_batch(2, 1) = coeff_3_dx2(k3) + x3*dy_batch(2, 1)
            dy_batch(3, 1) = k3*coeff_3(k3) + x3*dy_batch(3, 1)
            d2y_rmix(1, 1) = coeff_3_dx1x1(k3) + x3*d2y_rmix(1, 1)
            d2y_rmix(2, 1) = coeff_3_dx1x2(k3) + x3*d2y_rmix(2, 1)
            d2y_rmix(3, 1) = k3*coeff_3_dx1(k3) + x3*d2y_rmix(3, 1)
        end do

        if (N3 > 1) then
            k3 = 1
            y_batch(1) = coeff_3(k3) + x3*y_batch(1)
            dy_batch(1, 1) = coeff_3_dx1(k3) + x3*dy_batch(1, 1)
            dy_batch(2, 1) = coeff_3_dx2(k3) + x3*dy_batch(2, 1)
            dy_batch(3, 1) = k3*coeff_3(k3) + x3*dy_batch(3, 1)
            d2y_rmix(1, 1) = coeff_3_dx1x1(k3) + x3*d2y_rmix(1, 1)
            d2y_rmix(2, 1) = coeff_3_dx1x2(k3) + x3*d2y_rmix(2, 1)
            d2y_rmix(3, 1) = k3*coeff_3_dx1(k3) + x3*d2y_rmix(3, 1)
        end if

        k3 = 0
        y_batch(1) = coeff_3(k3) + x3*y_batch(1)
        dy_batch(1, 1) = coeff_3_dx1(k3) + x3*dy_batch(1, 1)
        dy_batch(2, 1) = coeff_3_dx2(k3) + x3*dy_batch(2, 1)
        d2y_rmix(1, 1) = coeff_3_dx1x1(k3) + x3*d2y_rmix(1, 1)
        d2y_rmix(2, 1) = coeff_3_dx1x2(k3) + x3*d2y_rmix(2, 1)
    end subroutine evaluate_batch_splines_3d_der2_core_rmix_nq1

    recursive subroutine evaluate_batch_splines_3d_der2_core_rmix_nq1_o355( &
            spl, x, y_batch, dy_batch, d2y_rmix)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)
        real(dp), intent(out) :: dy_batch(:, :)
        real(dp), intent(out) :: d2y_rmix(:, :)

        integer, parameter :: N2 = 5, N3 = 5
        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3), inv_h_step(3)
        real(dp) :: x1, x2, x3, c
        real(dp) :: c23, c23_dx1, c23_dx1x1
        integer :: interval_index(3), i1, i2, i3, k2, k3, j
        real(dp) :: coeff_3(0:N3), coeff_3_dx1(0:N3)
        real(dp) :: coeff_3_dx2(0:N3), coeff_3_dx1x1(0:N3)
        real(dp) :: coeff_3_dx1x2(0:N3)

        x_min = spl%x_min
        h_step = spl%h_step
        inv_h_step = spl%inv_h_step
        period = spl%period

#include "spline3d_o555_point_setup.inc"

        do k3 = 0, N3
            do k2 = N2, 0, -1
                c = spl%coeff(1, 3, k2, k3, i1, i2, i3)
                c23 = c
                c23_dx1 = 3.0_dp*c
                c23_dx1x1 = 6.0_dp*c

                c = spl%coeff(1, 2, k2, k3, i1, i2, i3)
                c23 = c + x1*c23
                c23_dx1 = 2.0_dp*c + x1*c23_dx1
                c23_dx1x1 = 2.0_dp*c + x1*c23_dx1x1

                c = spl%coeff(1, 1, k2, k3, i1, i2, i3)
                c23 = c + x1*c23
                c23_dx1 = c + x1*c23_dx1

                c = spl%coeff(1, 0, k2, k3, i1, i2, i3)
                c23 = c + x1*c23

                if (k2 == N2) then
                    coeff_3(k3) = c23
                    coeff_3_dx1(k3) = c23_dx1
                    coeff_3_dx1x1(k3) = c23_dx1x1
                    coeff_3_dx2(k3) = real(N2, dp)*c23
                    coeff_3_dx1x2(k3) = real(N2, dp)*c23_dx1
                else
                    coeff_3(k3) = c23 + x2*coeff_3(k3)
                    coeff_3_dx1(k3) = c23_dx1 + x2*coeff_3_dx1(k3)
                    coeff_3_dx1x1(k3) = c23_dx1x1 + &
                        x2*coeff_3_dx1x1(k3)
                    if (k2 > 0) then
                        coeff_3_dx2(k3) = real(k2, dp)*c23 + &
                            x2*coeff_3_dx2(k3)
                        coeff_3_dx1x2(k3) = real(k2, dp)*c23_dx1 + &
                            x2*coeff_3_dx1x2(k3)
                    end if
                end if
            end do
        end do

#define D2_11 d2y_rmix(1, 1)
#define D2_12 d2y_rmix(2, 1)
#define D2_13 d2y_rmix(3, 1)

#include "spline3d_o555_k3_reduce_nq1.inc"

#undef D2_11
#undef D2_12
#undef D2_13
    end subroutine evaluate_batch_splines_3d_der2_core_rmix_nq1_o355

    recursive subroutine evaluate_batch_splines_3d_der2_core_rmix_nq1_o555( &
        spl, x, y_batch, dy_batch, d2y_rmix)
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)      ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)   ! (3, n_quantities)
        real(dp), intent(out) :: d2y_rmix(:, :)   ! (3, n_quantities)

        integer, parameter :: N1 = 5, N2 = 5, N3 = 5

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3), inv_h_step(3)
        real(dp) :: x1, x2, x3
        integer :: interval_index(3)
        integer :: i1, i2, i3
        integer :: k2, k3, j
        real(dp) :: c

        real(dp) :: coeff_23(0:N2, 0:N3)
        real(dp) :: coeff_23_dx1(0:N2, 0:N3)
        real(dp) :: coeff_23_dx1x1(0:N2, 0:N3)

        real(dp) :: coeff_3(0:N3)
        real(dp) :: coeff_3_dx1(0:N3)
        real(dp) :: coeff_3_dx2(0:N3)
        real(dp) :: coeff_3_dx1x1(0:N3)
        real(dp) :: coeff_3_dx1x2(0:N3)

        x_min = spl%x_min
        h_step = spl%h_step
        inv_h_step = spl%inv_h_step
        period = spl%period

#include "spline3d_o555_point_setup.inc"

#include "spline3d_o555_k1_reduce_nq1.inc"

#define D2_11 d2y_rmix(1, 1)
#define D2_12 d2y_rmix(2, 1)
#define D2_13 d2y_rmix(3, 1)

#include "spline3d_o555_k2_reduce_nq1.inc"
#include "spline3d_o555_k3_reduce_nq1.inc"

#undef D2_11
#undef D2_12
#undef D2_13
    end subroutine evaluate_batch_splines_3d_der2_core_rmix_nq1_o555

    recursive subroutine evaluate_batch_splines_3d_der2_core_rmix_o555(spl, x, y_batch, &
                                                             dy_batch, d2y_rmix)
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)      ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)   ! (3, n_quantities)
        real(dp), intent(out) :: d2y_rmix(:, :)   ! (3, n_quantities)

        integer, parameter :: N1 = 5, N2 = 5, N3 = 5

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3), inv_h_step(3)
        real(dp) :: x1, x2, x3
        integer :: interval_index(3)
        integer :: i1, i2, i3
        integer :: k2, k3, j, iq
        integer :: NQ
        real(dp) :: c

        real(dp) :: coeff_23(MAX_QUANTITIES, 0:N2, 0:N3)
        real(dp) :: coeff_23_dx1(MAX_QUANTITIES, 0:N2, 0:N3)
        real(dp) :: coeff_23_dx1x1(MAX_QUANTITIES, 0:N2, 0:N3)

        real(dp) :: coeff_3(MAX_QUANTITIES, 0:N3)
        real(dp) :: coeff_3_dx1(MAX_QUANTITIES, 0:N3)
        real(dp) :: coeff_3_dx2(MAX_QUANTITIES, 0:N3)
        real(dp) :: coeff_3_dx1x1(MAX_QUANTITIES, 0:N3)
        real(dp) :: coeff_3_dx1x2(MAX_QUANTITIES, 0:N3)

        NQ = spl%num_quantities

        x_min = spl%x_min
        h_step = spl%h_step
        inv_h_step = spl%inv_h_step
        period = spl%period

#include "spline3d_o555_point_setup.inc"

#include "spline3d_o555_k1_reduce_many.inc"

#define D2_11(iq) d2y_rmix(1, iq)
#define D2_12(iq) d2y_rmix(2, iq)
#define D2_13(iq) d2y_rmix(3, iq)

#include "spline3d_o555_k2_reduce_many.inc"
#include "spline3d_o555_k3_reduce_many.inc"

#undef D2_11
#undef D2_12
#undef D2_13
    end subroutine evaluate_batch_splines_3d_der2_core_rmix_o555

    recursive subroutine evaluate_batch_splines_3d_der2_core_nq1_o355( &
            spl, x, y_batch, dy_batch, d2y_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)
        real(dp), intent(out) :: dy_batch(:, :)
        real(dp), intent(out) :: d2y_batch(:, :)

        integer, parameter :: N2 = 5, N3 = 5
        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3), inv_h_step(3)
        real(dp) :: x1, x2, x3, c
        real(dp) :: c23, c23_dx1, c23_dx1x1
        integer :: interval_index(3), i1, i2, i3, k2, k3, j
        real(dp) :: coeff_3(0:N3), coeff_3_dx1(0:N3)
        real(dp) :: coeff_3_dx2(0:N3), coeff_3_dx1x1(0:N3)
        real(dp) :: coeff_3_dx1x2(0:N3), coeff_3_dx2x2(0:N3)

        x_min = spl%x_min
        h_step = spl%h_step
        inv_h_step = spl%inv_h_step
        period = spl%period

#include "spline3d_o555_point_setup.inc"

        ! Fuse the radial and theta reductions so the device routine retains
        ! six length-6 phi vectors instead of three 6-by-6 coefficient planes.
        do k3 = 0, N3
            do k2 = N2, 0, -1
                c = spl%coeff(1, 3, k2, k3, i1, i2, i3)
                c23 = c
                c23_dx1 = 3.0_dp*c
                c23_dx1x1 = 6.0_dp*c

                c = spl%coeff(1, 2, k2, k3, i1, i2, i3)
                c23 = c + x1*c23
                c23_dx1 = 2.0_dp*c + x1*c23_dx1
                c23_dx1x1 = 2.0_dp*c + x1*c23_dx1x1

                c = spl%coeff(1, 1, k2, k3, i1, i2, i3)
                c23 = c + x1*c23
                c23_dx1 = c + x1*c23_dx1

                c = spl%coeff(1, 0, k2, k3, i1, i2, i3)
                c23 = c + x1*c23

                if (k2 == N2) then
                    coeff_3(k3) = c23
                    coeff_3_dx1(k3) = c23_dx1
                    coeff_3_dx1x1(k3) = c23_dx1x1
                    coeff_3_dx2(k3) = real(N2, dp)*c23
                    coeff_3_dx1x2(k3) = real(N2, dp)*c23_dx1
                    coeff_3_dx2x2(k3) = real(N2*(N2 - 1), dp)*c23
                else
                    coeff_3(k3) = c23 + x2*coeff_3(k3)
                    coeff_3_dx1(k3) = c23_dx1 + x2*coeff_3_dx1(k3)
                    coeff_3_dx1x1(k3) = c23_dx1x1 + &
                        x2*coeff_3_dx1x1(k3)
                    if (k2 > 0) then
                        coeff_3_dx2(k3) = real(k2, dp)*c23 + &
                            x2*coeff_3_dx2(k3)
                        coeff_3_dx1x2(k3) = real(k2, dp)*c23_dx1 + &
                            x2*coeff_3_dx1x2(k3)
                    end if
                    if (k2 > 1) then
                        coeff_3_dx2x2(k3) = real(k2*(k2 - 1), dp)*c23 + &
                            x2*coeff_3_dx2x2(k3)
                    end if
                end if
            end do
        end do

#define SPLINE3D_O555_FULL_D2 1
#define D2_11 d2y_batch(1, 1)
#define D2_12 d2y_batch(2, 1)
#define D2_13 d2y_batch(3, 1)
#define D2_22 d2y_batch(4, 1)
#define D2_23 d2y_batch(5, 1)
#define D2_33 d2y_batch(6, 1)

#include "spline3d_o555_k3_reduce_nq1.inc"

#undef SPLINE3D_O555_FULL_D2
#undef D2_11
#undef D2_12
#undef D2_13
#undef D2_22
#undef D2_23
#undef D2_33
    end subroutine evaluate_batch_splines_3d_der2_core_nq1_o355

    recursive subroutine evaluate_batch_splines_3d_der2_core_nq1_o555(spl, x, y_batch, &
                                                            dy_batch, d2y_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)      ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)   ! (3, n_quantities)
        real(dp), intent(out) :: d2y_batch(:, :)  ! (6, n_quantities)

        integer, parameter :: N1 = 5, N2 = 5, N3 = 5

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3), inv_h_step(3)
        real(dp) :: x1, x2, x3
        integer :: interval_index(3)
        integer :: i1, i2, i3
        integer :: k2, k3, j
        real(dp) :: c

        real(dp) :: coeff_23(0:N2, 0:N3)
        real(dp) :: coeff_23_dx1(0:N2, 0:N3)
        real(dp) :: coeff_23_dx1x1(0:N2, 0:N3)

        real(dp) :: coeff_3(0:N3)
        real(dp) :: coeff_3_dx1(0:N3)
        real(dp) :: coeff_3_dx2(0:N3)
        real(dp) :: coeff_3_dx1x1(0:N3)
        real(dp) :: coeff_3_dx1x2(0:N3)
        real(dp) :: coeff_3_dx2x2(0:N3)

        x_min = spl%x_min
        h_step = spl%h_step
        inv_h_step = spl%inv_h_step
        period = spl%period

#include "spline3d_o555_point_setup.inc"

#include "spline3d_o555_k1_reduce_nq1.inc"

#define SPLINE3D_O555_FULL_D2 1
#define D2_11 d2y_batch(1, 1)
#define D2_12 d2y_batch(2, 1)
#define D2_13 d2y_batch(3, 1)
#define D2_22 d2y_batch(4, 1)
#define D2_23 d2y_batch(5, 1)
#define D2_33 d2y_batch(6, 1)

#include "spline3d_o555_k2_reduce_nq1.inc"
#include "spline3d_o555_k3_reduce_nq1.inc"

#undef SPLINE3D_O555_FULL_D2
#undef D2_11
#undef D2_12
#undef D2_13
#undef D2_22
#undef D2_23
#undef D2_33
    end subroutine evaluate_batch_splines_3d_der2_core_nq1_o555

    recursive subroutine evaluate_batch_splines_3d_der2_core_o555(spl, x, y_batch, dy_batch, &
                                                        d2y_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)      ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)   ! (3, n_quantities)
        real(dp), intent(out) :: d2y_batch(:, :)  ! (6, n_quantities)

        integer, parameter :: N1 = 5, N2 = 5, N3 = 5

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3), inv_h_step(3)
        real(dp) :: x1, x2, x3
        integer :: interval_index(3)
        integer :: i1, i2, i3
        integer :: k2, k3, j, iq
        integer :: NQ
        real(dp) :: c

        real(dp) :: coeff_23(MAX_QUANTITIES, 0:N2, 0:N3)
        real(dp) :: coeff_23_dx1(MAX_QUANTITIES, 0:N2, 0:N3)
        real(dp) :: coeff_23_dx1x1(MAX_QUANTITIES, 0:N2, 0:N3)

        real(dp) :: coeff_3(MAX_QUANTITIES, 0:N3)
        real(dp) :: coeff_3_dx1(MAX_QUANTITIES, 0:N3)
        real(dp) :: coeff_3_dx2(MAX_QUANTITIES, 0:N3)
        real(dp) :: coeff_3_dx1x1(MAX_QUANTITIES, 0:N3)
        real(dp) :: coeff_3_dx1x2(MAX_QUANTITIES, 0:N3)
        real(dp) :: coeff_3_dx2x2(MAX_QUANTITIES, 0:N3)

        NQ = spl%num_quantities

        x_min = spl%x_min
        h_step = spl%h_step
        inv_h_step = spl%inv_h_step
        period = spl%period

#include "spline3d_o555_point_setup.inc"

#include "spline3d_o555_k1_reduce_many.inc"

#define SPLINE3D_O555_FULL_D2 1
#define D2_11(iq) d2y_batch(1, iq)
#define D2_12(iq) d2y_batch(2, iq)
#define D2_13(iq) d2y_batch(3, iq)
#define D2_22(iq) d2y_batch(4, iq)
#define D2_23(iq) d2y_batch(5, iq)
#define D2_33(iq) d2y_batch(6, iq)

#include "spline3d_o555_k2_reduce_many.inc"
#include "spline3d_o555_k3_reduce_many.inc"

#undef SPLINE3D_O555_FULL_D2
#undef D2_11
#undef D2_12
#undef D2_13
#undef D2_22
#undef D2_23
#undef D2_33
    end subroutine evaluate_batch_splines_3d_der2_core_o555

    recursive subroutine evaluate_batch_splines_3d_der2_core_general(spl, x, y_batch, &
                                                           dy_batch, d2y_batch)
        !$acc routine seq
        type(BatchSplineData3D), intent(in) :: spl
        real(dp), intent(in) :: x(3)
        real(dp), intent(out) :: y_batch(:)      ! (n_quantities)
        real(dp), intent(out) :: dy_batch(:, :)   ! (3, n_quantities)
        real(dp), intent(out) :: d2y_batch(:, :)  ! (6, n_quantities)

        real(dp) :: x_norm(3), x_local(3), xj
        real(dp) :: period(3), x_min(3), h_step(3)
        ! Fixed-size arrays to avoid heap allocation (stack only)
        real(dp) :: coeff_23(MAX_QUANTITIES, 0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_23_dx1(MAX_QUANTITIES, 0:MAX_ORDER, 0:MAX_ORDER)
        real(dp) :: coeff_23_dx1x1(MAX_QUANTITIES, 0:MAX_ORDER, 0:MAX_ORDER)

        real(dp) :: coeff_3(MAX_QUANTITIES, 0:MAX_ORDER)
        real(dp) :: coeff_3_dx1(MAX_QUANTITIES, 0:MAX_ORDER)
        real(dp) :: coeff_3_dx2(MAX_QUANTITIES, 0:MAX_ORDER)
        real(dp) :: coeff_3_dx1x1(MAX_QUANTITIES, 0:MAX_ORDER)
        real(dp) :: coeff_3_dx1x2(MAX_QUANTITIES, 0:MAX_ORDER)
        real(dp) :: coeff_3_dx2x2(MAX_QUANTITIES, 0:MAX_ORDER)

        integer :: interval_index(3), k1, k2, k3, j, iq
        integer :: N1, N2, N3, NQ
        integer :: i1, i2, i3
        real(dp) :: c  ! Temporary variable for coefficient reuse

        N1 = spl%order(1)
        N2 = spl%order(2)
        N3 = spl%order(3)
        NQ = spl%num_quantities

        x_min = spl%x_min
        h_step = spl%h_step
        period(1) = h_step(1)*real(spl%num_points(1) - 1, dp)
        period(2) = h_step(2)*real(spl%num_points(2) - 1, dp)
        period(3) = h_step(3)*real(spl%num_points(3) - 1, dp)

        do j = 1, 3
            if (spl%periodic(j)) then
                xj = x(j)
                if (xj < x_min(j) .or. xj >= x_min(j) + period(j)) then
                    xj = modulo(xj - x_min(j), period(j)) + x_min(j)
                end if
            else
                xj = x(j)
            end if
            x_norm(j) = (xj - x_min(j))/h_step(j)
            interval_index(j) = max(0, min(spl%num_points(j) - 2, int(x_norm(j))))
            x_local(j) = (x_norm(j) - real(interval_index(j), dp))*h_step(j)
        end do

        i1 = interval_index(1) + 1
        i2 = interval_index(2) + 1
        i3 = interval_index(3) + 1

        ! First reduction: x1 interpolation with fused derivative computation
        ! Initialize all polynomials with highest order coefficient (k1 = N1)
        do k3 = 0, N3
            do k2 = 0, N2
    !$omp simd
                do iq = 1, NQ
                    c = spl%coeff(iq, N1, k2, k3, i1, i2, i3)
                    coeff_23(iq, k2, k3) = c
                    coeff_23_dx1(iq, k2, k3) = N1*c
                    coeff_23_dx1x1(iq, k2, k3) = N1*(N1 - 1)*c
                end do
            end do
        end do

        ! Fused backward Horner: compute all derivatives simultaneously
        ! Range k1 = N1-1 down to 2: update all three polynomials
        do k1 = N1 - 1, 2, -1
            do k3 = 0, N3
                do k2 = 0, N2
    !$omp simd
                    do iq = 1, NQ
                        c = spl%coeff(iq, k1, k2, k3, i1, i2, i3)
                        coeff_23(iq, k2, k3) = c + x_local(1)*coeff_23(iq, k2, k3)
                        coeff_23_dx1(iq, k2, k3) = k1*c + &
                                                   x_local(1)*coeff_23_dx1(iq, k2, k3)
                        coeff_23_dx1x1(iq, k2, k3) = k1*(k1 - 1)*c + &
                                                     x_local(1)*coeff_23_dx1x1(iq, k2, &
                                                                               k3)
                    end do
                end do
            end do
        end do

        ! k1 = 1: update value and first derivative only
        if (N1 > 1) then
            k1 = 1
            do k3 = 0, N3
                do k2 = 0, N2
    !$omp simd
                    do iq = 1, NQ
                        c = spl%coeff(iq, k1, k2, k3, i1, i2, i3)
                        coeff_23(iq, k2, k3) = c + x_local(1)*coeff_23(iq, k2, k3)
                        coeff_23_dx1(iq, k2, k3) = k1*c + &
                                                   x_local(1)*coeff_23_dx1(iq, k2, k3)
                    end do
                end do
            end do
        end if

        ! k1 = 0: update value only
        k1 = 0
        do k3 = 0, N3
            do k2 = 0, N2
    !$omp simd
                do iq = 1, NQ
                    c = spl%coeff(iq, k1, k2, k3, i1, i2, i3)
                    coeff_23(iq, k2, k3) = c + x_local(1)*coeff_23(iq, k2, k3)
                end do
            end do
        end do

        ! Second reduction: x2 interpolation with fused derivative computation
        ! Initialize all polynomials with highest order coefficient (k2 = N2)
        do k3 = 0, N3
    !$omp simd
            do iq = 1, NQ
                coeff_3(iq, k3) = coeff_23(iq, N2, k3)
                coeff_3_dx1(iq, k3) = coeff_23_dx1(iq, N2, k3)
                coeff_3_dx1x1(iq, k3) = coeff_23_dx1x1(iq, N2, k3)
                coeff_3_dx2(iq, k3) = N2*coeff_23(iq, N2, k3)
                coeff_3_dx1x2(iq, k3) = N2*coeff_23_dx1(iq, N2, k3)
                coeff_3_dx2x2(iq, k3) = N2*(N2 - 1)*coeff_23(iq, N2, k3)
            end do
        end do

        ! Fused backward Horner: update all polynomials simultaneously
        ! Range k2 = N2-1 down to 2: update all six polynomials
        do k2 = N2 - 1, 2, -1
            do k3 = 0, N3
    !$omp simd
                do iq = 1, NQ
                    coeff_3(iq, k3) = coeff_23(iq, k2, k3) + &
                                      x_local(2)*coeff_3(iq, k3)
                    coeff_3_dx1(iq, k3) = coeff_23_dx1(iq, k2, k3) + &
                                          x_local(2)*coeff_3_dx1(iq, k3)
                    coeff_3_dx1x1(iq, k3) = coeff_23_dx1x1(iq, k2, k3) + &
                                            x_local(2)*coeff_3_dx1x1(iq, k3)
                    coeff_3_dx2(iq, k3) = k2*coeff_23(iq, k2, k3) + &
                                          x_local(2)*coeff_3_dx2(iq, k3)
                    coeff_3_dx1x2(iq, k3) = k2*coeff_23_dx1(iq, k2, k3) + &
                                            x_local(2)*coeff_3_dx1x2(iq, k3)
                    coeff_3_dx2x2(iq, k3) = k2*(k2 - 1)*coeff_23(iq, k2, k3) + &
                                            x_local(2)*coeff_3_dx2x2(iq, k3)
                end do
            end do
        end do

        ! k2 = 1: update value, dx1, dx1x1, dx2, dx1x2 only
        if (N2 > 1) then
            k2 = 1
            do k3 = 0, N3
    !$omp simd
                do iq = 1, NQ
                    coeff_3(iq, k3) = coeff_23(iq, k2, k3) + &
                                      x_local(2)*coeff_3(iq, k3)
                    coeff_3_dx1(iq, k3) = coeff_23_dx1(iq, k2, k3) + &
                                          x_local(2)*coeff_3_dx1(iq, k3)
                    coeff_3_dx1x1(iq, k3) = coeff_23_dx1x1(iq, k2, k3) + &
                                            x_local(2)*coeff_3_dx1x1(iq, k3)
                    coeff_3_dx2(iq, k3) = k2*coeff_23(iq, k2, k3) + &
                                          x_local(2)*coeff_3_dx2(iq, k3)
                    coeff_3_dx1x2(iq, k3) = k2*coeff_23_dx1(iq, k2, k3) + &
                                            x_local(2)*coeff_3_dx1x2(iq, k3)
                end do
            end do
        end if

        ! k2 = 0: update value, dx1, dx1x1 only
        k2 = 0
        do k3 = 0, N3
    !$omp simd
            do iq = 1, NQ
                coeff_3(iq, k3) = coeff_23(iq, k2, k3) + &
                                  x_local(2)*coeff_3(iq, k3)
                coeff_3_dx1(iq, k3) = coeff_23_dx1(iq, k2, k3) + &
                                      x_local(2)*coeff_3_dx1(iq, k3)
                coeff_3_dx1x1(iq, k3) = coeff_23_dx1x1(iq, k2, k3) + &
                                        x_local(2)*coeff_3_dx1x1(iq, k3)
            end do
        end do

        ! Third reduction: x3 interpolation with fused derivative computation
        ! Initialize all outputs with highest order coefficient (k3 = N3)
    !$omp simd
        do iq = 1, NQ
            y_batch(iq) = coeff_3(iq, N3)
            dy_batch(1, iq) = coeff_3_dx1(iq, N3)
            dy_batch(2, iq) = coeff_3_dx2(iq, N3)
            dy_batch(3, iq) = N3*coeff_3(iq, N3)
            d2y_batch(1, iq) = coeff_3_dx1x1(iq, N3)
            d2y_batch(2, iq) = coeff_3_dx1x2(iq, N3)
            d2y_batch(3, iq) = N3*coeff_3_dx1(iq, N3)
            d2y_batch(4, iq) = coeff_3_dx2x2(iq, N3)
            d2y_batch(5, iq) = N3*coeff_3_dx2(iq, N3)
            d2y_batch(6, iq) = N3*(N3 - 1)*coeff_3(iq, N3)
        end do

        ! Fused backward Horner: update all outputs simultaneously
        ! Range k3 = N3-1 down to 2: update all outputs
        do k3 = N3 - 1, 2, -1
    !$omp simd
            do iq = 1, NQ
                y_batch(iq) = coeff_3(iq, k3) + x_local(3)*y_batch(iq)
                dy_batch(1, iq) = coeff_3_dx1(iq, k3) + x_local(3)*dy_batch(1, iq)
                dy_batch(2, iq) = coeff_3_dx2(iq, k3) + x_local(3)*dy_batch(2, iq)
                dy_batch(3, iq) = k3*coeff_3(iq, k3) + x_local(3)*dy_batch(3, iq)
                d2y_batch(1, iq) = coeff_3_dx1x1(iq, k3) + &
                                   x_local(3)*d2y_batch(1, iq)
                d2y_batch(2, iq) = coeff_3_dx1x2(iq, k3) + &
                                   x_local(3)*d2y_batch(2, iq)
                d2y_batch(3, iq) = k3*coeff_3_dx1(iq, k3) + &
                                   x_local(3)*d2y_batch(3, iq)
                d2y_batch(4, iq) = coeff_3_dx2x2(iq, k3) + &
                                   x_local(3)*d2y_batch(4, iq)
                d2y_batch(5, iq) = k3*coeff_3_dx2(iq, k3) + &
                                   x_local(3)*d2y_batch(5, iq)
                d2y_batch(6, iq) = k3*(k3 - 1)*coeff_3(iq, k3) + &
                                   x_local(3)*d2y_batch(6, iq)
            end do
        end do

        ! k3 = 1: update all except d2y_batch(6)
        if (N3 > 1) then
            k3 = 1
    !$omp simd
            do iq = 1, NQ
                y_batch(iq) = coeff_3(iq, k3) + x_local(3)*y_batch(iq)
                dy_batch(1, iq) = coeff_3_dx1(iq, k3) + x_local(3)*dy_batch(1, iq)
                dy_batch(2, iq) = coeff_3_dx2(iq, k3) + x_local(3)*dy_batch(2, iq)
                dy_batch(3, iq) = k3*coeff_3(iq, k3) + x_local(3)*dy_batch(3, iq)
                d2y_batch(1, iq) = coeff_3_dx1x1(iq, k3) + &
                                   x_local(3)*d2y_batch(1, iq)
                d2y_batch(2, iq) = coeff_3_dx1x2(iq, k3) + &
                                   x_local(3)*d2y_batch(2, iq)
                d2y_batch(3, iq) = k3*coeff_3_dx1(iq, k3) + &
                                   x_local(3)*d2y_batch(3, iq)
                d2y_batch(4, iq) = coeff_3_dx2x2(iq, k3) + &
                                   x_local(3)*d2y_batch(4, iq)
                d2y_batch(5, iq) = k3*coeff_3_dx2(iq, k3) + &
                                   x_local(3)*d2y_batch(5, iq)
            end do
        end if

        ! k3 = 0: update value and first-order derivatives only
        k3 = 0
    !$omp simd
        do iq = 1, NQ
            y_batch(iq) = coeff_3(iq, k3) + x_local(3)*y_batch(iq)
            dy_batch(1, iq) = coeff_3_dx1(iq, k3) + x_local(3)*dy_batch(1, iq)
            dy_batch(2, iq) = coeff_3_dx2(iq, k3) + x_local(3)*dy_batch(2, iq)
            d2y_batch(1, iq) = coeff_3_dx1x1(iq, k3) + &
                               x_local(3)*d2y_batch(1, iq)
            d2y_batch(2, iq) = coeff_3_dx1x2(iq, k3) + &
                               x_local(3)*d2y_batch(2, iq)
            d2y_batch(4, iq) = coeff_3_dx2x2(iq, k3) + &
                               x_local(3)*d2y_batch(4, iq)
        end do
    end subroutine evaluate_batch_splines_3d_der2_core_general

end module batch_interpolate_3d
