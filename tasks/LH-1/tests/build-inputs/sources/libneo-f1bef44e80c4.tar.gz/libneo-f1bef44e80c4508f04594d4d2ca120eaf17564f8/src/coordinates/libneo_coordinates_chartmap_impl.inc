
logical function chartmap_trace_once_enabled()
    character(len=32) :: value
    integer :: len_value, status
    logical, save :: used = .false.

    chartmap_trace_once_enabled = .false.
    if (used) return

    call get_environment_variable('LIBNEO_CHARTMAP_TRACE_ONCE', value, &
                                  length=len_value, status=status)
    if (status /= 0 .or. len_value <= 0) return
    if (trim(value(1:len_value)) == '0') return

    used = .true.
    chartmap_trace_once_enabled = .true.
end function chartmap_trace_once_enabled

subroutine chartmap_read_num_field_periods(ncid, num_field_periods)
    integer, intent(in) :: ncid
    integer, intent(out) :: num_field_periods

    integer :: var_num_field_periods
    integer :: var_nfp

    num_field_periods = 1
    if (nf90_inq_varid(ncid, 'num_field_periods', var_num_field_periods) == &
        NF90_NOERR) then
        if (nf90_get_var(ncid, var_num_field_periods, num_field_periods) /= &
            NF90_NOERR) num_field_periods = 1
    else if (nf90_inq_varid(ncid, 'nfp', var_nfp) == NF90_NOERR) then
        if (nf90_get_var(ncid, var_nfp, num_field_periods) /= NF90_NOERR) &
            num_field_periods = 1
    end if
    if (num_field_periods < 1) num_field_periods = 1
end subroutine chartmap_read_num_field_periods

subroutine chartmap_read_zeta_convention(ncid, zeta_convention)
    integer, intent(in) :: ncid
    integer, intent(out) :: zeta_convention

    integer :: status
    integer :: att_type
    integer :: att_len
    character(len=:), allocatable :: value

    zeta_convention = UNKNOWN

    status = nf90_inquire_attribute(ncid, NF90_GLOBAL, 'zeta_convention', &
                                    xtype=att_type, len=att_len)
    if (status /= NF90_NOERR) return
    if (att_type /= NF90_CHAR .or. att_len < 1) return

    allocate (character(len=att_len) :: value)
    status = nf90_get_att(ncid, NF90_GLOBAL, 'zeta_convention', value)
    if (status /= NF90_NOERR) return

    select case (trim(value))
    case ('cyl')
        zeta_convention = CYL
    case ('vmec')
        zeta_convention = VMEC
    case ('boozer')
        zeta_convention = BOOZER
    case default
        zeta_convention = UNKNOWN
    end select
end subroutine chartmap_read_zeta_convention

subroutine chartmap_read_rho_convention(ncid, rho_convention)
    integer, intent(in) :: ncid
    integer, intent(out) :: rho_convention

    integer :: status
    integer :: att_type
    integer :: att_len
    character(len=:), allocatable :: value

    rho_convention = UNKNOWN

    status = nf90_inquire_attribute(ncid, NF90_GLOBAL, 'rho_convention', &
                                    xtype=att_type, len=att_len)
    if (status /= NF90_NOERR) return
    if (att_type /= NF90_CHAR .or. att_len < 1) return

    allocate (character(len=att_len) :: value)
    status = nf90_get_att(ncid, NF90_GLOBAL, 'rho_convention', value)
    if (status /= NF90_NOERR) return

    select case (trim(value))
    case ('rho_tor')
        rho_convention = RHO_TOR
    case ('rho_pol')
        rho_convention = RHO_POL
    case ('psi_tor_norm', 's')
        rho_convention = PSI_TOR_NORM
    case ('psi_pol_norm')
        rho_convention = PSI_POL_NORM
    case default
        rho_convention = UNKNOWN
    end select
end subroutine chartmap_read_rho_convention

subroutine chartmap_extend_theta(nrho, ntheta, nzeta, theta, x, y, z, theta_spl, &
                                 x2, y2, z2)
    integer, intent(in) :: nrho, ntheta, nzeta
    real(dp), intent(in) :: theta(ntheta)
    real(dp), intent(in) :: x(nrho, ntheta, nzeta), y(nrho, ntheta, nzeta), &
                            z(nrho, ntheta, nzeta)
    real(dp), allocatable, intent(out) :: theta_spl(:)
    real(dp), allocatable, intent(out) :: x2(:, :, :), y2(:, :, :), z2(:, :, :)

    allocate (theta_spl(ntheta + 1))
    theta_spl(1:ntheta) = theta
    theta_spl(ntheta + 1) = theta(1) + TWOPI

    allocate (x2(nrho, ntheta + 1, nzeta))
    allocate (y2(nrho, ntheta + 1, nzeta))
    allocate (z2(nrho, ntheta + 1, nzeta))
    x2(:, 1:ntheta, :) = x
    y2(:, 1:ntheta, :) = y
    z2(:, 1:ntheta, :) = z
    x2(:, ntheta + 1, :) = x(:, 1, :)
    y2(:, ntheta + 1, :) = y(:, 1, :)
    z2(:, ntheta + 1, :) = z(:, 1, :)
end subroutine chartmap_extend_theta

subroutine chartmap_extend_zeta(nrho, ntheta, nzeta, zeta, zeta_period, x, y, z, &
                                zeta_spl, &
                                x2, y2, z2)
    integer, intent(in) :: nrho, ntheta, nzeta
    real(dp), intent(in) :: zeta(nzeta)
    real(dp), intent(in) :: zeta_period
    real(dp), intent(in) :: x(nrho, ntheta, nzeta), y(nrho, ntheta, nzeta), &
                            z(nrho, ntheta, nzeta)
    real(dp), allocatable, intent(out) :: zeta_spl(:)
    real(dp), allocatable, intent(out) :: x2(:, :, :), y2(:, :, :), z2(:, :, :)

    allocate (zeta_spl(nzeta + 1))
    zeta_spl(1:nzeta) = zeta
    zeta_spl(nzeta + 1) = zeta(1) + zeta_period

    allocate (x2(nrho, ntheta, nzeta + 1))
    allocate (y2(nrho, ntheta, nzeta + 1))
    allocate (z2(nrho, ntheta, nzeta + 1))
    x2(:, :, 1:nzeta) = x
    y2(:, :, 1:nzeta) = y
    z2(:, :, 1:nzeta) = z
    x2(:, :, nzeta + 1) = x(:, :, 1)
    y2(:, :, nzeta + 1) = y(:, :, 1)
    z2(:, :, nzeta + 1) = z(:, :, 1)
end subroutine chartmap_extend_zeta

subroutine chartmap_extend_theta_rz(nrho, ntheta, nzeta, theta, r, zc, theta_spl, &
                                    r2, z2)
    integer, intent(in) :: nrho, ntheta, nzeta
    real(dp), intent(in) :: theta(ntheta)
    real(dp), intent(in) :: r(nrho, ntheta, nzeta), zc(nrho, ntheta, nzeta)
    real(dp), allocatable, intent(out) :: theta_spl(:)
    real(dp), allocatable, intent(out) :: r2(:, :, :), z2(:, :, :)

    allocate (theta_spl(ntheta + 1))
    theta_spl(1:ntheta) = theta
    theta_spl(ntheta + 1) = theta(1) + TWOPI

    allocate (r2(nrho, ntheta + 1, nzeta))
    allocate (z2(nrho, ntheta + 1, nzeta))
    r2(:, 1:ntheta, :) = r
    z2(:, 1:ntheta, :) = zc
    r2(:, ntheta + 1, :) = r(:, 1, :)
    z2(:, ntheta + 1, :) = zc(:, 1, :)
end subroutine chartmap_extend_theta_rz

subroutine chartmap_extend_zeta_rz(nrho, ntheta, nzeta, zeta, zeta_period, r, zc, &
                                   zeta_spl, &
                                   r2, z2)
    integer, intent(in) :: nrho, ntheta, nzeta
    real(dp), intent(in) :: zeta(nzeta)
    real(dp), intent(in) :: zeta_period
    real(dp), intent(in) :: r(nrho, ntheta, nzeta), zc(nrho, ntheta, nzeta)
    real(dp), allocatable, intent(out) :: zeta_spl(:)
    real(dp), allocatable, intent(out) :: r2(:, :, :), z2(:, :, :)

    allocate (zeta_spl(nzeta + 1))
    zeta_spl(1:nzeta) = zeta
    zeta_spl(nzeta + 1) = zeta(1) + zeta_period

    allocate (r2(nrho, ntheta, nzeta + 1))
    allocate (z2(nrho, ntheta, nzeta + 1))
    r2(:, :, 1:nzeta) = r
    z2(:, :, 1:nzeta) = zc
    r2(:, :, nzeta + 1) = r(:, :, 1)
    z2(:, :, nzeta + 1) = zc(:, :, 1)
end subroutine chartmap_extend_zeta_rz

subroutine chartmap_eval_cart(self, u, vals)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: u(3)
    real(dp), intent(out) :: vals(3)

    real(dp) :: rz(2)
    real(dp) :: phi
    real(dp) :: phi_mod
    real(dp) :: zeta_period
    real(dp) :: u_eval(3)
    real(dp) :: x_min(3), x_max(3)

    if (self%has_spl_rz) then
        x_min = self%spl_rz%x_min
        x_max = self%spl_rz%x_min + self%spl_rz%h_step * &
                real(self%spl_rz%num_points - 1, dp)
    else
        x_min = self%spl_cart%x_min
        x_max = self%spl_cart%x_min + self%spl_cart%h_step * &
                real(self%spl_cart%num_points - 1, dp)
    end if

    u_eval = u
    u_eval(1) = max(x_min(1), min(u_eval(1), x_max(1)))
    u_eval(2) = modulo(u_eval(2) - x_min(2), TWOPI) + x_min(2)
    zeta_period = TWOPI/real(self%num_field_periods, dp)
    u_eval(3) = modulo(u_eval(3) - x_min(3), zeta_period) + x_min(3)

    if (self%has_spl_rz) then
        phi = u_eval(3)
        phi_mod = modulo(phi - self%spl_rz%x_min(3), zeta_period) + &
                  self%spl_rz%x_min(3)
        call evaluate_batch_splines_3d(self%spl_rz, u_eval, rz)
        vals(1) = rz(1)*cos(phi_mod)
        vals(2) = rz(1)*sin(phi_mod)
        vals(3) = rz(2)
    else
        call evaluate_batch_splines_3d(self%spl_cart, u_eval, vals)
    end if
end subroutine chartmap_eval_cart

subroutine chartmap_eval_cart_der(self, u, vals, dvals)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: u(3)
    real(dp), intent(out) :: vals(3)
    real(dp), intent(out) :: dvals(3, 3)

    real(dp) :: rz(2)
    real(dp) :: drz(3, 2)
    real(dp) :: phi
    real(dp) :: phi_mod
    real(dp) :: cph, sph
    real(dp) :: zeta_period
    real(dp) :: u_eval(3)
    real(dp) :: x_min(3), x_max(3)

    if (self%has_spl_rz) then
        x_min = self%spl_rz%x_min
        x_max = self%spl_rz%x_min + self%spl_rz%h_step * &
                real(self%spl_rz%num_points - 1, dp)
    else
        x_min = self%spl_cart%x_min
        x_max = self%spl_cart%x_min + self%spl_cart%h_step * &
                real(self%spl_cart%num_points - 1, dp)
    end if

    u_eval = u
    u_eval(1) = max(x_min(1), min(u_eval(1), x_max(1)))
    u_eval(2) = modulo(u_eval(2) - x_min(2), TWOPI) + x_min(2)
    zeta_period = TWOPI/real(self%num_field_periods, dp)
    u_eval(3) = modulo(u_eval(3) - x_min(3), zeta_period) + x_min(3)

    if (self%has_spl_rz) then
        phi = u_eval(3)
        phi_mod = modulo(phi - self%spl_rz%x_min(3), zeta_period) + &
                  self%spl_rz%x_min(3)
        cph = cos(phi_mod)
        sph = sin(phi_mod)
        call evaluate_batch_splines_3d_der(self%spl_rz, u_eval, rz, drz)

        vals(1) = rz(1)*cph
        vals(2) = rz(1)*sph
        vals(3) = rz(2)

        ! dvals(cart_component, coord_index) = d(x_cart)/d(u_coord)
        ! drz(derivative_dim, quantity) where quantity 1=R, 2=Z
        ! X = R*cos(phi), Y = R*sin(phi), Z = Z

        ! d/drho derivatives:
        dvals(1, 1) = drz(1, 1)*cph        ! dX/drho = dR/drho * cos
        dvals(2, 1) = drz(1, 1)*sph        ! dY/drho = dR/drho * sin
        dvals(3, 1) = drz(1, 2)            ! dZ/drho = dZ/drho

        ! d/dtheta derivatives:
        dvals(1, 2) = drz(2, 1)*cph        ! dX/dtheta = dR/dtheta * cos
        dvals(2, 2) = drz(2, 1)*sph        ! dY/dtheta = dR/dtheta * sin
        dvals(3, 2) = drz(2, 2)            ! dZ/dtheta = dZ/dtheta

        ! d/dphi derivatives:
        dvals(1, 3) = drz(3, 1)*cph - rz(1)*sph  ! dX/dphi = dR/dphi*cos - R*sin
        dvals(2, 3) = drz(3, 1)*sph + rz(1)*cph  ! dY/dphi = dR/dphi*sin + R*cos
        dvals(3, 3) = drz(3, 2)            ! dZ/dphi = dZ/dphi
    else
        call evaluate_batch_splines_3d_der(self%spl_cart, u_eval, vals, dvals)
        ! batch der returns dvals(deriv_dim, quantity); transpose to the documented
        ! dvals(cart_component, coord_index) = d x_i / d u_k (see the .f90 twin).
        dvals = transpose(dvals)
    end if
end subroutine chartmap_eval_cart_der

subroutine make_chartmap_coordinate_system(cs, filename)
    class(coordinate_system_t), allocatable, intent(out) :: cs
    character(len=*), intent(in) :: filename

    allocate (chartmap_coordinate_system_t :: cs)

    select type (ccs => cs)
    type is (chartmap_coordinate_system_t)
        call initialize_chartmap(ccs, filename)
    class default
        error stop "make_chartmap_coordinate_system: allocation failed"
    end select
end subroutine make_chartmap_coordinate_system

subroutine initialize_chartmap(ccs, filename)
    type(chartmap_coordinate_system_t), intent(inout) :: ccs
    character(len=*), intent(in) :: filename

    integer :: ncid
    integer :: ierr
    integer :: len_rho, len_theta, len_zeta
    integer :: nrho, ntheta, nzeta
    character(len=2048) :: message
    real(dp), allocatable :: rho(:), theta(:), zeta(:)
    real(dp), allocatable :: x(:, :, :), y(:, :, :), z(:, :, :)
    real(dp), allocatable :: pos_batch(:, :, :, :)
    real(dp), allocatable :: pos_rz(:, :, :, :)
    real(dp), allocatable :: r(:, :, :), zc(:, :, :)
    real(dp), allocatable :: theta_spl(:), zeta_spl(:)
    real(dp), allocatable :: x_th(:, :, :), y_th(:, :, :), z_th(:, :, :)
    real(dp), allocatable :: x_spl(:, :, :), y_spl(:, :, :), z_spl(:, :, :)
    real(dp), allocatable :: r_th(:, :, :), z_th_rz(:, :, :)
    real(dp), allocatable :: r_spl(:, :, :), z_spl_rz(:, :, :)
    real(dp) :: x_min(3), x_max(3)
    real(dp) :: x_min_rz(3), x_max_rz(3)
    real(dp) :: zeta_period
    logical :: periodic_cart(3)
    logical :: periodic_rz(3)
    integer :: order(3)
    integer :: num_field_periods
    integer :: zeta_convention
    integer :: rho_convention

    call validate_chartmap_file(trim(filename), ierr, message)
    if (ierr /= 0) then
        print *, "initialize_chartmap: invalid chartmap file"
        print *, trim(message)
        error stop
    end if

    call nc_open(trim(filename), ncid)

    call nc_inq_dim(ncid, 'rho', len_rho)
    call nc_inq_dim(ncid, 'theta', len_theta)
    call nc_inq_dim(ncid, 'zeta', len_zeta)

    nrho = len_rho
    ntheta = len_theta
    nzeta = len_zeta

    allocate (rho(nrho), theta(ntheta), zeta(nzeta))
    call nc_get(ncid, 'rho', rho)
    call nc_get(ncid, 'theta', theta)
    call nc_get(ncid, 'zeta', zeta)

    allocate (x(nrho, ntheta, nzeta))
    allocate (y(nrho, ntheta, nzeta))
    allocate (z(nrho, ntheta, nzeta))
    call nc_get(ncid, 'x', x)
    call nc_get(ncid, 'y', y)
    call nc_get(ncid, 'z', z)
    call chartmap_read_num_field_periods(ncid, num_field_periods)
    call chartmap_read_zeta_convention(ncid, zeta_convention)
    call chartmap_read_rho_convention(ncid, rho_convention)
    call nc_close(ncid)

    if (num_field_periods == 1 .and. nzeta >= 2) then
        block
            real(dp) :: dz, period_est, nfp_est_real
            integer :: nfp_est

            dz = zeta(2) - zeta(1)
            period_est = (zeta(nzeta) - zeta(1)) + dz
            if (period_est > 0.0_dp) then
                nfp_est_real = TWOPI/period_est
                nfp_est = max(1, nint(nfp_est_real))
                if (abs(nfp_est_real - real(nfp_est, dp)) < 0.25_dp) then
                    num_field_periods = nfp_est
                end if
            end if
        end block
    end if

    order = [3, 3, 3]

    periodic_cart = [.false., .true., .false.]
    periodic_rz = [.false., .true., .false.]

    ccs%num_field_periods = num_field_periods
    ccs%zeta_convention = zeta_convention
    ccs%rho_convention = rho_convention
    zeta_period = TWOPI/real(num_field_periods, dp)

    if (zeta_convention /= CYL .and. zeta_convention /= VMEC .and. &
        zeta_convention /= BOOZER) then
        print *, "initialize_chartmap: unsupported zeta_convention"
        print *, "  must be cyl, vmec, or boozer"
        error stop
    end if

    if (zeta_convention == CYL .or. zeta_convention == VMEC) then
        if (nzeta < 2) then
            print *, "initialize_chartmap: nzeta must be >= 2 for cyl convention"
            error stop
        end if

        allocate (r(nrho, ntheta, nzeta))
        allocate (zc(nrho, ntheta, nzeta))
        r = sqrt(x**2 + y**2)
        zc = z

        call chartmap_extend_theta_rz(nrho, ntheta, nzeta, theta, r, zc, &
                                      theta_spl, &
                                      r_th, z_th_rz)

        periodic_rz(3) = .true.
        call chartmap_extend_zeta_rz(nrho, ntheta + 1, nzeta, zeta, zeta_period, &
                                     r_th, z_th_rz, zeta_spl, r_spl, z_spl_rz)

        x_min_rz = [rho(1), theta_spl(1), zeta_spl(1)]
        x_max_rz = [rho(nrho), theta_spl(size(theta_spl)), zeta_spl(size(zeta_spl))]

        allocate (pos_rz(nrho, size(theta_spl), size(zeta_spl), 2))
        pos_rz(:, :, :, 1) = r_spl
        pos_rz(:, :, :, 2) = z_spl_rz

        call construct_batch_splines_3d(x_min_rz, x_max_rz, pos_rz, order, &
                                        periodic_rz, &
                                        ccs%spl_rz)
        ccs%has_spl_rz = .true.
    else
        if (nzeta < 2) then
            print *, "initialize_chartmap: nzeta must be >= 2"
            error stop
        end if

        call chartmap_extend_theta(nrho, ntheta, nzeta, theta, x, y, z, theta_spl, &
                                   x_th, y_th, z_th)

        periodic_cart(3) = .true.
        call chartmap_extend_zeta(nrho, ntheta + 1, nzeta, zeta, zeta_period, &
                                  x_th, y_th, z_th, zeta_spl, x_spl, y_spl, z_spl)

        x_min = [rho(1), theta_spl(1), zeta_spl(1)]
        x_max = [rho(nrho), theta_spl(size(theta_spl)), zeta_spl(size(zeta_spl))]

        allocate (pos_batch(nrho, size(theta_spl), size(zeta_spl), 3))
        pos_batch(:, :, :, 1) = x_spl
        pos_batch(:, :, :, 2) = y_spl
        pos_batch(:, :, :, 3) = z_spl

        call construct_batch_splines_3d(x_min, x_max, pos_batch, order, &
                                        periodic_cart, &
                                        ccs%spl_cart)
        ccs%has_spl_rz = .false.
    end if

    ccs%nrho = nrho
    ccs%ntheta = ntheta
    ccs%nzeta = nzeta
end subroutine initialize_chartmap

subroutine chartmap_evaluate_cart(self, u, x)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: u(3)
    real(dp), intent(out) :: x(3)

    call chartmap_eval_cart(self, u, x)
end subroutine chartmap_evaluate_cart

subroutine chartmap_evaluate_cyl(self, u, x)
    use cylindrical_cartesian, only: cart_to_cyl
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: u(3)
    real(dp), intent(out) :: x(3)

    real(dp) :: xcart(3)
    real(dp) :: rz(2)
    real(dp) :: zeta_period

    if (self%has_spl_rz) then
        zeta_period = TWOPI/real(self%num_field_periods, dp)
        call evaluate_batch_splines_3d(self%spl_rz, u, rz)
        x(1) = rz(1)
        x(2) = modulo(u(3), zeta_period)
        x(3) = rz(2)
    else
        call chartmap_eval_cart(self, u, xcart)
        call cart_to_cyl(xcart, x)
    end if
end subroutine chartmap_evaluate_cyl

subroutine chartmap_covariant_basis(self, u, e_cov)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: u(3)
    real(dp), intent(out) :: e_cov(3, 3)

    real(dp) :: vals(3)
    real(dp) :: dvals(3, 3)

    call chartmap_eval_cart_der(self, u, vals, dvals)

    ! e_cov(cart_component, coord_index) = d(x_cart)/d(u_coord)
    ! dvals has the same indexing: dvals(cart_component, coord_index)
    e_cov = dvals
end subroutine chartmap_covariant_basis

subroutine chartmap_metric_tensor(self, u, g, ginv, sqrtg)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: u(3)
    real(dp), intent(out) :: g(3, 3), ginv(3, 3), sqrtg

    real(dp) :: e_cov(3, 3)
    real(dp) :: det
    integer :: i, j

    call self%covariant_basis(u, e_cov)

    do i = 1, 3
        do j = 1, 3
            g(i, j) = dot_product(e_cov(:, i), e_cov(:, j))
        end do
    end do

    det = g(1, 1)*(g(2, 2)*g(3, 3) - g(2, 3)*g(3, 2)) &
          - g(1, 2)*(g(2, 1)*g(3, 3) - g(2, 3)*g(3, 1)) &
          + g(1, 3)*(g(2, 1)*g(3, 2) - g(2, 2)*g(3, 1))

    sqrtg = sqrt(abs(det))

    ginv(1, 1) = (g(2, 2)*g(3, 3) - g(2, 3)*g(3, 2))/det
    ginv(1, 2) = (g(1, 3)*g(3, 2) - g(1, 2)*g(3, 3))/det
    ginv(1, 3) = (g(1, 2)*g(2, 3) - g(1, 3)*g(2, 2))/det
    ginv(2, 1) = (g(2, 3)*g(3, 1) - g(2, 1)*g(3, 3))/det
    ginv(2, 2) = (g(1, 1)*g(3, 3) - g(1, 3)*g(3, 1))/det
    ginv(2, 3) = (g(1, 3)*g(2, 1) - g(1, 1)*g(2, 3))/det
    ginv(3, 1) = (g(2, 1)*g(3, 2) - g(2, 2)*g(3, 1))/det
    ginv(3, 2) = (g(1, 2)*g(3, 1) - g(1, 1)*g(3, 2))/det
    ginv(3, 3) = (g(1, 1)*g(2, 2) - g(1, 2)*g(2, 1))/det
end subroutine chartmap_metric_tensor

subroutine chartmap_from_cyl(self, xcyl, u, ierr)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: xcyl(3)
    real(dp), intent(out) :: u(3)
    integer, intent(out) :: ierr

    real(dp) :: x_target(3), rho_theta(2)
    real(dp) :: zeta
    real(dp) :: zeta_period

    x_target(1) = xcyl(1)*cos(xcyl(2))
    x_target(2) = xcyl(1)*sin(xcyl(2))
    x_target(3) = xcyl(3)

    zeta_period = TWOPI/real(self%num_field_periods, dp)
    if (self%zeta_convention == CYL .or. self%zeta_convention == VMEC) then
        zeta = modulo(xcyl(2), zeta_period)
        call newton_slice(self, x_target, zeta, rho_theta, ierr)
        u(1) = min(max(rho_theta(1), 0.0_dp), 1.0_dp)
        u(2) = modulo(rho_theta(2), TWOPI)
        u(3) = zeta
        return
    end if

    call self%from_cart(x_target, u, ierr)
end subroutine chartmap_from_cyl

subroutine chartmap_from_cart(self, x, u, ierr)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x(3)
    real(dp), intent(out) :: u(3)
    integer, intent(out) :: ierr

    call chartmap_invert_cart(self, x, u, ierr)
end subroutine chartmap_from_cart

subroutine chartmap_invert_cart(self, x_target, u, ierr)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(out) :: u(3)
    integer, intent(out) :: ierr

    real(dp) :: u_try(3)
    real(dp) :: res_norm, best_res
    real(dp) :: zeta_period
    real(dp) :: phi
    real(dp) :: zeta_seed(5)
    logical :: trace
    integer :: k
    integer :: ierr_try

    ierr = chartmap_from_cyl_err_max_iter
    best_res = huge(1.0_dp)
    u = 0.0_dp

    zeta_period = TWOPI/real(self%num_field_periods, dp)
    if (.not. self%has_spl_rz) then
        trace = chartmap_trace_once_enabled()
        call chartmap_initial_guess_cartesian_3d(self, x_target, u_try)
        call chartmap_refine_cart_seed(self, x_target, zeta_period, u_try, &
                                       res_norm, ierr)
        if (ierr == chartmap_from_cyl_ok) then
            call chartmap_solve_cart(self, x_target, u_try(1), u_try(2), u_try(3), &
                                     ierr_try, trace)
            if (ierr_try == chartmap_from_cyl_ok) then
                ierr = chartmap_from_cyl_ok
            end if
        else
            call chartmap_solve_cart(self, x_target, u_try(1), u_try(2), u_try(3), &
                                     ierr_try, trace)
            if (ierr_try == chartmap_from_cyl_ok) ierr = chartmap_from_cyl_ok
        end if
        if (ierr /= chartmap_from_cyl_ok) return
        u = u_try
        u(1) = min(max(u(1), 0.0_dp), 1.0_dp)
        u(2) = modulo(u(2), TWOPI)
        u(3) = modulo(u(3), zeta_period)
        return
    end if

    phi = atan2(x_target(2), x_target(1))
    zeta_seed = [modulo(phi, zeta_period), 0.0_dp, 0.25_dp*zeta_period, &
                 0.50_dp*zeta_period, 0.75_dp*zeta_period]

    trace = chartmap_trace_once_enabled()

    do k = 1, size(zeta_seed)
        call chartmap_try_cart_seed(self, x_target, zeta_seed(k), u_try, res_norm, &
                                    ierr_try, trace .and. k == 1)
        if (ierr_try /= chartmap_from_cyl_ok) cycle
        if (res_norm < best_res) then
            best_res = res_norm
            u = u_try
            ierr = chartmap_from_cyl_ok
        end if
    end do

    if (ierr /= chartmap_from_cyl_ok) return
    u(1) = min(max(u(1), 0.0_dp), 1.0_dp)
    u(2) = modulo(u(2), TWOPI)
    u(3) = modulo(u(3), zeta_period)
end subroutine chartmap_invert_cart

subroutine chartmap_try_cart_seed(self, x_target, zeta_seed, u, res_norm, ierr, &
                                  trace)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(in) :: zeta_seed
    real(dp), intent(out) :: u(3)
    real(dp), intent(out) :: res_norm
    integer, intent(out) :: ierr
    logical, intent(in) :: trace

    real(dp) :: rho, theta, zeta
    real(dp) :: x_round(3)

    zeta = zeta_seed
    call chartmap_initial_guess(self, x_target, zeta, rho, theta, ierr)
    if (ierr /= chartmap_from_cyl_ok) then
        res_norm = huge(1.0_dp)
        u = 0.0_dp
        return
    end if

    call chartmap_solve_cart(self, x_target, rho, theta, zeta, ierr, trace)
    u = [rho, theta, zeta]
    if (ierr /= chartmap_from_cyl_ok) then
        res_norm = huge(1.0_dp)
        return
    end if

    call chartmap_eval_cart(self, u, x_round)
    res_norm = sqrt(sum((x_target - x_round)**2))
end subroutine chartmap_try_cart_seed

subroutine chartmap_solve_cart(self, x_target, rho, theta, zeta, ierr, trace)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(inout) :: rho
    real(dp), intent(inout) :: theta
    real(dp), intent(inout) :: zeta
    integer, intent(out) :: ierr
    logical, intent(in) :: trace

    real(dp) :: delta(3)
    real(dp) :: rho_new, theta_new, zeta_new
    real(dp) :: res_norm, res_norm_new
    real(dp) :: tol_res, tol_step
    real(dp) :: step_norm
    real(dp) :: zeta_period
    integer :: iter
    logical :: success

    ierr = chartmap_from_cyl_ok
    zeta_period = TWOPI/real(self%num_field_periods, dp)
    zeta = modulo(zeta, zeta_period)
    tol_res = max(1.0e-10_dp, self%tol_newton)
    tol_step = max(1.0e-10_dp, self%tol_newton)
    do iter = 1, 60
        call chartmap_newton_delta_cart(self, x_target, rho, theta, zeta, delta, &
                                        res_norm, ierr)
        if (ierr /= chartmap_from_cyl_ok) return
        if (res_norm < tol_res) return
        step_norm = sqrt(sum(delta**2))
        if (step_norm < tol_step) then
            ierr = chartmap_from_cyl_err_max_iter
            return
        end if
        call chartmap_line_search_cart(self, x_target, rho, theta, zeta, &
                                       zeta_period, &
                                       delta, res_norm, rho_new, theta_new, &
                                       zeta_new, &
                                       res_norm_new, success)
        if (.not. success) then
            ierr = chartmap_from_cyl_err_max_iter
            return
        end if
        if (trace) print *, "chartmap_from_cart iter=", iter, " res=", res_norm, &
            " step=", step_norm
        rho = rho_new
        theta = theta_new
        zeta = zeta_new
    end do
    ierr = chartmap_from_cyl_err_max_iter
end subroutine chartmap_solve_cart

subroutine chartmap_newton_delta_cart(self, x_target, rho, theta, zeta, delta, &
                                      res_norm, ierr)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(in) :: rho
    real(dp), intent(in) :: theta
    real(dp), intent(in) :: zeta
    real(dp), intent(out) :: delta(3)
    real(dp), intent(out) :: res_norm
    integer, intent(out) :: ierr

    real(dp) :: residual(3)
    real(dp) :: dx_drho(3), dx_dtheta(3), dx_dzeta(3)
    real(dp) :: jtj(3, 3), jtr(3)

    ierr = chartmap_from_cyl_ok
    delta = 0.0_dp

    call chartmap_eval_residual_and_partials_cart(self, x_target, rho, &
                                                  theta, zeta, &
                                                  residual, res_norm, dx_drho, &
                                                  dx_dtheta, dx_dzeta)

    jtj(1, 1) = dot_product(dx_drho, dx_drho)
    jtj(1, 2) = dot_product(dx_drho, dx_dtheta)
    jtj(1, 3) = dot_product(dx_drho, dx_dzeta)
    jtj(2, 1) = jtj(1, 2)
    jtj(2, 2) = dot_product(dx_dtheta, dx_dtheta)
    jtj(2, 3) = dot_product(dx_dtheta, dx_dzeta)
    jtj(3, 1) = jtj(1, 3)
    jtj(3, 2) = jtj(2, 3)
    jtj(3, 3) = dot_product(dx_dzeta, dx_dzeta)

    jtr(1) = dot_product(dx_drho, residual)
    jtr(2) = dot_product(dx_dtheta, residual)
    jtr(3) = dot_product(dx_dzeta, residual)

    call chartmap_solve_normal_eq3(jtj, jtr, delta, ierr)
end subroutine chartmap_newton_delta_cart

subroutine chartmap_eval_residual_and_partials_cart(self, x_target, rho, &
                                                    theta, zeta, &
                                                    residual, res_norm, dx_drho, &
                                                    dx_dtheta, dx_dzeta)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(in) :: rho
    real(dp), intent(in) :: theta
    real(dp), intent(in) :: zeta
    real(dp), intent(out) :: residual(3)
    real(dp), intent(out) :: res_norm
    real(dp), intent(out) :: dx_drho(3)
    real(dp), intent(out) :: dx_dtheta(3)
    real(dp), intent(out) :: dx_dzeta(3)

    real(dp) :: uvec(3)
    real(dp) :: vals(3)
    real(dp) :: dvals(3, 3)

    uvec = [rho, theta, zeta]
    call chartmap_eval_cart_der(self, uvec, vals, dvals)

    residual = x_target - vals
    res_norm = sqrt(sum(residual**2))
    ! dvals(cart_component, coord_index) = d(x_cart)/d(u_coord)
    ! Extract columns: dx_drho = [dX/drho, dY/drho, dZ/drho] = dvals(:, 1)
    dx_drho = dvals(:, 1)
    dx_dtheta = dvals(:, 2)
    dx_dzeta = dvals(:, 3)
end subroutine chartmap_eval_residual_and_partials_cart

subroutine chartmap_solve_normal_eq3(jtj, jtr, delta, ierr)
    real(dp), intent(in) :: jtj(3, 3)
    real(dp), intent(in) :: jtr(3)
    real(dp), intent(out) :: delta(3)
    integer, intent(out) :: ierr

    real(dp) :: a(3, 3), b(3)
    real(dp) :: lambda
    integer :: k
    logical :: ok

    ierr = chartmap_from_cyl_ok
    delta = 0.0_dp

    lambda = 0.0_dp
    do k = 1, 10
        a = jtj
        a(1, 1) = a(1, 1) + lambda
        a(2, 2) = a(2, 2) + lambda
        a(3, 3) = a(3, 3) + lambda
        b = jtr

        call chartmap_solve_3x3(a, b, delta, ok)
        if (ok) return

        if (lambda == 0.0_dp) then
            lambda = 1.0e-12_dp*max(1.0_dp, jtj(1, 1) + jtj(2, 2) + jtj(3, 3))
        else
            lambda = 10.0_dp*lambda
        end if
    end do

    ierr = chartmap_from_cyl_err_singular
end subroutine chartmap_solve_normal_eq3

subroutine chartmap_solve_3x3(a, b, x, ok)
    real(dp), intent(inout) :: a(3, 3)
    real(dp), intent(inout) :: b(3)
    real(dp), intent(out) :: x(3)
    logical, intent(out) :: ok
    real(dp), parameter :: pivtol = 1.0e-18_dp
    real(dp) :: pivot
    real(dp) :: factor
    real(dp) :: tmp_row(3)
    real(dp) :: tmp_b
    integer :: i, k, piv

    ok = .true.; x = 0.0_dp
    do i = 1, 3
        piv = i
        pivot = abs(a(i, i))
        do k = i + 1, 3
            if (abs(a(k, i)) > pivot) then
                piv = k
                pivot = abs(a(k, i))
            end if
        end do
        if (pivot < pivtol) then
            ok = .false.
            return
        end if
        if (piv /= i) then
            tmp_row = a(i, :)
            a(i, :) = a(piv, :)
            a(piv, :) = tmp_row
            tmp_b = b(i)
            b(i) = b(piv)
            b(piv) = tmp_b
        end if
        pivot = a(i, i)
        a(i, :) = a(i, :)/pivot
        b(i) = b(i)/pivot
        do k = 1, 3
            if (k == i) cycle
            factor = a(k, i)
            a(k, :) = a(k, :) - factor*a(i, :)
            b(k) = b(k) - factor*b(i)
        end do
    end do
    x = b
end subroutine chartmap_solve_3x3

subroutine chartmap_line_search_cart(self, x_target, rho, theta, zeta, &
                                     zeta_period, &
                                     delta, res_norm, rho_new, theta_new, &
                                     zeta_new, &
                                     res_norm_new, success)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(in) :: rho
    real(dp), intent(in) :: theta
    real(dp), intent(in) :: zeta
    real(dp), intent(in) :: zeta_period
    real(dp), intent(in) :: delta(3)
    real(dp), intent(in) :: res_norm
    real(dp), intent(out) :: rho_new
    real(dp), intent(out) :: theta_new
    real(dp), intent(out) :: zeta_new
    real(dp), intent(out) :: res_norm_new
    logical, intent(out) :: success

    real(dp) :: alpha
    real(dp) :: uvec(3)
    real(dp) :: x_trial(3)
    real(dp) :: residual(3)
    integer :: k

    success = .false.; rho_new = rho; theta_new = theta; zeta_new = zeta
    res_norm_new = res_norm
    alpha = 1.0_dp
    do k = 1, 12
        rho_new = rho + alpha*delta(1)
        if (rho_new < -0.02_dp .or. rho_new > 1.02_dp) then
            alpha = 0.5_dp*alpha
            cycle
        end if

        theta_new = modulo(theta + alpha*delta(2), TWOPI)
        zeta_new = modulo(zeta + alpha*delta(3), zeta_period)
        uvec = [rho_new, theta_new, zeta_new]
        call chartmap_eval_cart(self, uvec, x_trial)
        residual = x_target - x_trial
        res_norm_new = sqrt(sum(residual**2))

        if (res_norm_new < res_norm) then
            success = .true.
            return
        end if

        alpha = 0.5_dp*alpha
    end do
end subroutine chartmap_line_search_cart

subroutine chartmap_initial_guess(self, x_target, zeta, rho, theta, ierr)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(in) :: zeta
    real(dp), intent(out) :: rho
    real(dp), intent(out) :: theta
    integer, intent(out) :: ierr

    real(dp) :: uvec(3)
    real(dp) :: axis_x(3), bound_x(3)
    real(dp) :: vals(3)
    real(dp) :: denom
    real(dp) :: e_r(2)
    real(dp) :: r_rel
    real(dp) :: z_rel

    ierr = chartmap_from_cyl_ok

    if (.not. self%has_spl_rz) then
        call chartmap_initial_guess_cartesian(self, x_target, zeta, rho, theta)
        return
    end if

    uvec = [0.0_dp, 0.0_dp, zeta]
    call chartmap_eval_cart(self, uvec, vals)
    axis_x = vals

    e_r(1) = cos(zeta)
    e_r(2) = sin(zeta)
    r_rel = e_r(1)*(x_target(1) - axis_x(1)) + e_r(2)*(x_target(2) - axis_x(2))
    z_rel = x_target(3) - axis_x(3)
    theta = atan2(z_rel, r_rel)

    uvec = [1.0_dp, theta, zeta]
    call chartmap_eval_cart(self, uvec, vals)
    bound_x = vals

    denom = sqrt(sum((bound_x - axis_x)**2))
    if (denom < 1.0e-14_dp) then
        ierr = chartmap_from_cyl_err_invalid
        rho = 0.0_dp
        return
    end if

    rho = sqrt(sum((x_target - axis_x)**2))/denom
    rho = min(max(rho, 0.0_dp), 1.0_dp)
end subroutine chartmap_initial_guess

subroutine chartmap_initial_guess_cartesian(self, x_target, zeta, rho, theta)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(in) :: zeta
    real(dp), intent(out) :: rho
    real(dp), intent(out) :: theta

    real(dp) :: uvec(3)
    real(dp) :: x_try(3)
    real(dp) :: best_dist2, dist2
    integer :: nrho_probe, ntheta_probe
    integer :: ir, it

    nrho_probe = min(max(self%nrho, 5), 9)
    ntheta_probe = min(max(self%ntheta, 16), 32)

    best_dist2 = huge(1.0_dp)
    rho = 0.0_dp
    theta = 0.0_dp

    do it = 1, ntheta_probe
        uvec(2) = TWOPI*real(it - 1, dp)/real(ntheta_probe, dp)
        uvec(3) = zeta
        do ir = 1, nrho_probe
            uvec(1) = real(ir - 1, dp)/real(nrho_probe - 1, dp)
            call chartmap_eval_cart(self, uvec, x_try)
            dist2 = sum((x_target - x_try)**2)
            if (dist2 < best_dist2) then
                best_dist2 = dist2
                rho = uvec(1)
                theta = uvec(2)
            end if
        end do
    end do
end subroutine chartmap_initial_guess_cartesian

subroutine chartmap_initial_guess_cartesian_3d(self, x_target, u)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(out) :: u(3)

    real(dp) :: uvec(3)
    real(dp) :: x_try(3)
    real(dp) :: best_dist2, dist2
    real(dp) :: zeta_period
    integer :: nrho_probe, ntheta_probe, nzeta_probe
    integer :: ir, it, iz

    nrho_probe = min(max(self%nrho, 9), 17)
    ntheta_probe = min(max(self%ntheta, 32), 64)
    nzeta_probe = min(max(self%nzeta, 24), 48)
    zeta_period = TWOPI/real(self%num_field_periods, dp)

    best_dist2 = huge(1.0_dp)
    u = 0.0_dp

    do iz = 1, nzeta_probe
        uvec(3) = zeta_period*real(iz - 1, dp)/real(nzeta_probe, dp)
        do it = 1, ntheta_probe
            uvec(2) = TWOPI*real(it - 1, dp)/real(ntheta_probe, dp)
            do ir = 1, nrho_probe
                uvec(1) = real(ir - 1, dp)/real(nrho_probe - 1, dp)
                call chartmap_eval_cart(self, uvec, x_try)
                dist2 = sum((x_target - x_try)**2)
                if (dist2 < best_dist2) then
                    best_dist2 = dist2
                    u = uvec
                end if
            end do
        end do
    end do
end subroutine chartmap_initial_guess_cartesian_3d

subroutine chartmap_refine_cart_seed(self, x_target, zeta_period, u, res_norm, ierr)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(in) :: zeta_period
    real(dp), intent(inout) :: u(3)
    real(dp), intent(out) :: res_norm
    integer, intent(out) :: ierr

    real(dp) :: trial(3), best_u(3), x_trial(3)
    real(dp) :: step_rho, step_theta, step_zeta
    real(dp) :: best_dist2, dist2
    integer :: iter, ir, it, iz

    ierr = chartmap_from_cyl_ok
    step_rho = 1.0_dp/16.0_dp
    step_theta = TWOPI/64.0_dp
    step_zeta = zeta_period/48.0_dp

    call chartmap_eval_cart(self, u, x_trial)
    best_dist2 = sum((x_target - x_trial)**2)

    do iter = 1, 64
        best_u = u
        do iz = -1, 1
            trial(3) = modulo(u(3) + real(iz, dp)*step_zeta, zeta_period)
            do it = -1, 1
                trial(2) = modulo(u(2) + real(it, dp)*step_theta, TWOPI)
                do ir = -1, 1
                    trial(1) = min(max(u(1) + real(ir, dp)*step_rho, 0.0_dp), 1.0_dp)
                    call chartmap_eval_cart(self, trial, x_trial)
                    dist2 = sum((x_target - x_trial)**2)
                    if (dist2 < best_dist2) then
                        best_dist2 = dist2
                        best_u = trial
                    end if
                end do
            end do
        end do

        if (any(best_u /= u)) then
            u = best_u
        else
            step_rho = 0.5_dp*step_rho
            step_theta = 0.5_dp*step_theta
            step_zeta = 0.5_dp*step_zeta
            if (max(step_rho, max(step_theta, step_zeta)) < 1.0e-12_dp) exit
        end if
    end do

    call chartmap_eval_cart(self, u, x_trial)
    res_norm = sqrt(sum((x_target - x_trial)**2))
    if (res_norm > 1.0e-4_dp) ierr = chartmap_from_cyl_err_max_iter
end subroutine chartmap_refine_cart_seed

subroutine chartmap_newton_delta(self, x_target, rho, theta, zeta, delta, &
                                 res_norm, &
                                 ierr)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(in) :: rho
    real(dp), intent(in) :: theta
    real(dp), intent(in) :: zeta
    real(dp), intent(out) :: delta(2)
    real(dp), intent(out) :: res_norm
    integer, intent(out) :: ierr

    real(dp) :: residual(3)
    real(dp) :: dx_drho(3), dx_dtheta(3)
    real(dp) :: jtj11, jtj12, jtj22, jtr1, jtr2

    ierr = chartmap_from_cyl_ok
    delta = 0.0_dp

    call chartmap_eval_residual_and_partials(self, x_target, rho, theta, zeta, &
                                             residual, &
                                             res_norm, dx_drho, dx_dtheta)

    jtj11 = dot_product(dx_drho, dx_drho)
    jtj12 = dot_product(dx_drho, dx_dtheta)
    jtj22 = dot_product(dx_dtheta, dx_dtheta)
    jtr1 = dot_product(dx_drho, residual)
    jtr2 = dot_product(dx_dtheta, residual)

    call chartmap_solve_normal_eq(jtj11, jtj12, jtj22, jtr1, jtr2, delta, ierr)
end subroutine chartmap_newton_delta

subroutine chartmap_solve_normal_eq(jtj11, jtj12, jtj22, jtr1, jtr2, delta, ierr)
    real(dp), intent(in) :: jtj11
    real(dp), intent(in) :: jtj12
    real(dp), intent(in) :: jtj22
    real(dp), intent(in) :: jtr1
    real(dp), intent(in) :: jtr2
    real(dp), intent(out) :: delta(2)
    integer, intent(out) :: ierr

    real(dp) :: a11, a12, a22, det, lambda
    integer :: k

    ierr = chartmap_from_cyl_ok
    delta = 0.0_dp

    lambda = 0.0_dp
    do k = 1, 8
        a11 = jtj11 + lambda
        a12 = jtj12
        a22 = jtj22 + lambda
        det = a11*a22 - a12*a12
        if (abs(det) > 1.0e-18_dp) exit
        if (lambda == 0.0_dp) then
            lambda = 1.0e-12_dp*max(1.0_dp, jtj11 + jtj22)
        else
            lambda = 10.0_dp*lambda
        end if
    end do

    if (abs(det) <= 1.0e-18_dp) then
        ierr = chartmap_from_cyl_err_singular
        return
    end if

    delta(1) = (a22*jtr1 - a12*jtr2)/det
    delta(2) = (a11*jtr2 - a12*jtr1)/det
end subroutine chartmap_solve_normal_eq

subroutine chartmap_eval_residual_and_partials(self, x_target, rho, theta, zeta, &
                                               residual, &
                                               res_norm, dx_drho, dx_dtheta)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(in) :: rho
    real(dp), intent(in) :: theta
    real(dp), intent(in) :: zeta
    real(dp), intent(out) :: residual(3)
    real(dp), intent(out) :: res_norm
    real(dp), intent(out) :: dx_drho(3)
    real(dp), intent(out) :: dx_dtheta(3)

    real(dp) :: uvec(3)
    real(dp) :: vals(3)
    real(dp) :: dvals(3, 3)

    uvec = [rho, theta, zeta]
    call chartmap_eval_cart_der(self, uvec, vals, dvals)

    residual = x_target - vals
    res_norm = sqrt(sum(residual**2))
    ! dvals(cart_component, coord_index) = d(x_cart)/d(u_coord)
    dx_drho = dvals(:, 1)
    dx_dtheta = dvals(:, 2)
end subroutine chartmap_eval_residual_and_partials

subroutine chartmap_line_search(self, x_target, rho, theta, zeta, delta, res_norm, &
                                rho_new, theta_new, res_norm_new, success)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(in) :: rho
    real(dp), intent(in) :: theta
    real(dp), intent(in) :: zeta
    real(dp), intent(in) :: delta(2)
    real(dp), intent(in) :: res_norm
    real(dp), intent(out) :: rho_new
    real(dp), intent(out) :: theta_new
    real(dp), intent(out) :: res_norm_new
    logical, intent(out) :: success

    real(dp) :: alpha
    real(dp) :: uvec(3)
    real(dp) :: x_trial(3)
    real(dp) :: residual(3)
    integer :: k

    success = .false.
    rho_new = rho
    theta_new = theta
    res_norm_new = res_norm

    alpha = 1.0_dp
    do k = 1, 12
        rho_new = rho + alpha*delta(1)
        if (rho_new < -0.02_dp .or. rho_new > 1.02_dp) then
            alpha = 0.5_dp*alpha
            cycle
        end if

        theta_new = modulo(theta + alpha*delta(2), TWOPI)
        uvec = [rho_new, theta_new, zeta]
        call chartmap_eval_cart(self, uvec, x_trial)
        residual = x_target - x_trial
        res_norm_new = sqrt(sum(residual**2))

        if (res_norm_new < res_norm) then
            success = .true.
            return
        end if

        alpha = 0.5_dp*alpha
    end do
end subroutine chartmap_line_search

subroutine newton_slice(self, x_target, zeta, rho_theta, ierr)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3), zeta
    real(dp), intent(out) :: rho_theta(2)
    integer, intent(out) :: ierr

    real(dp) :: rho, theta
    logical :: trace

    ierr = chartmap_from_cyl_ok
    trace = chartmap_trace_once_enabled()
    if (trace) then
        print *, "chartmap_from_cyl trace:"
        print *, "  zeta=", zeta
        print *, "  x_target=", x_target
    end if

    call chartmap_solve_slice(self, x_target, zeta, rho, theta, ierr, trace)

    rho_theta = [rho, theta]
end subroutine newton_slice

subroutine chartmap_solve_slice(self, x_target, zeta, rho, theta, ierr, trace)
    class(chartmap_coordinate_system_t), intent(in) :: self
    real(dp), intent(in) :: x_target(3)
    real(dp), intent(in) :: zeta
    real(dp), intent(out) :: rho
    real(dp), intent(out) :: theta
    integer, intent(out) :: ierr
    logical, intent(in) :: trace

    integer :: iter
    real(dp) :: delta(2)
    real(dp) :: res_norm, res_norm_new
    real(dp) :: rho_new, theta_new
    logical :: ok_step
    real(dp), parameter :: tol_res = 1.0e-10_dp, tol_step = 1.0e-10_dp

    ierr = chartmap_from_cyl_ok
    call chartmap_initial_guess(self, x_target, zeta, rho, theta, ierr)
    if (ierr /= chartmap_from_cyl_ok) return

    do iter = 1, 60
        call chartmap_newton_delta(self, x_target, rho, theta, zeta, delta, &
                                   res_norm, ierr)
        if (ierr /= chartmap_from_cyl_ok) exit
        if (res_norm < tol_res) exit
        if (maxval(abs(delta)) < max(tol_step, self%tol_newton)) exit

        call chartmap_line_search(self, x_target, rho, theta, zeta, delta, &
                                  res_norm, rho_new, &
                                  theta_new, res_norm_new, ok_step)
        if (.not. ok_step) then
            if (maxval(abs(delta)) < max(tol_step, self%tol_newton)) exit
            ierr = chartmap_from_cyl_err_max_iter
            exit
        end if

        rho = rho_new
        theta = theta_new

        if (trace) then
            print *, "  iter=", iter, " rho=", rho, " theta=", theta, &
                " |res|=", res_norm_new, " |d|=", maxval(abs(delta))
        end if
    end do

    if (ierr == chartmap_from_cyl_ok .and. iter >= 60) then
        ierr = chartmap_from_cyl_err_max_iter
    end if
end subroutine chartmap_solve_slice
