!
  module chamb_mod
    logical :: rnegflag=.false.
!$omp threadprivate(rnegflag)
  end module chamb_mod
!
  module parmot_mod
    double precision :: rmu,ro0,eeff
  end module parmot_mod
!
  module new_vmec_stuff_mod
    character*1000   :: netcdffile = ''  ! Empty = unset, apply 'wout.nc' default at usage
    integer          :: nsurfm,nstrm,nper=1,kpar
    integer          :: multharm=5,n_theta,n_phi
    integer          :: ns_A=5  !<- spline order for vector potential
    integer          :: ns_s=5  !<- spline order for R,Z,lambda over s
    integer          :: ns_tp=5 !<- spline order for R,Z,lambda over theta and varphi
    double precision :: rmajor=1d0,h_theta,h_phi
    double precision :: vmec_B_scale=1d0, vmec_RZ_scale=1d0
    double precision, dimension(:),     allocatable :: axm,axn,soa
    double precision, dimension(:),     allocatable :: aiota,s,sps,phi
    double precision, dimension(:,:),   allocatable :: almnc,rmnc,zmnc
    double precision, dimension(:,:),   allocatable :: almns,rmns,zmns
    ! Exact magnetic axis (VMEC wout raxis_cc/zaxis_cs), indexed n=0..ntor:
    !   R_axis(phi) = sum_n raxis_cc(n) cos(n*nfp*phi) + raxis_cs(n) sin(...)
    !   Z_axis(phi) = sum_n zaxis_cc(n) cos(n*nfp*phi) + zaxis_cs(n) sin(...)
    ! The exact axis curve (no flux surface at s=0), used for the analytic
    ! near-axis chartmap limit. raxis_cs/zaxis_cc are zero unless lasym.
    integer :: ntor_axis = -1
    double precision, dimension(:), allocatable :: raxis_cc, zaxis_cs
    double precision, dimension(:), allocatable :: raxis_cs, zaxis_cc
!
    double precision, dimension(:,:,:,:,:,:), allocatable :: sR,sZ,slam

    ! Near-axis healing of the VMEC harmonics. Preferred selector:
    !   axis_healing = 'legacy'          - old default: discard min(|m|,4)
    !                                      surfaces and extrapolate.
    !                  'legacy_adaptive' - old adaptive boundary from
    !                                      determine_nheal_for_axis.
    !                  'powerlaw'        - rho**|m| continuation below
    !                                      s_axis_heal.
    !                  'polyfit'         - rho**|m| * least-squares poly(s)
    !                                      below s_axis_heal. Recommended.
    ! The empty string means "unset": deprecated logical switches below are
    ! mapped to a mode with a warning (see resolve_axis_healing_mode).
    character(len=16) :: axis_healing = ''
    double precision :: s_axis_heal = 1.0d-2       ! anchor flux for powerlaw/polyfit
    double precision :: rho_axis_heal = -1.0d0     ! deprecated; use s_axis_heal
    integer :: axis_healing_polyfit_degree = 3     ! polyfit polynomial degree in s
    logical :: rho_axis_heal_warning_printed = .False.
    ! DEPRECATED boolean switches (use axis_healing). Kept for back-compat and
    ! mapped to a mode with a deprecation warning; the next SIMPLE release will
    ! remove them and default axis_healing to 'polyfit'.
    logical :: old_axis_healing = .True.
    logical :: old_axis_healing_boundary = .True.
    logical :: axis_healing_power_law = .False.
    logical :: axis_healing_polyfit = .False.
  end module new_vmec_stuff_mod
!
  module vector_potentail_mod
    integer :: ns
    double precision :: hs,torflux
    double precision, dimension(:,:),         allocatable :: sA_phi
  end module vector_potentail_mod
!
  module canonical_coordinates_mod
    integer, parameter :: ns_max=6, n_qua=3
!
    integer :: ns_s_c,ns_tp_c
    integer :: ns_c,n_theta_c,n_phi_c
    integer, parameter :: nh_stencil=3
    double precision :: hs_c,h_theta_c,h_phi_c
    double precision, dimension(:,:,:), allocatable :: G_c,sqg_c,&
      B_vartheta_c,B_varphi_c,A_vartheta_c,A_varphi_c,Delta_varphi_c,chi_gauge,&
      Bmod_c
!
    double precision, dimension(ns_max)                     :: derf1,derf2,derf3
    double precision, dimension(:,:,:,:,:,:),   allocatable :: s_G_c
    double precision, dimension(:,:,:,:,:,:,:), allocatable :: s_sqg_Bt_Bp
  end module canonical_coordinates_mod

  module canonical_coordinates_new_mod
    implicit none
    integer, parameter :: ns_max=6, n_qua=5
    integer :: ns_s_c,ns_tp_c
    integer :: ns_c,n_theta_c,n_phi_c
    integer, parameter :: nh_stencil=3
    double precision :: hs_c,h_theta_c,h_phi_c
    double precision, dimension(:,:,:), allocatable :: Delta_varphi_c,&
      h_vartheta_c,h_varphi_c,A_vartheta_c,A_varphi_c,chi_gauge,Bmod_c

      double precision, dimension(ns_max)                     :: derf1,derf2,derf3
      double precision, dimension(:,:,:,:,:,:),   allocatable :: s_Delta_varphi_c
      double precision, dimension(:,:,:,:,:,:,:), allocatable :: s_Bmod_B_A
  end module canonical_coordinates_new_mod
!
  module boozer_coordinates_mod
    use, intrinsic :: iso_fortran_env, only: dp => real64
    use canonical_coordinates_mod, only: ns_max, derf1, derf2, derf3

    implicit none

    logical :: use_B_r = .false.
    logical :: use_del_tp_B = .false.

    integer :: ns_s_B,ns_tp_B
    integer :: ns_B,n_theta_B,n_phi_B
    real(dp) :: hs_B, h_theta_B, h_phi_B

! spline coefficients for Boozer $B_\vartheta$ and $B_\varphi$:
    real(dp), allocatable :: s_Bcovar_tp_B(:, :, :)
    real(dp), allocatable :: s_Bmod_B(:, :, :, :, :, :)
    real(dp), allocatable :: s_Bcovar_r_B(:, :, :, :, :, :)
    real(dp), allocatable :: s_delt_delp_V(:, :, :, :, :, :, :)
    real(dp), allocatable :: s_delt_delp_B(:, :, :, :, :, :, :)
  end module boozer_coordinates_mod
!
  module velo_mod
    integer :: isw_field_type = 0
  end module velo_mod
!
module diag_mod
  logical :: dodiag=.false.
  integer(8) :: icounter
end module diag_mod
