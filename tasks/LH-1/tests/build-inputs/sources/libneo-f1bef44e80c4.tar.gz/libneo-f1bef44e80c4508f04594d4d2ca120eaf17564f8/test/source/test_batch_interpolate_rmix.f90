program test_batch_interpolate_rmix
    use, intrinsic :: iso_fortran_env, only: dp => real64
    use interpolate, only: BatchSplineData3D, construct_batch_splines_3d, &
                           destroy_batch_splines_3d, evaluate_batch_splines_3d_der2, &
                           evaluate_batch_splines_3d_der_nq1_o355
    use batch_interpolate_3d, only: evaluate_batch_splines_3d_der2_rmix, &
        evaluate_batch_spline_3d_scalar_cubic_der2_rmix

    implicit none

    real(dp), parameter :: TOL = 1.0d-12

    call test_rmix_matches_full_der2_nq1_o555
    call test_scalar_cubic_rmix_matches_full_der2
    call test_rmix_matches_full_der2_nq1_o355_periodic
    call test_der_nq1_o355_matches_full_der2_periodic
    call test_rmix_matches_full_der2_nq2_general
    call test_rmix_matches_full_der2_nq2_o555

    print *, "PASSED: evaluate_batch_splines_3d_der2_rmix matches full der2"

contains

    subroutine test_scalar_cubic_rmix_matches_full_der2
        integer, parameter :: N_POINTS(3) = [22, 24, 26]
        integer, parameter :: ORDER(3) = [3, 3, 3]
        logical, parameter :: PERIODIC(3) = [.false., .true., .true.]

        type(BatchSplineData3D) :: spl
        real(dp) :: y_data(N_POINTS(1), N_POINTS(2), N_POINTS(3), 1)
        real(dp) :: x_min(3), x_max(3), x_eval(3)
        real(dp) :: y_ref(1), y_got, y_device
        real(dp) :: dy_ref(3, 1), dy_got(3), dy_device(3)
        real(dp) :: d2_ref(6, 1), d2_got(3), d2_device(3)
        integer :: i1, i2, i3, n_test

        x_min = [0.05_dp, 0.0_dp, -0.4_dp]
        x_max = [1.0_dp, 2.0_dp, 0.8_dp]
        do i3 = 1, N_POINTS(3)
            do i2 = 1, N_POINTS(2)
                do i1 = 1, N_POINTS(1)
                    y_data(i1, i2, i3, 1) = &
                        0.04_dp*real(i1, dp)**2 + &
                        sin(0.13_dp*real(i1*i2, dp)) + &
                        cos(0.09_dp*real(i2*i3, dp))
                end do
            end do
        end do

        call construct_batch_splines_3d( &
            x_min, x_max, y_data, ORDER, PERIODIC, spl)
        do n_test = 0, 9
            x_eval(1) = x_min(1) + (x_max(1) - x_min(1))* &
                real(n_test + 1, dp)/11.0_dp
            x_eval(2) = x_min(2) + (x_max(2) - x_min(2))* &
                real(2*n_test - 3, dp)/7.0_dp
            x_eval(3) = x_min(3) + (x_max(3) - x_min(3))* &
                real(3*n_test + 2, dp)/8.0_dp

            call evaluate_batch_splines_3d_der2( &
                spl, x_eval, y_ref, dy_ref, d2_ref)
            call evaluate_batch_spline_3d_scalar_cubic_der2_rmix( &
                spl, x_eval, y_got, dy_got, d2_got)
            call assert_close_vec('cubic rmix value', [y_got], y_ref, TOL)
            call assert_close_vec('cubic rmix dy', dy_got, dy_ref(:, 1), TOL)
            call assert_close_vec( &
                'cubic rmix d2', d2_got, d2_ref(1:3, 1), TOL)

            !$acc serial copyin(x_eval) copyout(y_device, dy_device, d2_device)
            call evaluate_batch_spline_3d_scalar_cubic_der2_rmix( &
                spl, x_eval, y_device, dy_device, d2_device)
            !$acc end serial
            call assert_close_vec( &
                'cubic rmix device value', [y_device], y_ref, TOL)
            call assert_close_vec( &
                'cubic rmix device dy', dy_device, dy_ref(:, 1), TOL)
            call assert_close_vec( &
                'cubic rmix device d2', d2_device, d2_ref(1:3, 1), TOL)
        end do
        call destroy_batch_splines_3d(spl)
    end subroutine test_scalar_cubic_rmix_matches_full_der2

    subroutine test_rmix_matches_full_der2_nq1_o555
        integer, parameter :: N_POINTS(3) = [24, 26, 28]
        integer, parameter :: ORDER(3) = [5, 5, 5]
        logical, parameter :: PERIODIC(3) = [.false., .false., .false.]

        type(BatchSplineData3D) :: spl
        real(dp) :: y_data(N_POINTS(1), N_POINTS(2), N_POINTS(3), 1)
        real(dp) :: x_min(3), x_max(3)
        real(dp) :: x_eval(3)
        real(dp) :: y1(1), y2(1)
        real(dp) :: dy1(3, 1), dy2(3, 1)
        real(dp) :: d2_full(6, 1), d2_rmix(3, 1)
        integer :: i1, i2, i3, n_test

        x_min = [0.1d0, -0.2d0, 0.3d0]
        x_max = [1.3d0, 0.9d0, 2.1d0]

        do i3 = 1, N_POINTS(3)
            do i2 = 1, N_POINTS(2)
                do i1 = 1, N_POINTS(1)
                    y_data(i1, i2, i3, 1) = sin(real(i1 - 1, dp)*0.07d0) + &
                                            cos(real(i2 - 1, dp)*0.05d0) + &
                                            exp(-real(i3 - 1, dp)*0.03d0)
                end do
            end do
        end do

        call construct_batch_splines_3d(x_min, x_max, y_data, ORDER, PERIODIC, spl)

        do n_test = 1, 7
            x_eval(1) = x_min(1) + (x_max(1) - x_min(1)) * real(1 + n_test, dp) / 9.0d0
            x_eval(2) = x_min(2) + (x_max(2) - x_min(2)) * real(2 + n_test, dp) / 9.0d0
            x_eval(3) = x_min(3) + (x_max(3) - x_min(3)) * real(3 + n_test, dp) / 9.0d0

            call evaluate_batch_splines_3d_der2(spl, x_eval, y1, dy1, d2_full)
            call evaluate_batch_splines_3d_der2_rmix(spl, x_eval, y2, dy2, d2_rmix)

            call assert_close_vec("value", y2, y1, TOL)
            call assert_close_mat("dy", dy2, dy1, TOL)
            call assert_close_vec("d2_rmix(1)", d2_rmix(1, :), d2_full(1, :), TOL)
            call assert_close_vec("d2_rmix(2)", d2_rmix(2, :), d2_full(2, :), TOL)
            call assert_close_vec("d2_rmix(3)", d2_rmix(3, :), d2_full(3, :), TOL)
        end do

        call destroy_batch_splines_3d(spl)
    end subroutine test_rmix_matches_full_der2_nq1_o555

    subroutine test_rmix_matches_full_der2_nq2_general
        integer, parameter :: N_POINTS(3) = [21, 23, 25]
        integer, parameter :: ORDER(3) = [3, 5, 3]
        logical, parameter :: PERIODIC(3) = [.false., .true., .false.]
        integer, parameter :: NQ = 2

        type(BatchSplineData3D) :: spl
        real(dp) :: y_data(N_POINTS(1), N_POINTS(2), N_POINTS(3), NQ)
        real(dp) :: x_min(3), x_max(3)
        real(dp) :: x_eval(3)
        real(dp) :: y1(NQ), y2(NQ)
        real(dp) :: dy1(3, NQ), dy2(3, NQ)
        real(dp) :: d2_full(6, NQ), d2_rmix(3, NQ)
        integer :: i1, i2, i3, iq, n_test

        x_min = [-0.5d0, 0.0d0, -1.0d0]
        x_max = [0.7d0, 2.0d0, 1.2d0]

        do iq = 1, NQ
            do i3 = 1, N_POINTS(3)
                do i2 = 1, N_POINTS(2)
                    do i1 = 1, N_POINTS(1)
                        y_data(i1, i2, i3, iq) = real(iq, dp) * &
                                                 (0.1d0*real(i1, dp)**2 + &
                                                  0.2d0*sin(real(i2 - 1, dp)*0.07d0) + &
                                                  0.3d0*cos(real(i3 - 1, dp)*0.05d0))
                    end do
                end do
            end do
        end do

        call construct_batch_splines_3d(x_min, x_max, y_data, ORDER, PERIODIC, spl)

        do n_test = 1, 7
            x_eval(1) = x_min(1) + (x_max(1) - x_min(1)) * real(1 + n_test, dp) / 9.0d0
            x_eval(2) = x_min(2) + (x_max(2) - x_min(2)) * real(2 + n_test, dp) / 9.0d0
            x_eval(3) = x_min(3) + (x_max(3) - x_min(3)) * real(3 + n_test, dp) / 9.0d0

            call evaluate_batch_splines_3d_der2(spl, x_eval, y1, dy1, d2_full)
            call evaluate_batch_splines_3d_der2_rmix(spl, x_eval, y2, dy2, d2_rmix)

            call assert_close_vec("value", y2, y1, TOL)
            call assert_close_mat("dy", dy2, dy1, TOL)
            call assert_close_vec("d2_rmix(1)", d2_rmix(1, :), d2_full(1, :), TOL)
            call assert_close_vec("d2_rmix(2)", d2_rmix(2, :), d2_full(2, :), TOL)
            call assert_close_vec("d2_rmix(3)", d2_rmix(3, :), d2_full(3, :), TOL)
        end do

        call destroy_batch_splines_3d(spl)
    end subroutine test_rmix_matches_full_der2_nq2_general

    subroutine test_rmix_matches_full_der2_nq1_o355_periodic
        integer, parameter :: N_POINTS(3) = [23, 25, 27]
        integer, parameter :: ORDER(3) = [3, 5, 5]
        logical, parameter :: PERIODIC(3) = [.false., .true., .true.]

        type(BatchSplineData3D) :: spl
        real(dp) :: y_data(N_POINTS(1), N_POINTS(2), N_POINTS(3), 1)
        real(dp) :: x_min(3), x_max(3)
        real(dp) :: x_eval(3)
        real(dp) :: y1(1), y2(1)
        real(dp) :: dy1(3, 1), dy2(3, 1)
        real(dp) :: d2_full(6, 1), d2_rmix(3, 1)
        integer :: i1, i2, i3, n_test

        x_min = [-0.4d0, 0.0d0, -0.9d0]
        x_max = [0.8d0, 2.0d0, 1.1d0]

        do i3 = 1, N_POINTS(3)
            do i2 = 1, N_POINTS(2)
                do i1 = 1, N_POINTS(1)
                    y_data(i1, i2, i3, 1) = 0.1d0*real(i1, dp)**2 + &
                                            0.2d0*sin(real(i2 - 1, dp)*0.07d0) + &
                                            0.3d0*cos(real(i3 - 1, dp)*0.05d0)
                end do
            end do
        end do

        call construct_batch_splines_3d(x_min, x_max, y_data, ORDER, PERIODIC, spl)

        do n_test = 1, 7
            x_eval(1) = x_min(1) + (x_max(1) - x_min(1)) * real(1 + n_test, dp) / 9.0d0
            x_eval(2) = x_min(2) + (x_max(2) - x_min(2)) * real(2 + n_test, dp) / 9.0d0
            x_eval(3) = x_min(3) + (x_max(3) - x_min(3)) * real(3 + n_test, dp) / 9.0d0

            call evaluate_batch_splines_3d_der2(spl, x_eval, y1, dy1, d2_full)
            call evaluate_batch_splines_3d_der2_rmix(spl, x_eval, y2, dy2, d2_rmix)

            call assert_close_vec("value", y2, y1, TOL)
            call assert_close_mat("dy", dy2, dy1, TOL)
            call assert_close_vec("d2_rmix(1)", d2_rmix(1, :), d2_full(1, :), TOL)
            call assert_close_vec("d2_rmix(2)", d2_rmix(2, :), d2_full(2, :), TOL)
            call assert_close_vec("d2_rmix(3)", d2_rmix(3, :), d2_full(3, :), TOL)
        end do

        call destroy_batch_splines_3d(spl)
    end subroutine test_rmix_matches_full_der2_nq1_o355_periodic

    subroutine test_der_nq1_o355_matches_full_der2_periodic
        integer, parameter :: N_POINTS(3) = [23, 25, 27]
        integer, parameter :: ORDER(3) = [3, 5, 5]
        logical, parameter :: PERIODIC(3) = [.false., .true., .true.]

        type(BatchSplineData3D) :: spl
        real(dp) :: y_data(N_POINTS(1), N_POINTS(2), N_POINTS(3), 1)
        real(dp) :: x_min(3), x_max(3), x_eval(3)
        real(dp) :: y_ref(1), y_got(1)
        real(dp) :: dy_ref(3, 1), dy_got(3, 1), d2_ref(6, 1)
        real(dp) :: y_device(1), dy_device(3, 1)
        integer :: i1, i2, i3, n_test

        x_min = [-0.4d0, 0.0d0, -0.9d0]
        x_max = [0.8d0, 2.0d0, 1.1d0]
        do i3 = 1, N_POINTS(3)
            do i2 = 1, N_POINTS(2)
                do i1 = 1, N_POINTS(1)
                    y_data(i1, i2, i3, 1) = 0.1d0*real(i1, dp)**2 + &
                                            0.2d0*sin(real(i2 - 1, dp)*0.07d0) + &
                                            0.3d0*cos(real(i3 - 1, dp)*0.05d0)
                end do
            end do
        end do

        call construct_batch_splines_3d(x_min, x_max, y_data, ORDER, PERIODIC, spl)
        do n_test = 0, 9
            x_eval(1) = x_min(1) + (x_max(1) - x_min(1))*real(n_test + 1, dp)/11.0d0
            x_eval(2) = x_min(2) + (x_max(2) - x_min(2))*real(2*n_test + 1, dp)/7.0d0
            x_eval(3) = x_min(3) + (x_max(3) - x_min(3))*real(3*n_test + 2, dp)/8.0d0

            call evaluate_batch_splines_3d_der2(spl, x_eval, y_ref, dy_ref, d2_ref)
            call evaluate_batch_splines_3d_der_nq1_o355(spl, x_eval, y_got, dy_got)
            call assert_close_vec("o355 value", y_got, y_ref, TOL)
            call assert_close_mat("o355 dy", dy_got, dy_ref, TOL)

            !$acc serial copyin(x_eval) copyout(y_device, dy_device)
            call evaluate_batch_splines_3d_der_nq1_o355( &
                spl, x_eval, y_device, dy_device)
            !$acc end serial
            call assert_close_vec("o355 device value", y_device, y_ref, TOL)
            call assert_close_mat("o355 device dy", dy_device, dy_ref, TOL)
        end do
        call destroy_batch_splines_3d(spl)
    end subroutine test_der_nq1_o355_matches_full_der2_periodic

    subroutine test_rmix_matches_full_der2_nq2_o555
        integer, parameter :: N_POINTS(3) = [24, 26, 28]
        integer, parameter :: ORDER(3) = [5, 5, 5]
        logical, parameter :: PERIODIC(3) = [.false., .true., .false.]
        integer, parameter :: NQ = 2

        type(BatchSplineData3D) :: spl
        real(dp) :: y_data(N_POINTS(1), N_POINTS(2), N_POINTS(3), NQ)
        real(dp) :: x_min(3), x_max(3)
        real(dp) :: x_eval(3)
        real(dp) :: y1(NQ), y2(NQ)
        real(dp) :: dy1(3, NQ), dy2(3, NQ)
        real(dp) :: d2_full(6, NQ), d2_rmix(3, NQ)
        integer :: i1, i2, i3, iq, n_test

        x_min = [0.2d0, 0.0d0, -0.6d0]
        x_max = [1.4d0, 2.0d0, 0.8d0]

        do iq = 1, NQ
            do i3 = 1, N_POINTS(3)
                do i2 = 1, N_POINTS(2)
                    do i1 = 1, N_POINTS(1)
                        y_data(i1, i2, i3, iq) = real(iq, dp) * &
                                                 (sin(real(i1 - 1, dp)*0.05d0) + &
                                                  cos(real(i2 - 1, dp)*0.04d0) + &
                                                  exp(-real(i3 - 1, dp)*0.03d0))
                    end do
                end do
            end do
        end do

        call construct_batch_splines_3d(x_min, x_max, y_data, ORDER, PERIODIC, spl)

        do n_test = 1, 7
            x_eval(1) = x_min(1) + (x_max(1) - x_min(1)) * real(1 + n_test, dp) / 9.0d0
            x_eval(2) = x_min(2) + (x_max(2) - x_min(2)) * real(2 + n_test, dp) / 9.0d0
            x_eval(3) = x_min(3) + (x_max(3) - x_min(3)) * real(3 + n_test, dp) / 9.0d0

            call evaluate_batch_splines_3d_der2(spl, x_eval, y1, dy1, d2_full)
            call evaluate_batch_splines_3d_der2_rmix(spl, x_eval, y2, dy2, d2_rmix)

            call assert_close_vec("value", y2, y1, TOL)
            call assert_close_mat("dy", dy2, dy1, TOL)
            call assert_close_vec("d2_rmix(1)", d2_rmix(1, :), d2_full(1, :), TOL)
            call assert_close_vec("d2_rmix(2)", d2_rmix(2, :), d2_full(2, :), TOL)
            call assert_close_vec("d2_rmix(3)", d2_rmix(3, :), d2_full(3, :), TOL)
        end do

        call destroy_batch_splines_3d(spl)
    end subroutine test_rmix_matches_full_der2_nq2_o555

    subroutine assert_close_vec(label, got, ref, tol)
        character(*), intent(in) :: label
        real(dp), intent(in) :: got(:), ref(:)
        real(dp), intent(in) :: tol
        integer :: i

        if (size(got) /= size(ref)) error stop "assert_close_vec: size mismatch"

        do i = 1, size(got)
            if (abs(got(i) - ref(i)) > tol) then
                print *, "Mismatch: ", trim(label), " i=", i
                print *, "  got=", got(i)
                print *, "  ref=", ref(i)
                print *, "  absdiff=", abs(got(i) - ref(i))
                error stop "assert_close_vec failed"
            end if
        end do
    end subroutine assert_close_vec

    subroutine assert_close_mat(label, got, ref, tol)
        character(*), intent(in) :: label
        real(dp), intent(in) :: got(:, :), ref(:, :)
        real(dp), intent(in) :: tol
        integer :: i, j

        if (any(shape(got) /= shape(ref))) error stop "assert_close_mat: shape mismatch"

        do j = 1, size(got, 2)
            do i = 1, size(got, 1)
                if (abs(got(i, j) - ref(i, j)) > tol) then
                    print *, "Mismatch: ", trim(label), " (", i, ",", j, ")"
                    print *, "  got=", got(i, j)
                    print *, "  ref=", ref(i, j)
                    print *, "  absdiff=", abs(got(i, j) - ref(i, j))
                    error stop "assert_close_mat failed"
                end if
            end do
        end do
    end subroutine assert_close_mat

end program test_batch_interpolate_rmix
