set (CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

set (MAIN_LIB ${MAIN_LIB} neo)
set (HDF5_TOOLS_LIB ${HDF5_TOOLS_LIB} hdf5_tools)
set (MAGFIE_LIB ${MAGFIE_LIB} magfie)

set(PROJLIBS /proj/plasma/Libs/ CACHE STRING "Common library path")

include_directories(${PROJECT_SOURCE_DIR}/src/hdf5_tools)

# Assumes previous include of hdf5_tools/CMakeLists.txt for find_package
include_directories(${HDF5_INCLUDE_DIRS})

set(LIBNEO_TESTING_ENABLED OFF)
if(DEFINED ENV{LIBNEO_TESTING})
  string(STRIP "$ENV{LIBNEO_TESTING}" _libneo_testing_raw)
  string(TOLOWER "${_libneo_testing_raw}" _libneo_testing_value)
  if(NOT _libneo_testing_value STREQUAL ""
      AND NOT _libneo_testing_value STREQUAL "0"
      AND NOT _libneo_testing_value STREQUAL "false"
      AND NOT _libneo_testing_value STREQUAL "no"
      AND NOT _libneo_testing_value STREQUAL "off")
    set(LIBNEO_TESTING_ENABLED ON)
  endif()
endif()

find_package(Python COMPONENTS Interpreter)
if (NOT Python_FOUND)
  message(FATAL_ERROR "Python interpreter required for GEQDSK scripts")
endif()

if(LIBNEO_DETERMINISTIC_FP)
  add_test(
    NAME deterministic_fp_compile_flags
    COMMAND ${CMAKE_COMMAND}
      -DCOMPILE_COMMANDS=${CMAKE_BINARY_DIR}/compile_commands.json
      -DSOURCE_ROOT=${PROJECT_SOURCE_DIR}
      -P ${CMAKE_CURRENT_SOURCE_DIR}/cmake/check_deterministic_fp_flags.cmake
  )
endif()

set (COMMON_LIBS ${MAIN_LIB} ${BLAS_LIBRARIES} ${LAPACK_LIBRARIES})

add_executable(test_transport.x transport/test_transport.f90)
target_link_libraries(test_transport.x
  neo
  transport
  collision_freqs
  util_for_test
)

add_executable(test_collision_freqs.x collisions/test_collision_freqs.f90)
target_link_libraries(test_collision_freqs.x
  neo
  collision_freqs
  species
  util_for_test
)

add_executable(test_arnoldi.x source/test_arnoldi.f90)
target_link_libraries(test_arnoldi.x
  ${COMMON_LIBS}
)

add_executable(test_binsrc.x source/test_binsrc.f90)
target_link_libraries(test_binsrc.x
  ${COMMON_LIBS}
)

add_executable(test_boozer_coordinates_exports.x
  source/test_boozer_coordinates_exports.f90
)
target_link_libraries(test_boozer_coordinates_exports.x
  neo
)

add_executable(test_boozer_symplectic_table.x
  source/test_boozer_symplectic_table.f90
)
target_link_libraries(test_boozer_symplectic_table.x neo)

add_executable(test_axis_power_law_regularization.x
  source/test_axis_power_law_regularization.f90
)
target_link_libraries(test_axis_power_law_regularization.x
  neo
)

add_executable(test_axis_polyfit_regularization.x
  source/test_axis_polyfit_regularization.f90
)
target_link_libraries(test_axis_polyfit_regularization.x
  neo
)

add_executable(test_flux_pseudocartesian.x
  source/test_flux_pseudocartesian.f90
)
target_link_libraries(test_flux_pseudocartesian.x
  neo
)

add_executable(test_christoffel_symflux.x
  source/test_christoffel_symflux.f90
)
target_link_libraries(test_christoffel_symflux.x
  neo
)

add_executable(test_coordinate_christoffel.x
  source/test_coordinate_christoffel.f90
)
target_link_libraries(test_coordinate_christoffel.x
  neo
)

add_executable(test_axis_healing_mode.x
  source/test_axis_healing_mode.f90
)
target_link_libraries(test_axis_healing_mode.x
  neo
)

add_executable(test_geqdsk_tools.x source/test_geqdsk_tools.f90)
target_link_libraries(test_geqdsk_tools.x
  ${MAIN_LIB}
  ${MAGFIE_LIB}
)

if(LIBNEO_TESTING_ENABLED)
  set(TEST_OUTPUT_DIR ${CMAKE_BINARY_DIR}/test)
  file(MAKE_DIRECTORY ${TEST_OUTPUT_DIR})
  # Create subdirectories for different test types
  file(MAKE_DIRECTORY ${TEST_OUTPUT_DIR}/source)
  file(MAKE_DIRECTORY ${TEST_OUTPUT_DIR}/scripts)
  file(MAKE_DIRECTORY ${TEST_OUTPUT_DIR}/python)
  file(MAKE_DIRECTORY ${TEST_OUTPUT_DIR}/poincare)

  add_executable(test_geoflux.x source/test_geoflux.f90)
  target_link_libraries(test_geoflux.x
    ${COMMON_LIBS}
    ${MAGFIE_LIB}
  )

  add_executable(geoflux_coord_dump.x source/geoflux_coord_dump.f90)
  target_link_libraries(geoflux_coord_dump.x
    ${COMMON_LIBS}
    ${MAGFIE_LIB}
  )
endif()

add_executable(test_simpson.x source/test_simpson.f90)
target_link_libraries(test_simpson.x
  ${COMMON_LIBS}
)
add_executable(test_hdf5_tools.x source/test_hdf5_tools.f90)
target_link_libraries(test_hdf5_tools.x
  ${HDF5_TOOLS_LIB}
)

add_executable(test_system_utility.x
  source/test_system_utility.f90)
target_link_libraries(test_system_utility.x
  ${COMMON_LIBS}
)

add_executable(test_util.x source/test_util.f90)
target_link_libraries(test_util.x ${COMMON_LIBS})

add_executable(test_cgls_dense.x source/test_cgls_dense.f90)
target_link_libraries(test_cgls_dense.x ${COMMON_LIBS})

add_executable(test_spline_cgls_global.x source/test_spline_cgls_global.f90)
target_link_libraries(test_spline_cgls_global.x ${COMMON_LIBS})

add_executable(test_plag_coeff.x source/test_plag_coeff.f90)
target_link_libraries(test_plag_coeff.x ${COMMON_LIBS})

add_executable(test_spl_three_to_five.x source/test_spl_three_to_five.f90)
target_link_libraries(test_spl_three_to_five.x ${COMMON_LIBS})

add_executable(test_spline_build_lines.x source/test_spline_build_lines.f90)
target_link_libraries(test_spline_build_lines.x ${COMMON_LIBS})

add_executable(test_species.x source/test_species.f90)
target_link_libraries(test_species.x neo species)

add_executable(test_rng.x source/test_rng.f90 ../src/MC/rng.f90)
target_link_libraries(test_rng.x ${COMMON_LIBS})

add_executable(test_polylag_3.x source/test_polylag_3.f90)
target_link_libraries(test_polylag_3.x ${COMMON_LIBS} ${MAGFIE_LIB})

add_executable(test_interpolate.x source/test_interpolate.f90)
target_link_libraries(test_interpolate.x ${COMMON_LIBS})

add_executable(test_batch_interpolate.x source/test_batch_interpolate.f90)
target_link_libraries(test_batch_interpolate.x ${COMMON_LIBS})

add_executable(test_batch_interpolate_der3.x source/test_batch_interpolate_der3.f90)
target_link_libraries(test_batch_interpolate_der3.x ${COMMON_LIBS})

add_executable(test_batch_interpolate_many.x source/test_batch_interpolate_many.f90)
target_link_libraries(test_batch_interpolate_many.x ${COMMON_LIBS})

add_executable(test_batch_interpolate_rmix.x source/test_batch_interpolate_rmix.f90)
target_link_libraries(test_batch_interpolate_rmix.x ${COMMON_LIBS})
if(ENABLE_OPENACC AND CMAKE_Fortran_COMPILER_ID STREQUAL "NVHPC")
  if(LIBNEO_OPENACC_MEM STREQUAL "managed")
    set(_libneo_test_openacc_mem_option "managed")
  else()
    set(_libneo_test_openacc_mem_option "mem:${LIBNEO_OPENACC_MEM}")
  endif()
  target_compile_options(test_batch_interpolate_rmix.x PRIVATE
    -acc -gpu=${LIBNEO_OPENACC_GPU_ARCH},${_libneo_test_openacc_mem_option})
endif()

add_executable(test_batch_interpolate_scalar_cubic.x
  source/test_batch_interpolate_scalar_cubic.f90)
target_link_libraries(test_batch_interpolate_scalar_cubic.x ${COMMON_LIBS})

add_executable(test_batch_interpolate_1d_fixed.x
  source/test_batch_interpolate_1d_fixed.f90)
target_link_libraries(test_batch_interpolate_1d_fixed.x ${COMMON_LIBS})

add_executable(test_batch_interpolate_der_nq1.x source/test_batch_interpolate_der_nq1.f90)
target_link_libraries(test_batch_interpolate_der_nq1.x ${COMMON_LIBS})

add_executable(test_batch_interpolate_oracle.x source/test_batch_interpolate_oracle.f90)
target_link_libraries(test_batch_interpolate_oracle.x ${COMMON_LIBS})

add_executable(test_batch_interpolate_mask.x source/test_batch_interpolate_mask.f90)
target_link_libraries(test_batch_interpolate_mask.x ${COMMON_LIBS})

add_executable(test_batch_eval_oracle.x
    source/test_batch_eval_oracle.f90
    source/spline_eval_reference.f90)
target_link_libraries(test_batch_eval_oracle.x ${COMMON_LIBS})

add_executable(benchmark_spline_performance.x source/benchmark_spline_performance.f90)
target_link_libraries(benchmark_spline_performance.x ${COMMON_LIBS})

add_executable(test_spline_performance.x source/test_spline_performance.f90)
target_link_libraries(test_spline_performance.x ${COMMON_LIBS})

add_executable(test_vmec_modules.x source/test_vmec_modules.f90)
target_link_libraries(test_vmec_modules.x neo)

add_executable(test_coordinate_systems.x source/test_coordinate_systems.f90)
target_link_libraries(test_coordinate_systems.x neo ${MAGFIE_LIB})

add_executable(test_chartmap_coordinates.x source/test_chartmap_coordinates.f90)
target_link_libraries(test_chartmap_coordinates.x neo ${MAGFIE_LIB})

add_executable(test_chartmap_basis_debug.x source/test_chartmap_basis_debug.f90)
target_link_libraries(test_chartmap_basis_debug.x neo ${MAGFIE_LIB})

add_executable(test_chartmap_validator.x source/test_chartmap_validator.f90)
target_link_libraries(test_chartmap_validator.x neo)

add_executable(test_chartmap_boozer_coordinates.x source/test_chartmap_boozer_coordinates.f90)
target_link_libraries(test_chartmap_boozer_coordinates.x neo ${MAGFIE_LIB})

add_executable(test_chartmap_invert_cart.x source/test_chartmap_invert_cart.f90)
target_link_libraries(test_chartmap_invert_cart.x neo ${MAGFIE_LIB})

# TODO: Update test for new psi_1..psi_7 interface
# add_executable(test_analytical_gs_circular.x source/test_analytical_gs_circular.f90)
# target_link_libraries(test_analytical_gs_circular.x ${MAGFIE_LIB} ${COMMON_LIBS})

add_executable(test_analytical_circular.x source/test_analytical_circular.f90)
target_link_libraries(test_analytical_circular.x ${MAGFIE_LIB} ${COMMON_LIBS})

add_executable(test_ripple_field.x source/test_ripple_field.f90)
target_link_libraries(test_ripple_field.x ${MAGFIE_LIB} ${COMMON_LIBS})

add_executable(test_nctools_nc_get3.x source/test_nctools_nc_get3.f90)
target_link_libraries(test_nctools_nc_get3.x
  ${COMMON_LIBS}
)


## Standard tests according to standard libneo Fortran test convention.

add_test(NAME test_binsrc COMMAND test_binsrc.x)
add_test(NAME test_axis_power_law_regularization
  COMMAND test_axis_power_law_regularization.x)
add_test(NAME test_axis_polyfit_regularization
  COMMAND test_axis_polyfit_regularization.x)
add_test(NAME test_flux_pseudocartesian
  COMMAND test_flux_pseudocartesian.x)
add_test(NAME test_christoffel_symflux
  COMMAND test_christoffel_symflux.x)
add_test(NAME test_coordinate_christoffel
  COMMAND test_coordinate_christoffel.x)
add_test(NAME test_axis_healing_mode
  COMMAND test_axis_healing_mode.x)
add_test(NAME test_boozer_coordinates_exports
  COMMAND test_boozer_coordinates_exports.x
)
add_test(NAME test_boozer_symplectic_table
  COMMAND test_boozer_symplectic_table.x
)
add_test(NAME test_geqdsk_tools COMMAND test_geqdsk_tools.x)
add_test(NAME test_simpson COMMAND test_simpson.x)
add_test(NAME test_hdf5_tools COMMAND test_hdf5_tools.x)
add_test(NAME test_util COMMAND test_util.x)
add_test(NAME test_cgls_dense COMMAND test_cgls_dense.x)
add_test(NAME test_plag_coeff COMMAND test_plag_coeff.x)
add_test(NAME test_spl_three_to_five COMMAND test_spl_three_to_five.x)
add_test(NAME test_spline_build_lines COMMAND test_spline_build_lines.x)
add_test(NAME test_species COMMAND test_species.x)
add_test(NAME test_rng COMMAND test_rng.x)
add_test(NAME test_polylag_3 COMMAND test_polylag_3.x)
add_test(NAME test_spline_cgls_global COMMAND test_spline_cgls_global.x)
add_test(NAME test_interpolate COMMAND test_interpolate.x)
add_test(NAME test_batch_interpolate COMMAND test_batch_interpolate.x)
add_test(NAME test_batch_interpolate_der3 COMMAND test_batch_interpolate_der3.x)
add_test(NAME test_batch_interpolate_many COMMAND test_batch_interpolate_many.x)
add_test(NAME test_batch_interpolate_rmix COMMAND test_batch_interpolate_rmix.x)
add_test(NAME test_batch_interpolate_scalar_cubic
  COMMAND test_batch_interpolate_scalar_cubic.x)
add_test(NAME test_batch_interpolate_1d_fixed
  COMMAND test_batch_interpolate_1d_fixed.x)
add_test(NAME test_batch_interpolate_der_nq1 COMMAND test_batch_interpolate_der_nq1.x)
add_test(NAME test_batch_interpolate_oracle COMMAND test_batch_interpolate_oracle.x)
add_test(NAME test_batch_interpolate_mask COMMAND test_batch_interpolate_mask.x)
add_test(NAME test_batch_eval_oracle COMMAND test_batch_eval_oracle.x)
add_test(NAME test_spline_performance COMMAND test_spline_performance.x)
add_test(NAME test_collision_freqs COMMAND test_collision_freqs.x)
add_test(NAME test_transport COMMAND test_transport.x)
add_test(NAME test_vmec_modules COMMAND test_vmec_modules.x)
add_test(NAME test_coordinate_systems COMMAND test_coordinate_systems.x)
# add_test(NAME test_analytical_gs_circular COMMAND test_analytical_gs_circular.x)  # TODO: update for new interface
add_test(NAME test_analytical_circular COMMAND test_analytical_circular.x)
add_test(NAME test_nctools_nc_get3 COMMAND test_nctools_nc_get3.x)

# These tests use fixed relative paths ../../test/resources/... in the sources.
# Run them from ${CMAKE_SOURCE_DIR}/test/source so those paths resolve to
# ${CMAKE_SOURCE_DIR}/test/resources/...
set_tests_properties(test_geqdsk_tools PROPERTIES
  WORKING_DIRECTORY ${CMAKE_SOURCE_DIR}/test/source
)

# test_ascot5_compare is run separately in CI workflow (not in ctest)
# because a5py requires libascot.so at import time, which the test builds

add_test(NAME test_ripple_field COMMAND test_ripple_field.x)

if(LIBNEO_TESTING_ENABLED)
  add_test(
    NAME test_geoflux
    COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/run_geoflux_test.py
            --exe $<TARGET_FILE:test_geoflux.x>
            --data-dir ${TEST_OUTPUT_DIR}/scripts
  )

  add_test(
    NAME test_geqdsk_plot
    COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/geqdsk_plot.py
            --data-dir ${TEST_OUTPUT_DIR}/scripts
            --output-dir ${TEST_OUTPUT_DIR}/scripts
            --basename geqdsk
  )
  set_tests_properties(test_geqdsk_plot PROPERTIES DEPENDS test_geoflux)

  add_test(
    NAME test_geoflux_plot
    COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/geoflux_plot.py
            --exe $<TARGET_FILE:geoflux_coord_dump.x>
            --data-dir ${TEST_OUTPUT_DIR}/scripts
            --output-dir ${TEST_OUTPUT_DIR}/scripts
            --basename geoflux
  )
  set_tests_properties(test_geoflux_plot PROPERTIES DEPENDS test_geoflux)

  add_test(
    NAME test_geoflux_coordinate_system
    COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/run_geoflux_test.py
            --exe $<TARGET_FILE:test_geoflux_coordinate_system.x>
            --data-dir ${TEST_OUTPUT_DIR}/scripts
  )
  set_tests_properties(test_geoflux_coordinate_system PROPERTIES
    FAIL_REGULAR_EXPRESSION "STOP"
    DEPENDS test_geoflux)
endif()

## Custom tests

# This requires an additional call to setup_test_arnoldi.py, so use the script
# instead of calling the executable directly.
# \note Maybe this could be solved with setup_test_arnoldi.py && test_arnoldi.x.
# Afterwards fail condition is set: test will fail if the output
# contains 'STOP'.
add_test(NAME test_arnoldi_setup
  COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/source/setup_test_arnoldi.py)
set_tests_properties(test_arnoldi_setup PROPERTIES WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_test(NAME test_arnoldi COMMAND test_arnoldi.x)
set_tests_properties(test_arnoldi PROPERTIES 
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS test_arnoldi_setup
  FAIL_REGULAR_EXPRESSION "STOP")

add_test(NAME test_system_utility
         COMMAND test_system_utility.x)
set_tests_properties(test_system_utility PROPERTIES  FAIL_REGULAR_EXPRESSION "WARNING: resource usage could not be determined.")

add_test(
  NAME setup_chartmap_volume
  COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/setup_chartmap_volume.py
          --output-dir ${CMAKE_CURRENT_BINARY_DIR}
)

add_test(
  NAME setup_vmec_wout
  COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/setup_vmec_wout.py
          --output-dir ${CMAKE_CURRENT_BINARY_DIR}
)

add_test(
  NAME setup_vmec_chartmap_python
  COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/setup_vmec_chartmap_python.py
          --output-dir ${CMAKE_CURRENT_BINARY_DIR}
)
set_tests_properties(setup_vmec_chartmap_python PROPERTIES
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout
)

add_test(
  NAME validate_vmec_rho_lcfs_auto
  COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/validate_vmec_rho_lcfs_auto.py
          --output-dir ${CMAKE_CURRENT_BINARY_DIR}
)
set_tests_properties(validate_vmec_rho_lcfs_auto PROPERTIES
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout
)

add_test(
  NAME validate_vmec_map2disc_chartmap_boundary_python
  COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/validate_vmec_map2disc_chartmap_boundary.py
          --wout ${CMAKE_CURRENT_BINARY_DIR}/wout.nc
          --chartmap ${CMAKE_CURRENT_BINARY_DIR}/wout_vmec_python.chartmap.nc
)
set_tests_properties(validate_vmec_map2disc_chartmap_boundary_python PROPERTIES
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_chartmap_python
)

add_test(
  NAME plot_vmec_map2disc_chartmap_boundary_python
  COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/plot_vmec_map2disc_chartmap_boundary.py
          --wout ${CMAKE_CURRENT_BINARY_DIR}/wout.nc
          --chartmap ${CMAKE_CURRENT_BINARY_DIR}/wout_vmec_python.chartmap.nc
          --out ${CMAKE_CURRENT_BINARY_DIR}/wout_vmec_python.chartmap_boundary.png
)
set_tests_properties(plot_vmec_map2disc_chartmap_boundary_python PROPERTIES
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_chartmap_python
)

add_test(
  NAME validate_vmec_map2disc_chartmap_boundary_cli
  COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/validate_vmec_map2disc_chartmap_boundary.py
          --wout ${CMAKE_CURRENT_BINARY_DIR}/wout.nc
          --chartmap ${CMAKE_CURRENT_BINARY_DIR}/wout_vmec_cli.chartmap.nc
)
set_tests_properties(validate_vmec_map2disc_chartmap_boundary_cli PROPERTIES
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_chartmap_python
)

add_test(
  NAME plot_vmec_map2disc_chartmap_boundary_cli
  COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/plot_vmec_map2disc_chartmap_boundary.py
          --wout ${CMAKE_CURRENT_BINARY_DIR}/wout.nc
          --chartmap ${CMAKE_CURRENT_BINARY_DIR}/wout_vmec_cli.chartmap.nc
          --out ${CMAKE_CURRENT_BINARY_DIR}/wout_vmec_cli.chartmap_boundary.png
)
set_tests_properties(plot_vmec_map2disc_chartmap_boundary_cli PROPERTIES
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_chartmap_python
)

add_test(
  NAME validate_vmec_map2disc_chartmap_boundary_python_padded
  COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/validate_vmec_map2disc_chartmap_boundary.py
          --wout ${CMAKE_CURRENT_BINARY_DIR}/wout.nc
          --chartmap ${CMAKE_CURRENT_BINARY_DIR}/wout_vmec_python_padded.chartmap.nc
          --boundary-offset 0.5
)
set_tests_properties(validate_vmec_map2disc_chartmap_boundary_python_padded PROPERTIES
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_chartmap_python
)

add_test(
  NAME plot_vmec_map2disc_chartmap_boundary_python_padded
  COMMAND ${Python_EXECUTABLE} ${CMAKE_SOURCE_DIR}/test/scripts/plot_vmec_map2disc_chartmap_boundary.py
          --wout ${CMAKE_CURRENT_BINARY_DIR}/wout.nc
          --chartmap ${CMAKE_CURRENT_BINARY_DIR}/wout_vmec_python_padded.chartmap.nc
          --out ${CMAKE_CURRENT_BINARY_DIR}/wout_vmec_python_padded.chartmap_boundary.png
          --boundary-offset 0.5
)
set_tests_properties(plot_vmec_map2disc_chartmap_boundary_python_padded PROPERTIES
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_chartmap_python
)

add_test(NAME test_chartmap_coordinates
  COMMAND test_chartmap_coordinates.x)
set_tests_properties(test_chartmap_coordinates PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  DEPENDS setup_chartmap_volume)

add_test(NAME test_chartmap_validator
  COMMAND test_chartmap_validator.x)
set_tests_properties(test_chartmap_validator PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_test(NAME test_chartmap_boozer_coordinates
  COMMAND test_chartmap_boozer_coordinates.x)
set_tests_properties(test_chartmap_boozer_coordinates PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_test(NAME test_chartmap_invert_cart
  COMMAND test_chartmap_invert_cart.x)
set_tests_properties(test_chartmap_invert_cart PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_library(chartmap_test_utils STATIC source/chartmap_test_utils.f90)
target_link_libraries(chartmap_test_utils PUBLIC neo)

add_library(chartmap_gate_fixtures STATIC source/chartmap_gate_fixtures.f90)
target_link_libraries(chartmap_gate_fixtures PUBLIC neo)

add_executable(test_chartmap_gate_jacobian.x source/test_chartmap_gate_jacobian.f90)
target_link_libraries(test_chartmap_gate_jacobian.x chartmap_gate_fixtures)
add_test(NAME test_chartmap_gate_jacobian
  COMMAND test_chartmap_gate_jacobian.x)
set_tests_properties(test_chartmap_gate_jacobian PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_executable(test_chartmap_gate_fieldline.x source/test_chartmap_gate_fieldline.f90)
target_link_libraries(test_chartmap_gate_fieldline.x chartmap_gate_fixtures neo_field)
add_test(NAME test_chartmap_gate_fieldline
  COMMAND test_chartmap_gate_fieldline.x)
set_tests_properties(test_chartmap_gate_fieldline PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_executable(test_chartmap_gate_reconstruction.x
  source/test_chartmap_gate_reconstruction.f90)
target_link_libraries(test_chartmap_gate_reconstruction.x
  chartmap_gate_fixtures neo_field)
add_test(NAME test_chartmap_gate_reconstruction
  COMMAND test_chartmap_gate_reconstruction.x)
set_tests_properties(test_chartmap_gate_reconstruction PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_executable(test_vmec_chartmap_generator.x source/test_vmec_chartmap_generator.f90)
target_link_libraries(test_vmec_chartmap_generator.x chartmap_test_utils)
add_test(NAME test_vmec_chartmap_generator
  COMMAND test_vmec_chartmap_generator.x)
set_tests_properties(test_vmec_chartmap_generator PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(test_python_chartmap_generator.x source/test_python_chartmap_generator.f90)
target_link_libraries(test_python_chartmap_generator.x chartmap_test_utils)
add_test(NAME test_python_chartmap_generator
  COMMAND test_python_chartmap_generator.x)
set_tests_properties(test_python_chartmap_generator PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_chartmap_python)

add_executable(test_vmec_coordinate_system.x source/test_vmec_coordinate_system.f90)
target_link_libraries(test_vmec_coordinate_system.x neo)
add_test(NAME test_vmec_coordinate_system
  COMMAND test_vmec_coordinate_system.x)
set_tests_properties(test_vmec_coordinate_system PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(test_splint_vmec_data_d3.x source/test_splint_vmec_data_d3.f90)
target_link_libraries(test_splint_vmec_data_d3.x neo)
add_test(NAME test_splint_vmec_data_d3
  COMMAND test_splint_vmec_data_d3.x)
set_tests_properties(test_splint_vmec_data_d3 PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(test_vmec_from_cyl.x source/test_vmec_from_cyl.f90)
target_link_libraries(test_vmec_from_cyl.x neo)
add_test(NAME test_vmec_from_cyl
  COMMAND test_vmec_from_cyl.x)
set_tests_properties(test_vmec_from_cyl PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(test_vector_conversion.x source/test_vector_conversion.f90)
target_link_libraries(test_vector_conversion.x neo ${MAGFIE_LIB})
add_test(NAME test_vector_conversion
  COMMAND test_vector_conversion.x)
set_tests_properties(test_vector_conversion PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_chartmap_volume)

add_executable(test_geoflux_coordinate_system.x source/test_geoflux_coordinate_system.f90)
target_link_libraries(test_geoflux_coordinate_system.x neo ${MAGFIE_LIB})

add_executable(test_chartmap_matches_vmec.x source/test_chartmap_matches_vmec.f90)
target_link_libraries(test_chartmap_matches_vmec.x neo)
add_test(NAME test_chartmap_matches_vmec
  COMMAND test_chartmap_matches_vmec.x)
set_tests_properties(test_chartmap_matches_vmec PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(bench_boozer_resolution.x source/bench_boozer_resolution.f90)
target_link_libraries(bench_boozer_resolution.x neo)

add_executable(test_boozer_converter_vs_simple.x source/test_boozer_converter_vs_simple.f90)
target_link_libraries(test_boozer_converter_vs_simple.x neo)
add_test(NAME test_boozer_converter_vs_simple
  COMMAND test_boozer_converter_vs_simple.x)
set_tests_properties(test_boozer_converter_vs_simple PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(test_boozer_angle_roundtrip.x source/test_boozer_angle_roundtrip.f90)
target_link_libraries(test_boozer_angle_roundtrip.x neo)
add_test(NAME test_boozer_angle_roundtrip
  COMMAND test_boozer_angle_roundtrip.x)
set_tests_properties(test_boozer_angle_roundtrip PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(test_boozer_chartmap_roundtrip.x source/test_boozer_chartmap_roundtrip.f90)
target_link_libraries(test_boozer_chartmap_roundtrip.x neo)
add_test(NAME test_boozer_chartmap_roundtrip
  COMMAND test_boozer_chartmap_roundtrip.x)
set_tests_properties(test_boozer_chartmap_roundtrip PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(test_boozmn_reader.x source/test_boozmn_reader.f90)
target_link_libraries(test_boozmn_reader.x neo)
add_test(NAME test_boozmn_reader
  COMMAND test_boozmn_reader.x)
set_tests_properties(test_boozmn_reader PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_executable(test_bc_file.x source/test_bc_file.f90)
target_link_libraries(test_bc_file.x neo)
add_test(NAME test_bc_file
  COMMAND test_bc_file.x)
set_tests_properties(test_bc_file PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_executable(test_delthe_delphi_bv_d2.x source/test_delthe_delphi_bv_d2.f90)
target_link_libraries(test_delthe_delphi_bv_d2.x neo)
add_test(NAME test_delthe_delphi_bv_d2
  COMMAND test_delthe_delphi_bv_d2.x)
set_tests_properties(test_delthe_delphi_bv_d2 PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(test_delthe_delphi_bv_d3.x source/test_delthe_delphi_bv_d3.f90)
target_link_libraries(test_delthe_delphi_bv_d3.x neo)
add_test(NAME test_delthe_delphi_bv_d3
  COMMAND test_delthe_delphi_bv_d3.x)
set_tests_properties(test_delthe_delphi_bv_d3 PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(test_chartmap_vmec_mapping.x source/test_chartmap_vmec_mapping.f90)
target_link_libraries(test_chartmap_vmec_mapping.x neo)
add_test(NAME test_chartmap_vmec_mapping
  COMMAND test_chartmap_vmec_mapping.x)
set_tests_properties(test_chartmap_vmec_mapping PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(test_chartmap_derivatives.x source/test_chartmap_derivatives.f90)
target_link_libraries(test_chartmap_derivatives.x neo)
add_test(NAME test_chartmap_derivatives
  COMMAND test_chartmap_derivatives.x)
set_tests_properties(test_chartmap_derivatives PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
  DEPENDS setup_vmec_wout)

add_executable(test_refcoords_file_detection.x source/test_refcoords_file_detection.f90)
target_link_libraries(test_refcoords_file_detection.x neo)
add_test(NAME test_refcoords_file_detection
  COMMAND test_refcoords_file_detection.x)
set_tests_properties(test_refcoords_file_detection PROPERTIES
  FAIL_REGULAR_EXPRESSION "STOP"
  WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

add_subdirectory(util_for_test)
add_subdirectory(util_for_test_field)
add_subdirectory(field)
add_subdirectory(magfie)
add_subdirectory(polylag)
add_subdirectory(poincare)
add_subdirectory(odeint)
add_subdirectory(spectre)
add_subdirectory(jorek)
