# This file is intended for configuration of libneo.

# Basic cmake settings/requirements
cmake_minimum_required(VERSION 3.22)

# Basic project settings.
project(libneo)

# Detect if libneo is standalone or a subproject
set(LIBNEO_IS_STANDALONE OFF)
if(CMAKE_PROJECT_NAME STREQUAL PROJECT_NAME)
    set(LIBNEO_IS_STANDALONE ON)
endif()

option(LIBNEO_BUILD_TESTING "Build tests for libneo" ${LIBNEO_IS_STANDALONE})

# A top-level BUILD_TESTING setting controls standalone libneo, but must not
# implicitly inject libneo's tests into a consuming project's target namespace.
if(LIBNEO_IS_STANDALONE AND DEFINED BUILD_TESTING)
    set(LIBNEO_BUILD_TESTING ${BUILD_TESTING})
elseif(NOT LIBNEO_IS_STANDALONE)
    # A consumer may reuse a build tree previously configured with an older
    # standalone libneo, leaving this cache entry enabled. Never inject
    # libneo's test targets into the consumer's target namespace.
    set(LIBNEO_BUILD_TESTING OFF)
endif()

# Standalone builds run libneo's own Python tests and f2py; resolve Python from
# the uv-managed project venv so their dependencies are available.
if(LIBNEO_IS_STANDALONE AND NOT SKBUILD)
    include(${CMAKE_CURRENT_SOURCE_DIR}/cmake/UvPython.cmake)
endif()

# Numerics-heavy components (neo core, magfie, collisions, transport,
# coordinates, vmec_field, efit_to_boozer) pull fortnum and require BLAS/LAPACK.
# Consumers that only link the light targets (interpolate, vmec_support, boozer,
# field, nctools, util, ...) set this OFF to skip those dependencies entirely.
option(LIBNEO_BUILD_NUMERICS "Build numerics-heavy components requiring BLAS/LAPACK and fortnum" ON)
option(LIBNEO_BUILD_JOREK "Build the HDF5-backed JOREK restart component" ${LIBNEO_BUILD_NUMERICS})
option(LIBNEO_DETERMINISTIC_FP
    "Disable value-changing floating-point optimizations in GNU Release and Fast builds" OFF)

if(LIBNEO_DETERMINISTIC_FP)
    set(CMAKE_EXPORT_COMPILE_COMMANDS ON)
endif()

set(CMAKE_POSITION_INDEPENDENT_CODE ON)
set(CMAKE_MODULE_PATH ${CMAKE_MODULE_PATH} "${PROJECT_SOURCE_DIR}/cmake/Modules/")

# Define available build types
set_property(CACHE CMAKE_BUILD_TYPE PROPERTY STRINGS
    Debug Release Fast
)

# Set default build type to Release if not specified
if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
    message(STATUS "Setting build type to 'Release' as none was specified.")
    set(CMAKE_BUILD_TYPE "Release" CACHE STRING
        "Choose the type of build." FORCE)
endif()

message(STATUS "CMake build type: ${CMAKE_BUILD_TYPE}")

# Enable interprocedural optimization (LTO) for Release builds
# DISABLED: LTO causes numerical instability in geqdsk_GS_prefactor calculation
# This is a confirmed gfortran LTO bug affecting finite difference calculations
# set(CMAKE_INTERPROCEDURAL_OPTIMIZATION_RELEASE TRUE)

include(Util)

set(CMAKE_Fortran_MODULE_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}/include)
set(CMAKE_LIBRARY_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR})

# The version number.
set(libneo_VERSION_MAJOR 2025)
set(libneo_VERSION_MINOR 08)
set(libneo_VERSION_PATCH 20)

# Auto-detect CUDA for NVHPC compilers (must be before enable_language)
# This sets NVHPC_CUDA_HOME and NVCOMPILER_COMM_LIBS_HOME environment variables
# if NVHPC compiler is detected and CUDA is found at /opt/cuda or /usr/local/cuda
include(${PROJECT_SOURCE_DIR}/cmake/SetupNVHPCCuda.cmake)

enable_language(C Fortran)
if(LIBNEO_DETERMINISTIC_FP AND NOT CMAKE_Fortran_COMPILER_ID STREQUAL "GNU")
    message(FATAL_ERROR
        "LIBNEO_DETERMINISTIC_FP currently supports only the GNU Fortran compiler")
endif()
if(LIBNEO_BUILD_TESTING)
    include(CTest)
endif()

option(ENABLE_OPENMP "Enable OpenMP compiler flags." ON)
set(_enable_openacc_default OFF)
if(CMAKE_Fortran_COMPILER_ID STREQUAL "NVHPC")
    set(_enable_openacc_default ON)
endif()
option(ENABLE_OPENACC "Enable OpenACC compiler flags." ${_enable_openacc_default})
set(OPENACC_OFFLOAD_TARGET "none" CACHE STRING "OpenACC offload target for GNU (none|nvptx)")
set_property(CACHE OPENACC_OFFLOAD_TARGET PROPERTY STRINGS none nvptx)
option(LIBNEO_ENABLE_GOLDEN_TESTS
    "Enable fetching and running the ODEINT golden record regression test" ON)

if(ENABLE_OPENMP)
    find_package(OpenMP REQUIRED COMPONENTS Fortran)
endif()

find_program(BASH_PROGRAM bash)

# Compiler-specific base flags and build profiles
if(${CMAKE_Fortran_COMPILER_ID} STREQUAL "GNU")
    # Base flags for all builds
    add_compile_options(-fPIC -g)
    add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-cpp>)
    add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-fno-realloc-lhs>)
    add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-fmax-errors=1>)
    add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-fbacktrace>)
    add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-ffree-line-length-132>)
    if(LIBNEO_DETERMINISTIC_FP)
        add_compile_options(-fno-fast-math -ffp-contract=off)
    endif()
    if(ENABLE_OPENACC)
        add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-fopenacc>)
        add_link_options($<$<LINK_LANGUAGE:Fortran>:-fopenacc>)
        if(OPENACC_OFFLOAD_TARGET STREQUAL "nvptx")
            add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-foffload=nvptx-none>)
            add_link_options($<$<LINK_LANGUAGE:Fortran>:-foffload=nvptx-none>)
        elseif(NOT OPENACC_OFFLOAD_TARGET STREQUAL "none")
            message(FATAL_ERROR "Invalid OPENACC_OFFLOAD_TARGET='${OPENACC_OFFLOAD_TARGET}' (expected none|nvptx)")
        endif()
    endif()

    # Build type specific flags
    if(CMAKE_BUILD_TYPE MATCHES Debug)
        add_compile_options(-Og
                          -Wall -Wextra
                          -Wno-unused-function)
        add_compile_options($<$<COMPILE_LANGUAGE:C>:-Wno-error=cast-function-type>)
        # no-recursion: gfortran < 14 emits an undefined reference to the
        # is_recursive guard for deferred-TBP targets under -Og -fcheck=recursion.
        add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-fcheck=all,no-recursion>)
        add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-Wno-external-argument-mismatch>)
        add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-ffpe-trap=invalid,zero,overflow>)
    elseif(CMAKE_BUILD_TYPE MATCHES "Release|Fast")
        # Common optimization flags for Release and Fast builds
        add_compile_options(-O3 -DNDEBUG
                          -funroll-loops
                          -ftree-vectorize)
        if(NOT LIBNEO_DETERMINISTIC_FP)
            add_compile_options(-ffast-math -ffp-contract=fast)
        endif()

        # Architecture-specific flags
        if(CMAKE_BUILD_TYPE MATCHES Fast OR CMAKE_HOST_SYSTEM_PROCESSOR MATCHES "aarch64|arm64|ARM64")
            # Fast mode or ARM: use native architecture
            # gfortran on ARM needs -mcpu=native, not -march=native
            if(CMAKE_HOST_SYSTEM_PROCESSOR MATCHES "aarch64|arm64|ARM64")
                add_compile_options(-mcpu=native)
            else()
                add_compile_options(-march=native)
            endif()
        else()
            # Release on x86-64: use v2 baseline for broad compatibility
            add_compile_options(-march=x86-64-v2 -mtune=generic)
        endif()
    endif()

    # Coverage disabled/removed from build system

    # https://github.com/numpy/numpy/issues/25777
    set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -Wno-error=incompatible-pointer-types")

    # Make trampolines a hard error - they would create executable stack
    add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-Wtrampolines>)
    add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-Werror=trampolines>)
    # Apple's linker doesn't support -z,noexecstack (uses different security model)
    if(NOT APPLE)
        add_link_options(-Wl,-z,noexecstack)
    endif()

elseif(${CMAKE_Fortran_COMPILER_ID} STREQUAL "Intel")
    # Base flags for all builds
    add_compile_options(-cpp -fPIC -g)

    # Build type specific flags
    if(CMAKE_BUILD_TYPE MATCHES Debug)
        add_compile_options(-O0 -check all -traceback -warn all)
    elseif(CMAKE_BUILD_TYPE MATCHES "Release|Fast")
        # Common optimization flags for Release and Fast builds
        add_compile_options(-O3 -fp-model fast=2 -no-prec-div -traceback)

        # Architecture-specific flags
        if(CMAKE_BUILD_TYPE MATCHES Fast)
            add_compile_options(-xHost)  # Native architecture
        else()
            add_compile_options(-xCORE-AVX2)  # Broad compatibility baseline
        endif()
    endif()

elseif(${CMAKE_Fortran_COMPILER_ID} STREQUAL "NVHPC")
    # Base flags for all builds
    add_compile_options(
        $<$<COMPILE_LANGUAGE:Fortran>:-Mpreprocess>
        -fPIC -g)

    # Note: OpenACC is applied selectively to interpolate library only
    # See src/interpolate/CMakeLists.txt

    # Build type specific flags
    if(CMAKE_BUILD_TYPE MATCHES Debug)
        add_compile_options(
            $<$<COMPILE_LANGUAGE:Fortran>:-O0>
            $<$<COMPILE_LANGUAGE:Fortran>:-Mbounds>
            $<$<COMPILE_LANGUAGE:Fortran>:-traceback>)
    elseif(CMAKE_BUILD_TYPE MATCHES "Release|Fast")
        # Common optimization flags for Release and Fast builds
        add_compile_options(
            $<$<COMPILE_LANGUAGE:Fortran>:-fast>
            $<$<COMPILE_LANGUAGE:Fortran>:-O3>
            $<$<COMPILE_LANGUAGE:Fortran>:-Mfprelaxed>
            $<$<COMPILE_LANGUAGE:Fortran>:-traceback>)

        # Architecture-specific flags
        if(CMAKE_BUILD_TYPE MATCHES Fast)
            add_compile_options($<$<COMPILE_LANGUAGE:Fortran>:-tp=host>)
        endif()
    endif()
endif()

include(FetchContent)
set(FORTIO_REF 11afd0bd1af0c99ea4e9a1c0df683dbdcc299b69 CACHE STRING
    "Fortio commit, tag, or branch used for the build")
if(NOT TARGET fortio)
    FetchContent_Declare(
        fortio
        GIT_REPOSITORY https://github.com/lazy-fortran/fortio.git
        GIT_TAG ${FORTIO_REF}
    )
    FetchContent_MakeAvailable(fortio)
endif()

# fortnum: numerical core (special functions, quadrature, FFT, ODE). Guarded so
# a repo that also pulls fortnum transitively via libneo does not double-declare
# the target.
if(LIBNEO_BUILD_NUMERICS AND NOT TARGET fortnum)
    if(DEFINED FORTNUM_SOURCE_DIR)
        get_filename_component(_fortnum_source "${FORTNUM_SOURCE_DIR}" ABSOLUTE
            BASE_DIR "${CMAKE_CURRENT_SOURCE_DIR}")
        if(NOT IS_DIRECTORY "${_fortnum_source}")
            message(FATAL_ERROR
                "FORTNUM_SOURCE_DIR='${_fortnum_source}' is not a directory")
        endif()
        add_subdirectory("${_fortnum_source}" "${CMAKE_CURRENT_BINARY_DIR}/fortnum"
            EXCLUDE_FROM_ALL)
    else()
        FetchContent_Declare(
            fortnum
            GIT_REPOSITORY https://github.com/lazy-fortran/fortnum.git
            GIT_TAG 62a559c0b8e1b28bd63550164a09ed9644e659b1
        )
        FetchContent_MakeAvailable(fortnum)
    endif()
endif()

# Tier 0: no internal libneo dependencies
add_subdirectory(src/util)
add_subdirectory(src/nctools)
if(LIBNEO_BUILD_NUMERICS OR LIBNEO_BUILD_JOREK)
    add_subdirectory(src/hdf5_tools)
endif()
add_subdirectory(src/polylag)
add_subdirectory(src/interpolate)
add_subdirectory(src/odeint)
add_subdirectory(src/field)

# Tier 1: depends on Tier 0
add_subdirectory(src/vmec_support)

if(LIBNEO_BUILD_JOREK)
    # Tier 1: JOREK restart HDF5 reader (depends on hdf5_tools only).
    add_library(jorek_support STATIC
        src/field/jorek_restart.f90
        src/field/jorek_bezier.f90
        src/field/jorek_field_values.f90
        src/field/jorek_model303_field.f90
    )
    target_link_libraries(jorek_support PUBLIC LIBNEO::hdf5_tools)
    set_property(TARGET jorek_support PROPERTY
        INTERFACE_INCLUDE_DIRECTORIES ${CMAKE_Fortran_MODULE_DIRECTORY})
    add_library(LIBNEO::jorek ALIAS jorek_support)
endif()

if(LIBNEO_BUILD_NUMERICS)
    # Tier 1: SPECTRE equilibrium HDF5 reader (depends on hdf5_tools only).
    add_library(spectre_support STATIC
        src/spectre/spectre_reader.f90
        src/spectre/spectre_basis.f90
    )
    target_link_libraries(spectre_support PUBLIC LIBNEO::hdf5_tools)
    set_property(TARGET spectre_support PROPERTY
        INTERFACE_INCLUDE_DIRECTORIES ${CMAKE_Fortran_MODULE_DIRECTORY})
    add_library(LIBNEO::spectre ALIAS spectre_support)

    add_subdirectory(src/coordinates)

    # Tier 1: abstract magnetic-field interface. magnetic_field_base.f90 provides
    # the `field_base` module (magnetic_field_t) used by the VMEC evaluators and
    # by downstream codes; a standalone target so consumers link it instead of
    # recompiling the source. Needs coordinates for coordinate_system_t.
    add_library(magnetic_field_base STATIC
        src/field/magnetic_field_base.f90
    )
    target_link_libraries(magnetic_field_base PUBLIC coordinates)
    set_property(TARGET magnetic_field_base PROPERTY
        INTERFACE_INCLUDE_DIRECTORIES ${CMAKE_Fortran_MODULE_DIRECTORY})
    add_library(LIBNEO::magnetic_field_base ALIAS magnetic_field_base)

    # Tier 2: VMEC magnetic-field evaluation.
    add_library(vmec_field STATIC
        src/field/field_vmec.f90
        src/field/vmec_field_eval.f90
    )
    target_link_libraries(vmec_field PUBLIC magnetic_field_base coordinates vmec_support interpolate)
    set_property(TARGET vmec_field PROPERTY
        INTERFACE_INCLUDE_DIRECTORIES ${CMAKE_Fortran_MODULE_DIRECTORY})
    add_library(LIBNEO::vmec_field ALIAS vmec_field)

    # Tier 2: SPECTRE magnetic-field evaluation in the stacked-rho chart (#371).
    add_library(spectre_field STATIC
        src/field/field_spectre.f90
    )
    target_link_libraries(spectre_field PUBLIC magnetic_field_base coordinates
                                               spectre_support)
    set_property(TARGET spectre_field PROPERTY
        INTERFACE_INCLUDE_DIRECTORIES ${CMAKE_Fortran_MODULE_DIRECTORY})
    add_library(LIBNEO::spectre_field ALIAS spectre_field)
endif()

# Tier 2: Boozer chartmap conversion (depends on vmec_support + interpolate + util).
add_library(boozer STATIC
    src/boozer_chartmap_types.f90
    src/boozer_rk_tables.f90
    src/boozer_converter.F90
    src/boozer_chartmap.f90
    src/field/boozer_chartmap_io.f90
    src/field/boozmn_file.f90
    src/field/boozmn_reader.f90
    src/field/bc_file.f90
)
target_link_libraries(boozer PUBLIC vmec_support interpolate neo_util)
target_link_libraries(boozer PRIVATE nctools fortio::fortio)
set_property(TARGET boozer PROPERTY
    INTERFACE_INCLUDE_DIRECTORIES ${CMAKE_Fortran_MODULE_DIRECTORY})
add_library(LIBNEO::boozer ALIAS boozer)

# Everything below is numerics-heavy (neo core, magfie, collisions, transport,
# efit_to_boozer, apps, tests, Python bindings) and needs BLAS/LAPACK + fortnum.
# Light consumers stop here.
if(NOT LIBNEO_BUILD_NUMERICS)
    return()
endif()

find_package(BLAS REQUIRED)
find_package(LAPACK REQUIRED)

# Aggregate libneo core. neo owns only poincare and re-exports every decomposed
# sub-target so monolithic consumers can keep linking LIBNEO::neo.
add_library(neo STATIC
    src/poincare.f90
)
target_link_libraries(neo PUBLIC
    $<TARGET_OBJECTS:neo_polylag>
    neo_util
    nctools
    vmec_support
    coordinates
    interpolate
    hdf5_tools
    field_base
    neo_field
    magnetic_field_base
    vmec_field
    boozer
    odeint
    fortnum
)
add_library(LIBNEO::neo ALIAS neo)
set_target_properties(neo PROPERTIES
    INTERFACE_INCLUDE_DIRECTORIES ${CMAKE_CURRENT_BINARY_DIR}/include
)

add_library(mc_efit STATIC
    src/MC/chamb_divB0.f90
    src/MC/rng.f90
)
target_link_libraries(mc_efit neo magfie)

add_executable(standardise_geqdsk.x
    src/magfie/standardise_geqdsk.f90
)
target_link_libraries(standardise_geqdsk.x magfie)

add_executable(vacfield.x src/magfie/vacfield.f90)
add_executable(coil_convert.x src/magfie/coil_convert.f90)

# Assumes previous include of hdf5_tools/CMakeLists.txt for find_package
set(hdf5_tools_include_dir ${CMAKE_BINARY_DIR})

target_link_libraries(vacfield.x magfie hdf5_tools)
target_link_libraries(coil_convert.x magfie)

# Tier 2+: depends on neo core
add_subdirectory(src/species)
add_subdirectory(src/collisions)
add_subdirectory(src/transport)
add_subdirectory(src/magfie)

if(ENABLE_OPENMP)
    target_link_libraries(neo PUBLIC OpenMP::OpenMP_Fortran)
    target_link_libraries(magfie PUBLIC OpenMP::OpenMP_Fortran)
endif()

add_subdirectory(src/efit_to_boozer)
add_executable(efit_to_boozer.x
    app/efit_to_boozer.f90
)
target_link_libraries(efit_to_boozer.x efit_to_boozer)
add_executable(hamada_to_boozer.x
    src/efit_to_boozer/field_line_integration_for_converter.f90
    src/efit_to_boozer/rhs_converter.f90
    app/hamada_to_boozer.f90
)
target_link_libraries(hamada_to_boozer.x efit_to_boozer)

add_executable(vmec_to_chartmap.x
    app/vmec_to_chartmap.f90
)
target_link_libraries(vmec_to_chartmap.x neo)

add_executable(near_axis_field_diag.x
    app/near_axis_field_diag.f90
)
target_link_libraries(near_axis_field_diag.x neo)


if(LIBNEO_BUILD_TESTING)
    add_subdirectory(test)
endif()


# MacOS RPATH specifics
# see https://gitlab.kitware.com/cmake/community/-/wikis/doc/cmake/RPATH-handling

# use, i.e. don't skip the full RPATH for the build tree
set(CMAKE_SKIP_BUILD_RPATH FALSE)

# when building, don't use the install RPATH already
# (but later on when installing)
set(CMAKE_BUILD_WITH_INSTALL_RPATH FALSE)

set(CMAKE_INSTALL_RPATH "$ORIGIN/lib")

# add the automatically determined parts of the RPATH
# which point to directories outside the build tree to the install RPATH
set(CMAKE_INSTALL_RPATH_USE_LINK_PATH TRUE)

# the RPATH to be used when installing, but only if it's not a system directory
list(FIND CMAKE_PLATFORM_IMPLICIT_LINK_DIRECTORIES "$ORIGIN/lib" isSystemDir)
if("${isSystemDir}" STREQUAL "-1")
    set(CMAKE_INSTALL_RPATH "$ORIGIN/lib")
endif("${isSystemDir}" STREQUAL "-1")

# Python bindings

find_package(Python COMPONENTS Interpreter Development NumPy)

message(STATUS "Python: ${Python_EXECUTABLE}")
message(STATUS "Python version: ${Python_VERSION}")
message(STATUS "Python include dirs: ${Python_INCLUDE_DIRS}")
message(STATUS "Python libraries: ${Python_LIBRARIES}")

if(NOT Python_FOUND)
    message("Python with NumPy not found, skipping interface build.")
    return()
endif()

# F2PY headers
execute_process(
    COMMAND "${Python_EXECUTABLE}"
    -c "import os; import numpy.f2py; print(os.path.dirname(numpy.f2py.__file__))"
    OUTPUT_VARIABLE F2PY_DIR
    OUTPUT_STRIP_TRAILING_WHITESPACE
)
set(F2PY_INCLUDE_DIR "${F2PY_DIR}/src")

include_directories(
    BEFORE
    ${Python_INCLUDE_DIRS}
    ${Python_NumPy_INCLUDE_DIRS}
    ${F2PY_INCLUDE_DIR}
)

message(STATUS "Python f2py include dir: ${F2PY_INCLUDE_DIR}")
message(STATUS "Python numpy include dir: ${Python_NumPy_INCLUDE_DIRS}")
message(STATUS "Python binary output dir: ${CMAKE_CURRENT_BINARY_DIR}")

add_library(fortranobject OBJECT "${F2PY_INCLUDE_DIR}/fortranobject.c")
target_link_libraries(fortranobject PUBLIC Python::NumPy)
target_include_directories(fortranobject PUBLIC "${F2PY_INCLUDE_DIR}")

add_custom_command(
    OUTPUT _magfiemodule.c _magfie-f2pywrappers.f _magfie-f2pywrappers2.f90
    DEPENDS
        src/f2py_interfaces/f2py_magfie.f90
        src/f2py_interfaces/f2py_vmec_wrappers.f90
        src/f2py_interfaces/f2py_vmec_support.f90
    VERBATIM
    COMMAND "${Python_EXECUTABLE}" -m numpy.f2py
        --f2cmap ${CMAKE_CURRENT_SOURCE_DIR}/.f2py_f2cmap
        "${CMAKE_CURRENT_SOURCE_DIR}/src/f2py_interfaces/f2py_magfie.f90"
        "${CMAKE_CURRENT_SOURCE_DIR}/src/f2py_interfaces/f2py_vmec_wrappers.f90"
        "${CMAKE_CURRENT_SOURCE_DIR}/src/f2py_interfaces/f2py_vmec_support.f90"
        "${CMAKE_CURRENT_SOURCE_DIR}/src/magfie/magfie_vmec.f90"
        -m _magfie --lower
)

Python_add_library(_magfie WITH_SOABI
    "${CMAKE_CURRENT_BINARY_DIR}/_magfiemodule.c"
    "${CMAKE_CURRENT_BINARY_DIR}/_magfie-f2pywrappers.f"
    "${CMAKE_CURRENT_BINARY_DIR}/_magfie-f2pywrappers2.f90"
    "${CMAKE_CURRENT_SOURCE_DIR}/src/f2py_interfaces/f2py_magfie.f90"
    "${CMAKE_CURRENT_SOURCE_DIR}/src/f2py_interfaces/f2py_vmec_wrappers.f90"
    "${CMAKE_CURRENT_SOURCE_DIR}/src/f2py_interfaces/f2py_vmec_support.f90"
    "${CMAKE_CURRENT_SOURCE_DIR}/src/magfie/magfie_vmec.f90"
)

target_link_libraries(_magfie PUBLIC fortranobject magfie neo interpolate)
add_dependencies(_magfie neo)
install(TARGETS _magfie DESTINATION .)
