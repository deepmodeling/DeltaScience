from __future__ import annotations

from pathlib import Path

import numpy as np

from .chartmap_io import ChartmapGrid, build_chartmap_grid, write_chartmap_netcdf


def _normalize_boundary_param(value: str) -> str:
    param = str(value).strip().lower()
    if param not in ("arc", "theta"):
        raise ValueError("boundary_param must be 'arc' or 'theta'")
    return param


def _vmec_theta_curve(
    geom,
    s_boundary: float,
    phi_val: float,
    *,
    boundary_offset: float,
    use_asym: bool,
):
    if boundary_offset == 0.0:
        def curve(t: np.ndarray) -> np.ndarray:
            th = np.asarray(t, dtype=float)
            R, Zc, _ = geom.coords_s(float(s_boundary), th, phi_val, use_asym=use_asym)
            return np.array([R, Zc])
        return curve

    theta_base = np.linspace(0.0, 2.0 * np.pi, 4096, endpoint=False, dtype=float)
    R_base, Z_base, _ = geom.coords_s(float(s_boundary), theta_base, phi_val, use_asym=use_asym)
    dR = np.gradient(R_base, theta_base, edge_order=2)
    dZ = np.gradient(Z_base, theta_base, edge_order=2)
    nR = dZ
    nZ = -dR
    norm = np.sqrt(nR**2 + nZ**2)
    norm = np.where(norm == 0.0, 1.0, norm)
    nR = nR / norm
    nZ = nZ / norm
    Rc = float(np.mean(R_base))
    Zc = float(np.mean(Z_base))
    outward = (R_base - Rc) * nR + (Z_base - Zc) * nZ
    flip = np.where(outward < 0.0, -1.0, 1.0)
    nR = nR * flip
    nZ = nZ * flip
    R_off = R_base + boundary_offset * nR
    Z_off = Z_base + boundary_offset * nZ

    theta_ext = np.concatenate([theta_base, [2.0 * np.pi]])
    R_ext = np.concatenate([R_off, [R_off[0]]])
    Z_ext = np.concatenate([Z_off, [Z_off[0]]])

    def curve(t: np.ndarray) -> np.ndarray:
        tt = np.asarray(t, dtype=float)
        th = np.mod(tt, 2.0 * np.pi)
        R = np.interp(th, theta_ext, R_ext)
        Zc = np.interp(th, theta_ext, Z_ext)
        return np.array([R, Zc])

    return curve


def _vmec_arc_curve(
    geom,
    s_boundary: float,
    phi_val: float,
    *,
    boundary_offset: float,
    use_asym: bool,
):
    theta_base = np.linspace(0.0, 2.0 * np.pi, 4096, endpoint=False, dtype=float)
    try:
        from shapely.geometry import Polygon
    except Exception as exc:  # pragma: no cover
        raise ImportError(
            "boundary_offset requires shapely; install libneo with the 'chartmap' extra"
        ) from exc

    R_base, Z_base, _ = geom.coords_s(float(s_boundary), theta_base, phi_val, use_asym=use_asym)
    poly = Polygon(np.column_stack([R_base, Z_base]))
    if not poly.is_valid:
        poly = poly.buffer(0.0)
    if poly.is_empty:
        raise ValueError("invalid VMEC boundary polygon for buffering")

    if boundary_offset == 0.0:
        off = poly
    else:
        off = poly.buffer(boundary_offset, join_style=1)
        if off.is_empty:
            raise ValueError("boundary_offset produced empty geometry")
        if off.geom_type != "Polygon":
            off = max(list(off.geoms), key=lambda g: g.area)

    coords = np.asarray(off.exterior.coords, dtype=float)
    coords_open = coords[:-1, :]
    i0 = int(np.argmax(coords_open[:, 0]))
    coords_open = np.vstack([coords_open[i0:, :], coords_open[:i0, :]])
    if coords_open.shape[0] >= 2 and coords_open[1, 1] - coords_open[0, 1] < 0.0:
        coords_open = coords_open[::-1, :]
    coords = np.vstack([coords_open, coords_open[0, :]])
    seg = np.sqrt(np.sum((coords[1:] - coords[:-1]) ** 2, axis=1))
    s_coords = np.concatenate(([0.0], np.cumsum(seg)))
    length = float(s_coords[-1])
    if length == 0.0:
        raise ValueError("buffered boundary has zero length")

    def curve(t: np.ndarray) -> np.ndarray:
        tt = np.asarray(t, dtype=float)
        u = (tt % (2.0 * np.pi)) / (2.0 * np.pi)
        s_query = u * length
        R = np.interp(s_query, s_coords, coords[:, 0])
        Zc = np.interp(s_query, s_coords, coords[:, 1])
        return np.array([R, Zc])

    return curve


def _vmec_boundary_curve(
    geom,
    s_boundary: float,
    phi_val: float,
    *,
    boundary_offset: float,
    boundary_param: str,
    use_asym: bool,
):
    if boundary_param == "theta":
        return _vmec_theta_curve(
            geom,
            s_boundary,
            phi_val,
            boundary_offset=boundary_offset,
            use_asym=use_asym,
        )
    return _vmec_arc_curve(
        geom,
        s_boundary,
        phi_val,
        boundary_offset=boundary_offset,
        use_asym=use_asym,
    )


def _as_path(path: str | Path) -> Path:
    p = Path(path)
    if not p:
        raise ValueError("path must be non-empty")
    return p


def _zeta_period(num_field_periods: int) -> float:
    if num_field_periods < 1:
        raise ValueError("num_field_periods must be >= 1")
    return 2.0 * float(np.pi) / float(num_field_periods)


def _build_grid(
    *,
    nrho: int,
    ntheta: int,
    nzeta: int,
    num_field_periods: int,
) -> ChartmapGrid:
    if nzeta < 2:
        raise ValueError("nzeta must be >= 2")
    period = _zeta_period(int(num_field_periods))
    zeta = np.linspace(0.0, period, int(nzeta), endpoint=False, dtype=float)
    return build_chartmap_grid(
        nrho=int(nrho),
        ntheta=int(ntheta),
        zeta=zeta,
        num_field_periods=int(num_field_periods),
    )


def _estimate_rho_lcfs_from_axis_ratio(
    *,
    rho_grid: np.ndarray,
    R_axis: np.ndarray,
    Z_axis: np.ndarray,
    R_lcfs: np.ndarray,
    Z_lcfs: np.ndarray,
    R_wall: np.ndarray,
    Z_wall: np.ndarray,
) -> float:
    d_lcfs = np.sqrt((R_lcfs - R_axis) ** 2 + (Z_lcfs - Z_axis) ** 2)
    d_wall = np.sqrt((R_wall - R_axis) ** 2 + (Z_wall - Z_axis) ** 2)

    mask = (d_lcfs > 0.0) & (d_wall > 0.0)
    ratio = d_lcfs[mask] / d_wall[mask]
    ratio = ratio[np.isfinite(ratio)]
    if ratio.size == 0:
        raise ValueError("unable to estimate rho_lcfs from geometry")

    rho_lcfs = float(np.median(ratio))
    if not np.isfinite(rho_lcfs):
        raise ValueError("unable to estimate rho_lcfs from geometry")

    ir = int(np.searchsorted(rho_grid, rho_lcfs, side="right") - 1)
    ir = max(1, min(rho_grid.size - 2, ir))
    return float(rho_grid[ir])


def write_chartmap_from_vmec(
    wout_path: str | Path,
    out_path: str | Path,
    *,
    nrho: int = 33,
    ntheta: int = 65,
    nzeta: int = 33,
    num_field_periods: int | None = None,
    use_asym: bool = True,
) -> None:
    """
    Generate a chartmap NetCDF using pure VMEC coordinates.

    This creates a coordinate system where:
    - rho in [0, 1] maps directly to VMEC s via s = rho^2
    - rho = 1 corresponds exactly to the VMEC LCFS (s = 1)
    - theta is preserved as VMEC poloidal angle
    - No extension beyond LCFS

    This is the reference chartmap that should match VMEC exactly.

    Parameters
    ----------
    wout_path : path to VMEC wout NetCDF file
    out_path : output chartmap NetCDF path
    nrho : number of radial grid points
    ntheta : number of poloidal grid points
    nzeta : number of toroidal grid points
    num_field_periods : override nfp from wout file
    use_asym : include asymmetric Fourier terms if available
    """
    from netCDF4 import Dataset

    from .vmec import VMECGeometry

    wout = _as_path(wout_path)
    out = _as_path(out_path)

    geom = VMECGeometry.from_file(str(wout))

    if num_field_periods is None:
        with Dataset(wout, "r") as ds:
            if "nfp" not in ds.variables:
                raise ValueError("wout file missing nfp variable")
            nfp = int(np.array(ds.variables["nfp"][...]))
    else:
        nfp = int(num_field_periods)

    grid = _build_grid(nrho=nrho, ntheta=ntheta, nzeta=nzeta, num_field_periods=nfp)

    x = np.zeros((grid.rho.size, grid.theta.size, grid.zeta.size), dtype=np.float64)
    y = np.zeros_like(x)
    z = np.zeros_like(x)

    for iz, phi in enumerate(grid.zeta):
        phi_val = float(phi)

        for ir, rho_val in enumerate(grid.rho):
            s_val = float(rho_val) ** 2
            R_vmec, Z_vmec, _ = geom.coords_s(s_val, grid.theta, phi_val, use_asym=use_asym)
            x[ir, :, iz] = R_vmec * np.cos(phi_val) * 100.0
            y[ir, :, iz] = R_vmec * np.sin(phi_val) * 100.0
            z[ir, :, iz] = Z_vmec * 100.0

    write_chartmap_netcdf(
        out,
        grid=grid,
        x_rtz=x,
        y_rtz=y,
        z_rtz=z,
        zeta_convention="cyl",
        rho_convention="vmec",
    )


def write_chartmap_from_vmec_boundary(
    wout_path: str | Path,
    out_path: str | Path,
    *,
    nrho: int = 33,
    ntheta: int = 65,
    nzeta: int = 33,
    s_boundary: float = 1.0,
    boundary_offset: float = 0.0,
    boundary_param: str = "arc",
    num_field_periods: int | None = None,
    M: int = 16,
    Nt: int = 256,
    Ng: tuple[int, int] = (256, 256),
    use_asym: bool = True,
) -> None:
    """
    Generate a chartmap NetCDF using map2disc from a VMEC flux-surface boundary.

    - `s_boundary` selects the VMEC surface by normalized toroidal flux in (0, 1].
      (`s_boundary=1.0` corresponds to the LCFS.)
    - `boundary_offset` optionally displaces the boundary curve outward (meters)
      along the local curve normal in each zeta slice before map2disc.
    - `boundary_param` selects how the boundary is parameterized for map2disc:
      "arc" uses arclength along the offset boundary; "theta" preserves VMEC
      theta labeling and offsets points along the local normal.

    The output matches libneo_coordinates chartmap conventions:
    - Dimensions: rho, theta, zeta
    - Variables: rho, theta, zeta, x, y, z, num_field_periods
    - x/y/z stored with file dims (zeta, theta, rho)
    - Units: cm
    - Conventions: zeta_convention=cyl, rho_convention=unknown (geometric disk radius)
    """
    from map2disc import map as m2d
    from netCDF4 import Dataset

    from .vmec import VMECGeometry

    wout = _as_path(wout_path)
    out = _as_path(out_path)

    boundary_offset = float(boundary_offset)
    boundary_param = _normalize_boundary_param(boundary_param)

    if not (0.0 < float(s_boundary) <= 1.0):
        raise ValueError("s_boundary must be in (0, 1]")
    if boundary_offset < 0.0:
        raise ValueError("boundary_offset must be >= 0")

    geom = VMECGeometry.from_file(str(wout))

    if num_field_periods is None:
        with Dataset(wout, "r") as ds:
            if "nfp" not in ds.variables:
                raise ValueError("wout file missing nfp variable")
            nfp = int(np.array(ds.variables["nfp"][...]))
    else:
        nfp = int(num_field_periods)

    grid = _build_grid(nrho=nrho, ntheta=ntheta, nzeta=nzeta, num_field_periods=nfp)

    x = np.zeros((grid.rho.size, grid.theta.size, grid.zeta.size), dtype=np.float64)
    y = np.zeros_like(x)
    z = np.zeros_like(x)

    for iz, phi in enumerate(grid.zeta):
        phi_val = float(phi)
        curve = _vmec_boundary_curve(
            geom,
            float(s_boundary),
            phi_val,
            boundary_offset=boundary_offset,
            boundary_param=boundary_param,
            use_asym=use_asym,
        )

        bcm = m2d.BoundaryConformingMapping(curve=curve, M=int(M), Nt=int(Nt), Ng=Ng)
        bcm.solve_domain2disk()
        bcm.solve_disk2domain()

        rz = bcm.eval_rt_1d(grid.rho, grid.theta)
        R_grid = rz[0]
        Z_grid = rz[1]

        x[:, :, iz] = R_grid * np.cos(phi_val) * 100.0
        y[:, :, iz] = R_grid * np.sin(phi_val) * 100.0
        z[:, :, iz] = Z_grid * 100.0

    write_chartmap_netcdf(
        out,
        grid=grid,
        x_rtz=x,
        y_rtz=y,
        z_rtz=z,
        zeta_convention="cyl",
        rho_convention="unknown",
    )


def _cubic_hermite(t: np.ndarray, p0: np.ndarray, m0: np.ndarray, p1: np.ndarray, m1: np.ndarray) -> np.ndarray:
    """
    Cubic Hermite interpolation.

    Given endpoints p0, p1 and tangents m0, m1 (scaled by interval width),
    evaluate the cubic Hermite spline at parameter t in [0, 1].

    H(t) = (2t³ - 3t² + 1)·p0 + (t³ - 2t² + t)·m0 + (-2t³ + 3t²)·p1 + (t³ - t²)·m1
    """
    t = np.asarray(t, dtype=float)
    t2 = t * t
    t3 = t2 * t
    h00 = 2.0 * t3 - 3.0 * t2 + 1.0
    h10 = t3 - 2.0 * t2 + t
    h01 = -2.0 * t3 + 3.0 * t2
    h11 = t3 - t2
    return h00 * p0 + h10 * m0 + h01 * p1 + h11 * m1


def _quintic_hermite(
    t: np.ndarray,
    p0: np.ndarray,
    m0: np.ndarray,
    a0: np.ndarray,
    p1: np.ndarray,
    m1: np.ndarray,
    a1: np.ndarray,
) -> np.ndarray:
    """
    Quintic Hermite interpolation (C2 continuity).

    Given endpoints p0, p1, first derivatives m0, m1, and second derivatives a0, a1
    (all scaled by interval width), evaluate at parameter t in [0, 1].

    Provides C2 continuity: matches position, 1st and 2nd derivatives at both ends.
    """
    t = np.asarray(t, dtype=float)
    t2 = t * t
    t3 = t2 * t
    t4 = t3 * t
    t5 = t4 * t

    h00 = 1.0 - 10.0 * t3 + 15.0 * t4 - 6.0 * t5
    h10 = t - 6.0 * t3 + 8.0 * t4 - 3.0 * t5
    h20 = 0.5 * t2 - 1.5 * t3 + 1.5 * t4 - 0.5 * t5
    h01 = 10.0 * t3 - 15.0 * t4 + 6.0 * t5
    h11 = -4.0 * t3 + 7.0 * t4 - 3.0 * t5
    h21 = 0.5 * t3 - t4 + 0.5 * t5

    return h00 * p0 + h10 * m0 + h20 * a0 + h01 * p1 + h11 * m1 + h21 * a1


def write_chartmap_from_vmec_extended(
    wout_path: str | Path,
    out_path: str | Path,
    *,
    nrho: int = 33,
    ntheta: int = 65,
    nzeta: int = 33,
    nrho_vmec: int | None = None,
    rho_lcfs: float | None = None,
    boundary_offset: float = 0.1,
    num_field_periods: int | None = None,
    use_asym: bool = True,
) -> None:
    """
    Generate a chartmap NetCDF using VMEC coordinates with cubic Hermite extension.

    This mode uses exact VMEC flux coordinates inside the LCFS and extends beyond
    using cubic Hermite interpolation along coordinate line tangents. This provides
    C1 continuity at the LCFS boundary, suitable for symplectic integrators.

    Parameters
    ----------
    wout_path : path to VMEC wout NetCDF file
    out_path : output chartmap NetCDF path
    nrho : total number of radial grid points
    ntheta : number of poloidal grid points
    nzeta : number of toroidal grid points
    nrho_vmec : number of radial points inside LCFS (alternative to rho_lcfs)
    rho_lcfs : radial location of LCFS in [0, 1] (alternative to nrho_vmec)
    boundary_offset : distance beyond LCFS in meters for outer boundary
    num_field_periods : override nfp from wout file
    use_asym : include asymmetric Fourier terms if available

    Grid structure
    --------------
    - rho in [0, 1] with nrho points
    - For rho <= rho_lcfs: VMEC coordinates with s = (rho / rho_lcfs)^2
    - For rho > rho_lcfs: cubic Hermite extrapolation from LCFS tangent

    The cubic Hermite spline matches position and first derivative at the LCFS,
    providing C1 continuity. At the outer boundary, the tangent points radially
    outward to ensure smooth coordinate lines.
    """
    from netCDF4 import Dataset

    from .vmec import VMECGeometry

    wout = _as_path(wout_path)
    out = _as_path(out_path)

    boundary_offset = float(boundary_offset)
    if boundary_offset <= 0.0:
        raise ValueError("boundary_offset must be > 0 for extended mode")

    if nrho_vmec is not None and rho_lcfs is not None:
        raise ValueError("provide only one of nrho_vmec or rho_lcfs")
    if nrho_vmec is None and rho_lcfs is None:
        rho_lcfs = None

    geom = VMECGeometry.from_file(str(wout))

    if num_field_periods is None:
        with Dataset(wout, "r") as ds:
            if "nfp" not in ds.variables:
                raise ValueError("wout file missing nfp variable")
            nfp = int(np.array(ds.variables["nfp"][...]))
    else:
        nfp = int(num_field_periods)

    grid = _build_grid(nrho=nrho, ntheta=ntheta, nzeta=nzeta, num_field_periods=nfp)

    if nrho_vmec is not None:
        nrho_vmec = int(nrho_vmec)
        if nrho_vmec < 2 or nrho_vmec >= grid.rho.size:
            raise ValueError("nrho_vmec must be in [2, nrho-1]")
        ir_lcfs = nrho_vmec - 1
        rho_lcfs_val = float(grid.rho[ir_lcfs])
    else:
        theta_grid = grid.theta
        rho_lcfs_val: float
        if rho_lcfs is None:
            ratios = []
            for phi in grid.zeta:
                phi_val = float(phi)
                R_axis, Z_axis, _ = geom.coords_s(
                    0.0, np.array([0.0]), phi_val, use_asym=use_asym
                )
                R_lcfs, Z_lcfs, dR_ds, dZ_ds = geom.coords_s_with_deriv(
                    1.0, theta_grid, phi_val, use_asym=use_asym
                )
                outward_norm = np.sqrt(dR_ds**2 + dZ_ds**2)
                outward_norm = np.where(outward_norm == 0.0, 1.0, outward_norm)
                outward_R = dR_ds / outward_norm
                outward_Z = dZ_ds / outward_norm
                R_outer = R_lcfs + boundary_offset * outward_R
                Z_outer = Z_lcfs + boundary_offset * outward_Z
                ratios.append(
                    _estimate_rho_lcfs_from_axis_ratio(
                        rho_grid=grid.rho,
                        R_axis=np.full_like(R_lcfs, float(R_axis[0])),
                        Z_axis=np.full_like(Z_lcfs, float(Z_axis[0])),
                        R_lcfs=R_lcfs,
                        Z_lcfs=Z_lcfs,
                        R_wall=R_outer,
                        Z_wall=Z_outer,
                    )
                )
            rho_lcfs_val = float(np.median(np.array(ratios, dtype=float)))
        else:
            rho_lcfs_val = float(rho_lcfs)
            if not (0.0 < rho_lcfs_val < 1.0):
                raise ValueError("rho_lcfs must be in (0, 1)")
            ir_lcfs = int(np.searchsorted(grid.rho, rho_lcfs_val, side="right") - 1)
            if ir_lcfs < 1 or ir_lcfs >= grid.rho.size - 1:
                raise ValueError("rho_lcfs must leave room for extended region")
            rho_lcfs_val = float(grid.rho[ir_lcfs])

        ir_lcfs = int(np.searchsorted(grid.rho, rho_lcfs_val, side="right") - 1)
        ir_lcfs = max(1, min(grid.rho.size - 2, ir_lcfs))
        rho_lcfs_val = float(grid.rho[ir_lcfs])

    x = np.zeros((grid.rho.size, grid.theta.size, grid.zeta.size), dtype=np.float64)
    y = np.zeros_like(x)
    z = np.zeros_like(x)

    for iz, phi in enumerate(grid.zeta):
        phi_val = float(phi)

        R_lcfs, Z_lcfs, dR_ds, dZ_ds = geom.coords_s_with_deriv(
            1.0, grid.theta, phi_val, use_asym=use_asym
        )

        outward_norm = np.sqrt(dR_ds**2 + dZ_ds**2)
        outward_norm = np.where(outward_norm == 0.0, 1.0, outward_norm)
        outward_R = dR_ds / outward_norm
        outward_Z = dZ_ds / outward_norm

        R_outer = R_lcfs + boundary_offset * outward_R
        Z_outer = Z_lcfs + boundary_offset * outward_Z

        ds_drho_at_lcfs = 2.0 / rho_lcfs_val
        drho_dt = 1.0 - rho_lcfs_val
        m0_R = dR_ds * ds_drho_at_lcfs * drho_dt
        m0_Z = dZ_ds * ds_drho_at_lcfs * drho_dt

        m1_R = outward_R * boundary_offset
        m1_Z = outward_Z * boundary_offset

        for ir in range(ir_lcfs + 1):
            rho_val = grid.rho[ir]
            s_val = (float(rho_val) / rho_lcfs_val) ** 2
            R_in, Z_in, _ = geom.coords_s(s_val, grid.theta, phi_val, use_asym=use_asym)
            x[ir, :, iz] = R_in * np.cos(phi_val) * 100.0
            y[ir, :, iz] = R_in * np.sin(phi_val) * 100.0
            z[ir, :, iz] = Z_in * 100.0

        n_outer = grid.rho.size - ir_lcfs - 1
        if n_outer > 0:
            rho_outer = grid.rho[ir_lcfs + 1:]
            t_param = (rho_outer - rho_lcfs_val) / (1.0 - rho_lcfs_val)

            for ith in range(grid.theta.size):
                R_interp = _cubic_hermite(
                    t_param,
                    R_lcfs[ith],
                    m0_R[ith],
                    R_outer[ith],
                    m1_R[ith],
                )
                Z_interp = _cubic_hermite(
                    t_param,
                    Z_lcfs[ith],
                    m0_Z[ith],
                    Z_outer[ith],
                    m1_Z[ith],
                )
                x[ir_lcfs + 1:, ith, iz] = R_interp * np.cos(phi_val) * 100.0
                y[ir_lcfs + 1:, ith, iz] = R_interp * np.sin(phi_val) * 100.0
                z[ir_lcfs + 1:, ith, iz] = Z_interp * 100.0

    write_chartmap_netcdf(
        out,
        grid=grid,
        x_rtz=x,
        y_rtz=y,
        z_rtz=z,
        zeta_convention="cyl",
        rho_convention="vmec_extended",
        rho_lcfs=rho_lcfs_val,
    )


def _ray_wall_intersections(
    R_lcfs: np.ndarray,
    Z_lcfs: np.ndarray,
    dir_R: np.ndarray,
    dir_Z: np.ndarray,
    R_wall: np.ndarray,
    Z_wall: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Find wall intersections by tracing rays from LCFS in a prescribed direction.

    For each LCFS point, traces a ray in direction (dir_R, dir_Z) and finds where
    it intersects the wall curve. This is used to define a theta-to-wall mapping
    when the wall curve is given as an arbitrary closed (R,Z) contour.

    Parameters
    ----------
    R_lcfs : LCFS R coordinates for all theta values
    Z_lcfs : LCFS Z coordinates for all theta values
    dir_R : ray direction in R for all theta values
    dir_Z : ray direction in Z for all theta values
    R_wall : wall polygon R coordinates (closed curve)
    Z_wall : wall polygon Z coordinates (closed curve)

    Returns
    -------
    R_wall_intersect : R coordinates of wall intersections
    Z_wall_intersect : Z coordinates of wall intersections
    """
    try:
        from shapely.geometry import LineString, Point, Polygon
    except ImportError as exc:
        raise ImportError(
            "ray-wall intersection requires shapely; "
            "install libneo with the 'chartmap' extra"
        ) from exc

    wall_coords = np.column_stack([R_wall, Z_wall])
    if not np.allclose(wall_coords[0], wall_coords[-1]):
        wall_coords = np.vstack([wall_coords, wall_coords[0]])
    wall_ring = LineString(wall_coords)

    n_theta = len(R_lcfs)
    R_intersect = np.zeros(n_theta, dtype=float)
    Z_intersect = np.zeros(n_theta, dtype=float)

    for ith in range(n_theta):
        r0, z0 = R_lcfs[ith], Z_lcfs[ith]
        dr, dz = dir_R[ith], dir_Z[ith]

        norm = np.sqrt(dr**2 + dz**2)
        if norm < 1e-12:
            R_intersect[ith] = r0
            Z_intersect[ith] = z0
            continue

        ray_length = 10.0 * max(np.ptp(R_wall), np.ptp(Z_wall))
        r1 = r0 + ray_length * dr / norm
        z1 = z0 + ray_length * dz / norm
        ray = LineString([(r0, z0), (r1, z1)])

        intersection = ray.intersection(wall_ring)

        if intersection.is_empty:
            R_intersect[ith] = r0 + dr
            Z_intersect[ith] = z0 + dz
            continue

        if intersection.geom_type == "Point":
            R_intersect[ith] = intersection.x
            Z_intersect[ith] = intersection.y
        elif intersection.geom_type == "MultiPoint":
            origin = Point(r0, z0)
            closest = min(intersection.geoms, key=lambda p: origin.distance(p))
            R_intersect[ith] = closest.x
            Z_intersect[ith] = closest.y
        elif intersection.geom_type == "LineString":
            coords = np.array(intersection.coords)
            origin = Point(r0, z0)
            dists = [origin.distance(Point(c)) for c in coords]
            idx = np.argmin(dists)
            R_intersect[ith] = coords[idx, 0]
            Z_intersect[ith] = coords[idx, 1]
        else:
            R_intersect[ith] = r0 + dr
            Z_intersect[ith] = z0 + dz

    return R_intersect, Z_intersect


def write_chartmap_from_vmec_to_wall(
    wout_path: str | Path,
    out_path: str | Path,
    wall_rz: list[tuple[np.ndarray, np.ndarray]],
    wall_zeta: np.ndarray,
    *,
    nrho: int = 33,
    ntheta: int = 65,
    rho_lcfs: float | None = None,
    num_field_periods: int | None = None,
    use_asym: bool = True,
    wall_match: str = "vmec_derivative",
) -> None:
    """
    Generate a chartmap from VMEC coordinates extended to wall boundaries.

    This creates a boundary-fitted coordinate system where:
    - rho in [0, rho_lcfs]: VMEC coordinates with rho = sqrt(s) * rho_lcfs
    - rho in [rho_lcfs, 1]: Cubic Hermite interpolation from LCFS to wall
    - rho = 1: Exactly on the wall boundary

    The coordinate system has C1 continuity at the LCFS.

    Parameters
    ----------
    wout_path : path to VMEC wout NetCDF file
    out_path : output chartmap NetCDF path
    wall_rz : list of (R, Z) arrays defining wall boundary at each zeta
              Each R, Z should be a closed curve (first point != last point)
    wall_zeta : array of zeta values corresponding to wall_rz curves
    nrho : number of radial grid points
    ntheta : number of poloidal grid points
    rho_lcfs : radial location of LCFS in (0, 1). If None, estimate a value
               from geometry using the axis-to-LCFS and axis-to-wall distance
               ratio (median over theta,zeta).
    num_field_periods : override nfp from wout file
    use_asym : include asymmetric Fourier terms if available

    wall_match : how to map LCFS theta to wall intersections:
        - vmec_derivative (default): trace rays along the VMEC radial derivative
          (dR/ds, dZ/ds) at the LCFS. This preserves VMEC-theta alignment.
        - poloidal_normal: trace rays along the outward poloidal-plane normal
          of the LCFS (computed from d/dtheta and oriented using the VMEC
          radial derivative). This is appropriate for synthetic normal-offset
          walls and physical-wall matching.

    Notes
    -----
    The LCFS and wall points are connected by quintic Hermite interpolation with
    C2 continuity at the LCFS.
    """
    from netCDF4 import Dataset

    from .vmec import VMECGeometry

    wout = _as_path(wout_path)
    out = _as_path(out_path)

    if rho_lcfs is not None:
        rho_lcfs = float(rho_lcfs)
        if not (0.0 < rho_lcfs < 1.0):
            raise ValueError("rho_lcfs must be in (0, 1)")

    wall_zeta = np.asarray(wall_zeta, dtype=float)
    if len(wall_rz) != len(wall_zeta):
        raise ValueError("wall_rz and wall_zeta must have same length")

    geom = VMECGeometry.from_file(str(wout))

    if num_field_periods is None:
        with Dataset(wout, "r") as ds:
            if "nfp" not in ds.variables:
                raise ValueError("wout file missing nfp variable")
            nfp = int(np.array(ds.variables["nfp"][...]))
    else:
        nfp = int(num_field_periods)

    grid = build_chartmap_grid(
        nrho=int(nrho),
        ntheta=int(ntheta),
        zeta=wall_zeta,
        num_field_periods=int(nfp),
    )

    prepass = []
    ratios = []
    for iz, phi_val in enumerate(grid.zeta):
        phi_val = float(phi_val)

        R_wall, Z_wall = wall_rz[iz]
        R_wall = np.asarray(R_wall, dtype=float)
        Z_wall = np.asarray(Z_wall, dtype=float)

        R_lcfs, Z_lcfs, dR_ds, dZ_ds, d2R_ds2, d2Z_ds2 = geom.coords_s_with_second_deriv(
            1.0, grid.theta, phi_val, use_asym=use_asym
        )

        wall_match_norm = wall_match.strip().lower()
        if wall_match_norm not in {"vmec_derivative", "poloidal_normal"}:
            raise ValueError(
                "wall_match must be 'vmec_derivative' or 'poloidal_normal'"
            )

        if wall_match_norm == "vmec_derivative":
            dir_R = dR_ds
            dir_Z = dZ_ds
        else:
            dtheta = float(grid.theta[1] - grid.theta[0])
            dR_dth = (np.roll(R_lcfs, -1) - np.roll(R_lcfs, 1)) / (2.0 * dtheta)
            dZ_dth = (np.roll(Z_lcfs, -1) - np.roll(Z_lcfs, 1)) / (2.0 * dtheta)

            dir_R = dZ_dth
            dir_Z = -dR_dth

            norm_dir = np.sqrt(dir_R**2 + dir_Z**2)
            norm_dir = np.where(norm_dir == 0.0, 1.0, norm_dir)
            dir_R = dir_R / norm_dir
            dir_Z = dir_Z / norm_dir

            outward_dot = dir_R * dR_ds + dir_Z * dZ_ds
            flip = outward_dot < 0.0
            dir_R = np.where(flip, -dir_R, dir_R)
            dir_Z = np.where(flip, -dir_Z, dir_Z)

        R_wall_matched, Z_wall_matched = _ray_wall_intersections(
            R_lcfs, Z_lcfs, dir_R, dir_Z, R_wall, Z_wall
        )

        R_axis, Z_axis, _ = geom.coords_s(
            0.0, np.array([0.0]), phi_val, use_asym=use_asym
        )
        ratios.append(
            _estimate_rho_lcfs_from_axis_ratio(
                rho_grid=grid.rho,
                R_axis=np.full_like(R_lcfs, float(R_axis[0])),
                Z_axis=np.full_like(Z_lcfs, float(Z_axis[0])),
                R_lcfs=R_lcfs,
                Z_lcfs=Z_lcfs,
                R_wall=R_wall_matched,
                Z_wall=Z_wall_matched,
            )
        )
        prepass.append(
            (
                phi_val,
                R_wall_matched,
                Z_wall_matched,
                R_lcfs,
                Z_lcfs,
                dR_ds,
                dZ_ds,
                d2R_ds2,
                d2Z_ds2,
            )
        )

    if rho_lcfs is None:
        rho_lcfs_actual = float(np.median(np.array(ratios, dtype=float)))
    else:
        rho_lcfs_actual = float(rho_lcfs)

    ir_lcfs = int(np.searchsorted(grid.rho, rho_lcfs_actual, side="right") - 1)
    ir_lcfs = max(1, min(grid.rho.size - 2, ir_lcfs))
    rho_lcfs_actual = float(grid.rho[ir_lcfs])

    x = np.zeros((grid.rho.size, grid.theta.size, grid.zeta.size), dtype=np.float64)
    y = np.zeros_like(x)
    z = np.zeros_like(x)

    for iz, (
        phi_val,
        R_wall_matched,
        Z_wall_matched,
        R_lcfs,
        Z_lcfs,
        dR_ds,
        dZ_ds,
        d2R_ds2,
        d2Z_ds2,
    ) in enumerate(prepass):

        ds_drho_at_lcfs = 2.0 / rho_lcfs_actual
        d2s_drho2_at_lcfs = 2.0 / (rho_lcfs_actual**2)
        drho_interval = 1.0 - rho_lcfs_actual

        m0_R = dR_ds * ds_drho_at_lcfs * drho_interval
        m0_Z = dZ_ds * ds_drho_at_lcfs * drho_interval

        a0_R = (
            d2R_ds2 * (ds_drho_at_lcfs**2) + dR_ds * d2s_drho2_at_lcfs
        ) * (drho_interval**2)
        a0_Z = (
            d2Z_ds2 * (ds_drho_at_lcfs**2) + dZ_ds * d2s_drho2_at_lcfs
        ) * (drho_interval**2)

        chord_R = R_wall_matched - R_lcfs
        chord_Z = Z_wall_matched - Z_lcfs
        m1_R = chord_R
        m1_Z = chord_Z

        a1_R = np.zeros_like(a0_R)
        a1_Z = np.zeros_like(a0_Z)

        for ir in range(ir_lcfs + 1):
            rho_val = grid.rho[ir]
            s_val = (float(rho_val) / rho_lcfs_actual) ** 2
            R_in, Z_in, _ = geom.coords_s(s_val, grid.theta, phi_val, use_asym=use_asym)
            x[ir, :, iz] = R_in * np.cos(phi_val) * 100.0
            y[ir, :, iz] = R_in * np.sin(phi_val) * 100.0
            z[ir, :, iz] = Z_in * 100.0

        n_outer = grid.rho.size - ir_lcfs - 1
        if n_outer > 0:
            rho_outer = grid.rho[ir_lcfs + 1:]
            t_param = (rho_outer - rho_lcfs_actual) / (1.0 - rho_lcfs_actual)

            for ith in range(grid.theta.size):
                R_interp = _quintic_hermite(
                    t_param,
                    R_lcfs[ith],
                    m0_R[ith],
                    a0_R[ith],
                    R_wall_matched[ith],
                    m1_R[ith],
                    a1_R[ith],
                )
                Z_interp = _quintic_hermite(
                    t_param,
                    Z_lcfs[ith],
                    m0_Z[ith],
                    a0_Z[ith],
                    Z_wall_matched[ith],
                    m1_Z[ith],
                    a1_Z[ith],
                )
                x[ir_lcfs + 1:, ith, iz] = R_interp * np.cos(phi_val) * 100.0
                y[ir_lcfs + 1:, ith, iz] = R_interp * np.sin(phi_val) * 100.0
                z[ir_lcfs + 1:, ith, iz] = Z_interp * 100.0

    write_chartmap_netcdf(
        out,
        grid=grid,
        x_rtz=x,
        y_rtz=y,
        z_rtz=z,
        zeta_convention="cyl",
        rho_convention="vmec_to_wall",
        rho_lcfs=rho_lcfs_actual,
    )


def write_chartmap_from_vmec_and_stl(
    wout_path: str | Path,
    stl_path: str | Path,
    out_path: str | Path,
    *,
    nrho: int = 33,
    ntheta: int = 65,
    nzeta: int = 33,
    rho_lcfs: float | None = None,
    n_boundary_points: int = 512,
    stitch_tol: float = 1.0e-6,
    stl_units: str | None = None,
    stl_scale: float = 1.0,
    num_field_periods: int | None = None,
    use_asym: bool = True,
) -> None:
    """
    Generate a chartmap from VMEC extended to STL wall boundaries.

    Convenience function that combines STL boundary extraction with
    write_chartmap_from_vmec_to_wall.

    Parameters
    ----------
    wout_path : path to VMEC wout NetCDF file
    stl_path : path to STL wall geometry file
    out_path : output chartmap NetCDF path
    nrho : number of radial grid points
    ntheta : number of poloidal grid points
    nzeta : number of toroidal slices
    rho_lcfs : radial location of LCFS in (0, 1). If None, estimate a value
               from geometry (see write_chartmap_from_vmec_to_wall).
    n_boundary_points : points for STL boundary extraction
    stitch_tol : tolerance for stitching open contours
    num_field_periods : override nfp from wout file
    use_asym : include asymmetric Fourier terms if available
    """
    from netCDF4 import Dataset

    from .stl_boundary import extract_boundary_slices

    wout = _as_path(wout_path)
    stl = _as_path(stl_path)

    if num_field_periods is None:
        with Dataset(wout, "r") as ds:
            if "nfp" not in ds.variables:
                raise ValueError("wout file missing nfp variable")
            nfp = int(np.array(ds.variables["nfp"][...]))
    else:
        nfp = int(num_field_periods)

    period = _zeta_period(nfp)
    phi_vals = np.linspace(0.0, period, nzeta, endpoint=False, dtype=float)

    slices = extract_boundary_slices(
        stl,
        n_phi=nzeta,
        n_boundary_points=n_boundary_points,
        stitch_tol=stitch_tol,
        phi_vals=phi_vals,
        stl_units=stl_units,
        stl_scale=stl_scale,
    )

    wall_rz = []
    wall_zeta = []
    for s in slices:
        R = s.outer_filled[:-1, 0]
        Z = s.outer_filled[:-1, 1]
        wall_rz.append((R, Z))
        wall_zeta.append(s.phi)

    write_chartmap_from_vmec_to_wall(
        wout,
        out_path,
        wall_rz,
        np.array(wall_zeta),
        nrho=nrho,
        ntheta=ntheta,
        rho_lcfs=rho_lcfs,
        num_field_periods=nfp,
        use_asym=use_asym,
    )


def chartmap_to_rz(
    chartmap_path: str | Path,
    rho: float | np.ndarray,
    theta: float | np.ndarray,
    zeta: float | np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """
    Interpolate (R, Z) from a chartmap NetCDF at given (rho, theta, zeta).

    Uses trilinear interpolation on the chartmap grid. Handles periodic boundary
    conditions in theta and zeta.

    Parameters
    ----------
    chartmap_path : path to chartmap NetCDF file
    rho : radial coordinate(s) in [0, 1]
    theta : poloidal angle(s) in radians
    zeta : toroidal angle(s) in radians (cylindrical convention)

    Returns
    -------
    R : major radius coordinate(s) in meters
    Z : vertical coordinate(s) in meters
    """
    from netCDF4 import Dataset

    path = _as_path(chartmap_path)
    rho = np.atleast_1d(np.asarray(rho, dtype=float)).flatten()
    theta = np.atleast_1d(np.asarray(theta, dtype=float)).flatten()
    zeta = np.atleast_1d(np.asarray(zeta, dtype=float)).flatten()

    if not (rho.shape == theta.shape == zeta.shape):
        raise ValueError("rho, theta, zeta must have the same shape")

    with Dataset(path, "r") as ds:
        rho_grid = np.array(ds.variables["rho"][:], dtype=float)
        theta_grid = np.array(ds.variables["theta"][:], dtype=float)
        zeta_grid = np.array(ds.variables["zeta"][:], dtype=float)
        x = np.array(ds.variables["x"][:, :, :], dtype=float)
        y = np.array(ds.variables["y"][:, :, :], dtype=float)
        z = np.array(ds.variables["z"][:, :, :], dtype=float)
        nfp = int(np.array(ds.variables["num_field_periods"][...]))
        units = str(getattr(ds.variables["x"], "units", "cm")).strip().lower()

    scale = 0.01 if units == "cm" else 1.0
    r_grid = np.sqrt((x * scale) ** 2 + (y * scale) ** 2)
    z_grid = z * scale

    rho = np.clip(rho, float(rho_grid[0]), float(rho_grid[-1]))
    theta = np.mod(theta, 2.0 * np.pi)
    zeta_period = 2.0 * np.pi / float(nfp)
    zeta = np.mod(zeta, zeta_period)

    dr = float(rho_grid[1] - rho_grid[0])
    dth = 2.0 * np.pi / float(theta_grid.size)
    dz = zeta_period / float(zeta_grid.size)

    ur = (rho - float(rho_grid[0])) / dr
    ut = theta / dth
    uz = zeta / dz

    ir0 = np.floor(ur).astype(int)
    it0 = np.floor(ut).astype(int) % theta_grid.size
    iz0 = np.floor(uz).astype(int) % zeta_grid.size

    ir0 = np.clip(ir0, 0, rho_grid.size - 2)
    ir1 = ir0 + 1
    it1 = (it0 + 1) % theta_grid.size
    iz1 = (iz0 + 1) % zeta_grid.size

    tr = ur - ir0.astype(float)
    tt = ut - np.floor(ut)
    tz = uz - np.floor(uz)

    def tri(arr):
        c000 = arr[iz0, it0, ir0]
        c001 = arr[iz0, it0, ir1]
        c010 = arr[iz0, it1, ir0]
        c011 = arr[iz0, it1, ir1]
        c100 = arr[iz1, it0, ir0]
        c101 = arr[iz1, it0, ir1]
        c110 = arr[iz1, it1, ir0]
        c111 = arr[iz1, it1, ir1]
        v00 = c000 * (1.0 - tr) + c001 * tr
        v01 = c010 * (1.0 - tr) + c011 * tr
        v10 = c100 * (1.0 - tr) + c101 * tr
        v11 = c110 * (1.0 - tr) + c111 * tr
        v0 = v00 * (1.0 - tt) + v01 * tt
        v1 = v10 * (1.0 - tt) + v11 * tt
        return v0 * (1.0 - tz) + v1 * tz

    R = tri(r_grid)
    Z = tri(z_grid)
    return R, Z


def vmec_to_chartmap_coords(
    wout_path: str | Path,
    chartmap_path: str | Path,
    s: float | np.ndarray,
    theta_vmec: float | np.ndarray,
    zeta: float | np.ndarray,
    *,
    max_iter: int = 30,
    tol_m: float = 1.0e-8,
    use_asym: bool = True,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Convert VMEC coordinates to chartmap coordinates.

    For each input (s, theta_vmec, zeta), finds the chartmap (rho, theta_cm)
    that gives the same (R, Z) position at the same zeta.

    Parameters
    ----------
    wout_path : path to VMEC wout NetCDF file
    chartmap_path : path to chartmap NetCDF file
    s : VMEC normalized toroidal flux coordinate(s) in [0, 1]
    theta_vmec : VMEC poloidal angle(s) in radians
    zeta : toroidal angle(s) in radians (same for VMEC and chartmap)
    max_iter : maximum Newton iterations for inversion
    tol_m : convergence tolerance in meters
    use_asym : include VMEC asymmetric terms if available

    Returns
    -------
    rho : chartmap radial coordinate(s)
    theta_cm : chartmap poloidal angle(s) in radians
    dist : final distance error(s) in meters
    zeta : toroidal angle(s) (unchanged, returned for convenience)

    Notes
    -----
    Uses Newton iteration to invert the chartmap coordinate transformation.
    Initial guess: rho = sqrt(s), theta_cm = theta_vmec.
    """
    from .vmec import VMECGeometry

    wout = _as_path(wout_path)
    cm_path = _as_path(chartmap_path)

    s = np.atleast_1d(np.asarray(s, dtype=float)).flatten()
    theta_vmec = np.atleast_1d(np.asarray(theta_vmec, dtype=float)).flatten()
    zeta = np.atleast_1d(np.asarray(zeta, dtype=float)).flatten()

    if not (s.shape == theta_vmec.shape == zeta.shape):
        raise ValueError("s, theta_vmec, zeta must have the same shape")

    geom = VMECGeometry.from_file(str(wout))

    R_target = np.zeros_like(s)
    Z_target = np.zeros_like(s)
    for i in range(s.size):
        R_arr, Z_arr, _ = geom.coords_s(
            float(s[i]), np.array([float(theta_vmec[i])]), float(zeta[i]),
            use_asym=use_asym
        )
        R_target[i] = float(R_arr[0])
        Z_target[i] = float(Z_arr[0])

    rho = np.clip(np.sqrt(s), 0.0, 0.999)
    theta = theta_vmec.copy() % (2.0 * np.pi)

    for _ in range(max_iter):
        R, Z = chartmap_to_rz(cm_path, rho, theta, zeta)
        f1 = R - R_target
        f2 = Z - Z_target
        err = np.maximum(np.abs(f1), np.abs(f2))
        if np.all(err < tol_m):
            break

        dr = 1.0e-4
        dth = 1.0e-4
        Rr, Zr = chartmap_to_rz(cm_path, np.clip(rho + dr, 0, 0.999), theta, zeta)
        Rt, Zt = chartmap_to_rz(cm_path, rho, theta + dth, zeta)

        dR_dr = (Rr - R) / dr
        dZ_dr = (Zr - Z) / dr
        dR_dth = (Rt - R) / dth
        dZ_dth = (Zt - Z) / dth

        det = dR_dr * dZ_dth - dR_dth * dZ_dr
        det = np.where(np.abs(det) < 1e-16, 1e-16, det)

        drho = (dZ_dth * f1 - dR_dth * f2) / det
        dtheta = (-dZ_dr * f1 + dR_dr * f2) / det

        rho = np.clip(rho - 0.5 * drho, 0.0, 0.999)
        theta = (theta - 0.5 * dtheta) % (2.0 * np.pi)

    R_final, Z_final = chartmap_to_rz(cm_path, rho, theta, zeta)
    dist = np.sqrt((R_final - R_target) ** 2 + (Z_final - Z_target) ** 2)

    return rho, theta, dist, zeta


def write_chartmap_from_stl(
    stl_path: str | Path,
    out_path: str | Path,
    *,
    nrho: int = 33,
    ntheta: int = 65,
    nphi: int = 32,
    axis_xy: tuple[float, float] | None = None,
    num_field_periods: int = 1,
    n_boundary_points: int = 512,
    stitch_tol: float = 1.0e-6,
    stl_units: str | None = None,
    stl_scale: float = 1.0,
    M: int = 16,
    Nt: int = 256,
    Ng: tuple[int, int] = (256, 256),
) -> None:
    """
    Generate a chartmap NetCDF using map2disc from an STL boundary.
    """
    from .stl_boundary import extract_boundary_slices, write_chartmap_from_stl as _write_from_slices

    stl = _as_path(stl_path)
    out = _as_path(out_path)

    if nphi < 2:
        raise ValueError("nphi must be >= 2")
    if num_field_periods < 1:
        raise ValueError("num_field_periods must be >= 1")

    period = _zeta_period(int(num_field_periods))
    phi_vals = np.linspace(0.0, period, int(nphi), endpoint=False, dtype=float)

    slices = extract_boundary_slices(
        stl,
        n_phi=int(nphi),
        n_boundary_points=int(n_boundary_points),
        axis_xy=axis_xy,
        stitch_tol=float(stitch_tol),
        phi_vals=phi_vals,
        stl_units=stl_units,
        stl_scale=stl_scale,
    )
    _write_from_slices(
        slices,
        out,
        nrho=int(nrho),
        ntheta=int(ntheta),
        num_field_periods=int(num_field_periods),
        M=int(M),
        Nt=int(Nt),
        Ng=Ng,
    )
