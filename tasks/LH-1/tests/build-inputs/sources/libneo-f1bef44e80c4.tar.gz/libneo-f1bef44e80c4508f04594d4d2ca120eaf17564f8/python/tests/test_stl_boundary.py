from __future__ import annotations

import numpy as np


def _is_closed(polyline: np.ndarray, tol: float = 1.0e-10) -> bool:
    if polyline.ndim != 2 or polyline.shape[1] != 2 or polyline.shape[0] < 3:
        return False
    return np.linalg.norm(polyline[0] - polyline[-1]) <= tol


def test_fill_open_contour_closes_and_preserves_circle() -> None:
    from libneo.stl_boundary import fill_open_contour

    r0 = 1.7
    a = 0.35

    t = np.linspace(0.2 * np.pi, 1.8 * np.pi, 200)
    open_circle = np.column_stack((r0 + a * np.cos(t), a * np.sin(t)))

    filled = fill_open_contour(open_circle)

    assert _is_closed(filled, tol=1.0e-8)

    d = np.sqrt((filled[:, 0] - r0) ** 2 + filled[:, 1] ** 2)
    assert np.max(np.abs(d - a)) < 5.0e-3


def test_slice_mesh_rz_torus_returns_closed_outer_contour() -> None:
    import trimesh

    from libneo.stl_boundary import classify_rz_contours, slice_mesh_rz

    r0 = 1.7
    a = 0.35

    mesh = trimesh.creation.torus(
        major_radius=r0,
        minor_radius=a,
        major_sections=128,
        minor_sections=96,
    )

    contours = slice_mesh_rz(mesh, phi=0.0)
    outer, holes = classify_rz_contours(contours)

    assert holes == []
    assert _is_closed(outer, tol=1.0e-6)

    d = np.sqrt((outer[:, 0] - r0) ** 2 + outer[:, 1] ** 2)
    assert float(np.std(d)) < 5.0e-3


def test_write_boundaries_netcdf_format(tmp_path) -> None:
    from netCDF4 import Dataset

    from libneo.stl_boundary import BoundarySlice, write_boundaries_netcdf

    axis_xy = (0.1, -0.2)
    filled = np.array(
        [
            [1.0, 0.0],
            [0.0, 1.0],
            [-1.0, 0.0],
            [0.0, -1.0],
            [1.0, 0.0],
        ],
        dtype=float,
    )
    original = filled.copy()
    original[1, :] = np.nan

    slices = [
        BoundarySlice(
            axis_xy=axis_xy,
            phi=0.0,
            outer_filled=filled,
            outer_original_on_filled=original,
            hole_spans=[(2, 2)],
            hole_contours=[],
        ),
        BoundarySlice(
            axis_xy=axis_xy,
            phi=np.pi,
            outer_filled=filled,
            outer_original_on_filled=filled,
            hole_spans=[],
            hole_contours=[],
        ),
    ]

    out = tmp_path / "boundaries.nc"
    write_boundaries_netcdf(slices, out)

    with Dataset(out, "r") as ds:
        assert set(ds.dimensions) == {"n_phi", "n_points", "max_holes"}
        assert ds.dimensions["n_phi"].size == 2
        assert ds.dimensions["n_points"].size == 4

        for name in [
            "phi",
            "axis_x",
            "axis_y",
            "R_original",
            "Z_original",
            "R_filled",
            "Z_filled",
            "n_holes",
            "hole_start",
            "hole_end",
        ]:
            assert name in ds.variables

        assert float(ds.variables["axis_x"].getValue()) == axis_xy[0]
        assert float(ds.variables["axis_y"].getValue()) == axis_xy[1]

        assert int(ds.variables["n_holes"][0]) == 1
        assert int(ds.variables["hole_start"][0, 0]) == 2
        assert int(ds.variables["hole_end"][0, 0]) == 2


import pytest


@pytest.mark.network
def test_extract_boundary_slices_from_public_vmec_with_ports(tmp_path) -> None:
    import tempfile
    from urllib.request import urlopen

    from pathlib import Path

    from libneo.stl_boundary import (
        extract_boundary_slices,
        plot_grid,
        plot_mesh_3d,
        plot_rz_slices,
    )
    from libneo.vmec_wall import PortSpec, cut_cylindrical_ports, wall_mesh_from_wout

    pytest.importorskip("trimesh")

    wout_url = (
        "https://princetonuniversity.github.io/STELLOPT/examples/wout_ncsx_c09r00_fixed.nc"
    )

    def _download_file(url: str, dst: str) -> None:
        with urlopen(url, timeout=30) as resp, open(dst, "wb") as f:
            f.write(resp.read())

    with tempfile.TemporaryDirectory():
        wout_path = tmp_path / "wout.nc"
        _download_file(wout_url, str(wout_path))

        base = wall_mesh_from_wout(wout_path, n_theta=128, n_zeta=96)
        n_ports = 12
        ports = [
            PortSpec(
                phi=float(phi),
                z=0.0,
                radius=0.18,
                length=0.8,
            )
            for phi in np.linspace(0.0, 2.0 * np.pi, n_ports, endpoint=False)
        ]
        cut = cut_cylindrical_ports(base, ports)
        assert base.faces.shape[0] - cut.faces.shape[0] > 50
        assert cut.is_watertight is False

        stl_path = tmp_path / "wall_ports.stl"
        cut.export(stl_path)

        slices = extract_boundary_slices(stl_path, n_phi=8, n_boundary_points=256)
        assert len(slices) == 8
        assert all(_is_closed(s.outer_filled, tol=1.0e-6) for s in slices)

        out_dir = Path("build/test/python")
        out_dir.mkdir(parents=True, exist_ok=True)
        plot_rz_slices(slices, out_dir / "stl_boundary_public_vmec_rz.png")
        plot_grid(slices[0], out_dir / "stl_boundary_public_vmec_grid.png")
        plot_mesh_3d(
            slices,
            stl_path,
            out_dir / "stl_boundary_public_vmec_mesh_3d.png",
            max_faces=None,
            face_alpha=0.98,
            edge_width=0.25,
            padding=0.25,
            camera_dist=18.0,
        )


def test_write_chartmap_from_stl_torus(tmp_path) -> None:
    """Test chartmap generation from a simple torus mesh."""
    import trimesh
    from netCDF4 import Dataset

    from libneo.stl_boundary import (
        BoundarySlice,
        extract_boundary_slices,
        write_chartmap_from_stl,
    )

    r0 = 1.7
    a = 0.35

    mesh = trimesh.creation.torus(
        major_radius=r0,
        minor_radius=a,
        major_sections=64,
        minor_sections=48,
    )

    stl_path = tmp_path / "torus.stl"
    mesh.export(stl_path)

    slices = extract_boundary_slices(stl_path, n_phi=4, n_boundary_points=64)
    assert len(slices) == 4

    chartmap_path = tmp_path / "torus.chartmap.nc"
    write_chartmap_from_stl(slices, chartmap_path, nrho=9, ntheta=17)

    with Dataset(chartmap_path, "r") as ds:
        assert ds.getncattr("zeta_convention") == "cyl"
        assert ds.getncattr("rho_convention") == "unknown"

        assert set(ds.dimensions) == {"rho", "theta", "zeta"}
        assert ds.dimensions["rho"].size == 9
        assert ds.dimensions["theta"].size == 17
        assert ds.dimensions["zeta"].size == 4

        for name in ["rho", "theta", "zeta", "x", "y", "z", "num_field_periods"]:
            assert name in ds.variables

        assert ds.variables["x"].units == "cm"
        assert ds.variables["y"].units == "cm"
        assert ds.variables["z"].units == "cm"

        x = ds.variables["x"][:]
        y = ds.variables["y"][:]
        z = ds.variables["z"][:]

        R = np.sqrt(x**2 + y**2)
        assert R.min() > 0.0
        assert np.abs(z).max() < (a + 0.1) * 100.0


def test_extract_boundary_slices_stl_units_mm(tmp_path) -> None:
    import numpy as np
    import trimesh

    from libneo.stl_boundary import extract_boundary_slices

    mesh_m = trimesh.creation.torus(
        major_radius=1.7,
        minor_radius=0.35,
        major_sections=48,
        minor_sections=36,
    )

    stl_m = tmp_path / "torus_m.stl"
    mesh_m.export(stl_m)

    mesh_mm = mesh_m.copy()
    mesh_mm.apply_scale(1000.0)
    stl_mm = tmp_path / "torus_mm.stl"
    mesh_mm.export(stl_mm)

    slices_m = extract_boundary_slices(stl_m, n_phi=4, n_boundary_points=128)
    slices_mm = extract_boundary_slices(
        stl_mm, n_phi=4, n_boundary_points=128, stl_units="mm"
    )

    assert len(slices_m) == len(slices_mm)
    assert np.allclose(slices_m[0].axis_xy, slices_mm[0].axis_xy, atol=1.0e-8)
    assert np.allclose(
        slices_m[0].outer_filled,
        slices_mm[0].outer_filled,
        atol=1.0e-7,
        rtol=0.0,
    )
