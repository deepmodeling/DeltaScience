module fortio
    !! Native typed file, compression, and ZIP API.
    use, intrinsic :: iso_fortran_env, only: int8, int32, int64, real64
    use fortio_bytes, only: byte_reader_t
    use fortio_compression, only: calculate_crc32, compress_raw, compress_zlib, &
        decompress_zlib
    use fortio_hdf5_reader, only: hdf5_file_t, hdf5_attribute_t
    use fortio_netcdf_classic, only: classic_file_t
    use fortio_status
    use fortio_zip, only: zip_writer_t
    implicit none
    private

    integer, parameter :: FORMAT_NONE = 0
    integer, parameter :: FORMAT_NETCDF_CLASSIC = 1
    integer, parameter :: FORMAT_HDF5 = 2

    type, public :: fortio_file_t
        !! Format-detecting file handle for the supported NetCDF and HDF5 subset.
        private
        integer :: format = FORMAT_NONE
        type(classic_file_t) :: classic
        type(hdf5_file_t) :: hdf5
    contains
        procedure :: open => file_open
        procedure :: close => file_close
        procedure :: read_i32_scalar => file_read_i32_scalar
        procedure :: read_i32_1 => file_read_i32_1
        procedure :: read_i32_2 => file_read_i32_2
        procedure :: read_i32_3 => file_read_i32_3
        procedure :: read_i64_1 => file_read_i64_1
        procedure :: read_r64_scalar => file_read_r64_scalar
        procedure :: read_r64_1 => file_read_r64_1
        procedure :: read_r64_2 => file_read_r64_2
        procedure :: read_into_r64_2 => file_read_into_r64_2
        procedure :: read_r64_3 => file_read_r64_3
        procedure :: read_r64_4 => file_read_r64_4
        procedure :: read_r64_5 => file_read_r64_5
        procedure :: read_c64_1 => file_read_c64_1
        procedure :: read_c64_2 => file_read_c64_2
        procedure :: read_c64_3 => file_read_c64_3
        procedure :: read_i32_attribute => file_read_i32_attribute
        procedure :: read_text_scalar => file_read_text_scalar
        procedure :: exists => file_exists
        procedure :: describe => file_describe
        procedure :: list_children => file_list_children
        procedure :: get_attributes => file_get_attributes
        generic :: read => read_i32_scalar, read_i32_1, read_i32_2, read_i32_3, read_i64_1, &
            read_r64_scalar, read_r64_1, read_r64_2, read_r64_3, &
            read_r64_4, read_r64_5, read_c64_1, read_c64_2, read_c64_3
        final :: file_finalize
    end type fortio_file_t

    public :: fortio_status_t
    public :: FORTIO_SUCCESS, FORTIO_EIO, FORTIO_EFORMAT, FORTIO_ENOTFOUND
    public :: FORTIO_ETYPE, FORTIO_ESHAPE, FORTIO_ENOTSUP, FORTIO_ESTATE
    public :: FORTIO_EEXIST
    public :: hdf5_attribute_t
    public :: calculate_crc32, compress_raw, compress_zlib, decompress_zlib
    public :: zip_writer_t

contains

    subroutine file_read_i64_1(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        integer(int64), allocatable, intent(out) :: value(:)
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "64-bit integer data requires HDF5")
            return
        end if
        call this%hdf5%read_i64_1(path, value, status)
    end subroutine file_read_i64_1

    subroutine file_describe(this, path, is_group, type_class, dimensions, status, element_size)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        logical, intent(out) :: is_group
        integer, intent(out) :: type_class
        integer(int64), allocatable, intent(out) :: dimensions(:)
        type(fortio_status_t), intent(inout) :: status
        integer, intent(out), optional :: element_size

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "object description requires HDF5")
            return
        end if
        call this%hdf5%describe(path, is_group, type_class, dimensions, status, element_size)
    end subroutine file_describe

    subroutine file_list_children(this, path, names, group_flags, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        character(len=:), allocatable, intent(out) :: names(:)
        logical, allocatable, intent(out) :: group_flags(:)
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "child listing requires HDF5")
            return
        end if
        call this%hdf5%list_children(path, names, group_flags, status)
    end subroutine file_list_children

    subroutine file_get_attributes(this, path, attributes, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        type(hdf5_attribute_t), allocatable, intent(out) :: attributes(:)
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "attribute copying requires HDF5")
            return
        end if
        call this%hdf5%get_attributes(path, attributes, status)
    end subroutine file_get_attributes

    subroutine file_read_c64_1(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        complex(real64), allocatable, intent(out) :: value(:)
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "complex data requires HDF5")
            return
        end if
        call this%hdf5%read_c64_1(path, value, status)
    end subroutine file_read_c64_1

    subroutine file_read_c64_2(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        complex(real64), allocatable, intent(out) :: value(:, :)
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "complex data requires HDF5")
            return
        end if
        call this%hdf5%read_c64_2(path, value, status)
    end subroutine file_read_c64_2

    subroutine file_read_c64_3(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        complex(real64), allocatable, intent(out) :: value(:, :, :)
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "complex data requires HDF5")
            return
        end if
        call this%hdf5%read_c64_3(path, value, status)
    end subroutine file_read_c64_3

    subroutine file_open(this, path, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        type(fortio_status_t), intent(inout) :: status
        type(byte_reader_t) :: detector
        integer(int8) :: signature(8)
        type(fortio_status_t) :: close_status

        call detector%open(path, status)
        if (.not. status%ok()) return
        call detector%read_bytes(signature, status)
        call detector%close(close_status)
        if (.not. status%ok()) return
        if (is_hdf5_signature(signature)) then
            call this%hdf5%open(path, status)
            if (status%ok()) this%format = FORMAT_HDF5
        else
            call this%classic%open(path, status)
            if (status%ok()) this%format = FORMAT_NETCDF_CLASSIC
        end if
    end subroutine file_open

    subroutine file_close(this, status)
        class(fortio_file_t), intent(inout) :: this
        type(fortio_status_t), intent(inout) :: status

        select case (this%format)
        case (FORMAT_NETCDF_CLASSIC)
            call this%classic%close(status)
        case (FORMAT_HDF5)
            call this%hdf5%close(status)
        case default
            call status%clear()
        end select
        this%format = FORMAT_NONE
    end subroutine file_close

    subroutine file_read_i32_scalar(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        integer(int32), intent(out) :: value
        type(fortio_status_t), intent(inout) :: status

        select case (this%format)
        case (FORMAT_NETCDF_CLASSIC)
            call this%classic%read_i32_scalar(path, value, status)
        case (FORMAT_HDF5)
            call this%hdf5%read_i32_scalar(path, value, status)
        case default
            call status%set(FORTIO_ESTATE, "no supported file is open")
        end select
    end subroutine file_read_i32_scalar

    subroutine file_read_i32_1(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        integer(int32), allocatable, intent(out) :: value(:)
        type(fortio_status_t), intent(inout) :: status

        select case (this%format)
        case (FORMAT_NETCDF_CLASSIC)
            call this%classic%read_i32_1(path, value, status)
        case (FORMAT_HDF5)
            call this%hdf5%read_i32_1(path, value, status)
        case default
            call status%set(FORTIO_ESTATE, "no supported file is open")
        end select
    end subroutine file_read_i32_1

    subroutine file_read_i32_2(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        integer(int32), allocatable, intent(out) :: value(:, :)
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "integer rank 2 requires HDF5")
            return
        end if
        call this%hdf5%read_i32_2(path, value, status)
    end subroutine file_read_i32_2

    subroutine file_read_i32_3(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        integer(int32), allocatable, intent(out) :: value(:, :, :)
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "integer rank 3 requires HDF5")
            return
        end if
        call this%hdf5%read_i32_3(path, value, status)
    end subroutine file_read_i32_3

    subroutine file_read_r64_scalar(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        real(real64), intent(out) :: value
        type(fortio_status_t), intent(inout) :: status

        select case (this%format)
        case (FORMAT_NETCDF_CLASSIC)
            call this%classic%read_r64_scalar(path, value, status)
        case (FORMAT_HDF5)
            call this%hdf5%read_r64_scalar(path, value, status)
        case default
            call status%set(FORTIO_ESTATE, "no supported file is open")
        end select
    end subroutine file_read_r64_scalar

    subroutine file_read_r64_1(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        real(real64), allocatable, intent(out) :: value(:)
        type(fortio_status_t), intent(inout) :: status

        select case (this%format)
        case (FORMAT_NETCDF_CLASSIC)
            call this%classic%read_r64_1(path, value, status)
        case (FORMAT_HDF5)
            call this%hdf5%read_r64_1(path, value, status)
        case default
            call status%set(FORTIO_ESTATE, "no supported file is open")
        end select
    end subroutine file_read_r64_1

    subroutine file_read_r64_2(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        real(real64), allocatable, intent(out) :: value(:, :)
        type(fortio_status_t), intent(inout) :: status

        select case (this%format)
        case (FORMAT_NETCDF_CLASSIC)
            call this%classic%read_r64_2(path, value, status)
        case (FORMAT_HDF5)
            call this%hdf5%read_r64_2(path, value, status)
        case default
            call status%set(FORTIO_ESTATE, "no supported file is open")
        end select
    end subroutine file_read_r64_2

    subroutine file_read_into_r64_2(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        real(real64), contiguous, target, intent(out) :: value(:, :)
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "read-into rank 2 requires HDF5")
            return
        end if
        call this%hdf5%read_into_r64_2(path, value, status)
    end subroutine file_read_into_r64_2

    subroutine file_read_r64_3(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        real(real64), allocatable, intent(out) :: value(:, :, :)
        type(fortio_status_t), intent(inout) :: status

        select case (this%format)
        case (FORMAT_NETCDF_CLASSIC)
            call this%classic%read_r64_3(path, value, status)
        case (FORMAT_HDF5)
            call this%hdf5%read_r64_3(path, value, status)
        case default
            call status%set(FORTIO_ESTATE, "no supported file is open")
        end select
    end subroutine file_read_r64_3

    subroutine file_read_r64_4(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        real(real64), allocatable, intent(out) :: value(:, :, :, :)
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "real rank 4 requires HDF5")
            return
        end if
        call this%hdf5%read_r64_4(path, value, status)
    end subroutine file_read_r64_4

    subroutine file_read_r64_5(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        real(real64), allocatable, intent(out) :: value(:, :, :, :, :)
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "real rank 5 requires HDF5")
            return
        end if
        call this%hdf5%read_r64_5(path, value, status)
    end subroutine file_read_r64_5

    subroutine file_read_i32_attribute(this, path, name, values, found, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path, name
        integer(int32), allocatable, intent(out) :: values(:)
        logical, intent(out) :: found
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "attributes are only supported for HDF5 here")
            return
        end if
        call this%hdf5%read_i32_attribute(path, name, values, found, status)
    end subroutine file_read_i32_attribute

    subroutine file_read_text_scalar(this, path, value, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        character(len=:), allocatable, intent(out) :: value
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "strings are only supported for HDF5 here")
            return
        end if
        call this%hdf5%read_text_scalar(path, value, status)
    end subroutine file_read_text_scalar

    subroutine file_exists(this, path, exists, status)
        class(fortio_file_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        logical, intent(out) :: exists
        type(fortio_status_t), intent(inout) :: status

        if (this%format /= FORMAT_HDF5) then
            call status%set(FORTIO_ENOTSUP, "object existence requires HDF5")
            return
        end if
        call this%hdf5%exists(path, exists, status)
    end subroutine file_exists

    pure logical function is_hdf5_signature(bytes)
        integer(int8), intent(in) :: bytes(8)

        is_hdf5_signature = all(bytes == [int(z'89', int8), int(z'48', int8), &
            int(z'44', int8), int(z'46', int8), int(z'0d', int8), int(z'0a', int8), &
            int(z'1a', int8), int(z'0a', int8)])
    end function is_hdf5_signature

    subroutine file_finalize(this)
        type(fortio_file_t), intent(inout) :: this
        type(fortio_status_t) :: ignored

        call this%close(ignored)
    end subroutine file_finalize

end module fortio
