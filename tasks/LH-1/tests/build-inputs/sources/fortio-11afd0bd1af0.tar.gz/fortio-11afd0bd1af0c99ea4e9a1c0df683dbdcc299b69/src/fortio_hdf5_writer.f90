module fortio_hdf5_writer
    use, intrinsic :: iso_fortran_env, only: int8, int32, int64, real32, real64
    use fortio_bytes, only: byte_writer_t
    use fortio_checksum, only: lookup3_checksum
    use fortio_deflate, only: deflate_compress, shuffle_bytes
    use fortio_status, only: fortio_status_t, FORTIO_ESTATE, FORTIO_ESHAPE, &
        FORTIO_ENOTSUP
    implicit none
    private

    integer, parameter :: TYPE_I32 = 1
    integer, parameter :: TYPE_R64 = 2
    integer, parameter :: TYPE_TEXT = 3
    integer, parameter :: TYPE_C64 = 4
    integer, parameter :: TYPE_I64 = 5
    integer, parameter :: TYPE_R32 = 6
    integer, parameter :: TYPE_DIMENSION_LIST = 7
    integer, parameter :: TYPE_I8 = 8
    integer(int64), parameter :: ROOT_ADDRESS = 48_int64
    ! Reserve space for the superblock and object headers when streaming
    ! dataset payloads directly into the output image.  MEPHIT's metadata is
    ! comfortably below this bound; a larger image is rejected explicitly.
    integer(int64), parameter :: STREAM_HEADER_RESERVE = 16_int64*1024_int64*1024_int64

    type :: hdf5_output_attribute_t
        character(len=:), allocatable :: name
        integer :: type_code = 0
        integer(int32), allocatable :: values_i32(:)
        real(real64), allocatable :: values_r64(:)
        character(len=:), allocatable :: value_text
        logical :: null_terminated = .false.
    end type hdf5_output_attribute_t

    type :: hdf5_output_dataset_t
        character(len=:), allocatable :: name
        integer :: parent_group = 1
        integer :: type_code = 0
        integer(int64), allocatable :: dimensions(:)
        integer(int8), allocatable :: values_i8(:)
        integer(int32), allocatable :: values_i32(:)
        integer(int64), allocatable :: values_i64(:)
        real(real64), allocatable :: values_r64(:)
        real(real32), allocatable :: values_r32(:)
        character(len=:), allocatable :: value_text
        complex(real64), allocatable :: values_c64(:)
        type(hdf5_output_attribute_t), allocatable :: attributes(:)
        integer, allocatable :: dimension_scales(:)
        logical :: is_dimension_scale = .false.
        logical :: char_array = .false.
        integer :: heap_index = 0
        integer(int64) :: global_heap_address = -1_int64
        integer(int8), allocatable :: filtered_bytes(:)
        integer :: deflate_level = 0
        logical :: deflate = .false.
        logical :: shuffle = .false.
        integer(int64) :: object_address = 0_int64
        integer(int64) :: data_address = 0_int64
        logical :: streamed = .false.
    end type hdf5_output_dataset_t

    type :: hdf5_output_group_t
        character(len=:), allocatable :: path
        character(len=:), allocatable :: name
        integer :: parent_group = 0
        integer(int64) :: object_address = 0_int64
        type(hdf5_output_attribute_t), allocatable :: attributes(:)
    end type hdf5_output_group_t

    type :: hdf5_free_range_t
        integer(int64) :: offset = 0_int64
        integer(int64) :: size = 0_int64
    end type hdf5_free_range_t

    type, public :: hdf5_writer_t
        character(len=:), allocatable :: path
        type(byte_writer_t) :: output
        type(hdf5_output_group_t), allocatable :: groups(:)
        type(hdf5_output_dataset_t), allocatable :: datasets(:)
        type(hdf5_free_range_t), allocatable :: free_ranges(:)
        integer(int64) :: stream_end = 0_int64
        logical :: streaming = .false.
        logical :: output_initialized = .false.
        logical :: pending_flush = .false.
        logical :: opened = .false.
    contains
        procedure :: create => hdf5_writer_create
        procedure :: reopen => hdf5_writer_reopen
        procedure :: define_group => hdf5_define_group
        procedure :: add_i32_scalar => hdf5_add_i32_scalar
        procedure :: add_i8 => hdf5_add_i8
        procedure :: add_char => hdf5_add_char
        procedure :: add_i32_values => add_i32_flat
        procedure :: add_r64_values => add_r64_flat
        procedure :: add_i32_1 => hdf5_add_i32_1
        procedure :: add_i32_2 => hdf5_add_i32_2
        procedure :: add_i32_3 => hdf5_add_i32_3
        procedure :: add_i64_1 => hdf5_add_i64_1
        procedure :: add_r64_scalar => hdf5_add_r64_scalar
        procedure :: add_r32_1 => hdf5_add_r32_1
        procedure :: add_r64_1 => hdf5_add_r64_1
        procedure :: add_r64_2 => hdf5_add_r64_2
        procedure :: add_r64_3 => hdf5_add_r64_3
        procedure :: add_r64_4 => hdf5_add_r64_4
        procedure :: add_r64_5 => hdf5_add_r64_5
        procedure :: add_text_scalar => hdf5_add_text_scalar
        procedure :: add_c64_1 => hdf5_add_c64_1
        procedure :: add_c64_2 => hdf5_add_c64_2
        procedure :: add_c64_3 => hdf5_add_c64_3
        procedure :: add_text_attribute => hdf5_add_text_attribute
        procedure :: add_i32_attribute => hdf5_add_i32_attribute
        procedure :: add_r64_attribute => hdf5_add_r64_attribute
        procedure :: add_root_text_attribute => hdf5_add_root_text_attribute
        procedure :: add_root_i32_attribute => hdf5_add_root_i32_attribute
        procedure :: add_root_r64_attribute => hdf5_add_root_r64_attribute
        procedure :: mark_dimension_scale => hdf5_mark_dimension_scale
        procedure :: set_dimension_list => hdf5_set_dimension_list
        procedure :: set_deflate => hdf5_set_deflate
        procedure :: remove_dataset => hdf5_remove_dataset
        procedure :: stream_dataset => hdf5_stream_dataset
        procedure :: object_exists => hdf5_object_exists
        procedure :: suspend => hdf5_writer_suspend
        procedure :: flush => hdf5_writer_flush
        procedure :: close => hdf5_writer_close
        final :: finalize_hdf5_writer
    end type hdf5_writer_t

contains

    subroutine finalize_hdf5_writer(this)
        type(hdf5_writer_t), intent(inout) :: this
        type(fortio_status_t) :: status

        call this%output%close(status)
    end subroutine finalize_hdf5_writer

    subroutine hdf5_set_deflate(this, name, shuffle, level, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        logical, intent(in) :: shuffle
        integer, intent(in) :: level
        type(fortio_status_t), intent(inout) :: status
        integer :: dataset_id

        call status%clear()
        if (.not. this%opened) then
            call status%set(FORTIO_ESTATE, "HDF5 writer is not open")
            return
        end if
        if (level < 0 .or. level > 9) then
            call status%set(FORTIO_ESHAPE, "deflate level must be between zero and nine")
            return
        end if
        if (this%streaming) then
            call status%set(FORTIO_ENOTSUP, &
                "deflate filters are incompatible with streaming HDF5 output")
            return
        end if
        call find_dataset(this, name, dataset_id, status)
        if (.not. status%ok()) return
        this%datasets(dataset_id)%shuffle = shuffle
        this%datasets(dataset_id)%deflate = .true.
        this%datasets(dataset_id)%deflate_level = level
    end subroutine hdf5_set_deflate

    subroutine hdf5_writer_create(this, path, status, streaming)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        type(fortio_status_t), intent(inout) :: status
        logical, intent(in), optional :: streaming

        call status%clear()
        call this%output%close(status)
        if (.not. status%ok()) return
        this%path = trim(path)
        if (allocated(this%datasets)) deallocate(this%datasets)
        if (allocated(this%groups)) deallocate(this%groups)
        if (allocated(this%free_ranges)) deallocate(this%free_ranges)
        allocate(this%datasets(0), this%groups(1), this%free_ranges(0))
        this%groups(1)%path = ""
        this%groups(1)%name = ""
        this%groups(1)%parent_group = 0
        this%groups(1)%object_address = ROOT_ADDRESS
        allocate(this%groups(1)%attributes(0))
        this%streaming = .false.
        this%output_initialized = .false.
        this%pending_flush = .false.
        if (present(streaming)) this%streaming = streaming
        this%stream_end = STREAM_HEADER_RESERVE
        if (this%streaming) then
            call this%output%open(this%path, status)
            if (.not. status%ok()) return
            call this%output%seek(this%stream_end + 1_int64)
        end if
        this%opened = .true.
        this%pending_flush = .false.
    end subroutine hdf5_writer_create

    subroutine hdf5_writer_reopen(this, path, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        type(fortio_status_t), intent(inout) :: status

        call status%clear()
        if (this%opened) then
            call status%set(FORTIO_ESTATE, "HDF5 writer is already open")
            return
        end if
        if (.not. allocated(this%path)) then
            call status%set(FORTIO_ESTATE, "HDF5 writer has no retained state")
            return
        end if
        if (this%path /= trim(path)) then
            call status%set(FORTIO_ESTATE, "HDF5 writer state belongs to another file")
            return
        end if
        if (.not. allocated(this%groups) .or. .not. allocated(this%datasets)) then
            call status%set(FORTIO_ESTATE, "HDF5 writer state is incomplete")
            return
        end if
        call this%output%reopen(this%path, status)
        if (.not. status%ok()) return
        this%opened = .true.
    end subroutine hdf5_writer_reopen

    subroutine hdf5_writer_suspend(this, status)
        class(hdf5_writer_t), intent(inout) :: this
        type(fortio_status_t), intent(inout) :: status

        call status%clear()
        ! Keep writer state for a same-process reopen.  In streaming mode raw
        ! payloads are already on disk; otherwise the retained state includes
        ! the complete image until h5_deinit.  Ordinary close semantics are
        ! unchanged.
        this%opened = .false.
        this%pending_flush = .true.
    end subroutine hdf5_writer_suspend

    subroutine hdf5_writer_flush(this, status)
        class(hdf5_writer_t), intent(inout) :: this
        type(fortio_status_t), intent(inout) :: status
        logical :: was_opened

        call status%clear()
        was_opened = this%opened
        this%opened = .true.
        call hdf5_writer_close(this, status)
        if (was_opened .and. .not. status%ok()) this%opened = .true.
    end subroutine hdf5_writer_flush

    subroutine hdf5_add_i32_scalar(this, name, value, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        integer(int32), intent(in) :: value
        type(fortio_status_t), intent(inout) :: status

        call add_i32_flat(this, name, [integer(int64) ::], [value], status)
    end subroutine hdf5_add_i32_scalar

    subroutine hdf5_add_i8(this, name, dimensions, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        integer(int64), intent(in) :: dimensions(:)
        integer(int8), intent(in) :: values(:)
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_dataset_t) :: dataset
        character(len=:), allocatable :: leaf_name
        integer :: parent_group

        if (.not. prepare_dataset(this, name, dimensions, size(values, kind=int64), &
            parent_group, leaf_name, status)) return
        dataset%name = leaf_name
        dataset%parent_group = parent_group
        dataset%type_code = TYPE_I8
        dataset%dimensions = dimensions
        dataset%values_i8 = values
        allocate(dataset%attributes(0))
        call this%stream_dataset(dataset, status)
        if (.not. status%ok()) return
        call append_dataset(this%datasets, dataset)
    end subroutine hdf5_add_i8

    subroutine hdf5_add_char(this, name, dimensions, value, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name, value
        integer(int64), intent(in) :: dimensions(:)
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_dataset_t) :: dataset
        character(len=:), allocatable :: leaf_name
        integer :: parent_group

        if (.not. prepare_dataset(this, name, dimensions, len(value, kind=int64), &
            parent_group, leaf_name, status)) return
        dataset%name = leaf_name
        dataset%parent_group = parent_group
        dataset%type_code = TYPE_TEXT
        dataset%dimensions = dimensions
        dataset%value_text = value
        dataset%char_array = .true.
        allocate(dataset%attributes(0))
        call this%stream_dataset(dataset, status)
        if (.not. status%ok()) return
        call append_dataset(this%datasets, dataset)
    end subroutine hdf5_add_char

    subroutine hdf5_define_group(this, path, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        type(fortio_status_t), intent(inout) :: status
        integer :: group_id

        call status%clear()
        if (.not. this%opened) then
            call status%set(FORTIO_ESTATE, "HDF5 writer is not open")
            return
        end if
        call ensure_group_path(this, path, group_id, status)
    end subroutine hdf5_define_group

    subroutine hdf5_add_i32_1(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        integer(int32), intent(in) :: values(:)
        type(fortio_status_t), intent(inout) :: status

        call add_i32_flat(this, name, [int(size(values), int64)], values, status)
    end subroutine hdf5_add_i32_1

    subroutine hdf5_add_i32_2(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        integer(int32), intent(in) :: values(:, :)
        type(fortio_status_t), intent(inout) :: status

        call add_i32_flat(this, name, int(shape(values), int64), &
            reshape(values, [size(values)]), status)
    end subroutine hdf5_add_i32_2

    subroutine hdf5_add_i32_3(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        integer(int32), intent(in) :: values(:, :, :)
        type(fortio_status_t), intent(inout) :: status

        call add_i32_flat(this, name, int(shape(values), int64), &
            reshape(values, [size(values)]), status)
    end subroutine hdf5_add_i32_3

    subroutine hdf5_add_i64_1(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        integer(int64), intent(in) :: values(:)
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_dataset_t) :: dataset
        character(len=:), allocatable :: leaf_name
        integer :: parent_group

        if (.not. prepare_dataset(this, name, [int(size(values), int64)], &
            size(values, kind=int64), parent_group, &
            leaf_name, status)) return
        dataset%name = leaf_name
        dataset%parent_group = parent_group
        dataset%type_code = TYPE_I64
        dataset%dimensions = [int(size(values), int64)]
        dataset%values_i64 = values
        allocate(dataset%attributes(0))
        call this%stream_dataset(dataset, status)
        if (.not. status%ok()) return
        call append_dataset(this%datasets, dataset)
    end subroutine hdf5_add_i64_1

    subroutine hdf5_add_r64_scalar(this, name, value, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        real(real64), intent(in) :: value
        type(fortio_status_t), intent(inout) :: status

        call add_r64_flat(this, name, [integer(int64) ::], [value], status)
    end subroutine hdf5_add_r64_scalar

    subroutine hdf5_add_r32_1(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        real(real32), intent(in) :: values(:)
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_dataset_t) :: dataset
        character(len=:), allocatable :: leaf_name
        integer :: parent_group

        if (.not. prepare_dataset(this, name, [int(size(values), int64)], &
            size(values, kind=int64), parent_group, leaf_name, status)) return
        dataset%name = leaf_name
        dataset%parent_group = parent_group
        dataset%type_code = TYPE_R32
        dataset%dimensions = [int(size(values), int64)]
        dataset%values_r32 = values
        allocate(dataset%attributes(0))
        call this%stream_dataset(dataset, status)
        if (.not. status%ok()) return
        call append_dataset(this%datasets, dataset)
    end subroutine hdf5_add_r32_1

    subroutine hdf5_add_text_scalar(this, name, value, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name, value
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_dataset_t) :: dataset
        character(len=:), allocatable :: leaf_name
        integer :: parent_group

        if (.not. prepare_dataset(this, name, [integer(int64) ::], 1_int64, &
            parent_group, leaf_name, status)) return
        dataset%name = leaf_name
        dataset%parent_group = parent_group
        dataset%type_code = TYPE_TEXT
        allocate(dataset%dimensions(0))
        if (len_trim(value) == 0) then
            dataset%value_text = achar(0)
        else
            dataset%value_text = value(:len_trim(value))
        end if
        allocate(dataset%attributes(0))
        call this%stream_dataset(dataset, status)
        if (.not. status%ok()) return
        call append_dataset(this%datasets, dataset)
    end subroutine hdf5_add_text_scalar

    subroutine hdf5_add_r64_1(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        real(real64), intent(in) :: values(:)
        type(fortio_status_t), intent(inout) :: status

        call add_r64_flat(this, name, [int(size(values), int64)], values, status)
    end subroutine hdf5_add_r64_1

    subroutine hdf5_add_r64_2(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        real(real64), intent(in) :: values(:, :)
        type(fortio_status_t), intent(inout) :: status

        call add_r64_flat(this, name, int(shape(values), int64), &
            reshape(values, [size(values)]), status)
    end subroutine hdf5_add_r64_2

    subroutine hdf5_add_r64_3(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        real(real64), intent(in) :: values(:, :, :)
        type(fortio_status_t), intent(inout) :: status

        call add_r64_flat(this, name, int(shape(values), int64), &
            reshape(values, [size(values)]), status)
    end subroutine hdf5_add_r64_3

    subroutine hdf5_add_r64_4(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        real(real64), intent(in) :: values(:, :, :, :)
        type(fortio_status_t), intent(inout) :: status

        call add_r64_flat(this, name, int(shape(values), int64), &
            reshape(values, [size(values)]), status)
    end subroutine hdf5_add_r64_4

    subroutine hdf5_add_r64_5(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        real(real64), intent(in) :: values(:, :, :, :, :)
        type(fortio_status_t), intent(inout) :: status

        call add_r64_flat(this, name, int(shape(values), int64), &
            reshape(values, [size(values)]), status)
    end subroutine hdf5_add_r64_5

    subroutine hdf5_add_c64_1(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        complex(real64), intent(in) :: values(:)
        type(fortio_status_t), intent(inout) :: status

        call add_c64_flat(this, name, [int(size(values), int64)], values, status)
    end subroutine hdf5_add_c64_1

    subroutine hdf5_add_c64_2(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        complex(real64), intent(in) :: values(:, :)
        type(fortio_status_t), intent(inout) :: status

        call add_c64_flat(this, name, int(shape(values), int64), &
            reshape(values, [size(values)]), status)
    end subroutine hdf5_add_c64_2

    subroutine hdf5_add_c64_3(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        complex(real64), intent(in) :: values(:, :, :)
        type(fortio_status_t), intent(inout) :: status

        call add_c64_flat(this, name, int(shape(values), int64), &
            reshape(values, [size(values)]), status)
    end subroutine hdf5_add_c64_3

    subroutine add_c64_flat(this, name, dimensions, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        integer(int64), intent(in) :: dimensions(:)
        complex(real64), intent(in) :: values(:)
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_dataset_t) :: dataset
        character(len=:), allocatable :: leaf_name
        integer :: parent_group

        if (.not. prepare_dataset(this, name, dimensions, size(values, kind=int64), &
            parent_group, leaf_name, status)) return
        dataset%name = leaf_name
        dataset%parent_group = parent_group
        dataset%type_code = TYPE_C64
        dataset%dimensions = dimensions
        dataset%values_c64 = values
        allocate(dataset%attributes(0))
        call this%stream_dataset(dataset, status)
        if (.not. status%ok()) return
        call append_dataset(this%datasets, dataset)
    end subroutine add_c64_flat

    subroutine add_i32_flat(this, name, dimensions, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        integer(int64), intent(in) :: dimensions(:)
        integer(int32), intent(in) :: values(:)
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_dataset_t) :: dataset
        character(len=:), allocatable :: leaf_name
        integer :: parent_group

        if (.not. prepare_dataset(this, name, dimensions, size(values, kind=int64), &
            parent_group, leaf_name, status)) &
            return
        dataset%name = leaf_name
        dataset%parent_group = parent_group
        dataset%type_code = TYPE_I32
        dataset%dimensions = dimensions
        dataset%values_i32 = values
        allocate(dataset%attributes(0))
        call this%stream_dataset(dataset, status)
        if (.not. status%ok()) return
        call append_dataset(this%datasets, dataset)
    end subroutine add_i32_flat

    subroutine add_r64_flat(this, name, dimensions, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        integer(int64), intent(in) :: dimensions(:)
        real(real64), intent(in) :: values(:)
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_dataset_t) :: dataset
        character(len=:), allocatable :: leaf_name
        integer :: parent_group

        if (.not. prepare_dataset(this, name, dimensions, size(values, kind=int64), &
            parent_group, leaf_name, status)) &
            return
        dataset%name = leaf_name
        dataset%parent_group = parent_group
        dataset%type_code = TYPE_R64
        dataset%dimensions = dimensions
        dataset%values_r64 = values
        allocate(dataset%attributes(0))
        call this%stream_dataset(dataset, status)
        if (.not. status%ok()) return
        call append_dataset(this%datasets, dataset)
    end subroutine add_r64_flat

    subroutine hdf5_add_text_attribute(this, dataset_name, name, value, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: dataset_name, name, value
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_attribute_t) :: attribute
        integer :: dataset_id

        call find_dataset(this, dataset_name, dataset_id, status)
        if (.not. status%ok()) return
        attribute%name = trim(name)
        attribute%type_code = TYPE_TEXT
        attribute%value_text = value
        call append_attribute(this%datasets(dataset_id)%attributes, attribute, status)
    end subroutine hdf5_add_text_attribute

    subroutine hdf5_add_i32_attribute(this, dataset_name, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: dataset_name, name
        integer(int32), intent(in) :: values(:)
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_attribute_t) :: attribute
        integer :: dataset_id

        call find_dataset(this, dataset_name, dataset_id, status)
        if (.not. status%ok()) return
        attribute%name = trim(name)
        attribute%type_code = TYPE_I32
        attribute%values_i32 = values
        call append_attribute(this%datasets(dataset_id)%attributes, attribute, status)
    end subroutine hdf5_add_i32_attribute

    subroutine hdf5_add_r64_attribute(this, dataset_name, name, value, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: dataset_name, name
        real(real64), intent(in) :: value
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_attribute_t) :: attribute
        integer :: dataset_id

        call find_dataset(this, dataset_name, dataset_id, status)
        if (.not. status%ok()) return
        attribute%name = trim(name)
        attribute%type_code = TYPE_R64
        attribute%values_r64 = [value]
        call append_attribute(this%datasets(dataset_id)%attributes, attribute, status)
    end subroutine hdf5_add_r64_attribute

    subroutine hdf5_add_root_text_attribute(this, name, value, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name, value
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_attribute_t) :: attribute

        attribute%name = trim(name)
        attribute%type_code = TYPE_TEXT
        attribute%value_text = value
        call append_attribute(this%groups(1)%attributes, attribute, status)
    end subroutine hdf5_add_root_text_attribute

    subroutine hdf5_add_root_i32_attribute(this, name, values, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        integer(int32), intent(in) :: values(:)
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_attribute_t) :: attribute

        attribute%name = trim(name)
        attribute%type_code = TYPE_I32
        attribute%values_i32 = values
        call append_attribute(this%groups(1)%attributes, attribute, status)
    end subroutine hdf5_add_root_i32_attribute

    subroutine hdf5_add_root_r64_attribute(this, name, value, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        real(real64), intent(in) :: value
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_attribute_t) :: attribute

        attribute%name = trim(name)
        attribute%type_code = TYPE_R64
        attribute%values_r64 = [value]
        call append_attribute(this%groups(1)%attributes, attribute, status)
    end subroutine hdf5_add_root_r64_attribute

    subroutine hdf5_mark_dimension_scale(this, dataset_name, status, coordinate_variable)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: dataset_name
        type(fortio_status_t), intent(inout) :: status
        logical, intent(in), optional :: coordinate_variable
        integer :: dataset_id
        character(len=64) :: scale_name
        logical :: is_coordinate

        call find_dataset(this, dataset_name, dataset_id, status)
        if (.not. status%ok()) return
        this%datasets(dataset_id)%is_dimension_scale = .true.
        is_coordinate = .true.
        if (present(coordinate_variable)) is_coordinate = coordinate_variable
        call append_dimension_scale_text(this%datasets(dataset_id)%attributes, &
            "CLASS", "DIMENSION_SCALE", status)
        if (.not. status%ok()) return
        if (is_coordinate) then
            call append_dimension_scale_text(this%datasets(dataset_id)%attributes, &
                "NAME", trim(dataset_name), status)
        else
            write (scale_name, '("This is a netCDF dimension but not a netCDF variable.",i10)') &
                product(this%datasets(dataset_id)%dimensions)
            call append_dimension_scale_text(this%datasets(dataset_id)%attributes, &
                "NAME", scale_name, status)
        end if
    end subroutine hdf5_mark_dimension_scale

    subroutine hdf5_set_dimension_list(this, dataset_name, scale_names, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: dataset_name
        character(len=*), intent(in) :: scale_names(:)
        type(fortio_status_t), intent(inout) :: status
        integer :: dataset_id, i

        call find_dataset(this, dataset_name, dataset_id, status)
        if (.not. status%ok()) return
        allocate(this%datasets(dataset_id)%dimension_scales(size(scale_names)))
        do i = 1, size(scale_names)
            call find_dataset(this, trim(scale_names(i)), &
                this%datasets(dataset_id)%dimension_scales(i), status)
            if (.not. status%ok()) return
        end do
    end subroutine hdf5_set_dimension_list

    subroutine append_dimension_scale_text(attributes, name, value, status)
        type(hdf5_output_attribute_t), allocatable, intent(inout) :: attributes(:)
        character(len=*), intent(in) :: name, value
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_attribute_t) :: attribute

        attribute%name = name
        attribute%type_code = TYPE_TEXT
        attribute%value_text = value//achar(0)
        attribute%null_terminated = .true.
        call append_attribute(attributes, attribute, status)
    end subroutine append_dimension_scale_text

    subroutine hdf5_remove_dataset(this, name, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_dataset_t), allocatable :: temporary(:)
        integer :: dataset_id, count
        integer(int64) :: data_size

        call find_dataset(this, name, dataset_id, status)
        if (.not. status%ok()) then
            call status%clear()
            return
        end if
        if (this%streaming .and. this%datasets(dataset_id)%streamed) then
            data_size = dataset_data_size(this%datasets(dataset_id))
            call release_stream_range(this, this%datasets(dataset_id)%data_address, data_size)
        end if
        count = size(this%datasets)
        allocate(temporary(count - 1))
        if (dataset_id > 1) temporary(:dataset_id - 1) = this%datasets(:dataset_id - 1)
        if (dataset_id < count) temporary(dataset_id:) = this%datasets(dataset_id + 1:)
        call move_alloc(temporary, this%datasets)
    end subroutine hdf5_remove_dataset

    logical function hdf5_object_exists(this, path) result(exists)
        class(hdf5_writer_t), intent(in) :: this
        character(len=*), intent(in) :: path
        character(len=:), allocatable :: normalized, dataset_path
        integer :: i

        call normalize_path(path, normalized)
        exists = len(normalized) == 0
        if (exists) return
        do i = 2, size(this%groups)
            if (this%groups(i)%path == normalized) then
                exists = .true.
                return
            end if
        end do
        do i = 1, size(this%datasets)
            if (this%datasets(i)%parent_group == 1) then
                dataset_path = this%datasets(i)%name
            else
                dataset_path = trim(this%groups(this%datasets(i)%parent_group)%path)//"/"// &
                    this%datasets(i)%name
            end if
            if (dataset_path == normalized) then
                exists = .true.
                return
            end if
        end do
    end function hdf5_object_exists

    subroutine find_dataset(this, name, dataset_id, status)
        class(hdf5_writer_t), intent(in) :: this
        character(len=*), intent(in) :: name
        integer, intent(out) :: dataset_id
        type(fortio_status_t), intent(inout) :: status
        character(len=:), allocatable :: normalized, parent_path, leaf_name
        integer :: i, parent_group, separator

        call status%clear()
        call normalize_path(name, normalized)
        separator = scan(normalized, "/", back=.true.)
        if (separator == 0) then
            parent_path = ""
            leaf_name = normalized
        else
            parent_path = normalized(:separator - 1)
            leaf_name = normalized(separator + 1:)
        end if
        parent_group = group_by_path(this%groups, parent_path)
        dataset_id = 0
        do i = 1, size(this%datasets)
            if (this%datasets(i)%parent_group == parent_group) then
                if (this%datasets(i)%name == leaf_name) then
                    dataset_id = i
                    return
                end if
            end if
        end do
        call status%set(FORTIO_ESTATE, "HDF5 attribute dataset does not exist")
    end subroutine find_dataset

    subroutine append_attribute(attributes, attribute, status)
        type(hdf5_output_attribute_t), allocatable, intent(inout) :: attributes(:)
        type(hdf5_output_attribute_t), intent(in) :: attribute
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_attribute_t), allocatable :: temporary(:)
        integer :: count, i

        if (len(attribute%name) == 0 .or. len(attribute%name) > 255) then
            call status%set(FORTIO_ENOTSUP, "HDF5 attribute name is not supported")
            return
        end if
        do i = 1, size(attributes)
            if (attributes(i)%name == attribute%name) then
                attributes(i) = attribute
                return
            end if
        end do
        count = size(attributes)
        allocate(temporary(count + 1))
        if (count > 0) temporary(:count) = attributes
        temporary(count + 1) = attribute
        call move_alloc(temporary, attributes)
    end subroutine append_attribute

    logical function prepare_dataset(this, name, dimensions, count, parent_group, &
            leaf_name, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: name
        integer(int64), intent(in) :: dimensions(:), count
        integer, intent(out) :: parent_group
        character(len=:), allocatable, intent(out) :: leaf_name
        type(fortio_status_t), intent(inout) :: status
        character(len=:), allocatable :: normalized, parent_path
        integer :: i, separator

        call status%clear()
        prepare_dataset = this%opened
        if (.not. prepare_dataset) then
            call status%set(FORTIO_ESTATE, "HDF5 writer is not open")
            return
        end if
        call normalize_path(name, normalized)
        separator = scan(normalized, "/", back=.true.)
        if (separator == 0) then
            parent_path = ""
            leaf_name = normalized
        else
            parent_path = normalized(:separator - 1)
            leaf_name = normalized(separator + 1:)
        end if
        if (len(leaf_name) == 0 .or. len(leaf_name) > 255) then
            call status%set(FORTIO_ENOTSUP, "HDF5 dataset name is not supported")
            prepare_dataset = .false.
            return
        end if
        call ensure_group_path(this, parent_path, parent_group, status)
        if (.not. status%ok()) then
            prepare_dataset = .false.
            return
        end if
        if (product(dimensions) /= count) then
            call status%set(FORTIO_ESHAPE, "HDF5 dataset shape does not match values")
            prepare_dataset = .false.
            return
        end if
        do i = 1, size(this%datasets)
            if (this%datasets(i)%parent_group == parent_group .and. &
                this%datasets(i)%name == leaf_name) then
                prepare_dataset = .false.
                return
            end if
        end do
    end function prepare_dataset

    subroutine append_dataset(datasets, dataset)
        type(hdf5_output_dataset_t), allocatable, intent(inout) :: datasets(:)
        type(hdf5_output_dataset_t), intent(in) :: dataset
        type(hdf5_output_dataset_t), allocatable :: temporary(:)
        integer :: count

        count = size(datasets)
        allocate(temporary(count + 1))
        if (count > 0) temporary(:count) = datasets
        temporary(count + 1) = dataset
        call move_alloc(temporary, datasets)
    end subroutine append_dataset

    subroutine hdf5_stream_dataset(this, dataset, status)
        class(hdf5_writer_t), intent(inout) :: this
        type(hdf5_output_dataset_t), intent(inout) :: dataset
        type(fortio_status_t), intent(inout) :: status
        integer(int64) :: data_size, offset
        integer(int8), allocatable :: bytes(:)

        call status%clear()
        if (.not. this%streaming) return
        data_size = dataset_data_size(dataset)
        call allocate_stream_range(this, data_size, offset)
        dataset%data_address = offset
        dataset%streamed = .true.
        if (data_size == 0_int64) return

        call this%output%seek(offset + 1_int64)
        select case (dataset%type_code)
        case (TYPE_I8)
            call this%output%write_bytes(dataset%values_i8, status)
            deallocate(dataset%values_i8)
        case (TYPE_I32)
            allocate(bytes(4*size(dataset%values_i32)))
            bytes = transfer(dataset%values_i32, bytes)
            call convert_native_to_little_endian(bytes, 4)
            call this%output%write_bytes(bytes, status)
            deallocate(bytes, dataset%values_i32)
        case (TYPE_I64)
            allocate(bytes(8*size(dataset%values_i64)))
            bytes = transfer(dataset%values_i64, bytes)
            call convert_native_to_little_endian(bytes, 8)
            call this%output%write_bytes(bytes, status)
            deallocate(bytes, dataset%values_i64)
        case (TYPE_R64)
            call this%output%write_le_r64_array(dataset%values_r64, status)
            deallocate(dataset%values_r64)
        case (TYPE_R32)
            allocate(bytes(4*size(dataset%values_r32)))
            bytes = transfer(dataset%values_r32, bytes)
            call convert_native_to_little_endian(bytes, 4)
            call this%output%write_bytes(bytes, status)
            deallocate(bytes, dataset%values_r32)
        case (TYPE_C64)
            call this%output%write_le_c64_array(dataset%values_c64, status)
            deallocate(dataset%values_c64)
        case (TYPE_TEXT)
            allocate(bytes(len(dataset%value_text)))
            bytes = transfer(dataset%value_text, bytes)
            call this%output%write_bytes(bytes, status)
            deallocate(bytes)
        end select
    end subroutine hdf5_stream_dataset

    subroutine allocate_stream_range(this, data_size, offset)
        class(hdf5_writer_t), intent(inout) :: this
        integer(int64), intent(in) :: data_size
        integer(int64), intent(out) :: offset
        type(hdf5_free_range_t), allocatable :: remaining(:)
        integer :: i, count

        do i = 1, size(this%free_ranges)
            if (this%free_ranges(i)%size < data_size) cycle
            offset = this%free_ranges(i)%offset
            if (this%free_ranges(i)%size == data_size) then
                count = size(this%free_ranges)
                allocate(remaining(max(0, count - 1)))
                if (i > 1) remaining(:i - 1) = this%free_ranges(:i - 1)
                if (i < count) remaining(i:) = this%free_ranges(i + 1:)
                call move_alloc(remaining, this%free_ranges)
            else
                this%free_ranges(i)%offset = this%free_ranges(i)%offset + data_size
                this%free_ranges(i)%size = this%free_ranges(i)%size - data_size
            end if
            return
        end do
        offset = this%stream_end
        this%stream_end = this%stream_end + data_size
    end subroutine allocate_stream_range

    subroutine release_stream_range(this, offset, data_size)
        class(hdf5_writer_t), intent(inout) :: this
        integer(int64), intent(in) :: offset, data_size
        type(hdf5_free_range_t), allocatable :: temporary(:)
        integer :: count

        if (.not. this%streaming .or. data_size <= 0_int64) return
        count = size(this%free_ranges)
        allocate(temporary(count + 1))
        if (count > 0) temporary(:count) = this%free_ranges
        temporary(count + 1)%offset = offset
        temporary(count + 1)%size = data_size
        call move_alloc(temporary, this%free_ranges)
    end subroutine release_stream_range

    subroutine ensure_group_path(this, path, group_id, status)
        class(hdf5_writer_t), intent(inout) :: this
        character(len=*), intent(in) :: path
        integer, intent(out) :: group_id
        type(fortio_status_t), intent(inout) :: status
        type(hdf5_output_group_t) :: group
        character(len=:), allocatable :: normalized, component, current_path, remaining
        integer :: separator, existing

        call status%clear()
        call normalize_path(path, normalized)
        if (len(normalized) == 0) then
            group_id = 1
            return
        end if
        remaining = normalized
        current_path = ""
        group_id = 1
        do
            separator = index(remaining, "/")
            if (separator == 0) then
                component = remaining
                remaining = ""
            else
                component = remaining(:separator - 1)
                remaining = remaining(separator + 1:)
            end if
            if (len(component) == 0 .or. len(component) > 255) then
                call status%set(FORTIO_ENOTSUP, "HDF5 group name is not supported")
                return
            end if
            if (len(current_path) == 0) then
                current_path = component
            else
                current_path = current_path//"/"//component
            end if
            existing = group_by_path(this%groups, current_path)
            if (existing == 0) then
                group%path = current_path
                group%name = component
                group%parent_group = group_id
                if (allocated(group%attributes)) deallocate(group%attributes)
                allocate(group%attributes(0))
                call append_group(this%groups, group)
                group_id = size(this%groups)
            else
                group_id = existing
            end if
            if (len(remaining) == 0) exit
        end do
    end subroutine ensure_group_path

    subroutine append_group(groups, group)
        type(hdf5_output_group_t), allocatable, intent(inout) :: groups(:)
        type(hdf5_output_group_t), intent(in) :: group
        type(hdf5_output_group_t), allocatable :: temporary(:)
        integer :: count

        count = size(groups)
        allocate(temporary(count + 1))
        temporary(:count) = groups
        temporary(count + 1) = group
        call move_alloc(temporary, groups)
    end subroutine append_group

    integer function group_by_path(groups, path) result(group_id)
        type(hdf5_output_group_t), intent(in) :: groups(:)
        character(len=*), intent(in) :: path
        integer :: i

        group_id = 0
        do i = 1, size(groups)
            if (groups(i)%path == path) then
                group_id = i
                return
            end if
        end do
    end function group_by_path

    pure subroutine normalize_path(path, normalized)
        character(len=*), intent(in) :: path
        character(len=:), allocatable, intent(out) :: normalized
        integer :: first, last

        normalized = trim(adjustl(path))
        first = 1
        last = len(normalized)
        do while (first <= last)
            if (normalized(first:first) /= "/") exit
            first = first + 1
        end do
        do while (last >= first)
            if (normalized(last:last) /= "/") exit
            last = last - 1
        end do
        if (first > last) then
            normalized = ""
        else
            normalized = normalized(first:last)
        end if
    end subroutine normalize_path

    subroutine hdf5_writer_close(this, status)
        class(hdf5_writer_t), intent(inout) :: this
        type(fortio_status_t), intent(inout) :: status
        integer(int8), allocatable :: metadata(:)
        integer(int64) :: next_address, eof_address, heap_address
        integer :: i, j, heap_count

        call status%clear()
        if (.not. this%opened) return
        if (.not. this%streaming) then
            call prepare_filtered_datasets(this, status)
            if (.not. status%ok()) return
        end if
        heap_count = 0
        do i = 1, size(this%datasets)
            if (.not. this%datasets(i)%is_dimension_scale) cycle
            heap_count = heap_count + 1
            this%datasets(i)%heap_index = heap_count
        end do
        next_address = ROOT_ADDRESS + group_header_size(1, this%groups, this%datasets)
        do i = 2, size(this%groups)
            this%groups(i)%object_address = next_address
            next_address = next_address + group_header_size(i, this%groups, this%datasets)
        end do
        do i = 1, size(this%datasets)
            this%datasets(i)%object_address = next_address
            next_address = next_address + dataset_header_size(this%datasets(i))
        end do
        do i = 1, size(this%datasets)
            if (this%streaming .and. this%datasets(i)%streamed) cycle
            this%datasets(i)%data_address = next_address
            next_address = next_address + dataset_data_size(this%datasets(i))
        end do
        heap_address = next_address
        if (heap_count > 0) then
            next_address = next_address + global_heap_size(heap_count)
            do i = 1, size(this%datasets)
                this%datasets(i)%global_heap_address = heap_address
            end do
        end if
        eof_address = next_address
        if (this%streaming) then
            if (next_address > STREAM_HEADER_RESERVE) then
                call status%set(FORTIO_ENOTSUP, &
                    "HDF5 streaming metadata exceeds reserved header space")
                return
            end if
            eof_address = max(eof_address, this%stream_end)
        end if

        if (this%output%descriptor < 0) then
            if (this%output_initialized) then
                call this%output%reopen(this%path, status)
                if (.not. status%ok()) return
                if (this%streaming) then
                    call this%output%seek(1_int64)
                else
                    call this%output%reset(status)
                end if
            else
                call this%output%open(this%path, status)
            end if
        else if (this%streaming) then
            call this%output%seek(1_int64)
        else
            call this%output%reset(status)
        end if
        if (.not. status%ok()) return
        metadata = make_superblock(eof_address)
        call this%output%write_bytes(metadata, status)
        if (.not. status%ok()) return
        metadata = make_group_header(1, this%groups, this%datasets)
        call this%output%write_bytes(metadata, status)
        if (.not. status%ok()) return
        do i = 2, size(this%groups)
            metadata = make_group_header(i, this%groups, this%datasets)
            call this%output%write_bytes(metadata, status)
            if (.not. status%ok()) return
        end do
        do i = 1, size(this%datasets)
            metadata = make_dataset_header(this%datasets(i), this%datasets)
            call this%output%write_bytes(metadata, status)
            if (.not. status%ok()) return
        end do
        do i = 1, size(this%datasets)
            if (this%streaming .and. this%datasets(i)%streamed) cycle
            if (allocated(this%datasets(i)%filtered_bytes)) then
                call this%output%write_bytes(this%datasets(i)%filtered_bytes, status)
                if (.not. status%ok()) return
                cycle
            end if
            select case (this%datasets(i)%type_code)
            case (TYPE_I8)
                call this%output%write_bytes(this%datasets(i)%values_i8, status)
                if (.not. status%ok()) return
            case (TYPE_I32)
                do j = 1, size(this%datasets(i)%values_i32)
                    call this%output%write_le_i32(this%datasets(i)%values_i32(j), status)
                    if (.not. status%ok()) return
                end do
            case (TYPE_I64)
                do j = 1, size(this%datasets(i)%values_i64)
                    call this%output%write_le_i64(this%datasets(i)%values_i64(j), status)
                    if (.not. status%ok()) return
                end do
            case (TYPE_R64)
                call this%output%write_le_r64_array(this%datasets(i)%values_r64, status)
                if (.not. status%ok()) return
            case (TYPE_R32)
                do j = 1, size(this%datasets(i)%values_r32)
                    call this%output%write_le_r32(this%datasets(i)%values_r32(j), status)
                    if (.not. status%ok()) return
                end do
            case (TYPE_TEXT)
                do j = 1, len(this%datasets(i)%value_text)
                    call this%output%write_i8( &
                        int(iachar(this%datasets(i)%value_text(j:j)), int8), status)
                    if (.not. status%ok()) return
                end do
            case (TYPE_C64)
                call this%output%write_le_c64_array(this%datasets(i)%values_c64, status)
                if (.not. status%ok()) return
            end select
        end do
        if (heap_count > 0) then
            metadata = make_global_heap(this%datasets, heap_count)
            call this%output%write_bytes(metadata, status)
            if (.not. status%ok()) return
        end if
        this%output_initialized = .true.
        call this%output%close(status)
        if (.not. status%ok()) return
        this%opened = .false.
        this%pending_flush = .false.
    end subroutine hdf5_writer_close

    subroutine prepare_filtered_datasets(this, status)
        class(hdf5_writer_t), intent(inout) :: this
        type(fortio_status_t), intent(inout) :: status
        integer(int8), allocatable :: raw(:), shuffled(:)
        integer :: i

        call status%clear()
        do i = 1, size(this%datasets)
            if (allocated(this%datasets(i)%filtered_bytes)) &
                deallocate(this%datasets(i)%filtered_bytes)
            if (.not. this%datasets(i)%deflate) cycle
            call encode_dataset_bytes(this%datasets(i), raw)
            if (this%datasets(i)%shuffle) then
                call shuffle_bytes(raw, dataset_element_size(this%datasets(i)), shuffled)
                call deflate_compress(shuffled, this%datasets(i)%deflate_level, &
                    this%datasets(i)%filtered_bytes, status)
            else
                call deflate_compress(raw, this%datasets(i)%deflate_level, &
                    this%datasets(i)%filtered_bytes, status)
            end if
            if (.not. status%ok()) return
        end do
    end subroutine prepare_filtered_datasets

    subroutine encode_dataset_bytes(dataset, bytes)
        type(hdf5_output_dataset_t), intent(in) :: dataset
        integer(int8), allocatable, intent(out) :: bytes(:)
        real(real64), allocatable :: complex_components(:)
        integer :: i

        select case (dataset%type_code)
        case (TYPE_I8)
            bytes = dataset%values_i8
        case (TYPE_I32)
            bytes = transfer(dataset%values_i32, 0_int8, &
                size=4*size(dataset%values_i32))
            call convert_native_to_little_endian(bytes, 4)
        case (TYPE_I64)
            bytes = transfer(dataset%values_i64, 0_int8, &
                size=8*size(dataset%values_i64))
            call convert_native_to_little_endian(bytes, 8)
        case (TYPE_R64)
            bytes = transfer(dataset%values_r64, 0_int8, &
                size=8*size(dataset%values_r64))
            call convert_native_to_little_endian(bytes, 8)
        case (TYPE_R32)
            bytes = transfer(dataset%values_r32, 0_int8, &
                size=4*size(dataset%values_r32))
            call convert_native_to_little_endian(bytes, 4)
        case (TYPE_TEXT)
            allocate(bytes(0))
            call append_text(bytes, dataset%value_text)
        case (TYPE_C64)
            allocate(complex_components(2*size(dataset%values_c64)))
            do i = 1, size(dataset%values_c64)
                complex_components(2*i - 1) = real(dataset%values_c64(i), real64)
                complex_components(2*i) = aimag(dataset%values_c64(i))
            end do
            bytes = transfer(complex_components, 0_int8, &
                size=8*size(complex_components))
            call convert_native_to_little_endian(bytes, 8)
        end select
    end subroutine encode_dataset_bytes

    subroutine convert_native_to_little_endian(bytes, element_size)
        integer(int8), intent(inout) :: bytes(:)
        integer, intent(in) :: element_size
        integer(int8) :: native_one(4), temporary
        integer :: element, first, left, right

        native_one = transfer(1_int32, native_one)
        if (native_one(1) == 1_int8) return
        do element = 1, size(bytes)/element_size
            first = (element - 1)*element_size
            do left = 1, element_size/2
                right = element_size - left + 1
                temporary = bytes(first + left)
                bytes(first + left) = bytes(first + right)
                bytes(first + right) = temporary
            end do
        end do
    end subroutine convert_native_to_little_endian

    integer function dataset_element_size(dataset) result(width)
        type(hdf5_output_dataset_t), intent(in) :: dataset

        select case (dataset%type_code)
        case (TYPE_I32, TYPE_R32)
            width = 4
        case (TYPE_I64, TYPE_R64)
            width = 8
        case (TYPE_C64)
            width = 16
        case (TYPE_I8, TYPE_TEXT)
            width = 1
        end select
    end function dataset_element_size

    integer(int64) function group_header_size(group_id, groups, datasets) result(total)
        integer, intent(in) :: group_id
        type(hdf5_output_group_t), intent(in) :: groups(:)
        type(hdf5_output_dataset_t), intent(in) :: datasets(:)
        integer(int64) :: chunk_size
        integer :: i, width

        chunk_size = 28_int64
        do i = 2, size(groups)
            if (groups(i)%parent_group == group_id) &
                chunk_size = chunk_size + 15 + len(groups(i)%name)
        end do
        do i = 1, size(datasets)
            if (datasets(i)%parent_group == group_id) &
                chunk_size = chunk_size + 15 + len(datasets(i)%name)
        end do
        do i = 1, size(groups(group_id)%attributes)
            chunk_size = chunk_size + 4 + &
                attribute_payload_size(groups(group_id)%attributes(i))
        end do
        width = merge(1, 2, chunk_size <= 255)
        total = 6 + width + chunk_size + 4
    end function group_header_size

    integer(int64) function dataset_header_size(dataset) result(total)
        type(hdf5_output_dataset_t), intent(in) :: dataset
        integer(int64) :: chunk_size
        integer :: width

        chunk_size = dataset_chunk_size(dataset)
        width = merge(1, 2, chunk_size <= 255)
        total = 6 + width + chunk_size + 4
    end function dataset_header_size

    integer(int64) function dataset_chunk_size(dataset) result(total)
        type(hdf5_output_dataset_t), intent(in) :: dataset
        integer :: datatype_size, i

        select case (dataset%type_code)
        case (TYPE_I8)
            datatype_size = 12
        case (TYPE_I32, TYPE_I64)
            datatype_size = 12
        case (TYPE_R32, TYPE_R64)
            datatype_size = 20
        case (TYPE_TEXT)
            datatype_size = 8
        case (TYPE_C64)
            datatype_size = 128
        end select
        total = 4 + (4 + 8*size(dataset%dimensions)) + 4 + datatype_size + &
            4 + layout_payload_size(dataset)
        if (dataset%deflate) total = total + 4 + filter_payload_size(dataset)
        do i = 1, size(dataset%attributes)
            total = total + 4 + attribute_payload_size(dataset%attributes(i))
        end do
        if (allocated(dataset%dimension_scales)) then
            total = total + 4 + dimension_list_payload_size( &
                size(dataset%dimension_scales))
        end if
    end function dataset_chunk_size

    integer function dimension_list_payload_size(rank) result(total)
        integer, intent(in) :: rank

        total = 60 + 16*rank
    end function dimension_list_payload_size

    integer(int64) function global_heap_size(scale_count) result(total)
        integer, intent(in) :: scale_count

        total = 4096_int64 + 0_int64*scale_count
    end function global_heap_size

    integer function layout_payload_size(dataset) result(total)
        type(hdf5_output_dataset_t), intent(in) :: dataset

        if (dataset%deflate) then
            total = 26 + dimension_encoding_width(dataset)* &
                (size(dataset%dimensions) + 1)
        else
            total = 18
        end if
    end function layout_payload_size

    integer function filter_payload_size(dataset) result(total)
        type(hdf5_output_dataset_t), intent(in) :: dataset

        total = 12
        if (dataset%shuffle) total = total + 10
    end function filter_payload_size

    integer function dimension_encoding_width(dataset) result(width)
        type(hdf5_output_dataset_t), intent(in) :: dataset
        integer(int64) :: largest

        largest = int(dataset_element_size(dataset), int64)
        if (size(dataset%dimensions) > 0) largest = max(largest, maxval(dataset%dimensions))
        width = 1
        do while (width < 8)
            if (largest < ishft(1_int64, 8*width)) exit
            width = width + 1
        end do
    end function dimension_encoding_width

    integer(int64) function attribute_payload_size(attribute) result(total)
        type(hdf5_output_attribute_t), intent(in) :: attribute
        integer :: datatype_size, dataspace_size, data_size

        select case (attribute%type_code)
        case (TYPE_TEXT)
            datatype_size = 8
            dataspace_size = 4
            data_size = max(1, len_trim(attribute%value_text))
        case (TYPE_I32)
            datatype_size = 12
            dataspace_size = 12
            data_size = 4*size(attribute%values_i32)
        case (TYPE_R64)
            datatype_size = 20
            dataspace_size = 4
            data_size = 8
        case default
            datatype_size = 0
            dataspace_size = 0
            data_size = 0
        end select
        total = 9 + len(attribute%name) + 1 + datatype_size + dataspace_size + data_size
    end function attribute_payload_size

    integer(int64) function dataset_data_size(dataset) result(total)
        type(hdf5_output_dataset_t), intent(in) :: dataset

        if (dataset%streamed) then
            if (dataset%type_code == TYPE_TEXT) then
                total = len(dataset%value_text, kind=int64)
            else
                total = int(dataset_element_size(dataset), int64) * &
                    product(dataset%dimensions)
            end if
        else if (allocated(dataset%filtered_bytes)) then
            total = size(dataset%filtered_bytes, kind=int64)
        else if (dataset%type_code == TYPE_I8) then
            total = size(dataset%values_i8, kind=int64)
        else if (dataset%type_code == TYPE_I32) then
            total = 4_int64*size(dataset%values_i32, kind=int64)
        else if (dataset%type_code == TYPE_I64) then
            total = 8_int64*size(dataset%values_i64, kind=int64)
        else if (dataset%type_code == TYPE_R64) then
            total = 8_int64*size(dataset%values_r64, kind=int64)
        else if (dataset%type_code == TYPE_R32) then
            total = 4_int64*size(dataset%values_r32, kind=int64)
        else if (dataset%type_code == TYPE_C64) then
            total = 16_int64*size(dataset%values_c64, kind=int64)
        else
            total = len(dataset%value_text)
        end if
    end function dataset_data_size

    function make_superblock(eof_address) result(bytes)
        integer(int64), intent(in) :: eof_address
        integer(int8), allocatable :: bytes(:)

        allocate(bytes(0))
        call append_values(bytes, [int(z'89', int8), int(z'48', int8), int(z'44', int8), &
            int(z'46', int8), int(z'0d', int8), int(z'0a', int8), int(z'1a', int8), &
            int(z'0a', int8)])
        call append_u8(bytes, 3)
        call append_u8(bytes, 8)
        call append_u8(bytes, 8)
        call append_u8(bytes, 0)
        call append_le64(bytes, 0_int64)
        call append_le64(bytes, -1_int64)
        call append_le64(bytes, eof_address)
        call append_le64(bytes, ROOT_ADDRESS)
        call append_checksum(bytes)
    end function make_superblock

    function make_global_heap(datasets, scale_count) result(bytes)
        type(hdf5_output_dataset_t), intent(in) :: datasets(:)
        integer, intent(in) :: scale_count
        integer(int8), allocatable :: bytes(:)
        integer :: i
        integer(int64) :: free_size

        allocate(bytes(0))
        call append_text(bytes, "GCOL")
        call append_u8(bytes, 1)
        call append_values(bytes, [0_int8, 0_int8, 0_int8])
        call append_le64(bytes, global_heap_size(scale_count))
        do i = 1, size(datasets)
            if (.not. datasets(i)%is_dimension_scale) cycle
            call append_le16(bytes, datasets(i)%heap_index)
            call append_le16(bytes, 0)
            call append_le32(bytes, 0_int32)
            call append_le64(bytes, 8_int64)
            call append_le64(bytes, datasets(i)%object_address)
        end do
        free_size = global_heap_size(scale_count) - size(bytes, kind=int64)
        call append_le16(bytes, 0)
        call append_le16(bytes, 0)
        call append_le32(bytes, 0_int32)
        call append_le64(bytes, free_size)
        do while (size(bytes, kind=int64) < global_heap_size(scale_count))
            call append_u8(bytes, 0)
        end do
    end function make_global_heap

    function make_group_header(group_id, groups, datasets) result(bytes)
        integer, intent(in) :: group_id
        type(hdf5_output_group_t), intent(in) :: groups(:)
        type(hdf5_output_dataset_t), intent(in) :: datasets(:)
        integer(int8), allocatable :: bytes(:), chunk(:), payload(:)
        integer(int64) :: chunk_size
        integer :: i, width, flags

        allocate(chunk(0))
        allocate(payload(0))
        call append_u8(payload, 0)
        call append_u8(payload, 0)
        call append_le64(payload, -1_int64)
        call append_le64(payload, -1_int64)
        call append_message(chunk, 2, 0, payload)
        deallocate(payload)
        allocate(payload(0))
        call append_u8(payload, 0)
        call append_u8(payload, 0)
        call append_message(chunk, 10, 1, payload)
        do i = 2, size(groups)
            if (groups(i)%parent_group /= group_id) cycle
            deallocate(payload)
            allocate(payload(0))
            call append_u8(payload, 1)
            call append_u8(payload, 0)
            call append_u8(payload, len(groups(i)%name))
            call append_text(payload, groups(i)%name)
            call append_le64(payload, groups(i)%object_address)
            call append_message(chunk, 6, 0, payload)
        end do
        do i = 1, size(datasets)
            if (datasets(i)%parent_group /= group_id) cycle
            deallocate(payload)
            allocate(payload(0))
            call append_u8(payload, 1)
            call append_u8(payload, 0)
            call append_u8(payload, len(datasets(i)%name))
            call append_text(payload, datasets(i)%name)
            call append_le64(payload, datasets(i)%object_address)
            call append_message(chunk, 6, 0, payload)
        end do
        do i = 1, size(groups(group_id)%attributes)
            payload = make_attribute_payload(groups(group_id)%attributes(i))
            call append_message(chunk, 12, 0, payload)
        end do
        chunk_size = size(chunk, kind=int64)
        width = merge(1, 2, chunk_size <= 255)
        flags = merge(0, 1, width == 1)
        allocate(bytes(0))
        call append_text(bytes, "OHDR")
        call append_u8(bytes, 2)
        call append_u8(bytes, flags)
        call append_unsigned(bytes, chunk_size, width)
        call append_values(bytes, chunk)
        call append_checksum(bytes)
    end function make_group_header

    function make_dataset_header(dataset, datasets) result(bytes)
        type(hdf5_output_dataset_t), intent(in) :: dataset
        type(hdf5_output_dataset_t), intent(in) :: datasets(:)
        integer(int8), allocatable :: bytes(:), chunk(:), payload(:)
        integer(int64) :: chunk_size
        integer :: i, width, flags

        allocate(chunk(0), payload(0))
        call append_u8(payload, 2)
        call append_u8(payload, size(dataset%dimensions))
        call append_u8(payload, 0)
        call append_u8(payload, merge(0, 1, size(dataset%dimensions) == 0))
        do i = size(dataset%dimensions), 1, -1
            call append_le64(payload, dataset%dimensions(i))
        end do
        call append_message(chunk, 1, 0, payload)
        deallocate(payload)
        allocate(payload(0))
        if (dataset%type_code == TYPE_I8) then
            call append_values(payload, [int(z'10', int8), int(z'08', int8), 0_int8, &
                0_int8, 1_int8, 0_int8, 0_int8, 0_int8, 0_int8, 0_int8, &
                8_int8, 0_int8])
        else if (dataset%type_code == TYPE_I32) then
            call append_values(payload, [int(z'10', int8), int(z'08', int8), 0_int8, &
                0_int8, 4_int8, 0_int8, 0_int8, 0_int8, 0_int8, 0_int8, &
                int(z'20', int8), 0_int8])
        else if (dataset%type_code == TYPE_I64) then
            call append_values(payload, [int(z'10', int8), int(z'08', int8), 0_int8, &
                0_int8, 8_int8, 0_int8, 0_int8, 0_int8, 0_int8, 0_int8, &
                int(z'40', int8), 0_int8])
        else if (dataset%type_code == TYPE_R64) then
            call append_values(payload, [int(z'11', int8), int(z'20', int8), &
                int(z'3f', int8), 0_int8, 8_int8, 0_int8, 0_int8, 0_int8, &
                0_int8, 0_int8, int(z'40', int8), 0_int8, int(z'34', int8), &
                int(z'0b', int8), 0_int8, int(z'34', int8), -1_int8, 3_int8, &
                0_int8, 0_int8])
        else if (dataset%type_code == TYPE_R32) then
            call append_values(payload, [int(z'11', int8), int(z'20', int8), &
                int(z'1f', int8), 0_int8, 4_int8, 0_int8, 0_int8, 0_int8, &
                0_int8, 0_int8, int(z'20', int8), 0_int8, int(z'17', int8), &
                8_int8, 0_int8, int(z'17', int8), int(z'7f', int8), 0_int8, &
                0_int8, 0_int8])
        else if (dataset%type_code == TYPE_TEXT) then
            call append_values(payload, [int(z'13', int8), 0_int8, 0_int8, 0_int8])
            call append_le32(payload, int(merge(1, len(dataset%value_text), &
                dataset%char_array), int32))
        else
            call append_values(payload, [int(z'16', int8), 2_int8, 0_int8, 0_int8])
            call append_le32(payload, 16_int32)
            call append_text(payload, "real")
            call append_values(payload, [0_int8, 0_int8, 0_int8, 0_int8])
            call append_le32(payload, 0_int32)
            call append_values(payload, [(0_int8, i=1, 28)])
            call append_values(payload, [int(z'11', int8), int(z'20', int8), &
                int(z'3f', int8), 0_int8, 8_int8, 0_int8, 0_int8, 0_int8, &
                0_int8, 0_int8, int(z'40', int8), 0_int8, int(z'34', int8), &
                int(z'0b', int8), 0_int8, int(z'34', int8), -1_int8, 3_int8, &
                0_int8, 0_int8])
            call append_text(payload, "imag")
            call append_values(payload, [0_int8, 0_int8, 0_int8, 0_int8])
            call append_le32(payload, 8_int32)
            call append_values(payload, [(0_int8, i=1, 28)])
            call append_values(payload, [int(z'11', int8), int(z'20', int8), &
                int(z'3f', int8), 0_int8, 8_int8, 0_int8, 0_int8, 0_int8, &
                0_int8, 0_int8, int(z'40', int8), 0_int8, int(z'34', int8), &
                int(z'0b', int8), 0_int8, int(z'34', int8), -1_int8, 3_int8, &
                0_int8, 0_int8])
        end if
        call append_message(chunk, 3, 1, payload)
        deallocate(payload)
        allocate(payload(0))
        if (dataset%deflate) then
            call append_u8(payload, 2)
            call append_u8(payload, merge(2, 1, dataset%shuffle))
            if (dataset%shuffle) then
                call append_le16(payload, 2)
                call append_le16(payload, 0)
                call append_le16(payload, 1)
                call append_le32(payload, int(dataset_element_size(dataset), int32))
            end if
            call append_le16(payload, 1)
            call append_le16(payload, 0)
            call append_le16(payload, 1)
            call append_le32(payload, int(dataset%deflate_level, int32))
            call append_message(chunk, 11, 1, payload)
            deallocate(payload)
            allocate(payload(0))
            call append_u8(payload, 4)
            call append_u8(payload, 2)
            call append_u8(payload, 2)
            call append_u8(payload, size(dataset%dimensions) + 1)
            width = dimension_encoding_width(dataset)
            call append_u8(payload, width)
            do i = size(dataset%dimensions), 1, -1
                call append_unsigned(payload, dataset%dimensions(i), width)
            end do
            call append_unsigned(payload, int(dataset_element_size(dataset), int64), width)
            call append_u8(payload, 1)
            call append_le64(payload, dataset_data_size(dataset))
            call append_le32(payload, 0_int32)
            call append_le64(payload, dataset%data_address)
        else
            call append_u8(payload, 3)
            call append_u8(payload, 1)
            call append_le64(payload, dataset%data_address)
            call append_le64(payload, dataset_data_size(dataset))
        end if
        call append_message(chunk, 8, 0, payload)
        do i = 1, size(dataset%attributes)
            payload = make_attribute_payload(dataset%attributes(i))
            call append_message(chunk, 12, 0, payload)
        end do
        if (allocated(dataset%dimension_scales)) then
            payload = make_dimension_list_payload(dataset, datasets)
            call append_message(chunk, 12, 0, payload)
        end if
        chunk_size = size(chunk, kind=int64)
        width = merge(1, 2, chunk_size <= 255)
        flags = merge(0, 1, width == 1)
        allocate(bytes(0))
        call append_text(bytes, "OHDR")
        call append_u8(bytes, 2)
        call append_u8(bytes, flags)
        call append_unsigned(bytes, chunk_size, width)
        call append_values(bytes, chunk)
        call append_checksum(bytes)
    end function make_dataset_header

    function make_attribute_payload(attribute) result(payload)
        type(hdf5_output_attribute_t), intent(in) :: attribute
        integer(int8), allocatable :: payload(:)
        integer :: i, text_size

        allocate(payload(0))
        call append_u8(payload, 3)
        call append_u8(payload, 0)
        call append_le16(payload, len(attribute%name) + 1)
        select case (attribute%type_code)
        case (TYPE_TEXT)
            call append_le16(payload, 8)
            call append_le16(payload, 4)
        case (TYPE_I32)
            call append_le16(payload, 12)
            call append_le16(payload, 12)
        case (TYPE_R64)
            call append_le16(payload, 20)
            call append_le16(payload, 4)
        end select
        call append_u8(payload, 0)
        call append_text(payload, attribute%name)
        call append_u8(payload, 0)
        select case (attribute%type_code)
        case (TYPE_TEXT)
            text_size = max(1, len_trim(attribute%value_text))
            call append_values(payload, [int(z'13', int8), &
                merge(0_int8, 1_int8, attribute%null_terminated), 0_int8, 0_int8])
            call append_le32(payload, int(text_size, int32))
        case (TYPE_I32)
            call append_values(payload, [int(z'10', int8), int(z'08', int8), 0_int8, &
                0_int8, 4_int8, 0_int8, 0_int8, 0_int8, 0_int8, 0_int8, &
                int(z'20', int8), 0_int8])
        case (TYPE_R64)
            call append_values(payload, [int(z'11', int8), int(z'20', int8), &
                int(z'3f', int8), 0_int8, 8_int8, 0_int8, 0_int8, 0_int8, &
                0_int8, 0_int8, int(z'40', int8), 0_int8, int(z'34', int8), &
                int(z'0b', int8), 0_int8, int(z'34', int8), -1_int8, 3_int8, &
                0_int8, 0_int8])
        end select
        if (attribute%type_code == TYPE_I32) then
            call append_values(payload, [2_int8, 1_int8, 0_int8, 1_int8])
            call append_le64(payload, int(size(attribute%values_i32), int64))
        else
            call append_values(payload, [2_int8, 0_int8, 0_int8, 0_int8])
        end if
        select case (attribute%type_code)
        case (TYPE_TEXT)
            if (len_trim(attribute%value_text) == 0) then
                call append_u8(payload, 0)
            else
                call append_text(payload, attribute%value_text(:len_trim(attribute%value_text)))
            end if
        case (TYPE_I32)
            do i = 1, size(attribute%values_i32)
                call append_le32(payload, attribute%values_i32(i))
            end do
        case (TYPE_R64)
            call append_le_r64(payload, attribute%values_r64(1))
        end select
    end function make_attribute_payload

    function make_dimension_list_payload(dataset, datasets) result(payload)
        type(hdf5_output_dataset_t), intent(in) :: dataset
        type(hdf5_output_dataset_t), intent(in) :: datasets(:)
        integer(int8), allocatable :: payload(:)
        integer :: i, scale_id

        allocate(payload(0))
        call append_u8(payload, 3)
        call append_u8(payload, 0)
        call append_le16(payload, 15)
        call append_le16(payload, 16)
        call append_le16(payload, 20)
        call append_u8(payload, 0)
        call append_text(payload, "DIMENSION_LIST")
        call append_u8(payload, 0)
        call append_values(payload, [int(z'19', int8), 0_int8, 0_int8, 0_int8])
        call append_le32(payload, 16_int32)
        call append_values(payload, [int(z'17', int8), 0_int8, 0_int8, 0_int8])
        call append_le32(payload, 8_int32)
        call append_values(payload, [2_int8, 1_int8, 1_int8, 1_int8])
        call append_le64(payload, int(size(dataset%dimension_scales), int64))
        call append_le64(payload, int(size(dataset%dimension_scales), int64))
        do i = size(dataset%dimension_scales), 1, -1
            scale_id = dataset%dimension_scales(i)
            call append_le32(payload, 1_int32)
            call append_le64(payload, dataset%global_heap_address)
            call append_le32(payload, int(datasets(scale_id)%heap_index, int32))
        end do
    end function make_dimension_list_payload

    subroutine append_message(bytes, message_type, flags, payload)
        integer(int8), allocatable, intent(inout) :: bytes(:)
        integer, intent(in) :: message_type, flags
        integer(int8), intent(in) :: payload(:)

        call append_u8(bytes, message_type)
        call append_le16(bytes, size(payload))
        call append_u8(bytes, flags)
        call append_values(bytes, payload)
    end subroutine append_message

    subroutine append_checksum(bytes)
        integer(int8), allocatable, intent(inout) :: bytes(:)

        call append_le32(bytes, lookup3_checksum(bytes))
    end subroutine append_checksum

    subroutine append_text(bytes, text)
        integer(int8), allocatable, intent(inout) :: bytes(:)
        character(len=*), intent(in) :: text
        integer(int8), allocatable :: values(:)
        integer :: i

        allocate(values(len(text)))
        do i = 1, len(text)
            values(i) = int(iachar(text(i:i)), int8)
        end do
        call append_values(bytes, values)
    end subroutine append_text

    subroutine append_u8(bytes, value)
        integer(int8), allocatable, intent(inout) :: bytes(:)
        integer, intent(in) :: value

        call append_values(bytes, [int(value, int8)])
    end subroutine append_u8

    subroutine append_le16(bytes, value)
        integer(int8), allocatable, intent(inout) :: bytes(:)
        integer, intent(in) :: value

        call append_values(bytes, [int(iand(value, 255), int8), &
            int(iand(shiftr(value, 8), 255), int8)])
    end subroutine append_le16

    subroutine append_le32(bytes, value)
        integer(int8), allocatable, intent(inout) :: bytes(:)
        integer(int32), intent(in) :: value
        integer(int8) :: values(4)
        integer :: i

        do i = 1, 4
            values(i) = int(iand(shiftr(value, 8*(i - 1)), int(z'ff', int32)), int8)
        end do
        call append_values(bytes, values)
    end subroutine append_le32

    subroutine append_le64(bytes, value)
        integer(int8), allocatable, intent(inout) :: bytes(:)
        integer(int64), intent(in) :: value
        integer(int8) :: values(8)
        integer :: i

        do i = 1, 8
            values(i) = int(iand(shiftr(value, 8*(i - 1)), int(z'ff', int64)), int8)
        end do
        call append_values(bytes, values)
    end subroutine append_le64

    subroutine append_le_r64(bytes, value)
        integer(int8), allocatable, intent(inout) :: bytes(:)
        real(real64), intent(in) :: value

        call append_le64(bytes, transfer(value, 0_int64))
    end subroutine append_le_r64

    subroutine append_unsigned(bytes, value, width)
        integer(int8), allocatable, intent(inout) :: bytes(:)
        integer(int64), intent(in) :: value
        integer, intent(in) :: width
        integer :: i

        do i = 1, width
            call append_u8(bytes, int(iand(shiftr(value, 8*(i - 1)), 255_int64)))
        end do
    end subroutine append_unsigned

    subroutine append_values(bytes, values)
        integer(int8), allocatable, intent(inout) :: bytes(:)
        integer(int8), intent(in) :: values(:)
        integer(int8), allocatable :: temporary(:)
        integer :: count

        count = size(bytes)
        allocate(temporary(count + size(values)))
        if (count > 0) temporary(:count) = bytes
        if (size(values) > 0) temporary(count + 1:) = values
        call move_alloc(temporary, bytes)
    end subroutine append_values

end module fortio_hdf5_writer
