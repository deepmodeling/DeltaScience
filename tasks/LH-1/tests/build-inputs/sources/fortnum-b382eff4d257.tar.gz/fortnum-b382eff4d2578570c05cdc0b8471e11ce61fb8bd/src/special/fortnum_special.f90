module fortnum_special
    ! Public umbrella module re-exporting special functions.
    !
    ! This module aggregates the public APIs of the special function families:
    ! - Modified Bessel functions (fortnum_special_bessel)
    ! - Dawson integral (fortnum_special_dawson)
    ! - Lower incomplete gamma function (fortnum_special_gamma)
    ! - Confluent hypergeometric 1F1 (fortnum_special_hypergeometric_1f1)
    !
    ! Re-export layout preserves each module's derivative policy for future
    ! derivative product entry points (issue #40). Each routine documents its
    ! derivative policy in the originating module; this umbrella merely
    ! re-exports without modification.

    use fortnum_special_bessel, only: &
        bessel_in, &
        bessel_in_array, &
        bessel_kn, &
        bessel_in_jvp, &
        bessel_kn_jvp
    use fortnum_special_dawson, only: &
        dawson, &
        dawson_jvp, &
        dawson_grad
    use fortnum_special_gamma, only: &
        gamma_lower, &
        gamma_reg_p, &
        gamma_lower_jvp
    use fortnum_special_hypergeometric_1f1, only: &
        hyperg_1f1, &
        hyperg_1f1_a1, &
        hyperg_1f1_a1_jvp, &
        hyperg_1f1_a1_vjp
    use fortnum_special_jacobi, only: &
        jacobi_p, &
        jacobi_p_derivative, &
        scaled_jacobi_p, &
        scaled_jacobi_p_gradient, &
        tetrahedron_koornwinder, &
        tetrahedron_koornwinder_gradient, &
        triangle_dubiner, &
        triangle_dubiner_gradient
    use fortnum_special_legendre, only: &
        legendre_p, &
        legendre_p_derivative, &
        legendre_q, &
        legendre_q_derivative
    use fortnum_special_spherical, only: &
        spherical_harmonic, &
        spherical_harmonic_theta_derivative, &
        spherical_harmonic_phi_derivative, &
        spherical_harmonic_product_coefficient
    use fortnum_special_toroidal, only: &
        toroidal_p, &
        toroidal_q, &
        toroidal_p_derivative, &
        toroidal_q_derivative

    implicit none
    private

    ! Bessel functions: modified I_n and K_n (integer order)
    ! Derivative policy: analytic_rule (ad.md §1, §4).
    ! Active argument: x only (n is inactive order selector).
    public :: bessel_in, bessel_in_array, bessel_kn
    public :: bessel_in_jvp, bessel_kn_jvp

    ! Dawson integral F(x) = exp(-x^2) * integral_0^x exp(t^2) dt
    ! Derivative policy: analytic_rule; F'(x) = 1 - 2*x*F(x).
    ! Active argument: x.
    public :: dawson
    public :: dawson_jvp, dawson_grad

    ! Incomplete gamma functions
    ! Derivative policy: analytic_rule.
    ! Active arguments: a (shape), x (integration limit).
    ! gamma_lower(a,x) = P(a,x)*Gamma(a), unnormalized lower incomplete.
    ! gamma_reg_p(a,x) = gamma_lower(a,x)/Gamma(a), regularized form.
    public :: gamma_lower, gamma_reg_p
    ! d/dx only; d/da deferred (requires digamma, see gamma_lower module header).
    public :: gamma_lower_jvp

    ! Confluent hypergeometric 1F1(a;b;z) (Kummer M), complex a, b, z.
    ! Derivative policy: analytic_rule; d/dz M = (a/b) M(a+1,b+1,z).
    ! Active argument: z.  Inactive: a, b.  hyperg_1f1_a1 fixes a = 1.
    public :: hyperg_1f1, hyperg_1f1_a1
    public :: hyperg_1f1_a1_jvp, hyperg_1f1_a1_vjp

    ! Classical Jacobi polynomials for alpha,beta > -1.
    public :: jacobi_p, jacobi_p_derivative, scaled_jacobi_p
    public :: scaled_jacobi_p_gradient
    public :: tetrahedron_koornwinder, triangle_dubiner
    public :: tetrahedron_koornwinder_gradient, triangle_dubiner_gradient

    ! Ferrers associated Legendre P_l^m(x), including Condon-Shortley phase.
    ! Derivative policy: analytic_rule. Active argument: x.
    public :: legendre_p, legendre_p_derivative

    ! Real ordinary Legendre Q_l(x) on the x > 1 branch.
    ! Derivative policy: analytic_rule. Active argument: x.
    public :: legendre_q, legendre_q_derivative

    ! Standard orthonormal complex spherical harmonics on 0 <= theta <= pi.
    ! Angular derivatives are analytical products away from the poles.
    public :: spherical_harmonic
    public :: spherical_harmonic_theta_derivative
    public :: spherical_harmonic_phi_derivative
    public :: spherical_harmonic_product_coefficient

    ! Hobson-normalized half-integer Legendre functions for toroidal harmonics.
    public :: toroidal_p, toroidal_q
    public :: toroidal_p_derivative, toroidal_q_derivative

end module fortnum_special
