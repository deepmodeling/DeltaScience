program test_fortnum_linalg
    ! Behavioral tests for fortnum_linalg: closed-form 2x2/3x3 determinant and
    ! inverse round-trips A*inv(A) = I, the near-singular jacobian_ok3 predicate
    ! (true / false / NaN), the in-place partial-pivot LU solve against known
    ! systems at several sizes including a pivot-required case, an inv3 cross
    ! check, and the singular-status contract for inv2/inv3/lu_solve.
    use, intrinsic :: iso_fortran_env, only: dp => real64, error_unit
    use fortnum_linalg, only: dense_solve, det2, det3, det2_jvp, det3_jvp, &
        inv2, inv3, &
        jacobian_ok3, lu_factor, lu_solve, linear_solve_jvp, &
        linear_solve_jvp_factored, linear_solve_vjp, &
        linear_solve_vjp_factored, lu_factorization_t, LINALG_OK, &
        LINALG_SINGULAR, LINALG_MAX_N
    implicit none

    integer :: nfail
    nfail = 0

    call test_det(nfail)
    call test_det_jvp(nfail)
    call test_inv2_roundtrip(nfail)
    call test_inv3_roundtrip(nfail)
    call test_jacobian_ok3(nfail)
    call test_lu_known(nfail)
    call test_lu_pivot(nfail)
    call test_lu_vs_inv3(nfail)
    call test_lu_object(nfail)
    call test_singular(nfail)
    call test_linear_solve_products(nfail)
    call test_host_dense_solve(nfail)

    if (nfail > 0) then
        write (error_unit, "(i0,a)") nfail, " test(s) failed"
        stop 1
    end if
    write (*, "(a)") "PASS"
    stop 0

contains

    subroutine test_host_dense_solve(nfail)
        integer, intent(inout) :: nfail

        integer, parameter :: n = LINALG_MAX_N + 3
        complex(dp) :: complex_a(n, n), complex_b(n), complex_x(n)
        complex(dp) :: complex_exact(n)
        complex(dp) :: complex_many_b(n, 2), complex_many_exact(n, 2)
        complex(dp) :: complex_many_x(n, 2)
        real(dp) :: real_a(n, n), real_b(n), real_exact(n), real_x(n)
        real(dp) :: real_many_b(n, 2), real_many_exact(n, 2)
        real(dp) :: real_many_x(n, 2)
        integer :: column, info, row

        real_a = 0.0_dp
        complex_a = cmplx(0.0_dp, 0.0_dp, dp)
        do column = 1, n
            real_exact(column) = real(column, dp)/real(n, dp) - 0.5_dp
            complex_exact(column) = cmplx( &
                real_exact(column), (-1.0_dp)**column/real(column, dp), dp)
            do row = 1, n
                real_a(row, column) = 1.0_dp/real(row + column, dp)
                complex_a(row, column) = cmplx( &
                    real_a(row, column), &
                    0.03_dp*real(row - column, dp), dp)
            end do
            real_a(column, column) = real_a(column, column) + 2.0_dp
            complex_a(column, column) = complex_a(column, column) + 2.0_dp
        end do
        real_b = matmul(real_a, real_exact)
        complex_b = matmul(complex_a, complex_exact)

        call dense_solve(real_a, real_b, real_x, info)
        call check_int("host_dense_real_status", info, LINALG_OK, nfail)
        call check("host_dense_real_solution", &
            maxval(abs(real_x - real_exact)), 0.0_dp, 2.0e-14_dp, nfail)
        call dense_solve(complex_a, complex_b, complex_x, info)
        call check_int("host_dense_complex_status", info, LINALG_OK, nfail)
        call check("host_dense_complex_solution", &
            maxval(abs(complex_x - complex_exact)), 0.0_dp, 3.0e-14_dp, nfail)

        real_many_exact(:, 1) = real_exact
        real_many_exact(:, 2) = 1.0_dp - 0.25_dp*real_exact
        complex_many_exact(:, 1) = complex_exact
        complex_many_exact(:, 2) = cmplx(0.5_dp, -0.25_dp, dp)*complex_exact
        real_many_b = matmul(real_a, real_many_exact)
        complex_many_b = matmul(complex_a, complex_many_exact)
        call dense_solve(real_a, real_many_b, real_many_x, info)
        call check_int("host_dense_real_many_status", info, LINALG_OK, nfail)
        call check("host_dense_real_many_solution", &
            maxval(abs(real_many_x - real_many_exact)), &
            0.0_dp, 2.0e-14_dp, nfail)
        call dense_solve(complex_a, complex_many_b, complex_many_x, info)
        call check_int("host_dense_complex_many_status", info, LINALG_OK, nfail)
        call check("host_dense_complex_many_solution", &
            maxval(abs(complex_many_x - complex_many_exact)), &
            0.0_dp, 3.0e-14_dp, nfail)

        real_a = 0.0_dp
        call dense_solve(real_a, real_b, real_x, info)
        call check_true("host_dense_singular_status", info > LINALG_OK, nfail)
    end subroutine test_host_dense_solve

    subroutine check(label, got, expected, atol, nfail)
        character(*), intent(in) :: label
        real(dp), intent(in) :: got, expected, atol
        integer, intent(inout) :: nfail
        if (abs(got - expected) > atol) then
            nfail = nfail + 1
            write (error_unit, "(a,a,a,es12.4)") "FAIL [", label, "] err=", &
                abs(got - expected)
        end if
    end subroutine check

    subroutine test_lu_object(nfail)
        integer, intent(inout) :: nfail
        type(lu_factorization_t) :: factorization
        real(dp) :: a(3, 3), b1(3), b2(3), x1(3), x2(3)
        integer :: i, info, j

        a = reshape([4.0_dp, 1.0_dp, -1.0_dp, 2.0_dp, 5.0_dp, 1.0_dp, &
            0.5_dp, -2.0_dp, 3.0_dp], [3, 3])
        x1 = [1.0_dp, -2.0_dp, 0.5_dp]
        x2 = [-0.25_dp, 0.75_dp, 2.0_dp]
        b1 = 0.0_dp
        b2 = 0.0_dp
        do j = 1, 3
            do i = 1, 3
                b1(i) = b1(i) + a(i, j)*x1(j)
                b2(i) = b2(i) + a(i, j)*x2(j)
            end do
        end do
        call factorization%factor(a, info)
        if (info /= LINALG_OK) then
            nfail = nfail + 1
            return
        end if
        call factorization%solve(b1, info)
        call check("lu_object_rhs1", maxval(abs(b1 - x1)), 0.0_dp, 2.0e-14_dp, nfail)
        call factorization%solve(b2, info)
        call check("lu_object_rhs2", maxval(abs(b2 - x2)), 0.0_dp, 2.0e-14_dp, nfail)
    end subroutine test_lu_object

    subroutine check_true(label, cond, nfail)
        character(*), intent(in) :: label
        logical, intent(in) :: cond
        integer, intent(inout) :: nfail
        if (.not. cond) then
            nfail = nfail + 1
            write (error_unit, "(a,a,a)") "FAIL [", label, "] expected .true."
        end if
    end subroutine check_true

    subroutine check_int(label, got, expected, nfail)
        character(*), intent(in) :: label
        integer, intent(in) :: got, expected
        integer, intent(inout) :: nfail
        if (got /= expected) then
            nfail = nfail + 1
            write (error_unit, "(a,a,a,i0,a,i0)") "FAIL [", label, "] got=", &
                got, " expected=", expected
        end if
    end subroutine check_int

    subroutine test_det(nfail)
        integer, intent(inout) :: nfail
        real(dp) :: a2(2, 2), a3(3, 3)
        a2 = reshape([2.0_dp, 1.0_dp, 3.0_dp, 4.0_dp], [2, 2]) ! det = 8-3 = 5
        call check("det2", det2(a2), 5.0_dp, 1.0e-13_dp, nfail)
        ! Upper triangular: det = product of diagonal = 2*3*4 = 24.
        a3 = reshape([2.0_dp, 0.0_dp, 0.0_dp, 5.0_dp, 3.0_dp, 0.0_dp, &
            7.0_dp, 9.0_dp, 4.0_dp], [3, 3])
        call check("det3_triangular", det3(a3), 24.0_dp, 1.0e-12_dp, nfail)
    end subroutine test_det

    subroutine test_det_jvp(nfail)
        integer, intent(inout) :: nfail
        real(dp), parameter :: h = 1.0e-5_dp
        real(dp) :: a2(2, 2), v2(2, 2), a3(3, 3), v3(3, 3)
        real(dp) :: jv, fd_h, fd_half
        real(dp) :: plus2(2, 2), minus2(2, 2), plus3(3, 3), minus3(3, 3)

        a2 = reshape([2.0_dp, -0.5_dp, 1.25_dp, 3.0_dp], [2, 2])
        v2 = reshape([0.2_dp, 0.3_dp, -0.4_dp, 0.1_dp], [2, 2])
        call det2_jvp(a2, v2, jv)
        plus2 = a2 + h*v2
        minus2 = a2 - h*v2
        fd_h = (det2(plus2) - det2(minus2))/(2.0_dp*h)
        plus2 = a2 + 0.5_dp*h*v2
        minus2 = a2 - 0.5_dp*h*v2
        fd_half = (det2(plus2) - det2(minus2))/h
        call check("det2_jvp_fd", jv, fd_half, 2.0e-10_dp, nfail)
        call check("det2_jvp_fd_refine", fd_h, fd_half, 2.0e-10_dp, nfail)

        a3 = reshape([2.0_dp, -0.5_dp, 0.3_dp, 1.25_dp, 3.0_dp, -0.8_dp, &
            0.4_dp, 0.7_dp, 1.8_dp], [3, 3])
        v3 = reshape([0.2_dp, 0.3_dp, -0.4_dp, 0.1_dp, -0.2_dp, 0.5_dp, &
            -0.3_dp, 0.6_dp, 0.25_dp], [3, 3])
        call det3_jvp(a3, v3, jv)
        plus3 = a3 + h*v3
        minus3 = a3 - h*v3
        fd_h = (det3(plus3) - det3(minus3))/(2.0_dp*h)
        plus3 = a3 + 0.5_dp*h*v3
        minus3 = a3 - 0.5_dp*h*v3
        fd_half = (det3(plus3) - det3(minus3))/h
        call check("det3_jvp_fd", jv, fd_half, 2.0e-9_dp, nfail)
        call check("det3_jvp_fd_refine", fd_h, fd_half, 2.0e-9_dp, nfail)
    end subroutine test_det_jvp

    subroutine test_inv2_roundtrip(nfail)
        integer, intent(inout) :: nfail
        real(dp) :: a(2, 2), ainv(2, 2), prod(2, 2)
        integer :: info
        a = reshape([4.0_dp, 1.0_dp, 2.0_dp, 3.0_dp], [2, 2])
        call inv2(a, ainv, info)
        call check_int("inv2_ok", info, LINALG_OK, nfail)
        prod = matmul(a, ainv)
        call check("inv2_rt", maxval(abs(prod - eye(2))), 0.0_dp, 1.0e-12_dp, nfail)
    end subroutine test_inv2_roundtrip

    subroutine test_inv3_roundtrip(nfail)
        integer, intent(inout) :: nfail
        real(dp) :: a(3, 3), ainv(3, 3), prod(3, 3)
        integer :: info
        a = reshape([4.0_dp, 1.0_dp, 0.5_dp, 0.2_dp, 3.0_dp, 1.1_dp, &
            0.7_dp, 0.3_dp, 5.0_dp], [3, 3])
        call inv3(a, ainv, info)
        call check_int("inv3_ok", info, LINALG_OK, nfail)
        prod = matmul(a, ainv)
        call check("inv3_rt", maxval(abs(prod - eye(3))), 0.0_dp, 1.0e-12_dp, nfail)
    end subroutine test_inv3_roundtrip

    subroutine test_jacobian_ok3(nfail)
        integer, intent(inout) :: nfail
        real(dp) :: a(3, 3), bad(3, 3), nanm(3, 3)
        real(dp) :: nan
        a = reshape([4.0_dp, 1.0_dp, 0.5_dp, 0.2_dp, 3.0_dp, 1.1_dp, &
            0.7_dp, 0.3_dp, 5.0_dp], [3, 3])
        call check_true("jac_ok_true", jacobian_ok3(a), nfail)
        ! Row scaled by 1e-10 pushes |det| below the 1e-8*scale^3 floor.
        bad = a
        bad(2, :) = a(2, :)*1.0e-10_dp
        call check_true("jac_ok_false",.not. jacobian_ok3(bad), nfail)
        nan = 0.0_dp
        nan = nan/nan
        nanm = a
        nanm(1, 1) = nan
        call check_true("jac_ok_nan",.not. jacobian_ok3(nanm), nfail)
    end subroutine test_jacobian_ok3

    subroutine test_lu_known(nfail)
        integer, intent(inout) :: nfail
        call lu_case(2, nfail)
        call lu_case(3, nfail)
        call lu_case(5, nfail)
        call lu_case(LINALG_MAX_N, nfail)
    end subroutine test_lu_known

    ! Solve A x = b with A = I + small structured perturbation, x_true ramp.
    subroutine lu_case(n, nfail)
        integer, intent(in) :: n
        integer, intent(inout) :: nfail
        real(dp) :: a(n, n), b(n), xtrue(n)
        integer :: i, j, info
        character(len=24) :: lbl
        do i = 1, n
            xtrue(i) = real(i, dp)
            do j = 1, n
                if (i == j) then
                    a(i, j) = 2.0_dp + real(i, dp)
                else
                    a(i, j) = 0.3_dp/real(i + j, dp)
                end if
            end do
        end do
        b = matmul(a, xtrue)
        call lu_solve(n, a, b, info)
        write (lbl, "(a,i0)") "lu_n", n
        call check_int(trim(lbl), info, LINALG_OK, nfail)
        call check(trim(lbl)//"_x", maxval(abs(b - xtrue)), 0.0_dp, 1.0e-10_dp, nfail)
    end subroutine lu_case

    ! A = [[0,1],[1,0]] requires a pivot swap; x_true = [3, 5].
    subroutine test_lu_pivot(nfail)
        integer, intent(inout) :: nfail
        real(dp) :: a(2, 2), b(2), xtrue(2)
        integer :: info
        a = reshape([0.0_dp, 1.0_dp, 1.0_dp, 0.0_dp], [2, 2])
        xtrue = [3.0_dp, 5.0_dp]
        b = matmul(a, xtrue)
        call lu_solve(2, a, b, info)
        call check_int("lu_pivot_ok", info, LINALG_OK, nfail)
        call check("lu_pivot_x", maxval(abs(b - xtrue)), 0.0_dp, 1.0e-12_dp, nfail)
    end subroutine test_lu_pivot

    ! lu_solve(3,A,b) must match matmul(inv3(A), b).
    subroutine test_lu_vs_inv3(nfail)
        integer, intent(inout) :: nfail
        real(dp) :: a(3, 3), acopy(3, 3), ainv(3, 3), b(3), bcopy(3), xinv(3)
        integer :: info
        a = reshape([4.0_dp, 1.0_dp, 0.5_dp, 0.2_dp, 3.0_dp, 1.1_dp, &
            0.7_dp, 0.3_dp, 5.0_dp], [3, 3])
        b = [1.0_dp, -2.0_dp, 0.5_dp]
        acopy = a
        bcopy = b
        call inv3(a, ainv, info)
        xinv = matmul(ainv, b)
        call lu_solve(3, acopy, bcopy, info)
        call check("lu_vs_inv3", maxval(abs(bcopy - xinv)), 0.0_dp, 1.0e-11_dp, nfail)
    end subroutine test_lu_vs_inv3

    subroutine test_singular(nfail)
        integer, intent(inout) :: nfail
        real(dp) :: a2(2, 2), ainv2(2, 2), a3(3, 3), ainv3(3, 3)
        real(dp) :: as(3, 3), bs(3)
        integer :: info
        ! Two identical rows -> rank deficient.
        a2 = reshape([1.0_dp, 1.0_dp, 2.0_dp, 2.0_dp], [2, 2])
        call inv2(a2, ainv2, info)
        call check_int("inv2_sing", info, LINALG_SINGULAR, nfail)
        call check("inv2_sing_zero", maxval(abs(ainv2)), 0.0_dp, 0.0_dp, nfail)
        a3 = reshape([1.0_dp, 2.0_dp, 1.0_dp, 3.0_dp, 6.0_dp, 3.0_dp, &
            0.5_dp, 1.0_dp, 0.5_dp], [3, 3]) ! columns dependent
        call inv3(a3, ainv3, info)
        call check_int("inv3_sing", info, LINALG_SINGULAR, nfail)
        call check("inv3_sing_zero", maxval(abs(ainv3)), 0.0_dp, 0.0_dp, nfail)
        ! lu_solve on a singular A: column 2 = 2*column 1.
        as = reshape([1.0_dp, 0.0_dp, 2.0_dp, 2.0_dp, 0.0_dp, 4.0_dp, &
            0.0_dp, 1.0_dp, 1.0_dp], [3, 3])
        bs = [1.0_dp, 1.0_dp, 1.0_dp]
        call lu_solve(3, as, bs, info)
        call check_true("lu_sing", info > 0, nfail)
    end subroutine test_singular

    subroutine test_linear_solve_products(nfail)
        integer, intent(inout) :: nfail
        real(dp), parameter :: h = 1.0e-6_dp
        real(dp) :: a(3, 3), da(3, 3), b(3), db(3), x(3), dx(3), dx_reused(3)
        real(dp) :: xp(3), xm(3), ap(3, 3), am(3, 3), bp(3), bm(3)
        real(dp) :: u(3), abar(3, 3), bbar(3), lhs, rhs, factors(3, 3)
        real(dp) :: transpose_factors(3, 3)
        integer :: info, ipiv(3), transpose_ipiv(3)

        a = reshape([4.0_dp, 1.0_dp, -1.0_dp, &
            0.5_dp, 3.0_dp, 0.25_dp, &
            -0.2_dp, 0.4_dp, 2.5_dp], [3, 3])
        da = reshape([0.1_dp, -0.2_dp, 0.05_dp, &
            0.3_dp, 0.1_dp, -0.1_dp, &
            0.0_dp, 0.2_dp, -0.05_dp], [3, 3])
        b = [1.0_dp, -2.0_dp, 0.5_dp]
        db = [0.2_dp, 0.1_dp, -0.3_dp]

        ap = a
        x = b
        call lu_solve(3, ap, x, info)
        call linear_solve_jvp(3, a, x, da, db, dx, info)
        factors = a
        call lu_factor(3, factors, ipiv, info)
        call linear_solve_jvp_factored(3, factors, ipiv, x, da, db, dx_reused, info)

        ap = a + h*da
        am = a - h*da
        bp = b + h*db
        bm = b - h*db
        xp = bp
        xm = bm
        call lu_solve(3, ap, xp, info)
        call lu_solve(3, am, xm, info)
        call check("linear_jvp_fd", &
            maxval(abs(dx - (xp - xm)/(2.0_dp*h))), 0.0_dp, 2.0e-9_dp, nfail)
        call check("linear_jvp_reused_fd_1", &
            maxval(abs(dx_reused - (xp - xm)/(2.0_dp*h))), 0.0_dp, 2.0e-9_dp, nfail)

        da = 0.5_dp*da
        db = [-0.1_dp, 0.4_dp, 0.2_dp]
        call linear_solve_jvp_factored(3, factors, ipiv, x, da, db, dx_reused, info)
        ap = a + h*da
        am = a - h*da
        bp = b + h*db
        bm = b - h*db
        xp = bp
        xm = bm
        call lu_solve(3, ap, xp, info)
        call lu_solve(3, am, xm, info)
        call check("linear_jvp_reused_fd_2", &
            maxval(abs(dx_reused - (xp - xm)/(2.0_dp*h))), 0.0_dp, 2.0e-9_dp, nfail)

        u = [0.7_dp, -0.4_dp, 1.2_dp]
        call linear_solve_vjp(3, a, x, u, abar, bbar, info)
        lhs = dot_product(u, dx_reused)
        rhs = sum(abar*da) + dot_product(bbar, db)
        call check("linear_adjoint", lhs, rhs, 2.0e-14_dp, nfail)

        transpose_factors = transpose(a)
        call lu_factor(3, transpose_factors, transpose_ipiv, info)
        call linear_solve_vjp_factored(3, transpose_factors, transpose_ipiv, x, &
            u, abar, bbar, info)
        lhs = dot_product(u, (xp - xm)/(2.0_dp*h))
        rhs = sum(abar*da) + dot_product(bbar, db)
        call check("linear_vjp_reused_fd_1", lhs, rhs, 2.0e-9_dp, nfail)

        u = [-0.3_dp, 0.8_dp, 0.2_dp]
        call linear_solve_vjp_factored(3, transpose_factors, transpose_ipiv, x, &
            u, abar, bbar, info)
        lhs = dot_product(u, (xp - xm)/(2.0_dp*h))
        rhs = sum(abar*da) + dot_product(bbar, db)
        call check("linear_vjp_reused_fd_2", lhs, rhs, 2.0e-9_dp, nfail)
    end subroutine test_linear_solve_products

    pure function eye(n) result(m)
        integer, intent(in) :: n
        real(dp) :: m(n, n)
        integer :: i, j
        do j = 1, n
            do i = 1, n
                if (i == j) then
                    m(i, j) = 1.0_dp
                else
                    m(i, j) = 0.0_dp
                end if
            end do
        end do
    end function eye

end program test_fortnum_linalg
