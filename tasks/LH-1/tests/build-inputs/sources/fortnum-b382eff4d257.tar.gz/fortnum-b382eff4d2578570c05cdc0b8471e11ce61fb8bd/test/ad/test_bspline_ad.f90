program test_bspline_ad
    ! Verify the derivative routines in fortnum_bspline:
    !   bspline_eval_jvp      -- d/dx [sum_i c_i B_i(x)] . vx   (x active)
    !   bspline_eval_vjp      -- (d/dx [sum_i c_i B_i(x)])^T . u (x active)
    !   bspline_eval_coef_jvp -- d/dc [sum_i c_i B_i(x)] . vc   (coef active)
    !   bspline_eval_coef_vjp -- (d/dc [sum_i c_i B_i(x)])^T . u (coef active)
    !
    ! Checks:
    !   1. JVP vs central finite difference of the spline value (inside a span).
    !   2. JVP vs the analytic derivative computed directly from
    !      bspline_eval_deriv row 1 (the analytic spline-derivative routine).
    !   3. Dot-product (adjoint) identity u.(Jv) = v.(J^T u).
    !   4. Span-boundary non-smoothness: crossing an interior knot changes the
    !      primal_only span index and is flagged via check_smoothness.
    !   5. Coefficient products: coef JVP vs FD, coef VJP (u=1) equals the basis
    !      vector B(x), and the coef adjoint identity.
    use, intrinsic :: iso_fortran_env, only: dp => real64, error_unit
    use fortnum_bspline, only: bspline_workspace_t, bspline_init, &
        bspline_set_knots, bspline_eval_deriv, bspline_eval_jvp, &
        bspline_eval_vjp, bspline_span_index, bspline_span_derivative_status, &
        bspline_eval_basis, &
        bspline_eval_coef_jvp, bspline_eval_coef_vjp, &
        bspline_eval_combined_jvp, bspline_eval_combined_vjp, &
        bspline_eval_knots_jvp, bspline_eval_knots_vjp, &
        bspline_fit_jvp_factored, bspline_fit_vjp_factored
    use fortnum_linalg, only: lu_factor, lu_solve, LINALG_OK
    use fortnum_status, only: fortnum_status_t, FORTNUM_OK, FORTNUM_DOMAIN_ERROR
    use fortnum_ad_test_utils, only: rel_err, fd_jvp_step, &
        check_smoothness, ad_status_t, AD_SMOOTH, AD_NONSMOOTH
    implicit none

    integer :: nfail
    nfail = 0

    call test_jvp_vs_fd(nfail)
    call test_jvp_vs_analytic(nfail)
    call test_dotprod_identity(nfail)
    call test_span_boundary_nonsmooth(nfail)
    call test_coef_products(nfail)
    call test_knot_products(nfail)
    call test_fit_products(nfail)
    call test_combined_products(nfail)

    if (nfail > 0) then
        write (error_unit, '(i0,a)') nfail, " test(s) failed"
        stop 1
    end if
    write (*, '(a)') "PASS"
    stop 0

contains

    ! Build a representative order-4 (cubic) clamped B-spline on 6 breakpoints.
    subroutine setup(ws, coef)
        type(bspline_workspace_t), intent(out)              :: ws
        real(dp), allocatable,     intent(out)              :: coef(:)
        type(fortnum_status_t) :: s
        real(dp), parameter :: brk(6) = &
            [0.0_dp, 0.2_dp, 0.45_dp, 0.7_dp, 0.9_dp, 1.0_dp]
        integer :: i

        call bspline_init(ws, 4, 6, s)
        if (s%code /= FORTNUM_OK) error stop "setup init failed"
        call bspline_set_knots(ws, brk, s)
        if (s%code /= FORTNUM_OK) error stop "setup set_knots failed"
        allocate (coef(ws%ncoef))
        do i = 1, ws%ncoef
            coef(i) = sin(1.3_dp*real(i, dp)) + 0.5_dp*real(i, dp)
        end do
    end subroutine setup

    subroutine test_jvp_vs_fd(nfail)
        integer, intent(inout) :: nfail
        type(bspline_workspace_t) :: ws
        type(fortnum_status_t)    :: s
        real(dp), allocatable     :: coef(:)
        real(dp) :: x, vx, jv, h, sp, sm
        real(dp), allocatable :: v0(:)

        call setup(ws, coef)
        allocate (v0(ws%ncoef))
        x  = 0.53_dp ! interior, inside one span
        vx = 1.0_dp

        call bspline_eval_jvp(ws, x, coef, vx, jv, s)
        if (s%code /= FORTNUM_OK) then
            write (error_unit, '(a)') "FAIL [jvp_fd] jvp status"
            nfail = nfail + 1
            return
        end if

        h = fd_jvp_step([x], [vx])
        call eval_spline(ws, x + h*vx, coef, sp)
        call eval_spline(ws, x - h*vx, coef, sm)
        if (rel_err(jv, (sp - sm)/(2.0_dp*h)) > 1.0e-7_dp) then
            write (error_unit, '(a,es24.16,a,es24.16,a,es12.4)') &
                "FAIL [jvp_vs_fd] ad=", jv, " fd=", (sp - sm)/(2.0_dp*h), &
                " rel_err=", rel_err(jv, (sp - sm)/(2.0_dp*h))
            nfail = nfail + 1
        end if
    end subroutine test_jvp_vs_fd

    subroutine test_jvp_vs_analytic(nfail)
        integer, intent(inout) :: nfail
        type(bspline_workspace_t) :: ws
        type(fortnum_status_t)    :: s
        real(dp), allocatable     :: coef(:), dvals(:, :)
        real(dp) :: x, vx, jv, dsdx

        call setup(ws, coef)
        x  = 0.37_dp
        vx = 2.5_dp

        call bspline_eval_jvp(ws, x, coef, vx, jv, s)
        allocate (dvals(0:1, ws%ncoef))
        call bspline_eval_deriv(ws, x, 1, dvals, s)
        dsdx = dot_product(coef, dvals(1, :))

        if (rel_err(jv, dsdx*vx) > 1.0e-13_dp) then
            write (error_unit, '(a,es24.16,a,es24.16,a,es12.4)') &
                "FAIL [jvp_analytic] jv=", jv, " ds/dx*vx=", dsdx*vx, &
                " rel_err=", rel_err(jv, dsdx*vx)
            nfail = nfail + 1
        end if
    end subroutine test_jvp_vs_analytic

    subroutine test_dotprod_identity(nfail)
        integer, intent(inout) :: nfail
        type(bspline_workspace_t) :: ws
        type(fortnum_status_t)    :: s
        real(dp), allocatable     :: coef(:)
        real(dp) :: x, u, vx, jv, jtu

        call setup(ws, coef)
        x  = 0.61_dp
        u  = 1.7_dp
        vx = -0.9_dp

        call bspline_eval_jvp(ws, x, coef, vx, jv, s)
        call bspline_eval_vjp(ws, x, coef, u, jtu, s)

        ! scalar->scalar map: u.(J vx) = vx.(J^T u)
        if (rel_err(u*jv, vx*jtu) > 1.0e-13_dp) then
            write (error_unit, '(a,es24.16,a,es24.16,a,es12.4)') &
                "FAIL [dotprod] u.(Jv)=", u*jv, " v.(J^Tu)=", vx*jtu, &
                " rel_err=", rel_err(u*jv, vx*jtu)
            nfail = nfail + 1
        end if
    end subroutine test_dotprod_identity

    subroutine test_span_boundary_nonsmooth(nfail)
        integer, intent(inout) :: nfail
        type(bspline_workspace_t) :: ws
        type(fortnum_status_t) :: s
        real(dp), allocatable     :: coef(:)
        real(dp)          :: eps, xk
        integer           :: tag_base, tag_pert
        type(ad_status_t) :: st

        call setup(ws, coef)
        eps = 1.0e-9_dp
        xk  = 0.45_dp ! an interior breakpoint / knot

        tag_base = bspline_span_index(ws, xk - eps)
        tag_pert = bspline_span_index(ws, xk + eps)
        st = check_smoothness(tag_base, tag_pert, expect=AD_NONSMOOTH)
        if (.not. st%ok) then
            write (error_unit, '(a)') &
                "FAIL [span_boundary] crossing a knot not flagged non-smooth"
            nfail = nfail + 1
        end if
        call bspline_span_derivative_status(ws, xk, 1.0_dp, eps, s)
        if (s%code /= FORTNUM_DOMAIN_ERROR) then
            write (error_unit, '(a)') &
                "FAIL [span_boundary] public crossing status"
            nfail = nfail + 1
        end if

        tag_pert = bspline_span_index(ws, xk - 2.0_dp*eps)
        st = check_smoothness(tag_base, tag_pert, expect=AD_SMOOTH)
        if (.not. st%ok) then
            write (error_unit, '(a)') &
                "FAIL [span_boundary] same span incorrectly flagged non-smooth"
            nfail = nfail + 1
        end if
        call bspline_span_derivative_status(ws, xk - 3.0_dp*eps, 1.0_dp, &
            eps, s)
        if (s%code /= FORTNUM_OK) then
            write (error_unit, '(a)') &
                "FAIL [span_boundary] public same-span status"
            nfail = nfail + 1
        end if
    end subroutine test_span_boundary_nonsmooth

    ! (5) Coefficient-active products: s = sum_i c_i B_i(x) is linear in c with
    ! Jacobian B(x). Checks coef JVP vs central FD, coef VJP (u=1) == basis
    ! vector, and the adjoint identity u.(J vc) = vc.(J^T u).
    subroutine test_coef_products(nfail)
        integer, intent(inout) :: nfail
        type(bspline_workspace_t) :: ws
        type(fortnum_status_t)    :: s
        real(dp), allocatable     :: coef(:), vc(:), jtu(:), basis(:), cp(:), cm(:)
        real(dp) :: x, u, jv, fd, sp, sm, h, e
        integer  :: i
        logical  :: ok

        call setup(ws, coef)
        allocate (vc(ws%ncoef), jtu(ws%ncoef), basis(ws%ncoef))
        allocate (cp(ws%ncoef), cm(ws%ncoef))
        x = 0.53_dp
        do i = 1, ws%ncoef
            vc(i) = cos(0.7_dp*real(i, dp))
        end do

        call bspline_eval_coef_jvp(ws, x, vc, jv, s)
        if (s%code /= FORTNUM_OK) then
            write (error_unit, '(a)') "FAIL [coef_jvp] status"
            nfail = nfail + 1
            return
        end if

        h  = 1.0e-6_dp
        cp = coef + h*vc
        cm = coef - h*vc
        call eval_spline(ws, x, cp, sp)
        call eval_spline(ws, x, cm, sm)
        fd = (sp - sm)/(2.0_dp*h)
        if (rel_err(jv, fd) > 1.0e-7_dp) then
            write (error_unit, '(a,es24.16,a,es24.16,a,es12.4)') &
                "FAIL [coef_jvp_vs_fd] jv=", jv, " fd=", fd, &
                " rel_err=", rel_err(jv, fd)
            nfail = nfail + 1
        end if

        call bspline_eval_coef_vjp(ws, x, 1.0_dp, jtu, s)
        call bspline_eval_basis(ws, x, basis, s)
        ok = .true.
        do i = 1, ws%ncoef
            if (jtu(i) /= basis(i)) ok = .false.
        end do
        if (.not. ok) then
            write (error_unit, '(a)') "FAIL [coef_vjp grad /= basis vector]"
            nfail = nfail + 1
        end if

        u = 1.7_dp
        call bspline_eval_coef_vjp(ws, x, u, jtu, s)
        e = abs(u*jv - dot_product(vc, jtu))/max(abs(u*jv), 1.0_dp)
        if (e > 1.0e-13_dp) then
            write (error_unit, '(a,es24.16,a,es24.16,a,es12.4)') &
                "FAIL [coef_dotprod] u.(Jv)=", u*jv, &
                " v.(J^Tu)=", dot_product(vc, jtu), " rel_err=", e
            nfail = nfail + 1
        end if
    end subroutine test_coef_products

    subroutine test_knot_products(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: nbreak = 6
        real(dp), parameter :: brk(nbreak) = [ &
            0.0_dp, 0.2_dp, 0.45_dp, 0.7_dp, 0.9_dp, 1.0_dp]
        real(dp), parameter :: vbreak(nbreak) = [ &
            0.1_dp, -0.2_dp, 0.15_dp, 0.05_dp, -0.1_dp, 0.12_dp]
        type(bspline_workspace_t) :: ws, wsp, wsm
        type(fortnum_status_t) :: s
        real(dp), allocatable :: coef(:), breakbar(:)
        real(dp) :: bp(nbreak), bm(nbreak), jv, fd, sp, sm, h, u

        call setup(ws, coef)
        h = 1.0e-6_dp
        bp = brk + h*vbreak
        bm = brk - h*vbreak
        call bspline_init(wsp, 4, nbreak, s)
        call bspline_set_knots(wsp, bp, s)
        call bspline_init(wsm, 4, nbreak, s)
        call bspline_set_knots(wsm, bm, s)
        call bspline_eval_knots_jvp(ws, 0.53_dp, coef, vbreak, jv, s)
        call eval_spline(wsp, 0.53_dp, coef, sp)
        call eval_spline(wsm, 0.53_dp, coef, sm)
        fd = (sp - sm)/(2.0_dp*h)
        if (rel_err(jv, fd) > 2.0e-7_dp) then
            write (error_unit, '(a,es24.16,a,es24.16)') &
                "FAIL [knot_jvp] jv=", jv, " fd=", fd
            nfail = nfail + 1
        end if

        allocate (breakbar(nbreak))
        u = -1.4_dp
        call bspline_eval_knots_vjp(ws, 0.53_dp, coef, u, breakbar, s)
        if (rel_err(u*jv, dot_product(vbreak, breakbar)) > 2.0e-13_dp) then
            write (error_unit, '(a,es24.16,a,es24.16)') &
                "FAIL [knot_adjoint] lhs=", u*jv, &
                " rhs=", dot_product(vbreak, breakbar)
            nfail = nfail + 1
        end if
    end subroutine test_knot_products

    subroutine test_fit_products(nfail)
        integer, intent(inout) :: nfail
        integer, parameter :: n = 8
        real(dp), parameter :: h = 1.0e-6_dp
        type(bspline_workspace_t) :: ws
        type(fortnum_status_t) :: s
        real(dp), allocatable :: ignored(:)
        real(dp) :: basis(n, n), factors(n, n), transpose_factors(n, n)
        real(dp) :: dbasis(n, n), values(n), dvalues(n), coef(n), dcoef(n)
        real(dp) :: plus_basis(n, n), minus_basis(n, n)
        real(dp) :: plus_values(n), minus_values(n), plus_coef(n), minus_coef(n)
        real(dp) :: cbar(n), basis_bar(n, n), values_bar(n), lhs, rhs
        integer :: pivots(n), transpose_pivots(n), info, i, j

        call setup(ws, ignored)
        do i = 1, n
            call bspline_eval_basis(ws, real(i - 1, dp)/real(n - 1, dp), &
                basis(i, :), s)
            coef(i) = sin(0.4_dp*real(i, dp))
            dvalues(i) = 0.03_dp*real(mod(5*i, 7) - 3, dp)
            cbar(i) = 0.05_dp*real(mod(3*i, 11) - 5, dp)
            do j = 1, n
                dbasis(i, j) = 0.002_dp*real(mod(3*i + 5*j, 13) - 6, dp)
            end do
        end do
        values = matmul(basis, coef)
        factors = basis
        call lu_factor(n, factors, pivots, info)
        if (info /= LINALG_OK) error stop "fit test factorization failed"
        call bspline_fit_jvp_factored(factors, pivots, coef, dbasis, dvalues, &
            dcoef, s)

        plus_basis = basis + h*dbasis
        minus_basis = basis - h*dbasis
        plus_values = values + h*dvalues
        minus_values = values - h*dvalues
        plus_coef = plus_values
        minus_coef = minus_values
        call lu_solve(n, plus_basis, plus_coef, info)
        call lu_solve(n, minus_basis, minus_coef, info)
        if (maxval(abs(dcoef - (plus_coef - minus_coef)/(2.0_dp*h))) > &
            3.0e-9_dp) then
            write (error_unit, '(a)') "FAIL [fit_jvp]"
            nfail = nfail + 1
        end if

        transpose_factors = transpose(basis)
        call lu_factor(n, transpose_factors, transpose_pivots, info)
        call bspline_fit_vjp_factored(transpose_factors, transpose_pivots, coef, &
            cbar, basis_bar, values_bar, s)
        lhs = dot_product(cbar, dcoef)
        rhs = sum(basis_bar*dbasis) + dot_product(values_bar, dvalues)
        if (rel_err(lhs, rhs) > 3.0e-13_dp) then
            write (error_unit, '(a,es24.16,a,es24.16)') &
                "FAIL [fit_adjoint] lhs=", lhs, " rhs=", rhs
            nfail = nfail + 1
        end if
    end subroutine test_fit_products

    subroutine test_combined_products(nfail)
        integer, intent(inout) :: nfail
        type(bspline_workspace_t) :: ws
        type(fortnum_status_t) :: s
        real(dp), allocatable :: coef(:), vcoef(:), coefbar(:)
        real(dp) :: x, vx, u, h, jv, fd, sp, sm, xbar, lhs, rhs
        integer :: i

        call setup(ws, coef)
        allocate (vcoef(ws%ncoef), coefbar(ws%ncoef))
        do i = 1, ws%ncoef
            vcoef(i) = cos(0.37_dp*real(i, dp))
        end do
        x = 0.53_dp
        vx = -0.4_dp
        u = 2.1_dp

        call bspline_eval_combined_jvp(ws, x, coef, vx, vcoef, jv, s)
        if (s%code /= FORTNUM_OK) then
            write (error_unit, '(a)') "FAIL [combined_jvp] status"
            nfail = nfail + 1
            return
        end if
        h = 1.0e-6_dp
        call eval_spline(ws, x + h*vx, coef + h*vcoef, sp)
        call eval_spline(ws, x - h*vx, coef - h*vcoef, sm)
        fd = (sp - sm)/(2.0_dp*h)
        if (rel_err(jv, fd) > 1.0e-7_dp) then
            write (error_unit, '(a,es24.16,a,es24.16)') &
                "FAIL [combined_jvp] jv=", jv, " fd=", fd
            nfail = nfail + 1
        end if

        call bspline_eval_combined_vjp(ws, x, coef, u, xbar, coefbar, s)
        lhs = u*jv
        rhs = vx*xbar + dot_product(vcoef, coefbar)
        if (rel_err(lhs, rhs) > 1.0e-13_dp) then
            write (error_unit, '(a,es24.16,a,es24.16)') &
                "FAIL [combined_adjoint] lhs=", lhs, " rhs=", rhs
            nfail = nfail + 1
        end if
    end subroutine test_combined_products

    ! Spline value s(x) = sum_i c_i B_i(x).
    subroutine eval_spline(ws, x, coef, val)
        type(bspline_workspace_t), intent(in)  :: ws
        real(dp),                  intent(in)  :: x, coef(:)
        real(dp),                  intent(out) :: val
        type(fortnum_status_t) :: s
        real(dp), allocatable  :: b(:)
        allocate (b(ws%ncoef))
        call bspline_eval_basis(ws, x, b, s)
        val = dot_product(coef, b)
    end subroutine eval_spline

end program test_bspline_ad
