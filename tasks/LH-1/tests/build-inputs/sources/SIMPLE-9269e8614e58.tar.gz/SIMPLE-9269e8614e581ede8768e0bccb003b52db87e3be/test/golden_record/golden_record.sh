#!/bin/bash
CLONE_URL="https://github.com/itpplasma/SIMPLE.git"

SCRIPT_DIR=$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)
CUR_VER=$(git -C "$SCRIPT_DIR" describe --tags --always --dirty)
REF_VER=${1:-"main"}
SINGLE_CASE=${2:-""}  # Optional: specific test case to run

# Allow override of directories via environment variables
GOLDEN_RECORD_BASE_DIR=${GOLDEN_RECORD_BASE_DIR:-"$(pwd)/golden_record"}
GOLDEN_RECORD_REF_DIR=${GOLDEN_RECORD_REF_DIR:-""}
GOLDEN_RECORD_CUR_DIR=${GOLDEN_RECORD_CUR_DIR:-""}

# Set up deterministic directories
if [ -z "$GOLDEN_RECORD_REF_DIR" ]; then
    PROJECT_ROOT_REF="$GOLDEN_RECORD_BASE_DIR/simple_$REF_VER"
else
    PROJECT_ROOT_REF="$GOLDEN_RECORD_REF_DIR"
fi

if [ -z "$GOLDEN_RECORD_CUR_DIR" ]; then
    PROJECT_ROOT_CUR=$(cd "$SCRIPT_DIR/../.." && pwd)
else
    PROJECT_ROOT_CUR="$GOLDEN_RECORD_CUR_DIR"
fi

RUN_DIR_REF="$GOLDEN_RECORD_BASE_DIR/runs/run_$REF_VER"
RUN_DIR_CUR="$GOLDEN_RECORD_BASE_DIR/runs/run_$CUR_VER"
TEST_DATA_DIR="$GOLDEN_RECORD_BASE_DIR/test_data"
GOLDEN_LIBNEO_REF=${GOLDEN_LIBNEO_REF:-e2b281b1bc9f9f48f9526622445e0b2c0f8a4984}

# Find test cases - they should be copied by CMake to the golden_record directory
if [ -n "$SINGLE_CASE" ]; then
    # Single test case specified
    TEST_CASES="$SINGLE_CASE"
elif [ -d "$GOLDEN_RECORD_BASE_DIR/test_cases" ]; then
    TEST_CASES="$(cd "$GOLDEN_RECORD_BASE_DIR/test_cases" && find . -name simple.in -exec dirname {} \; | sed 's|^\./||' | sort)"
else
    # Fallback to original location if CMake hasn't copied them yet
    TEST_CASES="$(cd "$SCRIPT_DIR" && find . -name simple.in -exec dirname {} \; | sed 's|^\./||' | sort)"
fi

echo "Golden record base directory: $GOLDEN_RECORD_BASE_DIR"
echo "Reference version: $REF_VER"
echo "Current version: $CUR_VER"
echo "Project root (reference): $PROJECT_ROOT_REF"
echo "Project root (current): $PROJECT_ROOT_CUR"
echo "Test run directories:"
echo "  Current: $RUN_DIR_CUR"
echo "  Reference: $RUN_DIR_REF"

handle_success() {
    echo "Tests completed successfully."
    echo "Results preserved in: $GOLDEN_RECORD_BASE_DIR"
}

handle_failure() {
    local exit_code=$1
    echo "Tests failed with exit code: $exit_code"
    echo "Results preserved for debugging in: $GOLDEN_RECORD_BASE_DIR"
    exit $exit_code
}

# Determine and check out appropriate libneo version for historical builds
setup_libneo() {
    local PROJECT_ROOT="$1"
    local BASE_DIR="$(dirname "$PROJECT_ROOT")"
    local LIBNEO_URL="https://github.com/itpplasma/libneo.git"

    # Timestamp of SIMPLE commit
    local SIMPLE_TS
    SIMPLE_TS=$(git -C "$PROJECT_ROOT" log -1 --format=%ct)

    # Cache repository with all tags for lookup
    local LIBNEO_TAGS_DIR="$BASE_DIR/libneo_tags"
    if [ ! -d "$LIBNEO_TAGS_DIR/.git" ]; then
        git clone --quiet --no-checkout "$LIBNEO_URL" "$LIBNEO_TAGS_DIR"
    else
        git -C "$LIBNEO_TAGS_DIR" fetch --tags --quiet
    fi

    # Find newest tag not newer than SIMPLE commit
    # Use creatordate which works for both annotated and lightweight tags
    local LIBNEO_TAG
    LIBNEO_TAG=$(git -C "$LIBNEO_TAGS_DIR" for-each-ref --sort=-creatordate \
        --format '%(refname:short) %(creatordate:unix)' refs/tags | while read tag ts; do
            # Check that timestamp is not empty and is valid
            if [ -n "$ts" ] && [ "$ts" -le "$SIMPLE_TS" ] 2>/dev/null; then
                echo "$tag"
                break
            fi
        done)

    if [ -z "$LIBNEO_TAG" ]; then
        echo "No suitable libneo tag found; using oldest available for compatibility"
        # Use oldest tag for better compatibility with historical commits
        LIBNEO_TAG=$(git -C "$LIBNEO_TAGS_DIR" for-each-ref --sort=creatordate \
            --format '%(refname:short)' refs/tags | head -n 1)
    fi

    echo "Using libneo tag: $LIBNEO_TAG"
    local LIBNEO_TAG_DIR="$BASE_DIR/libneo_$LIBNEO_TAG"
    if [ ! -d "$LIBNEO_TAG_DIR/.git" ]; then
        git clone --quiet --branch "$LIBNEO_TAG" --depth 1 "$LIBNEO_URL" "$LIBNEO_TAG_DIR"
    fi

    ln -sfn "$LIBNEO_TAG_DIR" "$BASE_DIR/libneo"
}

main() {
    set -e  # Exit on any error

    # Create base directories
    mkdir -p "$GOLDEN_RECORD_BASE_DIR"
    mkdir -p "$TEST_DATA_DIR"

    local REF_CONTRACT_STAMP="$PROJECT_ROOT_REF/build/.golden-libneo-ref"
    if [ -f "$PROJECT_ROOT_REF/build/simple.x" ] && \
       [ "$(cat "$REF_CONTRACT_STAMP" 2>/dev/null)" != "$GOLDEN_LIBNEO_REF" ]; then
        rm -rf "$PROJECT_ROOT_REF/build"
    fi

    # Check if we need to build reference version
    if [ ! -f "$PROJECT_ROOT_REF/build/simple.x" ]; then
        echo "Reference build not found, cloning and building..."
        clone "$REF_VER" "$PROJECT_ROOT_REF" || handle_failure $?
        build "$PROJECT_ROOT_REF" || handle_failure $?
    else
        echo "Using existing reference build at: $PROJECT_ROOT_REF/build/simple.x"
    fi

    # Check if current version needs building (it should already be built)
    if [ ! -f "$PROJECT_ROOT_CUR/build/simple.x" ]; then
        echo "Current build not found at: $PROJECT_ROOT_CUR/build/simple.x"
        handle_failure 1
    else
        echo "Using current build at: $PROJECT_ROOT_CUR/build/simple.x"
    fi

    # Use the new scripts to run tests and compare
    "$SCRIPT_DIR/run_golden_tests.sh" "$PROJECT_ROOT_REF" "$RUN_DIR_REF" "$TEST_DATA_DIR" "$SINGLE_CASE" || handle_failure $?
    "$SCRIPT_DIR/run_golden_tests.sh" "$PROJECT_ROOT_CUR" "$RUN_DIR_CUR" "$TEST_DATA_DIR" "$SINGLE_CASE" || handle_failure $?

    # Compare results
    "$SCRIPT_DIR/compare_golden_results.sh" "$RUN_DIR_REF" "$RUN_DIR_CUR" "$TEST_CASES"
    comparison_result=$?

    if [ $comparison_result -eq 0 ]; then
        handle_success
    else
        handle_failure $comparison_result
    fi
}


clone() {
    local VERSION="$1"
    local PROJECT_ROOT="$2"
    if [ ! -d "$PROJECT_ROOT" ]; then
        echo "Cloning SIMPLE version $VERSION"
        git clone --filter=blob:none --no-checkout "$CLONE_URL" "$PROJECT_ROOT"
    fi

    cd "$PROJECT_ROOT"
    git fetch --all --quiet
    git checkout "$VERSION" --quiet
}

build() {
    local PROJECT_ROOT="$1"
    echo "Building SIMPLE in $PROJECT_ROOT"
    cd $PROJECT_ROOT

    if ! git merge-base --is-ancestor cc5872a855820e6fa2065a5f9aa7e17604e45d77 HEAD; then
        local REFERENCE_PATCH
        for REFERENCE_PATCH in \
            "$SCRIPT_DIR/reference_patches/rejected_step_state.patch" \
            "$SCRIPT_DIR/reference_patches/physical_exit_reporting.patch" \
            "$SCRIPT_DIR/reference_patches/canonical_map_resolution.patch"; do
            if git apply --check "$REFERENCE_PATCH"; then
                git apply "$REFERENCE_PATCH"
            elif ! git apply --reverse --check "$REFERENCE_PATCH"; then
                echo "Reference patch does not apply cleanly: $REFERENCE_PATCH"
                return 1
            fi
        done
    fi

    # For older versions, check if libneo is needed as a sibling directory
    if [ -f "SRC/CMakeLists.txt" ] && grep -q "../libneo" "SRC/CMakeLists.txt" 2>/dev/null; then
        echo "Old project structure detected, setting up libneo..."
        setup_libneo "$PROJECT_ROOT"
    fi

    # Check if CMakeLists.txt has fortplot dependency and adjust accordingly
    local CMAKE_OPTS="-DCMAKE_BUILD_TYPE=Release -DENABLE_PYTHON_INTERFACE=OFF -DSIMPLE_TESTING=OFF"

    if grep -q "fortplot" CMakeLists.txt 2>/dev/null; then
        echo "Detected fortplot dependency in CMakeLists.txt"
    fi

    # Enable deterministic floating-point for reproducible golden record tests
    CMAKE_OPTS="$CMAKE_OPTS -DSIMPLE_DETERMINISTIC_FP=ON -DLIBNEO_DETERMINISTIC_FP=ON"
    CMAKE_OPTS="$CMAKE_OPTS -DLIBNEO_REF=$GOLDEN_LIBNEO_REF -DCMAKE_EXPORT_COMPILE_COMMANDS=ON"

    cmake -S . -Bbuild -GNinja $CMAKE_OPTS > $PROJECT_ROOT/configure.log 2>&1
    if [ $? -ne 0 ]; then
        echo "CMake configuration failed. Check $PROJECT_ROOT/configure.log"
        tail -n 200 "$PROJECT_ROOT/configure.log" 2>/dev/null || true
        return 1
    fi

    local BUILD_PARALLEL="${CMAKE_BUILD_PARALLEL_LEVEL:-2}"
    cmake --build build --config Release --parallel "$BUILD_PARALLEL" > $PROJECT_ROOT/build.log 2>&1
    if [ $? -ne 0 ]; then
        echo "Build failed. Check $PROJECT_ROOT/build.log"
        tail -n 200 "$PROJECT_ROOT/build.log" 2>/dev/null || true
        return 1
    fi

    python3 "$SCRIPT_DIR/../python/test_deterministic_dependency_flags.py" \
        "$PROJECT_ROOT/build/compile_commands.json" \
        "$PROJECT_ROOT/build/_deps/libneo-src"
    printf '%s\n' "$GOLDEN_LIBNEO_REF" > "$PROJECT_ROOT/build/.golden-libneo-ref"
}


main "$@"
