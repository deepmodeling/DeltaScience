#!/usr/bin/env python3
"""End-to-end benchmark for VMEC and GVEC Boozer chartmaps on common cases."""

from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import sys

import netCDF4
import numpy as np

from boozer_chartmap_artifacts import (
    confined_metrics,
    download_if_missing,
    load_confined_fraction,
    plot_all_cases_total_losses,
    plot_case_loss_comparison,
    plot_field_component_comparison,
    plot_surface_comparison,
    run_cmd,
    summarize_confined_fraction,
)


SCRIPT_DIR = Path(__file__).resolve().parent
BUILD_DIR = SCRIPT_DIR.parent.parent / "build"
SIMPLE_X = BUILD_DIR / "simple.x"
TOOL_X = BUILD_DIR / "test" / "tests" / "export_boozer_chartmap_tool.x"
ROUNDTRIP_X = BUILD_DIR / "test" / "tests" / "test_boozer_chartmap_roundtrip.x"
ROUNDTRIP_PLOT = SCRIPT_DIR / "plot_boozer_chartmap_roundtrip.py"
GVEC_TO_CHARTMAP = SCRIPT_DIR.parent.parent / "tools" / "gvec_to_boozer_chartmap.py"
TEST_DATA = SCRIPT_DIR.parent / "test_data"


EQUILIBRIA = [
    {
        "name": "QA",
        "wout": TEST_DATA / "wout.nc",
        "url": "https://raw.githubusercontent.com/hiddenSymmetries/simsopt/master/tests/test_files/wout_LandremanPaul2021_QA_reactorScale_lowres_reference.nc",
        "trace_time": "1d-2",
        "facE_al": "1.0d0",
        "use_gvec": False,
        "vmec_roundtrip_field_tol": "8.0e-5",
        "vmec_roundtrip_orbit_tol": "2.0e-9",
        "gvec_roundtrip_field_tol": "2.5e-4",
        "gvec_minimize_tol": 1.0e-10,
        "gvec_max_iter": 4,
        "gvec_total_iter": 8,
    },
    {
        "name": "QH",
        "wout": TEST_DATA / "wout_qh.nc",
        "url": "https://raw.githubusercontent.com/hiddenSymmetries/simsopt/master/tests/test_files/wout_LandremanPaul2021_QH_reactorScale_lowres_reference.nc",
        "trace_time": "1d-2",
        "facE_al": "1.0d0",
        "use_gvec": False,
        "vmec_roundtrip_field_tol": "9.6e-5",
        "vmec_roundtrip_orbit_tol": "7.1e-9",
        "gvec_minimize_tol": 1.0e-10,
        "gvec_max_iter": 12,
        "gvec_total_iter": 24,
    },
    {
        "name": "NCSX",
        "wout": TEST_DATA / "wout_ncsx.nc",
        "url": "https://raw.githubusercontent.com/hiddenSymmetries/simsopt/master/tests/test_files/wout_c09r00_fixedBoundary_0.5T_vacuum_ns201.nc",
        "trace_time": "1d-2",
        "facE_al": "100.0d0",
        "use_gvec": False,
        "vmec_roundtrip_field_tol": "9.8e-5",
        "vmec_roundtrip_orbit_tol": "3.8e-7",
        "gvec_minimize_tol": 1.0e-10,
        "gvec_max_iter": 8,
        "gvec_total_iter": 16,
    },
]


def simple_in_vmec(wout_name: str, trace_time: str, facE_al: str) -> str:
    return f"""\
&config
multharm = 5
contr_pp = -1e10
trace_time = {trace_time}
macrostep_time_grid = 'log'
ntimstep = 61
sbeg = 0.3d0
ntestpart = 32
netcdffile = '{wout_name}'
isw_field_type = 2
deterministic = .True.
integmode = 1
facE_al = {facE_al}
/
"""


def simple_in_chartmap(chartmap_name: str, trace_time: str, facE_al: str) -> str:
    return f"""\
&config
multharm = 5
contr_pp = -1e10
trace_time = {trace_time}
macrostep_time_grid = 'log'
ntimstep = 61
sbeg = 0.3d0
ntestpart = 32
field_input = '{chartmap_name}'
coord_input = '{chartmap_name}'
isw_field_type = 2
deterministic = .True.
integmode = 1
startmode = 2
facE_al = {facE_al}
/
"""


def build_gvec_chartmap(
    wout: Path,
    run_dir: Path,
    minimize_tol: float,
    max_iter: int,
    total_iter: int,
) -> Path:
    import gvec
    from gvec.scripts.convert_wout import convert_vmec_wout
    from gvec.util import read_parameters

    convert_dir = run_dir / "convert"
    solve_dir = run_dir / "solve"
    convert_dir.mkdir(parents=True, exist_ok=True)
    solve_dir.mkdir(parents=True, exist_ok=True)
    convert_vmec_wout(wout, convert_dir)

    restart_state = next(convert_dir.glob("*State*.dat"))
    params = read_parameters(convert_dir / "parameter.toml")
    params["minimize_tol"] = float(minimize_tol)
    params["maxIter"] = int(max_iter)
    params["totalIter"] = int(total_iter)
    gvec.run(
        params,
        restartstate=restart_state,
        runpath=solve_dir,
        redirect_gvec_stdout=True,
        quiet=True,
    )

    param_final = sorted(solve_dir.glob("parameter*_final.ini"))[-1]
    state_final = sorted(solve_dir.glob("*State_final.dat"))[-1]
    output = run_dir / "boozer_chartmap.nc"
    run_cmd(
        [
            sys.executable,
            str(GVEC_TO_CHARTMAP),
            str(param_final),
            str(state_final),
            str(output),
            "--nrho",
            "50",
            "--ntheta",
            "36",
            "--nphi",
            "81",
        ],
        cwd=run_dir,
        label=f"{wout.stem} GVEC->chartmap",
        timeout=3600,
    )
    return output


def run_roundtrip(
    wout: Path,
    chartmap: Path,
    mode: str,
    prefix: Path,
    title: str,
    chart_label: str,
    field_tol: str,
    orbit_tol: str,
) -> None:
    prefix.parent.mkdir(parents=True, exist_ok=True)
    run_cmd(
        [
            str(ROUNDTRIP_X),
            str(wout),
            str(chartmap),
            mode,
            str(prefix),
            field_tol,
            orbit_tol,
        ],
        cwd=prefix.parent,
        label=title,
        timeout=3600,
    )
    run_cmd(
        [
            sys.executable,
            str(ROUNDTRIP_PLOT),
            "--prefix",
            str(prefix),
            "--direct-label",
            "VMEC-Boozer",
            "--chartmap-label",
            chart_label,
            "--title",
            title,
        ],
        cwd=prefix.parent,
        label=f"{title} plots",
    )


def parse_tau_line(stdout: str) -> tuple[float | None, int | None]:
    for line in stdout.splitlines():
        if line.strip().startswith("tau:"):
            parts = line.split()
            return float(parts[2].replace("D", "E")), int(parts[4])
    return None, None


def write_json(path: Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def assert_boozer_chartmap_file(path: Path) -> None:
    with netCDF4.Dataset(path) as ds:
        if int(getattr(ds, "boozer_field")) != 1:
            raise RuntimeError(f"{path}: boozer_field attribute missing or invalid")
        if str(getattr(ds, "zeta_convention")) != "boozer":
            raise RuntimeError(f"{path}: expected zeta_convention='boozer'")
        if str(getattr(ds, "rho_convention")) != "rho_tor":
            raise RuntimeError(f"{path}: expected rho_convention='rho_tor'")
        if "s" not in ds.dimensions or "s" not in ds.variables:
            raise RuntimeError(f"{path}: expected s for A_phi")
        if "theta_field" in ds.dimensions or "zeta_field" in ds.dimensions:
            raise RuntimeError(f"{path}: redundant endpoint field dimensions present")
        aphi = ds.variables["A_phi"]
        if aphi.dimensions != ("s",):
            raise RuntimeError(f"{path}: expected A_phi to use s dimension")
        if getattr(aphi, "radial_abscissa", "") != "s":
            raise RuntimeError(f"{path}: expected A_phi radial_abscissa='s'")
        if ds.variables["B_theta"].dimensions != ("rho",):
            raise RuntimeError(f"{path}: expected B_theta to use rho dimension")
        if ds.variables["B_phi"].dimensions != ("rho",):
            raise RuntimeError(f"{path}: expected B_phi to use rho dimension")
        if ds.variables["Bmod"].dimensions != ("zeta", "theta", "rho"):
            raise RuntimeError(f"{path}: expected Bmod to use zeta/theta/rho dimensions")
        rho = np.asarray(ds.variables["rho"][:], dtype=float)
        s = np.asarray(ds.variables["s"][:], dtype=float)
        if not np.allclose(np.diff(rho), rho[1] - rho[0], rtol=0.0, atol=1e-14):
            raise RuntimeError(f"{path}: rho grid is not uniform")
        if not np.allclose(np.diff(s), s[1] - s[0], rtol=0.0, atol=1e-14):
            raise RuntimeError(f"{path}: s grid is not uniform")
        if not np.allclose([s[0], s[-1]], [rho[0] ** 2, rho[-1] ** 2]):
            raise RuntimeError(f"{path}: s must span rho**2")
        if "rmajor" in ds.ncattrs():
            raise RuntimeError(
                f"{path}: rmajor attribute is no longer part of the format; "
                "the reader derives it from geometry"
            )


def assert_matching_microstep(name: str, ref_stdout: str, chartmap_stdout: str) -> None:
    # The chartmap run derives rmajor from the innermost-surface geometry
    # (axis-average R) while the VMEC run uses the volume-based Rmajor_p from
    # the wout. For the QA test case they differ by 1.2 percent, which feeds
    # linearly into dtaumin = 2*pi*rmajor*1e2/npoiper2 and ntau. 5 percent
    # bounds that geometric difference with margin while still catching the
    # order-of-magnitude rmajor bugs this check was introduced for (350b0f2).
    tol = 5.0e-2
    ref_dtaumin, ref_ntau = parse_tau_line(ref_stdout)
    chartmap_dtaumin, chartmap_ntau = parse_tau_line(chartmap_stdout)
    if ref_dtaumin is None or ref_ntau is None:
        raise RuntimeError(f"{name}: VMEC run did not print a tau line")
    if chartmap_dtaumin is None or chartmap_ntau is None:
        raise RuntimeError(f"{name}: chartmap run did not print a tau line")
    rel_ntau = abs(chartmap_ntau - ref_ntau) / max(ref_ntau, 1)
    if rel_ntau > tol:
        raise RuntimeError(
            f"{name}: chartmap ntau={chartmap_ntau}, VMEC ntau={ref_ntau}, "
            f"rel={rel_ntau:.3e} > {tol:.0e}"
        )
    rel = abs(chartmap_dtaumin - ref_dtaumin) / max(abs(ref_dtaumin), 1.0)
    if rel > tol:
        raise RuntimeError(
            f"{name}: chartmap dtaumin={chartmap_dtaumin:.17e}, "
            f"VMEC dtaumin={ref_dtaumin:.17e}, rel={rel:.3e} > {tol:.0e}"
        )
    print(f"[{name}] microstep: dtaumin rel diff {rel:.3e}, "
          f"ntau {ref_ntau} -> {chartmap_ntau} (rel {rel_ntau:.3e})")


def _compare_and_summarize(
    name: str,
    series: dict[str, np.ndarray],
    eq_dir: Path,
    field_metrics: dict[str, float],
) -> tuple[bool, dict[str, dict[str, float]]]:
    min_len = min(len(values) for values in series.values())
    metrics_by_label: dict[str, dict[str, np.ndarray | float]] = {}
    max_diffs = {"total": 0.0, "pass": 0.0, "trap": 0.0}
    ref_metrics = confined_metrics(series["VMEC-Boozer"][:min_len])
    tol = 1.0 / float(ref_metrics["npart"])
    for label, values in series.items():
        metrics_by_label[label] = confined_metrics(values[:min_len])

    labels = list(metrics_by_label)
    for idx, left in enumerate(labels):
        for right in labels[idx + 1:]:
            left_m = metrics_by_label[left]
            right_m = metrics_by_label[right]
            for key, tag in [("total_conf", "total"), ("pass_conf", "pass"), ("trap_conf", "trap")]:
                diff = float(np.max(np.abs(np.asarray(left_m[key]) - np.asarray(right_m[key]))))
                print(f"[{name}] max |{tag} diff| {left} vs {right} = {diff:.6e}")
                max_diffs[tag] = max(max_diffs[tag], diff)

    plot_case_loss_comparison(eq_dir / f"e2e_{name}.png", name, metrics_by_label)

    summary = {
        label: summarize_confined_fraction(series[label][:min_len])
        for label in series
    }
    summary["executed_modes"] = list(series)
    summary["comparison"] = {
        "tol": tol,
        "max_total_diff": max_diffs["total"],
        "max_pass_diff": max_diffs["pass"],
        "max_trap_diff": max_diffs["trap"],
    }
    summary["field_metrics"] = field_metrics
    write_json(eq_dir / "loss_summary.json", summary)

    ok = all(value <= tol for value in max_diffs.values())
    if not ok:
        print(f"[{name}] FAIL: confined-fraction mismatch exceeds {tol:.6e}")
    else:
        print(f"[{name}] PASS")
    return ok, summary


def run_single_equilibrium(eq: dict[str, str | Path], outdir: Path) -> tuple[bool, dict[str, dict[str, float]]]:
    name = str(eq["name"])
    wout = download_if_missing(Path(eq["wout"]), str(eq["url"]))
    trace_time = str(eq["trace_time"])
    facE_al = str(eq["facE_al"])
    use_gvec = bool(eq.get("use_gvec", False))
    vmec_roundtrip_field_tol = str(eq.get("vmec_roundtrip_field_tol", "8.0e-5"))
    vmec_roundtrip_orbit_tol = str(eq.get("vmec_roundtrip_orbit_tol", "2.0e-9"))
    gvec_roundtrip_field_tol = str(eq.get("gvec_roundtrip_field_tol", "2.5e-4"))
    gvec_minimize_tol = float(eq.get("gvec_minimize_tol", 1.0e-10))
    gvec_max_iter = int(eq.get("gvec_max_iter", 4))
    gvec_total_iter = int(eq.get("gvec_total_iter", 8))

    eq_dir = outdir / name
    if eq_dir.exists():
        shutil.rmtree(eq_dir)
    vmec_dir = eq_dir / "vmec_run"
    chartmap_dir = eq_dir / "vmec_chartmap_run"
    gvec_dir = eq_dir / "gvec_chartmap_run"
    vmec_dir.mkdir(parents=True)
    chartmap_dir.mkdir()
    gvec_dir.mkdir()

    wout_name = wout.name
    shutil.copy2(wout, vmec_dir / wout_name)
    (vmec_dir / "simple.in").write_text(simple_in_vmec(wout_name, trace_time, facE_al), encoding="utf-8")

    print(f"[{name}] Step 1: VMEC Boozer run")
    vmec_stdout = run_cmd([str(SIMPLE_X)], cwd=vmec_dir, label=f"{name} VMEC")
    cf_vmec = load_confined_fraction(vmec_dir / "confined_fraction.dat")
    start_vmec = vmec_dir / "start.dat"

    print(f"[{name}] Step 2: export VMEC Boozer chartmap")
    chartmap_nc = chartmap_dir / "boozer_chartmap.nc"
    start_boozer = chartmap_dir / "start.dat"
    run_cmd(
        [
            str(TOOL_X),
            str(vmec_dir / wout_name),
            str(chartmap_nc),
            str(start_vmec),
            str(start_boozer),
        ],
        cwd=chartmap_dir,
        label=f"{name} export",
    )
    assert_boozer_chartmap_file(chartmap_nc)

    print(f"[{name}] Step 3: VMEC chartmap SIMPLE run")
    (chartmap_dir / "simple.in").write_text(
        simple_in_chartmap("boozer_chartmap.nc", trace_time, facE_al),
        encoding="utf-8",
    )
    chartmap_stdout = run_cmd([str(SIMPLE_X)], cwd=chartmap_dir, label=f"{name} VMEC chartmap")
    assert_matching_microstep(name, vmec_stdout, chartmap_stdout)
    cf_chartmap = load_confined_fraction(chartmap_dir / "confined_fraction.dat")

    gvec_chartmap = None
    cf_gvec = None
    if use_gvec:
        print(f"[{name}] Step 4: build GVEC chartmap from common VMEC input")
        gvec_chartmap = build_gvec_chartmap(
            wout,
            gvec_dir,
            minimize_tol=gvec_minimize_tol,
            max_iter=gvec_max_iter,
            total_iter=gvec_total_iter,
        )
        assert_boozer_chartmap_file(gvec_chartmap)
        shutil.copy2(start_boozer, gvec_dir / "start.dat")
        (gvec_dir / "simple.in").write_text(
            simple_in_chartmap("boozer_chartmap.nc", trace_time, facE_al),
            encoding="utf-8",
        )
        if list(gvec_dir.glob("wout*")):
            raise RuntimeError(f"{name}: GVEC run directory unexpectedly contains VMEC files")

        print(f"[{name}] Step 5: GVEC chartmap SIMPLE run")
        run_cmd([str(SIMPLE_X)], cwd=gvec_dir, label=f"{name} GVEC chartmap")
        cf_gvec = load_confined_fraction(gvec_dir / "confined_fraction.dat")

    print(f"[{name}] Step 6: field/orbit comparison artifacts")
    run_roundtrip(
        wout,
        chartmap_nc,
        "export",
        eq_dir / "roundtrip_vmec" / "vmec",
        f"{name}: VMEC direct vs VMEC chartmap",
        "VMEC chartmap",
        vmec_roundtrip_field_tol,
        vmec_roundtrip_orbit_tol,
    )
    field_metrics: dict[str, float] = {}
    if use_gvec:
        run_roundtrip(
            wout,
            gvec_chartmap,
            "external",
            eq_dir / "roundtrip_gvec" / "gvec",
            f"{name}: VMEC direct vs GVEC chartmap",
            "GVEC chartmap",
            gvec_roundtrip_field_tol,
            "1.0e-6",
        )

        field_metrics = plot_field_component_comparison(
            eq_dir / f"{name.lower()}_field_components.png",
            name,
            chartmap_nc,
            gvec_chartmap,
            "VMEC chartmap",
            "GVEC chartmap",
        )
        plot_surface_comparison(
            eq_dir / f"{name.lower()}_surface_comparison.png",
            name,
            chartmap_nc,
            gvec_chartmap,
            "VMEC chartmap",
            "GVEC chartmap",
        )

    series = {
        "VMEC-Boozer": cf_vmec,
        "VMEC chartmap": cf_chartmap,
    }
    if use_gvec and cf_gvec is not None:
        series["GVEC chartmap"] = cf_gvec
    return _compare_and_summarize(name, series, eq_dir, field_metrics)


def main() -> None:
    for path, label in [
        (SIMPLE_X, "simple.x"),
        (TOOL_X, "export tool"),
        (ROUNDTRIP_X, "roundtrip comparison tool"),
        (GVEC_TO_CHARTMAP, "GVEC conversion script"),
    ]:
        if not path.exists():
            raise SystemExit(f"Missing {label}: {path}")

    outdir = Path.cwd() / "boozer_chartmap_e2e"
    if outdir.exists():
        shutil.rmtree(outdir)
    outdir.mkdir(parents=True)

    case_filter = os.environ.get("SIMPLE_BOOZER_CASES", "").strip()
    if case_filter:
        selected = {item.strip().upper() for item in case_filter.split(",") if item.strip()}
        equilibria = [eq for eq in EQUILIBRIA if str(eq["name"]).upper() in selected]
    else:
        equilibria = EQUILIBRIA

    all_ok = True
    combined_metrics: dict[str, dict[str, dict[str, np.ndarray | float]]] = {}
    summaries: dict[str, dict[str, dict[str, float]]] = {}
    for eq in equilibria:
        print(f"\n=== {eq['name']} ===")
        ok, summary = run_single_equilibrium(eq, outdir)
        series = {}
        eq_dir = outdir / str(eq["name"])
        for label, run_name in [
            ("VMEC-Boozer", "vmec_run"),
            ("VMEC chartmap", "vmec_chartmap_run"),
        ]:
            series[label] = confined_metrics(
                load_confined_fraction(eq_dir / run_name / "confined_fraction.dat")
            )
        if bool(eq.get("use_gvec", False)):
            series["GVEC chartmap"] = confined_metrics(
                load_confined_fraction(eq_dir / "gvec_chartmap_run" / "confined_fraction.dat")
            )
        combined_metrics[str(eq["name"])] = series
        summaries[str(eq["name"])] = summary
        all_ok = all_ok and ok

    plot_all_cases_total_losses(outdir / "all_e2e_losses.png", combined_metrics)
    write_json(outdir / "common_case_summaries.json", summaries)

    if not all_ok:
        raise SystemExit("One or more common-case end-to-end comparisons failed")
    print("ALL COMMON-CASE BOOZER CHARTMAP BENCHMARKS PASSED")


if __name__ == "__main__":
    main()
