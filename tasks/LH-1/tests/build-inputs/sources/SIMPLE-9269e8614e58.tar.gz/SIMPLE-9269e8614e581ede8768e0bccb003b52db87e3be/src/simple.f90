module simple
  use util, only: c, e_charge, p_mass, ev, twopi
  use new_vmec_stuff_mod, only : netcdffile, multharm, ns_s, ns_tp, &
                                 vmec_B_scale, vmec_RZ_scale

  use parmot_mod, only : rmu, ro0
  use velo_mod,   only : isw_field_type
  use field_can_mod, only : field_can_t
  use orbit_symplectic, only : symplectic_integrator_t, multistage_integrator_t, &
    orbit_sympl_init, orbit_timestep_sympl
  use field, only : vmec_field_t
  use field_can_mod, only : eval_field => evaluate, init_field_can, field_can_t, get_val
  use orbit_fo_boris, only : fo_state_t, fo_init, fo_step, fo_to_gc
  use diag_mod, only : icounter
  use chamb_sub, only : chamb_can

  implicit none

  ! Define real(dp) kind parameter
  integer, parameter :: dp = kind(1.0d0)
save

public

  integer, parameter :: ORBIT_FO_LOSS = 2
  integer, parameter :: ORBIT_FO_NUMERICAL = 3

  type :: tracer_t
    real(dp) :: fper
    real(dp) :: dtau, dtaumin, v0
    integer          :: n_e, n_d

    integer :: integmode = 0 ! 0 = RK, 1 = Euler1, 2 = Euler2, 3 = Midpoint, 4-7 = Gauss1-4, 15 = Lobatto3
    real(dp) :: relerr

    type(field_can_t) :: f
    type(symplectic_integrator_t) :: si
    type(multistage_integrator_t) :: mi
    type(fo_state_t) :: fo   ! full-orbit Boris state (orbit_model=ORBIT_FULL_ORBIT)
  end type tracer_t

  interface tstep
      module procedure timestep
      module procedure timestep_z
      module procedure timestep_sympl_z
   end interface tstep

  public :: encode_symplectic_state

contains

  subroutine encode_symplectic_state(f, z0, zsympl, h0, jperp, psi_star)
    !> Convert the public GC state to the normalization used by the symplectic
    !> Hamiltonian. This is the single source of truth used by initialization,
    !> reseeding, and the invariant API.
    type(field_can_t), intent(inout) :: f
    real(dp), intent(in) :: z0(:)
    real(dp), intent(out) :: zsympl(4)
    real(dp), intent(out), optional :: h0, jperp, psi_star

    real(dp) :: jperp_local, psi_star_local

    call eval_field(f, z0(1), z0(2), z0(3), 0)
    jperp_local = z0(4)**2*(1.0_dp - z0(5)**2)/f%Bmod
    psi_star_local = f%Aph + ro0*z0(4)*z0(5)*f%hph

    f%mu = jperp_local
    f%ro0 = ro0/sqrt(2.0_dp)
    f%vpar = z0(4)*z0(5)*sqrt(2.0_dp)
    zsympl(1:3) = z0(1:3)
    zsympl(4) = f%vpar*f%hph + f%Aph/f%ro0

    if (present(h0)) h0 = z0(4)**2
    if (present(jperp)) jperp = jperp_local
    if (present(psi_star)) psi_star = psi_star_local
  end subroutine encode_symplectic_state


  subroutine init_vmec(vmec_file, ans_s, ans_tp, amultharm, fper)
    use spline_vmec_sub, only : spline_vmec_data, volume_and_B00
    use vmecin_sub, only : stevvo

    character(*), intent(in) :: vmec_file
    integer, intent(in) :: ans_s, ans_tp, amultharm
    real(dp), intent(out) :: fper

    integer             :: L1i
    real(dp)    :: RT0, R0i, cbfi, bz0i, bf0, volume, B00

    ! TODO: Remove side effects
    netcdffile = vmec_file
    ns_s = ans_s
    ns_tp = ans_tp
    multharm = amultharm

    call spline_vmec_data ! initialize splines for VMEC field
    call stevvo(RT0, R0i, L1i, cbfi, bz0i, bf0) ! initialize periods and major radius
    fper = twopi/dble(L1i)   !<= field period
    print *, 'R0 = ', RT0, ' cm, fper = ', fper
    call volume_and_B00(volume,B00)
    print *,'volume = ',volume,' cm^3,  B_00 = ',B00,' G'
  end subroutine init_vmec


  subroutine init_params(self, Z_charge, m_mass, E_kin, npoints, store_step, relerr)
    ! Initializes normalization for velocity and Larmor radius based on kinetic energy
    ! of plasma particles (= temperature for thermal particles).
    use new_vmec_stuff_mod, only : rmajor

    type(tracer_t) :: self
    integer, intent(in), optional :: Z_charge, m_mass
    real(dp), intent(in), optional :: E_kin
    integer, intent(in), optional :: npoints  ! Integrator resolution. Number of
    ! integration points for strongly passing particles around the torus

    integer, intent(in), optional :: store_step       ! Store every X timesteps
    real(dp), intent(in), optional :: relerr  ! Relative error

    if (present(Z_charge)) self%n_e = Z_charge
    if (present(m_mass)) self%n_d = m_mass
    if (present(relerr)) self%relerr = relerr

    ! Neglect relativistic effects by large inverse relativistic temperature
    rmu=1d8

    ! Reference velocity and normalized Larmor radius
    if (present(E_kin)) then
      self%v0 = sqrt(2.d0*E_kin*ev/(self%n_d*p_mass))
    else
      self%v0 = sqrt(2.d0*3.5d6*ev/(self%n_d*p_mass))
    end if

    ! Larmor radius times magnetic field:
    ro0=self%v0*self%n_d*p_mass*c/(self%n_e*e_charge)

    if (present(npoints)) then
      self%dtaumin=twopi*rmajor*1.0d2/npoints
    else
      self%dtaumin=twopi*rmajor*1.0d2/256.0d0
    end if

   ! timestep where to get results
    if (present(store_step)) then
      self%dtau = store_step*self%dtaumin
    else
      self%dtau = self%dtaumin
    end if

  end subroutine init_params

  subroutine init_sympl(si, f, z0, dtau, dtaumin, rtol_init, mode_init)
    !
    type(symplectic_integrator_t), intent(inout) :: si
    type(field_can_t), intent(inout) :: f
    real(dp), intent(in) :: z0(:)
    real(dp), intent(in) :: dtau, dtaumin
    real(dp), intent(in) :: rtol_init
    integer, intent(in) :: mode_init ! 1 = expl.-impl. Euler, 2 = impl.-expl. Euler, 3 = Midpoint

    real(dp) :: z(4)

    if(min(dabs(mod(dtau, dtaumin)), dabs(mod(dtau, dtaumin)-dtaumin)) > 1d-9*dtaumin) then
      print *, 'dtau = ', dtau, ' dtaumin = ', dtaumin
      error stop 'orbit_sympl_init - error: dtau/dtaumin not integer'
    endif

    ! Initialize symplectic integrator
    si%pabs = z0(4)
    call encode_symplectic_state(f, z0, z)

    ! factor 1/sqrt(2) due to velocity normalisation different from other modules
    call orbit_sympl_init(si, f, z, dtaumin/dsqrt(2d0), nint(dtau/dtaumin), &
                          rtol_init, mode_init)
  end subroutine init_sympl

  subroutine reseed_sympl(si, f, z0, momentum_reference)
    !> Re-seed one particle's symplectic state from standard GC coordinates.
    !>
    !> Unlike init_sympl/orbit_sympl_init this routine does not select the
    !> module-global integration procedure. It is therefore safe to call from
    !> an OpenMP worker after a local RK recovery step: every write is confined
    !> to the caller's per-particle integrator and field objects.
    type(symplectic_integrator_t), intent(inout) :: si
    type(field_can_t), intent(inout) :: f
    real(dp), intent(in) :: z0(:)
    real(dp), intent(in), optional :: momentum_reference
    real(dp) :: z_seed(size(z0))

    z_seed = z0
    if (present(momentum_reference)) z_seed(4) = momentum_reference
    si%pabs = z_seed(4)
    call encode_symplectic_state(f, z_seed, si%z)
    call get_val(f, si%z(4))
    si%pthold = f%pth
    si%last_step_fraction = 1.d0
    si%last_event_radial_residual = 0.d0
    si%last_event_fraction_width = 0.d0
  end subroutine reseed_sympl

  ! Seed the full-orbit Boris pusher from a GC start record, same normalization and
  ! gyrophase reference as the symplectic GC seed so the two integrators start from
  ! the identical particle. fo_init places the Larmor offset itself.
  subroutine init_fo(fo, z0, dtaumin)
    use orbit_fo_field, only: fo_eval_field
    use params, only: orbit_coord
    type(fo_state_t), intent(out) :: fo
    real(dp), intent(in) :: z0(:)
    real(dp), intent(in) :: dtaumin
    real(dp) :: ro0_bar, mu, vpar_bar, vperp0
    real(dp) :: u_gc(3), Bmod, Acov(3), dA(3,3), dBmod(3), hcov(3)

    if (orbit_coord /= 1) error stop &
      'full-orbit tracing supports only orbit_coord=1 (Boozer)'
    if (z0(1) <= 0d0 .or. z0(1) >= 1d0) error stop &
      'full-orbit initialization requires 0 < s < 1'

    ! |B| at the guiding centre from the chartmap field (rho = sqrt(s)).
    u_gc = [dsqrt(z0(1)), z0(2), z0(3)]
    call fo_eval_field(u_gc, Acov, dA, Bmod, dBmod, hcov)
    mu = .5d0*z0(4)**2*(1.d0 - z0(5)**2)/Bmod*2d0
    ro0_bar = ro0/dsqrt(2d0)
    vpar_bar = z0(4)*z0(5)*dsqrt(2d0)
    vperp0 = dsqrt(max(2d0*mu*Bmod, 0d0))
    call fo_init(fo, z0(1:3), vpar_bar, vperp0, mu, 1d0, 1d0, &
      dtaumin/dsqrt(2d0), ro0_bar, z0(4))
  end subroutine init_fo

  ! Advance the full-orbit Boris pusher one normalized step and write back the
  ! standard SIMPLE z(1:5): z(1)=guiding-centre s, z(2:3)=angles, z(4)=pabs,
  ! z(5)=lambda. The step itself only locates the field (FO_OK / FO_LOCATE_FAIL);
  ! the ONLY confinement loss is the guiding centre crossing s>=1, decided in
  ! fo_to_gc (FO_LOSS -> ierr=2, counted fo_loss). A field-locate non-convergence
  ! (FO_LOCATE_FAIL -> ierr=3, counted fo_fault) is a numerical fault, reported
  ! but NEVER counted as a physical loss.
  subroutine orbit_timestep_fo(fo, z, ierr)
    use diag_counters, only: count_event, EVT_FO_LOSS, EVT_FO_FAULT
    use orbit_fo_boris, only: FO_OK, FO_LOSS
    type(fo_state_t), intent(inout) :: fo
    real(dp), intent(inout) :: z(:)
    integer, intent(out) :: ierr
    type(fo_state_t) :: fo_start
    real(dp) :: s, th, ph, vpar, z_start(size(z))
    integer :: status

    fo_start = fo
    z_start = z
    call fo_step(fo, status)
    if (status /= FO_OK) then
      ! Inversion unresolved (near-axis below chartmap resolution, or a field-period
      ! seam). NOT a physical loss; fo_step left the state at the last resolved
      ! position. Roll back both public and hidden pusher state so warning mode
      ! can consume a true held interval and retry from a meaningful position.
      fo = fo_start
      z = z_start
      ierr = ORBIT_FO_NUMERICAL
      call count_event(EVT_FO_FAULT)
      return
    end if
    call fo_to_gc(fo, s, th, ph, vpar, status)
    if (status == FO_LOSS) then
      z(1) = s
      z(2) = th
      z(3) = ph
      z(4) = fo%pabs
      z(5) = vpar/(z(4)*dsqrt(2d0))
      ierr = ORBIT_FO_LOSS
      call count_event(EVT_FO_LOSS)
      return
    else if (status /= FO_OK) then
      fo = fo_start
      z = z_start
      ierr = ORBIT_FO_NUMERICAL
      call count_event(EVT_FO_FAULT)
      return
    end if
    z(1) = s; z(2) = th; z(3) = ph
    z(4) = fo%pabs
    z(5) = vpar/(z(4)*dsqrt(2d0))
  end subroutine orbit_timestep_fo

  subroutine orbit_timestep_fo_bridge(fo, z, interval, ierr, continue_state)
    !> Advance one failed guiding-centre interval with the physical Cartesian
    !> Lorentz pusher. This is a narrow warning-mode bridge for reference fields
    !> that are already splined on the chartmap; normal GC trajectories never
    !> enter it. The Boris substeps resolve at most 0.1 rad of gyro-rotation.
    use orbit_fo_boris, only: fo_init_reference, fo_step, &
      fo_to_reference_gc, FO_OK, FO_LOSS
    use orbit_fo_field, only: fo_eval_reference_field, &
      fo_reference_field_available
    use field_can_mod, only: integ_to_ref, ref_to_integ
    type(fo_state_t), intent(inout) :: fo
    real(dp), intent(inout) :: z(5)
    real(dp), intent(in) :: interval
    integer, intent(out) :: ierr
    logical, intent(in), optional :: continue_state
    real(dp), parameter :: max_rotation_parameter = 0.05_dp
    integer, parameter :: max_substeps = 100000
    real(dp) :: z_start(5), u_gc(3), hcov(3), Bmod, mu
    real(dp) :: ro0_bar, vpar_bar, vperp, remaining, h, vpar_out
    integer :: status, nstep
    logical :: continuing

    z_start = z
    ierr = 2
    continuing = .false.
    if (present(continue_state)) continuing = continue_state
    if (.not. fo_reference_field_available()) return
    if (z(4) <= 0.0_dp .or. abs(z(5)) > 1.0_dp) return

    ro0_bar = ro0/sqrt(2.0_dp)
    if (.not. continuing) then
      call integ_to_ref(z(1:3), u_gc)
      if (u_gc(1) <= 0.0_dp .or. u_gc(1) >= 1.0_dp) return
      call fo_eval_reference_field(u_gc, hcov, Bmod, status)
      if (status /= 0 .or. Bmod <= 0.0_dp) return

      mu = z(4)**2*(1.0_dp - z(5)**2)/Bmod
      vpar_bar = sqrt(2.0_dp)*z(4)*z(5)
      vperp = sqrt(max(2.0_dp*mu*Bmod, 0.0_dp))
      call fo_init_reference(fo, u_gc, vpar_bar, vperp, mu, 1.0_dp, &
        1.0_dp, 0.0_dp, ro0_bar, z(4))
    else if (.not. fo%reference_field) then
      return
    end if

    remaining = abs(interval)/sqrt(2.0_dp)
    do nstep = 1, max_substeps
      if (remaining <= epsilon(1.0_dp)*max(abs(interval), 1.0_dp)) exit
      call fo_eval_reference_field(fo%u, hcov, Bmod, status)
      if (status /= 0 .or. Bmod <= 0.0_dp) then
        z = z_start
        return
      end if
      h = min(remaining, 2.0_dp*max_rotation_parameter*ro0_bar/Bmod)
      fo%dt = sign(h, interval)
      call fo_step(fo, status)
      if (status /= FO_OK) then
        z = z_start
        return
      end if
      remaining = remaining - h
    end do
    if (remaining > epsilon(1.0_dp)*max(abs(interval), 1.0_dp)) then
      z = z_start
      return
    end if

    call fo_to_reference_gc(fo, u_gc, vpar_out, status)
    if (status /= FO_OK .and. status /= FO_LOSS) then
      z = z_start
      return
    end if
    call ref_to_integ(u_gc, z(1:3))
    z(4) = fo%pabs
    z(5) = vpar_out/(sqrt(2.0_dp)*z(4))
    if (status == FO_LOSS) then
      ierr = 1
    else
      ierr = 0
    end if
  end subroutine orbit_timestep_fo_bridge

  subroutine timestep(self, s, th, ph, lam, ierr)
    type(tracer_t), intent(inout) :: self
    real(dp), intent(inout) :: s, th, ph, lam
    integer, intent(out) :: ierr

    real(dp), dimension(5) :: z

    z(1) = s
    z(2) = th
    z(3) = ph
    z(4) = 1d0
    z(5) = lam

    call timestep_z(self, z, ierr)

    s = z(1)
    th = z(2)
    ph = z(3)
    lam = z(5)
  end subroutine timestep

  subroutine timestep_z(self, z, ierr)
    use alpha_lifetime_sub, only : orbit_timestep_axis

    type(tracer_t), intent(inout) :: self
    real(dp), intent(inout) :: z(:)
    integer, intent(out) :: ierr

    call orbit_timestep_axis(z, self%dtau, self%dtau, self%relerr, ierr)
  end subroutine timestep_z

  subroutine timestep_sympl_z(si, f, z, ierr)
    type(symplectic_integrator_t), intent(inout) :: si
    type(field_can_t), intent(inout) :: f
    real(dp), intent(inout) :: z(:)
    integer, intent(out) :: ierr

    if (z(1) < 0.0 .or. z(1) > 1.0) then
      ierr = 1
      return
    end if

    call orbit_timestep_sympl(si, f, ierr)

    z(1:3) = si%z(1:3)
    z(5) = f%vpar/(si%pabs*dsqrt(2d0))  ! alambda

  end subroutine timestep_sympl_z

end module simple
