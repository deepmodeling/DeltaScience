module field_can_meiss
    !> Meiss canonical coordinates for magnetic field evaluation.
    !>
    !> This module implements Meiss-type canonical coordinates (r, theta_c, phi_c)
    !> where the magnetic field has the simple covariant form h = (0, hth, hph).
    !> The transformation to canonical coordinates is computed via ODE integration.
    !>
    !> Coordinate conventions:
    !>   - r: Integrator radial coordinate (= sqrt(s) by default)
    !>   - theta_c, phi_c: Canonical poloidal and toroidal angles
    !>   - s: Reference flux coordinate (normalized toroidal flux)
    !>
    !> Field source handling:
    !>   - vmec_field_t: Expects s-coordinates, returns components in s-coords.
    !>     This module converts r->s and applies Jacobian ds/dr = 2r.
    !>   - splined_field_t and others: Expected to operate in r-coordinates
    !>     directly, no coordinate transformation needed.
    !>
    !> The coordinate_scaling abstraction (default: sqrt_s_scaling_t) handles
    !> the s <-> r transformation systematically.
    !>
    !> Key subroutines:
    !>   - init_meiss: Initialize with field source and grid parameters
    !>   - get_meiss_coordinates: Build canonical coordinate transformation
    !>   - evaluate_meiss: Fast splined field evaluation in canonical coords
    !>   - cleanup_meiss: Release resources
    !>
    !> Related modules:
    !>   - field_can_albert: Extends Meiss with psi-based radial coordinate
    !>   - coordinate_scaling: Abstraction for s <-> r transforms

use, intrinsic :: iso_fortran_env, only : dp => real64
use interpolate, only : &
    BatchSplineData3D, construct_batch_splines_3d, &
    evaluate_batch_splines_3d, evaluate_batch_splines_3d_der, &
    evaluate_batch_splines_3d_der2
use util, only : twopi
use field_can_base, only : field_can_t, n_field_evaluations
    use field, only : magnetic_field_t, vmec_field_t, field_clone
    use field_splined, only: splined_field_t
    use field_spectre, only: spectre_field_t
    use coordinate_scaling, only : coordinate_scaling_t, sqrt_s_scaling_t, &
                                   identity_scaling_t, coordinate_scaling_clone
    use libneo_coordinates, only: chartmap_coordinate_system_t, UNKNOWN, &
                                  RHO_TOR, RHO_POL, PSI_TOR_NORM, PSI_POL_NORM

implicit none

type :: grid_indices_t
    integer :: i_th, i_phi
end type grid_indices_t

class(magnetic_field_t), allocatable :: field_noncan
integer, parameter :: default_n_r = 62, default_n_th = 63, default_n_phi = 64
real(dp), parameter :: default_transformation_relerr = 1d-11
real(dp), parameter :: default_xmin(3) = [1d-6, 0d0, 0d0]
integer :: n_r=default_n_r, n_th=default_n_th, n_phi=default_n_phi
real(dp) :: transformation_relerr = default_transformation_relerr
real(dp) :: xmin(3) = default_xmin
real(dp) :: xmax(3) = [1d0, twopi, twopi]

real(dp) :: h_r, h_th, h_phi

! Batch spline for optimized field evaluation (5 components: Ath, Aph, hth, hph, Bmod)
type(BatchSplineData3D) :: spl_field_batch
logical :: batch_splines_initialized = .false.

! For splining lambda (difference between canonical and toroidal cylinder angle)
! and chi (gauge transformation)
real(dp), dimension(:,:,:), allocatable :: lam_phi, chi_gauge
! Batch spline for transformation components (2 components: lam_phi, chi_gauge)
type(BatchSplineData3D) :: spl_transform_batch
logical :: transform_splines_initialized = .false.

integer, parameter :: default_spline_order = 5
integer, parameter :: default_ode_step_limit = 1000000
integer :: order(3) = [default_spline_order, default_spline_order, &
                       default_spline_order]
integer :: ode_step_limit = default_ode_step_limit
logical, parameter :: periodic(3) = [.False., .True., .True.]

! Coordinate scaling for s <-> r transform (default: r = sqrt(s))
class(coordinate_scaling_t), allocatable :: coord_scaling

! Caller-owned harvest of one Meiss construction. field_can_spectre keeps one per
! SPECTRE volume; harvest_meiss_volume moves the module-level splines into a slot.
type :: meiss_volume_t
    type(BatchSplineData3D) :: spl_field
    type(BatchSplineData3D) :: spl_transform
    class(coordinate_scaling_t), allocatable :: scaling
    real(dp) :: rmin
    real(dp) :: rmax
end type meiss_volume_t

contains

subroutine harvest_meiss_volume(vol)
    !> Move the current module-level construction (field and transform batch
    !> splines, radial domain, scaling) into a caller-owned slot. The batch spline
    !> coefficient arrays are moved, not copied; the module init flags are cleared
    !> so a following cleanup_meiss or construction re-uses the freed slots.
    type(meiss_volume_t), intent(out) :: vol

    call move_batch_spline_3d(spl_field_batch, vol%spl_field)
    call move_batch_spline_3d(spl_transform_batch, vol%spl_transform)
    batch_splines_initialized = .false.
    transform_splines_initialized = .false.

    call coordinate_scaling_clone(coord_scaling, vol%scaling)
    vol%rmin = xmin(1)
    vol%rmax = xmax(1)
end subroutine harvest_meiss_volume


subroutine move_batch_spline_3d(src, dst)
    type(BatchSplineData3D), intent(inout) :: src
    type(BatchSplineData3D), intent(out) :: dst

    dst%order = src%order
    dst%num_points = src%num_points
    dst%periodic = src%periodic
    dst%h_step = src%h_step
    dst%x_min = src%x_min
    dst%inv_h_step = src%inv_h_step
    dst%period = src%period
    dst%num_quantities = src%num_quantities
    call move_alloc(src%coeff, dst%coeff)
end subroutine move_batch_spline_3d

subroutine rh_can_wrapper(r_c, z, dz, context)
    real(dp), intent(in) :: r_c
    real(dp), dimension(:), intent(in) :: z
    real(dp), dimension(:), intent(out) :: dz
    class(*), intent(in) :: context
    
    integer :: i_th, i_phi
    
    select type(context)
    type is (grid_indices_t)
        i_th = context%i_th
        i_phi = context%i_phi
    end select
    
    call rh_can(r_c, z, dz, i_th, i_phi)
end subroutine rh_can_wrapper

subroutine init_meiss(field_noncan_, n_r_, n_th_, n_phi_, rmin, rmax, thmin, thmax, &
                      scaling, transformation_relerr_, spline_order_, ode_step_limit_)
    use, intrinsic :: ieee_arithmetic, only: ieee_is_finite
    use, intrinsic :: iso_fortran_env, only: int64
    use new_vmec_stuff_mod, only : nper

    class(magnetic_field_t), intent(in) :: field_noncan_
    integer, intent(in), optional :: n_r_, n_th_, n_phi_
    real(dp), intent(in), optional :: rmin, rmax, thmin, thmax
    class(coordinate_scaling_t), intent(in), optional :: scaling
    real(dp), intent(in), optional :: transformation_relerr_
    integer, intent(in), optional :: spline_order_
    integer, intent(in), optional :: ode_step_limit_

    call cleanup_meiss
    call field_clone(field_noncan_, field_noncan)

    ! Initialize coordinate scaling based on field type
    if (allocated(coord_scaling)) deallocate(coord_scaling)
    if (present(scaling)) then
        call coordinate_scaling_clone(scaling, coord_scaling)
    else
        ! Choose scaling based on field's coordinate system:
        ! - VMEC field: uses s-coordinates, needs sqrt_s_scaling (r = sqrt(s))
        ! - Splined field with RHO_TOR/RHO_POL: uses rho = sqrt(s), needs sqrt_s_scaling
        ! - Splined field with UNKNOWN/geometric: uses geometric rho, needs identity_scaling
        ! - Splined field with PSI_TOR_NORM: uses s-coordinates, needs sqrt_s_scaling
        call choose_default_scaling(field_noncan_, coord_scaling)
    end if

    n_r = default_n_r
    n_th = default_n_th
    n_phi = default_n_phi
    transformation_relerr = default_transformation_relerr
    order = default_spline_order
    ode_step_limit = default_ode_step_limit
    xmin = default_xmin
    xmax = [1d0, twopi, twopi/nper]
    if (present(n_r_)) n_r = n_r_
    if (present(n_th_)) n_th = n_th_
    if (present(n_phi_)) n_phi = n_phi_
    if (present(spline_order_)) order = spline_order_
    if (present(ode_step_limit_)) ode_step_limit = ode_step_limit_
    if (any(order < 3) .or. any(order > 5)) then
        error stop 'canonical map spline order must be between 3 and 5'
    end if
    if (ode_step_limit < 1) error stop 'canonical map ODE step limit must be positive'
    if (any([n_r, n_th, n_phi] < order + 1)) then
        error stop 'canonical map grid dimensions must exceed the spline order'
    end if
    if (max(n_r, n_th, n_phi) > 512) then
        error stop 'canonical map grid dimensions must not exceed 512'
    end if
    if (int(n_r, int64)*int(n_th, int64)*int(n_phi, int64) > 2097152_int64) then
        error stop 'canonical map grid exceeds the 2097152-point limit'
    end if
    if (present(transformation_relerr_)) then
        if (.not. ieee_is_finite(transformation_relerr_) .or. &
            transformation_relerr_ <= 0d0) then
            error stop 'canonical map ODE tolerance must be finite and positive'
        end if
        transformation_relerr = transformation_relerr_
    end if

    if (present(rmin)) xmin(1) = rmin
    if (present(rmax)) xmax(1) = rmax
    if (present(thmin)) xmin(2) = thmin
    if (present(thmax)) xmax(2) = thmax
    h_r = (xmax(1)-xmin(1))/(n_r-1)
    h_th = (xmax(2)-xmin(2))/(n_th-1)
    h_phi = (xmax(3)-xmin(3))/(n_phi-1)
end subroutine init_meiss


subroutine choose_default_scaling(field, scaling)
    !> Choose appropriate coordinate scaling based on field type.
    !>
    !> Scaling determines how the Meiss integrator coordinate r relates to flux:
    !>   - sqrt_s_scaling: r = sqrt(s), use when field is in s-coordinates (VMEC)
    !>   - identity_scaling: r = rho directly, use when field is already in rho coords
    !>
    !> For VMEC source field: uses sqrt_s_scaling (convert s -> r = sqrt(s))
    !> For RHO_TOR/RHO_POL chartmap: uses identity (rho IS sqrt(s))
    !> For PSI_TOR_NORM/PSI_POL_NORM: uses sqrt_s (convert s -> r = sqrt(s))
    !> For UNKNOWN (geometric): uses identity (rho is geometric)
    class(magnetic_field_t), intent(in) :: field
    class(coordinate_scaling_t), allocatable, intent(out) :: scaling

    logical :: use_identity

    use_identity = .false.

    select type (fld => field)
    type is (splined_field_t)
        select type (cs => fld%coords)
        class is (chartmap_coordinate_system_t)
            ! RHO_TOR/RHO_POL: rho = sqrt(s), already in Meiss integrator coords
            ! UNKNOWN: geometric rho, no flux meaning, use directly
            ! PSI_TOR_NORM/PSI_POL_NORM: rho = s, needs sqrt transform
            if (cs%rho_convention == RHO_TOR .or. &
                cs%rho_convention == RHO_POL .or. &
                cs%rho_convention == UNKNOWN) then
                use_identity = .true.
            end if
        end select
    end select

    if (use_identity) then
        allocate(identity_scaling_t :: scaling)
    else
        allocate(sqrt_s_scaling_t :: scaling)
    end if
end subroutine choose_default_scaling


subroutine cleanup_meiss()
    ! Clean up batch splines to prevent memory leaks
    use interpolate, only: destroy_batch_splines_3d
    
    if (batch_splines_initialized) then
        call destroy_batch_splines_3d(spl_field_batch)
        batch_splines_initialized = .false.
    end if
    
    if (transform_splines_initialized) then
        call destroy_batch_splines_3d(spl_transform_batch)
        transform_splines_initialized = .false.
    end if
    
    ! Clean up allocated arrays
    if (allocated(lam_phi)) deallocate(lam_phi)
    if (allocated(chi_gauge)) deallocate(chi_gauge)
    if (allocated(field_noncan)) deallocate(field_noncan)
    if (allocated(coord_scaling)) deallocate(coord_scaling)
end subroutine cleanup_meiss


subroutine evaluate_meiss(f, r, th_c, ph_c, mode_secders)
    type(field_can_t), intent(inout) :: f
    real(dp), intent(in) :: r, th_c, ph_c
    integer, intent(in) :: mode_secders

    real(dp) :: x(3)

    n_field_evaluations = n_field_evaluations + 1

    x = [r, th_c, ph_c]

    if (mode_secders > 0) then
        call evaluate_meiss_batch_der2(f, x)
        return
    end if

    call evaluate_meiss_batch_der(f, x)
end subroutine evaluate_meiss


subroutine integ_to_ref_meiss(xinteg, xref)
    real(dp), intent(in) :: xinteg(3)
    real(dp), intent(out) :: xref(3)
    real(dp) :: y_batch(2)  ! lam_phi, chi_gauge

    call evaluate_batch_splines_3d(spl_transform_batch, xinteg, y_batch)
    call coord_scaling%inverse(xinteg, xref)  ! r -> s (integrator -> reference)
    xref(2) = modulo(xinteg(2), twopi)
    xref(3) = modulo(xinteg(3) + y_batch(1), twopi)  ! y_batch(1) is lam_phi
end subroutine integ_to_ref_meiss


subroutine ref_to_integ_meiss(xref, xinteg)
    real(dp), intent(in) :: xref(3)
    real(dp), intent(out) :: xinteg(3)

    real(dp), parameter :: TOL = 1d-12
    integer, parameter :: MAX_ITER = 16

    real(dp) :: y_batch(2), dy_batch(3, 2), phi_integ_prev
    integer :: i

    call coord_scaling%transform(xref, xinteg)  ! s -> r (reference -> integrator)
    xinteg(2) = modulo(xref(2), twopi)
    xinteg(3) = modulo(xref(3), twopi)

    do i=1, MAX_ITER
        call evaluate_batch_splines_3d_der(spl_transform_batch, xinteg, y_batch, dy_batch)
        phi_integ_prev = xinteg(3)
        ! y_batch(1) is lam_phi, dy_batch(3,1) is d(lam_phi)/d(phi)
        xinteg(3) = phi_integ_prev - (phi_integ_prev + y_batch(1) - xref(3))/(1d0 + dy_batch(3,1))
        if (abs(xinteg(3) - phi_integ_prev) < TOL) return
    enddo
    print *, 'WARNING: ref_to_integ_meiss did not converge after', MAX_ITER, 'iterations'
end subroutine ref_to_integ_meiss


subroutine get_meiss_coordinates(ierr)
    integer, intent(out), optional :: ierr
    integer :: status

#ifdef SIMPLE_ENABLE_DEBUG_OUTPUT
    print *, 'field_can_meiss.init_transformation'
#endif
    call init_transformation(status)
    if (status /= 0) then
        call cleanup_meiss
        if (present(ierr)) then
            ierr = status
            return
        end if
        error stop 'Meiss transformation ODE failed'
    end if

#ifdef SIMPLE_ENABLE_DEBUG_OUTPUT
    print *, 'field_can_meiss.spline_transformation'
#endif
    call spline_transformation

#ifdef SIMPLE_ENABLE_DEBUG_OUTPUT
    print *, 'field_can_meiss.init_canonical_field_components'
#endif
    call init_canonical_field_components
    if (present(ierr)) ierr = 0
end subroutine get_meiss_coordinates


subroutine init_transformation(ierr)
    integer, intent(out), optional :: ierr
    integer :: status

    call init_transformation_arrays()
    call compute_transformation(status)
    if (present(ierr)) then
        ierr = status
    else if (status /= 0) then
        error stop 'Meiss transformation ODE failed'
    end if
end subroutine init_transformation

subroutine init_transformation_arrays()
!> Initialize transformation arrays - can be called separately for diagnostics
    if (allocated(lam_phi)) deallocate(lam_phi)
    if (allocated(chi_gauge)) deallocate(chi_gauge)
    allocate(lam_phi(n_r, n_th, n_phi), chi_gauge(n_r, n_th, n_phi))
    
    ! Initialize to zero (boundary conditions)
    lam_phi = 0.0_dp
    chi_gauge = 0.0_dp
end subroutine init_transformation_arrays

subroutine compute_transformation(ierr)
!> Compute transformation data via integration (expensive operation)
    integer, intent(out) :: ierr
    integer :: i_ctr
    integer, allocatable :: slice_status(:)
    logical :: parallel_slices

    i_ctr = 0
    allocate(slice_status(n_phi), source=0)
    parallel_slices = .true.
    select type (field_noncan)
    type is (spectre_field_t)
        parallel_slices = .false.
    end select

    if (parallel_slices) then
        !$omp parallel do private(i_ctr)
        do i_ctr = 1, n_phi
            call compute_phi_slice(i_ctr, slice_status(i_ctr))
        end do
        !$omp end parallel do
    else
        do i_ctr = 1, n_phi
            call compute_phi_slice(i_ctr, slice_status(i_ctr))
        end do
    end if
    ierr = maxval(slice_status)
end subroutine compute_transformation

subroutine compute_phi_slice(i_phi, ierr)
!> Compute transformation for single phi slice
    integer, intent(in) :: i_phi
    integer, intent(out) :: ierr
    real(dp) :: y(2)
    integer :: i_th

#ifdef SIMPLE_ENABLE_DEBUG_OUTPUT
    call print_progress(i_phi)
#endif
    
    ierr = 0
    do i_th = 1, n_th
        lam_phi(1, i_th, i_phi) = 0d0
        chi_gauge(1, i_th, i_phi) = 0d0
        y = 0d0
        
        if (is_hr_zero_on_slice(i_th, i_phi)) then
            call set_identity_slice(i_th, i_phi)
        else
            call integrate_radial_slice(i_th, i_phi, y, ierr)
            if (ierr /= 0) return
        endif
    enddo
end subroutine compute_phi_slice

subroutine set_identity_slice(i_th, i_phi)
!> Set identity transformation for radial slice where hr ≈ 0
    integer, intent(in) :: i_th, i_phi
    integer :: i_r
    
    do i_r = 2, n_r
        lam_phi(i_r, i_th, i_phi) = 0d0
        chi_gauge(i_r, i_th, i_phi) = 0d0
    enddo
end subroutine set_identity_slice

subroutine integrate_radial_slice(i_th, i_phi, y, ierr)
!> Integrate along radial direction for given (i_th, i_phi)
    integer, intent(in) :: i_th, i_phi
    real(dp), intent(inout) :: y(2)
    integer, intent(out) :: ierr
    integer :: i_r

    ierr = 0
    do i_r = 2, n_r
        call integrate(i_r, i_th, i_phi, y, ierr)
        if (ierr /= 0) then
            write (*, '(A,I0,A,I0,A,I0)') 'Meiss ODE failed at r index ', i_r, &
                ', theta index ', i_th, ', phi index ', i_phi
            return
        end if
    enddo
end subroutine integrate_radial_slice

subroutine print_progress(i_phi)
!> Print integration progress
    integer, intent(in) :: i_phi
    
#ifndef SIMPLE_ENABLE_DEBUG_OUTPUT
    return
#endif

    !$omp critical
    write(*,'(A, I4, A, I4)',advance='no') 'integrate ODE: ', i_phi, ' of ', n_phi
    if (i_phi < n_phi) then
        write(*, '(A)', advance="no") char(13)
    else
        write(*, *)
    end if
    !$omp end critical
end subroutine print_progress

subroutine integrate(i_r, i_th, i_phi, y, ierr)
    use odeint_allroutines_sub, only: odeint_allroutines

    integer, intent(in) :: i_r, i_th, i_phi
    real(dp), dimension(2), intent(inout) :: y
    integer, intent(out) :: ierr

    integer, parameter :: ndim = 2
    real(dp) :: r1, r2
    real(dp) :: relaxed_relerr
    type(grid_indices_t) :: context
#ifdef SIMPLE_NVHPC
    real(dp), parameter :: hp_threshold = 1d-12
    real(dp) :: phi_c, Ar_test, Ap_test, hr_test, hp_test
#endif

    r1 = xmin(1) + h_r*(i_r-2)
    r2 = xmin(1) + h_r*(i_r-1)

    relaxed_relerr = transformation_relerr

#ifdef SIMPLE_NVHPC
    ! NVHPC/nvfortran: avoid ODE step-size underflow near singular points by
    ! relaxing tolerance when hp is very small at the start of the step.
    phi_c = xmin(3) + h_phi*(i_phi-1)
    call ah_cov_on_slice(r1, modulo(phi_c + y(1), twopi), i_th, Ar_test, Ap_test, hr_test, hp_test)
    if (abs(hp_test) < hp_threshold) then
        relaxed_relerr = max(transformation_relerr, 1d-8)
    end if
#endif

    context = grid_indices_t(i_th, i_phi)
    call odeint_allroutines(y, ndim, context, r1, r2, relaxed_relerr, &
                            rh_can_wrapper, step_limit=ode_step_limit, ierr=ierr)
    if (ierr /= 0) return

    lam_phi(i_r, i_th, i_phi) = y(1)
    chi_gauge(i_r, i_th, i_phi) = y(2)

end subroutine integrate

subroutine rh_can(r_c, z, dz, i_th, i_phi)
    real(dp), intent(in) :: r_c
    real(dp), dimension(2), intent(in) :: z  ! lam_phi, chi_gauge
    real(dp), dimension(2), intent(out) :: dz
    integer, intent(in) :: i_th, i_phi
    real(dp) :: phi_c
    real(dp) :: Ar, Ap, hr, hp
    real(dp), parameter :: hp_min = 1d-14
    real(dp) :: hp_safe

    phi_c = xmin(3) + h_phi*(i_phi-1)
    call ah_cov_on_slice(r_c, modulo(phi_c + z(1), twopi), i_th, Ar, Ap, hr, hp)

    hp_safe = hp
    if (abs(hp_safe) < hp_min) then
        hp_safe = sign(hp_min, hp_safe + 0.5d0*hp_min)
    end if

    dz(1) = -hr / hp_safe
    dz(2) = Ar + Ap * dz(1)
end subroutine rh_can


subroutine spline_transformation
    real(dp), dimension(:,:,:,:), allocatable :: y_batch
    integer :: dims(3)
    
    ! Construct batch spline for transformation components (2: lam_phi, chi_gauge)
    dims = shape(lam_phi)
    allocate(y_batch(dims(1), dims(2), dims(3), 2))
    
    y_batch(:,:,:,1) = lam_phi
    y_batch(:,:,:,2) = chi_gauge
    
    call construct_batch_splines_3d(xmin, xmax, y_batch, order, periodic, spl_transform_batch)
    transform_splines_initialized = .true.
end subroutine spline_transformation


subroutine ah_cov_on_slice(r, phi, i_th, Ar, Ap, hr, hp)
    real(dp), intent(in) :: r, phi
    integer, intent(in) :: i_th
    real(dp), intent(out) :: Ar, Ap, hr, hp

    real(dp), dimension(3) :: Acov, hcov, x_integ, x_ref, jac
    real(dp) :: Bmod
    real(dp) :: th

    th = xmin(2) + h_th*(i_th-1)
    x_integ = [r, th, phi]

    select type (fld => field_noncan)
    type is (vmec_field_t)
        ! VMEC field expects s-coordinates, so convert r->s and apply Jacobian
        call coord_scaling%inverse(x_integ, x_ref, jac)
        call fld%evaluate(x_ref, Acov, hcov, Bmod)
        ! Convert output from s-coords to r-coords: A_r = A_s * ds/dr
        Ar = Acov(1) * jac(1)
        Ap = Acov(3)
        hr = hcov(1) * jac(1)
        hp = hcov(3)
    type is (splined_field_t)
        ! Splined field already stores data in scaled coordinates (r = sqrt(s))
        ! matching the Meiss integrator coordinates - no conversion needed
        call fld%evaluate(x_integ, Acov, hcov, Bmod)
        Ar = Acov(1)
        Ap = Acov(3)
        hr = hcov(1)
        hp = hcov(3)
    type is (spectre_field_t)
        ! SPECTRE chart (rho_g, theta, zeta) with identity scaling; covariant
        ! components are used raw in SI, the Gaussian-CGS conversion is applied at
        ! canonical evaluation. Here h_s = hcov(1) is nonzero (the reason the Meiss
        ! angle transform is required), while A_s = Acov(1) = 0 in the SPECTRE gauge.
        call bias_spectre_upper_endpoint(fld, x_integ)
        call fld%evaluate(x_integ, Acov, hcov, Bmod)
        Ar = Acov(1)
        Ap = Acov(3)
        hr = hcov(1)
        hp = hcov(3)
    class default
        error stop "ah_cov_on_slice: unsupported field type"
    end select
end subroutine ah_cov_on_slice

logical function is_hr_zero_on_slice(i_th, i_phi) result(is_zero)
!> Check if hr ≈ 0 along the entire radial direction for given (i_th, i_phi)
!> Sample hr at several radial points to make this determination
    integer, intent(in) :: i_th, i_phi
    
    real(dp), parameter :: hr_slice_threshold = 1d-9
    integer, parameter :: n_sample_points = 32
    real(dp) :: r_sample, phi_c, Ar, Ap, hr, hp
    integer :: i_sample
    logical :: all_zero
    
    phi_c = xmin(3) + h_phi*(i_phi-1)
    all_zero = .true.
    
    ! Sample hr at several radial points
    do i_sample = 1, n_sample_points
        ! Distribute sample points across radial range
        r_sample = xmin(1) + (xmax(1) - xmin(1)) * real(i_sample-1, dp) / real(n_sample_points-1, dp)
        
        ! Evaluate field at this point (using lam_phi=0 for sampling)
        call ah_cov_on_slice(r_sample, phi_c, i_th, Ar, Ap, hr, hp)
        
        if (abs(hr) >= hr_slice_threshold) then
            all_zero = .false.
            exit  ! Found non-zero hr, no need to check further
        endif
    enddo
    
    is_zero = all_zero
end function is_hr_zero_on_slice


subroutine init_canonical_field_components
    real(dp) :: xcan(3)
    real(dp), dimension(:,:,:,:), allocatable :: y_batch
    real(dp) :: xref(3), Acov(3), hcov(3), Bmod, lam, dlam(3), chi, dchi(3)
    integer :: i_r, i_th, i_phi

    if (allocated(lam_phi)) deallocate(lam_phi)
    if (allocated(chi_gauge)) deallocate(chi_gauge)
    allocate(y_batch(n_r, n_th, n_phi, 5))

    do i_phi=1,n_phi
        do i_th=1,n_th
            do i_r=1,n_r
                xcan = get_grid_point(i_r, i_th, i_phi)

                ! Use batch evaluation for both transformation components
                block
                    real(dp) :: y_trans(2), dy_trans(3,2)
                    call evaluate_batch_splines_3d_der(spl_transform_batch, xcan, y_trans, dy_trans)
                    lam = y_trans(1)    ! lam_phi
                    chi = y_trans(2)    ! chi_gauge  
                    dlam = dy_trans(:,1)  ! derivatives of lam_phi
                    dchi = dy_trans(:,2)  ! derivatives of chi_gauge
                end block

                ! xcan is in integrator coords (r, th, phi)
                ! xref here is the non-canonical angle coords (th, phi + lam)
                xref = [xcan(1), modulo(xcan(2), twopi), modulo(xcan(3) + lam, twopi)]

                select type (fld => field_noncan)
                type is (vmec_field_t)
                    ! VMEC field expects s-coordinates
                    block
                        real(dp) :: x_integ_local(3), x_ref_local(3), jac_local(3)
                        x_integ_local = xref
                        call coord_scaling%inverse(x_integ_local, x_ref_local, jac_local)
                        call fld%evaluate(x_ref_local, Acov, hcov, Bmod)
                    end block
                type is (splined_field_t)
                    ! Splined field already in scaled coordinates
                    call fld%evaluate(xref, Acov, hcov, Bmod)
                type is (spectre_field_t)
                    ! SPECTRE chart is its own radial coordinate (identity scaling)
                    call bias_spectre_upper_endpoint(fld, xref)
                    call fld%evaluate(xref, Acov, hcov, Bmod)
                class default
                    error stop "init_canonical_field_components: unsupported field type"
                end select

                ! Note: We only use theta/phi components of Acov/hcov below

                y_batch(i_r, i_th, i_phi, 1) = &
                    Acov(2) + Acov(3)*dlam(2) - dchi(2)
                y_batch(i_r, i_th, i_phi, 2) = &
                    Acov(3)*(1.0d0 + dlam(3)) - dchi(3)
                y_batch(i_r, i_th, i_phi, 3) = hcov(2) + hcov(3)*dlam(2)
                y_batch(i_r, i_th, i_phi, 4) = hcov(3)*(1.0d0 + dlam(3))
                y_batch(i_r, i_th, i_phi, 5) = Bmod
            end do
        end do
    end do

    call construct_batch_splines_3d(xmin, xmax, y_batch, order, periodic, spl_field_batch)
    batch_splines_initialized = .true.
end subroutine init_canonical_field_components


subroutine bias_spectre_upper_endpoint(field, x)
    type(spectre_field_t), intent(in) :: field
    real(dp), intent(inout) :: x(3)

    ! Exact stacked interfaces belong to the outer volume. A lower-volume
    ! construction must sample its upper endpoint as the one-sided inner limit.
    if (x(1) >= xmax(1) .and. xmax(1) < real(field%data%Mvol, dp)) then
        x(1) = nearest(xmax(1), -1.0_dp)
    end if
end subroutine bias_spectre_upper_endpoint


pure function get_grid_point(i_r, i_th, i_phi)
    integer, intent(in) :: i_r, i_th, i_phi
    real(dp) :: get_grid_point(3)

    get_grid_point = [ &
        xmin(1) + h_r*dble(i_r-1), &
        xmin(2) + h_th*dble(i_th-1), &
        xmin(3) + h_phi*dble(i_phi-1) &
    ]
end function get_grid_point


subroutine magfie_meiss(x,bmod,sqrtg,bder,hcovar,hctrvr,hcurl)
!  Computes magnetic field and derivatives with bmod in units of the magnetic code
!
!  Input parameters:
!            formal:  x               - array of canonicalized coordinates r, th, ph
!  Output parameters:
!            formal:  bmod            - magnetic field module
!                     sqrtg           - metric determinant
!                     bder            - covariant components of (grad B)/B
!                     hcovar          - covariant components of \bB/B
!                     hctrvr          - contravariant components of \bB/B
!                     hcurl           - contravariant components of curl (\bB/B)
    real(dp), intent(in) :: x(3)
    real(dp), intent(out) :: bmod, sqrtg
    real(dp), dimension(3), intent(out) :: bder, hcovar, hctrvr, hcurl

    type(field_can_t) :: f
    real(dp) :: sqrtg_bmod

    call evaluate_meiss(f, x(1), x(2), x(3), 0)

    bmod = f%Bmod

    sqrtg_bmod = f%hph*f%dAth(1) - f%hth*f%dAph(1)
    sqrtg = sqrtg_bmod/bmod
    bder = f%dBmod/bmod

    hcovar(1) = 0d0
    hcovar(2) = f%hth
    hcovar(3) = f%hph

    hctrvr(1) = (f%dAph(2) - f%dAth(3))/sqrtg_bmod
    hctrvr(2) = -f%dAph(1)/sqrtg_bmod
    hctrvr(3) = f%dAth(1)/sqrtg_bmod

    hcurl(1) = (f%dhph(2) - f%dhth(3))/sqrtg
    hcurl(2) = -f%dhph(1)/sqrtg
    hcurl(3) = f%dhth(1)/sqrtg
end subroutine magfie_meiss


! Batch evaluation helper for first derivatives
subroutine evaluate_meiss_batch_der(f, x)
    type(field_can_t), intent(inout) :: f
    real(dp), intent(in) :: x(3)
    
    real(dp) :: y_batch(5), dy_batch(3, 5)
    
    call evaluate_batch_splines_3d_der(spl_field_batch, x, y_batch, dy_batch)
    
    ! Unpack results: order is [Ath, Aph, hth, hph, Bmod]
    f%Ath = y_batch(1)
    f%Aph = y_batch(2) 
    f%hth = y_batch(3)
    f%hph = y_batch(4)
    f%Bmod = y_batch(5)
    
    f%dAth = dy_batch(:, 1)
    f%dAph = dy_batch(:, 2)
    f%dhth = dy_batch(:, 3)
    f%dhph = dy_batch(:, 4)
    f%dBmod = dy_batch(:, 5)
end subroutine evaluate_meiss_batch_der


! Batch evaluation helper for second derivatives  
subroutine evaluate_meiss_batch_der2(f, x)
    type(field_can_t), intent(inout) :: f
    real(dp), intent(in) :: x(3)
    
    real(dp) :: y_batch(5), dy_batch(3, 5), d2y_batch(6, 5)
    
    call evaluate_batch_splines_3d_der2(spl_field_batch, x, y_batch, dy_batch, d2y_batch)
    
    ! Unpack results: order is [Ath, Aph, hth, hph, Bmod]
    f%Ath = y_batch(1)
    f%Aph = y_batch(2)
    f%hth = y_batch(3) 
    f%hph = y_batch(4)
    f%Bmod = y_batch(5)
    
    f%dAth = dy_batch(:, 1)
    f%dAph = dy_batch(:, 2)
    f%dhth = dy_batch(:, 3)
    f%dhph = dy_batch(:, 4)
    f%dBmod = dy_batch(:, 5)
    
    f%d2Ath = d2y_batch(:, 1)
    f%d2Aph = d2y_batch(:, 2)
    f%d2hth = d2y_batch(:, 3)
    f%d2hph = d2y_batch(:, 4)
    f%d2Bmod = d2y_batch(:, 5)
end subroutine evaluate_meiss_batch_der2

end module field_can_meiss
