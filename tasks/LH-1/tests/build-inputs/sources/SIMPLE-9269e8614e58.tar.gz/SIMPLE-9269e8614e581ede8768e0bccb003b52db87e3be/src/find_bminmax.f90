  !
  module bminmax_mod
  implicit none

  ! Define real(dp) kind parameter
  integer, parameter :: dp = kind(1.0d0)
  !
  logical :: prop=.true.
  !
  integer, parameter :: nsbmnx=100
  real(dp)                      :: hsbmnx
  real(dp), dimension(0:nsbmnx) :: bmin_arr,bmax_arr
  !
  end module bminmax_mod
  !
module find_bminmax_sub
implicit none

! Define real(dp) kind parameter
integer, parameter :: dp = kind(1.0d0)

contains

  !ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
  !
  subroutine find_bminmax(s,bmin,bmax)
  !
  use new_vmec_stuff_mod, only : nper
  !
  implicit none
  !
  integer,          parameter :: np=100, nt=100
  !
  integer :: it,ip,iter
  real(dp) :: s,bmin,bmax,bmod,hp,ht,twopi
  real(dp) :: tmin,tmax,pmin,pmax
  real(dp), dimension(3) :: x,bder
  !
  twopi=8.d0*atan(1.d0)
  ht=twopi/dble(nt)
  hp=twopi/dble(nt*nper)
  x(1)=s
  x(2:3)=0.d0
  !
  call getbmod
  !
  tmin=0.d0
  tmax=0.d0
  pmin=0.d0
  pmax=0.d0
  bmin=bmod
  bmax=bmod
  !
  do it=1,nt
    x(2)=ht*dble(it)
    do ip=1,np
      x(3)=hp*dble(ip)
  !
      call getbmod
  !
      if(bmod.gt.bmax) then
        bmax=bmod
        tmax=x(2)
        pmax=x(3)
      elseif(bmod.lt.bmin) then
        bmin=bmod
        tmin=x(2)
        pmin=x(3)
      endif
  !
    enddo
  enddo
  !
  call newtextr(tmin,pmin,bmin)
  !
  call newtextr(tmax,pmax,bmax)
  !
  !-----------
  contains
  !-----------
  !
  subroutine getbmod
  use magfie_sub, only : magfie
  !
  implicit none
  !
  real(dp) :: sqrtg
  real(dp), dimension(3) :: hcovar, hctrvr, hcurl
  !
  call magfie(x,bmod,sqrtg,bder,hcovar,hctrvr,hcurl)
  !
  end subroutine getbmod
  !
  !-----------
  !
  subroutine newtextr(theta,phi,bextr)
  !
  implicit none
  !
  integer,          parameter :: niter=10
  real(dp), parameter :: hdt=1.d-3, hdp=1.d-3
  real(dp) :: bt,bp,btt,btp,bpt,bpp,theta,phi,bextr
  real(dp) :: det,dtheta,dphi,w
  !
  do iter=1,niter
    x(3)=phi
    x(2)=theta
  !
    call getbmod
  !
    bt=bder(2)*bmod
    bp=bder(3)*bmod
  !
    x(3)=phi
    x(2)=theta+hdt
  !
    call getbmod
  !
    btt=bder(2)*bmod
    bpt=bder(3)*bmod
    x(2)=theta-hdt
  !
    call getbmod
  !
    btt=(btt-bder(2)*bmod)/(2.d0*hdt)
    bpt=(bpt-bder(3)*bmod)/(2.d0*hdt)
    btp=bpt
    x(2)=theta
    x(3)=phi+hdp
  !
    call getbmod
  !
    bpp=bder(3)*bmod
  !
    x(3)=phi-hdp
  !
    call getbmod
  !
    bpp=(bpp-bder(3)*bmod)/(2.d0*hdp)
    det=btt*bpp-btp*bpt
    dtheta=(bt*bpp-bp*btp)/det
    dphi=(bp*btt-bt*bpt)/det
    w=min(ht/max(abs(dtheta),ht),hp/max(abs(dphi),hp))
    theta=theta-w*dtheta
    phi=phi-w*dphi
  enddo
  !
  bextr=bmod
  !
  end subroutine newtextr
  !
  !-----------
  !
  end subroutine find_bminmax
  !
  !ccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc
  !
  subroutine init_bminmax_arrays
    use bminmax_mod, only: prop, nsbmnx, hsbmnx, bmin_arr, bmax_arr

    integer :: k
    real(dp) :: s0

    if (.not. prop) return
    prop = .false.
    hsbmnx = 1.d0/dble(nsbmnx)
    ! The cache is defined in the coordinate system of the active magfie
    ! backend. The driver initializes it serially after selecting the tracing
    ! backend, before parallel orbit tracing reads it.
    do k = 0, nsbmnx
        s0 = max(1.d-8, hsbmnx*dble(k))
        call find_bminmax(s0, bmin_arr(k), bmax_arr(k))
    end do
  end subroutine init_bminmax_arrays

  subroutine get_bminmax(s, bmin, bmax)
    use bminmax_mod, only: prop, nsbmnx, hsbmnx, bmin_arr, bmax_arr

    real(dp), intent(in) :: s
    real(dp), intent(out) :: bmin, bmax
    integer :: k
    real(dp) :: ws

    if (prop) call init_bminmax_arrays

    ws = s/hsbmnx
    k = min(nsbmnx - 1, max(0, int(ws)))
    ws = ws - dble(k)
    bmin = bmin_arr(k)*(1.d0 - ws) + bmin_arr(k + 1)*ws
    bmax = bmax_arr(k)*(1.d0 - ws) + bmax_arr(k + 1)*ws
  end subroutine get_bminmax

end module find_bminmax_sub
