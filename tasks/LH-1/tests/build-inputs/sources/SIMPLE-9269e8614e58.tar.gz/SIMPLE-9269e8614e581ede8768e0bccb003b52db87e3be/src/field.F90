module field
    !> Field module aggregating all field types and factory functions.

    use libneo_coordinates, only: detect_refcoords_file_type, refcoords_file_chartmap, &
                                  refcoords_file_vmec_wout, refcoords_file_unknown
    use field_base, only: magnetic_field_t
    use field_vmec, only: vmec_field_t, create_vmec_field
    use field_coils, only: coils_field_t, create_coils_field
    use field_splined, only: splined_field_t, create_splined_field
    use field_boozer_chartmap, only: boozer_chartmap_field_t, &
                                     create_boozer_chartmap_field, &
                                     is_boozer_chartmap
    use field_spectre, only: spectre_field_t, create_spectre_field

    implicit none

contains

    subroutine field_clone(source, dest)
        class(magnetic_field_t), intent(in) :: source
        class(magnetic_field_t), allocatable, intent(out) :: dest

        select type (source)
        type is (vmec_field_t)
            allocate (vmec_field_t :: dest)
            select type (dest)
            type is (vmec_field_t)
                dest = source
            class default
                error stop 'field_clone: Allocation failure (vmec)'
            end select
        type is (coils_field_t)
            allocate (coils_field_t :: dest)
            select type (dest)
            type is (coils_field_t)
                dest = source
            class default
                error stop 'field_clone: Allocation failure (coils)'
            end select
        type is (splined_field_t)
            allocate (splined_field_t :: dest)
            select type (dest)
            type is (splined_field_t)
                dest = source
            class default
                error stop 'field_clone: Allocation failure (splined)'
            end select
        type is (boozer_chartmap_field_t)
            allocate (boozer_chartmap_field_t :: dest)
            select type (dest)
            type is (boozer_chartmap_field_t)
                dest = source
            class default
                error stop 'field_clone: Allocation failure (boozer_chartmap)'
            end select
        type is (spectre_field_t)
            allocate (spectre_field_t :: dest)
            select type (dest)
            type is (spectre_field_t)
                dest = source
            class default
                error stop 'field_clone: Allocation failure (spectre)'
            end select
        class default
            error stop 'field_clone: Unsupported field type'
        end select
    end subroutine field_clone

    subroutine field_from_file(filename, field)
        !> Create appropriate field type from file.
        !> For coils files, creates a splined_field_t wrapping coils_field_t.
        use reference_coordinates, only: ref_coords

        character(*), intent(in) :: filename
        class(magnetic_field_t), allocatable, intent(out) :: field

        character(len(filename)) :: stripped_name
        type(coils_field_t) :: raw_coils
        type(splined_field_t), allocatable :: splined_coils
        type(vmec_field_t) :: vmec_field
        type(boozer_chartmap_field_t), allocatable :: bc_temp
        type(spectre_field_t), allocatable :: spectre_temp
        integer :: file_type, ierr
        character(len=2048) :: message

        stripped_name = strip_directory(filename)

        if (is_spectre_file(filename)) then
            allocate (spectre_temp)
            call create_spectre_field(spectre_temp, filename, ierr)
            if (ierr /= 0) then
                print *, 'field_from_file: create_spectre_field failed for ', &
                    trim(filename), ' (ierr = ', ierr, ')'
                error stop
            end if
            call move_alloc(spectre_temp, field)
        else if (endswith(filename, '.nc')) then
            if (is_boozer_chartmap(filename)) then
                call create_boozer_chartmap_field(filename, bc_temp)
                call move_alloc(bc_temp, field)
            else
                call detect_refcoords_file_type(filename, file_type, ierr, message)
                if (ierr /= 0) then
                    print *, 'field_from_file: NetCDF file detection error for ', &
                        trim(filename)
                    print *, trim(message)
                    error stop
                end if

                select case (file_type)
                case (refcoords_file_vmec_wout)
                    call create_vmec_field(vmec_field)
                    call field_clone(vmec_field, field)
                case (refcoords_file_chartmap)
                    print *, &
                        'field_from_file: chartmap NetCDF is a coordinate system ', &
                        'file, not a field:'
                    print *, '  filename = ', trim(filename)
                    print *, &
                        'Set coord_input to this chartmap file and set field_input', &
                        ' to a VMEC wout.'
                    error stop
                case (refcoords_file_unknown)
                  print *, 'field_from_file: Unknown NetCDF file type: ', trim(filename)
                    error stop
                case default
                print *, 'field_from_file: Unexpected file_type ', file_type, ' for ', &
                        trim(filename)
                    error stop
                end select
            end if
        else if (startswidth(stripped_name, 'coils') .or. &
                 endswith(filename, '.coils')) then
            call create_coils_field(filename, raw_coils)
            allocate (splined_coils)
            call create_splined_field(raw_coils, ref_coords, splined_coils)
            call move_alloc(splined_coils, field)
        else
            print *, 'field_from_file: Unknown file name format ', filename
            error stop
        end if
    end subroutine field_from_file

    function is_spectre_file(filename) result(is_spectre)
        !> SPECTRE equilibria are HDF5. Accept a .h5 name or any non-.nc file whose
        !> first bytes carry the HDF5 signature, so a mislabelled extension still
        !> routes. NetCDF-4 is itself HDF5, so .nc is excluded from the magic sniff
        !> to keep VMEC and chartmap files on the NetCDF path.
        character(*), intent(in) :: filename
        logical :: is_spectre

        character(len=1) :: magic(8)
        integer :: unit, ios, i
        integer, parameter :: hdf5_magic(8) = [137, 72, 68, 70, 13, 10, 26, 10]

        is_spectre = endswith(filename, '.h5')
        if (is_spectre) return
        if (endswith(filename, '.nc')) return

        open (newunit=unit, file=filename, access='stream', form='unformatted', &
              status='old', action='read', iostat=ios)
        if (ios /= 0) return

        read (unit, iostat=ios) magic
        close (unit)
        if (ios /= 0) return

        is_spectre = .true.
        do i = 1, 8
            if (iachar(magic(i)) /= hdf5_magic(i)) then
                is_spectre = .false.
                return
            end if
        end do
    end function is_spectre_file

    function startswidth(text, start)
        logical :: startswidth
        character(*), intent(in) :: text
        character(*), intent(in) :: start
        integer :: len_text, len_start

        len_text = len_trim(text)
        len_start = len_trim(start)

        startswidth = .false.
        if (len_text >= len_start) then
            if (text(1:len_start) == start) then
                startswidth = .true.
            end if
        end if
    end function startswidth

    function endswith(text, ending)
        logical :: endswith
        character(*), intent(in) :: text
        character(*), intent(in) :: ending
        integer :: len_text, len_end

        len_text = len_trim(text)
        len_end = len_trim(ending)

        endswith = .false.
        if (len_text >= len_end) then
            if (text(len_text - len_end + 1:len_text) == ending) then
                endswith = .true.
            end if
        end if
    end function endswith

    function strip_directory(filename)
        character(*), intent(in) :: filename
        character(len(filename)) :: strip_directory
        integer :: i

        strip_directory = filename
        do i = len(filename), 1, -1
            if (filename(i:i) == '/') then
                strip_directory = filename(i + 1:len(filename))
                return
            end if
        end do
    end function strip_directory

end module field
