!-----------------------------------------------------------------------
!     Subroutine:    thrift_write
!     Authors:       S. Lazerson
!     Date:          12/20/2022
!     Description:   This subroutine writes the HDF5 output for THRIFT.
!-----------------------------------------------------------------------
      SUBROUTINE thrift_write
!-----------------------------------------------------------------------
!     Libraries
!-----------------------------------------------------------------------
      USE thrift_runtime
      USE thrift_vars
      USE thrift_profiles_mod, ONLY : nion_prof, Zatom_prof
      USE thrift_plasma_solver_mod
      USE thrift_globals, ONLY: solve_plasma_equations
#if defined(LHDF5)
      USE ez_hdf5
#endif
!-----------------------------------------------------------------------
!     Local Variables
!        ier         Error flag
!-----------------------------------------------------------------------
      IMPLICIT NONE
      INTEGER :: ier, nfg, i, nwrite, Nt_write
      INTEGER, ALLOCATABLE :: write_idx(:)
!----------------------------------------------------------------------
!     BEGIN SUBROUTINE
!----------------------------------------------------------------------
      IF (myworkid == master) THEN
#if defined(LHDF5)
         CALL open_hdf5('thrift_'//TRIM(id_string)//'.h5',fid,ier,LCREATE=.true.)
         IF (ier /= 0) CALL handle_err(HDF5_OPEN_ERR,'thrift_'//TRIM(id_string)//'.h5',ier)
         ! Version
         CALL write_scalar_hdf5(fid,'VERSION',ier,DBLVAR=THRIFT_VERSION,ATT='Version Number',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'VERSION',ier)
         ! Logicals
         CALL write_scalar_hdf5(fid,'lvmec',ier,BOOVAR=lvmec,ATT='VMEC input',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'lvmec',ier)
         CALL write_scalar_hdf5(fid,'leccd',ier,BOOVAR=leccd,ATT='ECCD Present',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'leccd',ier)
         CALL write_scalar_hdf5(fid,'lnbcd',ier,BOOVAR=lnbcd,ATT='NBCD Present',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'lnbcd',ier)
         CALL write_scalar_hdf5(fid,'lohmic',ier,BOOVAR=lohmic,ATT='Ohmic CD Present',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'lohmic',ier)
         ! Integers
         CALL write_scalar_hdf5(fid,'ntimesteps',ier,INTVAR=ntimesteps,ATT='Number of Time Steps',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'ntimesteps',ier)
         CALL write_scalar_hdf5(fid,'nssize',ier,INTVAR=nsj,ATT='Number of Radial Gridpoints in s space',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'nssize',ier)
         CALL write_scalar_hdf5(fid,'nion_prof',ier,INTVAR=nion_prof,ATT='Number of ion species',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'nion_prof',ier)
         CALL write_scalar_hdf5(fid,'nrho',ier,INTVAR=nrho,ATT='Number of Radial Gridpoints',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'nrho',ier)
         CALL write_scalar_hdf5(fid,'npicard',ier,INTVAR=npicard,ATT='Maximum number of Picard Iterations',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'npicard',ier)
         ! Floats
         CALL write_scalar_hdf5(fid,'jtol',ier,DBLVAR=jtol,ATT='j convergence factor [%]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'jtol',ier)
         CALL write_scalar_hdf5(fid,'picard_factor',ier,DBLVAR=picard_factor,ATT='Picard Iteration Factor',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'picard_factor',ier)
         CALL write_scalar_hdf5(fid,'eq_Aminor',ier,DBLVAR=eq_Aminor,ATT='eq_Aminor',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'eq_Aminor',ier)
         ! 1D Floats
         CALL write_var_hdf5(fid,'THRIFT_RHO',nrho,ier,DBLVAR=THRIFT_RHO,ATT='Radial Grid (r/a)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_RHO',ier)
         CALL write_var_hdf5(fid,'THRIFT_S',nsj,ier,DBLVAR=THRIFT_S,ATT='s Grid (r/a)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_S',ier)
         CALL write_var_hdf5(fid,'THRIFT_SNOB',nsj-2,ier,DBLVAR=THRIFT_SNOB,ATT='s grid (no boundaries) (r/a)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_SNOB',ier)
         CALL write_var_hdf5(fid,'THRIFT_RHOFULL',nrho+2,ier,DBLVAR=THRIFT_RHOFULL,ATT='Extended Radial Grid (r/a)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_RHOFULL',ier)
         CALL write_var_hdf5(fid,'THRIFT_T',ntimesteps,ier,DBLVAR=THRIFT_T,ATT='Time Slice Grid [s]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_T',ier)
         CALL write_var_hdf5(fid,'THRIFT_PHIEDGE',ntimesteps,ier,DBLVAR=THRIFT_PHIEDGE,ATT='Toroidal magnetic flux at plasma edge [Wb] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_PHIEDGE',ier)
         CALL write_var_hdf5(fid,'THRIFT_BETATOT',ntimesteps,ier,DBLVAR=THRIFT_BETATOT,ATT='Total Plasma Beta',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_BETATOT',ier)
         ! 2D Floats
         ! Current densities
         nfg = nrho+2
         CALL write_var_hdf5(fid,'THRIFT_J',      nsj,ntimesteps,ier,DBLVAR=THRIFT_J,ATT='Total Current Density [A/m^2] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_J',ier)
         CALL write_var_hdf5(fid,'THRIFT_JBOOT',  nsj,ntimesteps,ier,DBLVAR=THRIFT_JBOOT,ATT='Bootstrap Current Density [A/m^2] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_JBOOT',ier)
         CALL write_var_hdf5(fid,'THRIFT_JECCD',  nsj,ntimesteps,ier,DBLVAR=THRIFT_JECCD,ATT='ECCD Current Density [A/m^2] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_JECCD',ier)
         CALL write_var_hdf5(fid,'THRIFT_JNBCD',  nsj,ntimesteps,ier,DBLVAR=THRIFT_JNBCD,ATT='NBCD Current Density [A/m^2] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_JNBCD',ier)
         CALL write_var_hdf5(fid,'THRIFT_JOHMIC', nsj,ntimesteps,ier,DBLVAR=THRIFT_JOHMIC,ATT='Ohmic Current Density [A/m^2] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_JOHMIC',ier)
         CALL write_var_hdf5(fid,'THRIFT_JPLASMA',nsj,ntimesteps,ier,DBLVAR=THRIFT_JPLASMA,ATT='Plasma Response Current Density [A/m^2] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_JPLASMA',ier)
         CALL write_var_hdf5(fid,'THRIFT_JSOURCE',nsj,ntimesteps,ier,DBLVAR=THRIFT_JSOURCE,ATT='Source Current Density [A/m^2] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_JSOURCE',ier)
         ! Currents
         CALL write_var_hdf5(fid,'THRIFT_UGRID',nsj,ntimesteps,ier,DBLVAR=THRIFT_UGRID,ATT='U (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_UGRID',ier)
         CALL write_var_hdf5(fid,'THRIFT_I',nsj,ntimesteps,ier,DBLVAR=THRIFT_I,ATT='Enclosed Total Current [A] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_I',ier)
         CALL write_var_hdf5(fid,'THRIFT_IBOOT',nsj,ntimesteps,ier,DBLVAR=THRIFT_IBOOT,ATT='Enclosed Bootstrap Current [A] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_IBOOT',ier)
         CALL write_var_hdf5(fid,'THRIFT_IECCD',nsj,ntimesteps,ier,DBLVAR=THRIFT_IECCD,ATT='Enclosed ECCD Current [A] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_IECCD',ier)
         CALL write_var_hdf5(fid,'THRIFT_INBCD',nsj,ntimesteps,ier,DBLVAR=THRIFT_INBCD,ATT='Enclosed NBCD Current [A] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_INBCD',ier)
         CALL write_var_hdf5(fid,'THRIFT_IOHMIC',nsj,ntimesteps,ier,DBLVAR=THRIFT_IOHMIC,ATT='Enclosed Ohmic Current [A] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_IOHMIC',ier)
         CALL write_var_hdf5(fid,'THRIFT_IPLASMA',nsj,ntimesteps,ier,DBLVAR=THRIFT_IPLASMA,ATT='Enclosed Plasma Response Current [A] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_IPLASMA',ier)
         CALL write_var_hdf5(fid,'THRIFT_ISOURCE',nsj,ntimesteps,ier,DBLVAR=THRIFT_ISOURCE,ATT='Enclosed Source Current [A] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_ISOURCE',ier)
         ! Profile variables
         CALL write_var_hdf5(fid,'THRIFT_ETAPARA',nsj,ntimesteps,ier,DBLVAR=THRIFT_ETAPARA,ATT=' Parallel electric resistivity (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_ETAPARA',ier)
         CALL write_var_hdf5(fid,'THRIFT_P',nsj,ntimesteps,ier,DBLVAR=THRIFT_P,ATT=' Pressure (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_P',ier)
         CALL write_var_hdf5(fid,'THRIFT_PPRIME',nsj,ntimesteps,ier,DBLVAR=THRIFT_PPRIME,ATT=' Radial derivative of pressure (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_PPRIME',ier)
         ! Magnetic variables
         CALL write_var_hdf5(fid,'THRIFT_VP',nsj,ntimesteps,ier,DBLVAR=THRIFT_VP,ATT='dV/ds (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_VP',ier)
         CALL write_var_hdf5(fid,'THRIFT_S11',nsj,ntimesteps,ier,DBLVAR=THRIFT_S11,ATT='Susceptance matrix element S11 (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_S11',ier)
         CALL write_var_hdf5(fid,'THRIFT_S12',nsj,ntimesteps,ier,DBLVAR=THRIFT_S12,ATT='Susceptance matrix element S12 (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_S12',ier)
         CALL write_var_hdf5(fid,'THRIFT_BAV',nsj,ntimesteps,ier,DBLVAR=THRIFT_BAV,ATT='<B> [T] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_BAV',ier)
         CALL write_var_hdf5(fid,'THRIFT_BVAV',nsj,ntimesteps,ier,DBLVAR=THRIFT_BVAV,ATT='<Bv> [T] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_BVAV',ier)
         CALL write_var_hdf5(fid,'THRIFT_BSQAV',nsj,ntimesteps,ier,DBLVAR=THRIFT_BSQAV,ATT='<B^2> [T^2] (s-space) ',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_BSQAV',ier)
         CALL write_var_hdf5(fid,'THRIFT_IOTA',nsj,ntimesteps,ier,DBLVAR=THRIFT_IOTA,ATT='Rotational transform (s-space) ',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_IOTA',ier)
         CALL write_var_hdf5(fid,'THRIFT_RMAJOR',nsj,ntimesteps,ier,DBLVAR=THRIFT_RMAJOR,ATT='Effective major radius [m] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_RMAJOR',ier)
         CALL write_var_hdf5(fid,'THRIFT_AMINOR',nsj,ntimesteps,ier,DBLVAR=THRIFT_AMINOR,ATT='Effective minor radius  [m] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_AMINOR',ier)
         ! Electric Field
         CALL write_var_hdf5(fid,'THRIFT_EPARB',nsj,ntimesteps,ier,DBLVAR=THRIFT_EPARB,ATT='<E.B> [V.T/m] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_EPARB',ier)
         CALL write_var_hdf5(fid,'THRIFT_ER',nsj,ntimesteps,ier,DBLVAR=THRIFT_ER,ATT='Er [V/m] (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_ER',ier)
         ! ABCD
         CALL write_var_hdf5(fid,'THRIFT_COEFF_A',nsj,ntimesteps,ier,DBLVAR=THRIFT_COEFF_A,ATT='Coefficient A (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_COEFF_A',ier)
         CALL write_var_hdf5(fid,'THRIFT_COEFF_B',nsj,ntimesteps,ier,DBLVAR=THRIFT_COEFF_B,ATT='Coefficient B (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_COEFF_B',ier)
         CALL write_var_hdf5(fid,'THRIFT_COEFF_C',nsj,ntimesteps,ier,DBLVAR=THRIFT_COEFF_C,ATT='Coefficient C (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_COEFF_C',ier)
         CALL write_var_hdf5(fid,'THRIFT_COEFF_D',nsj,ntimesteps,ier,DBLVAR=THRIFT_COEFF_D,ATT='Coefficient D (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_COEFF_D',ier)
         CALL write_var_hdf5(fid,'THRIFT_COEFF_BP',nsj,ntimesteps,ier,DBLVAR=THRIFT_COEFF_BP,ATT='Derivative of coefficient B (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_COEFF_BP',ier)
         CALL write_var_hdf5(fid,'THRIFT_COEFF_CP',nsj,ntimesteps,ier,DBLVAR=THRIFT_COEFF_CP,ATT='Derivative of coefficient C (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_COEFF_CP',ier)
         CALL write_var_hdf5(fid,'THRIFT_COEFF_DP',nsj,ntimesteps,ier,DBLVAR=THRIFT_COEFF_DP,ATT='Derivative of coefficient D (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_COEFF_DP',ier)
         ! Alphas
         CALL write_var_hdf5(fid,'THRIFT_ALPHA1',nsj-2,ntimesteps,ier,DBLVAR=THRIFT_ALPHA1,ATT='Coefficient alpha_1 (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_ALPHA1',ier)
         CALL write_var_hdf5(fid,'THRIFT_ALPHA2',nsj-2,ntimesteps,ier,DBLVAR=THRIFT_ALPHA2,ATT='Coefficient alpha_2 (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_ALPHA2',ier)
         CALL write_var_hdf5(fid,'THRIFT_ALPHA3',nsj-2,ntimesteps,ier,DBLVAR=THRIFT_ALPHA3,ATT='Coefficient alpha_3 (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_ALPHA3',ier)
         CALL write_var_hdf5(fid,'THRIFT_ALPHA4',nsj-2,ntimesteps,ier,DBLVAR=THRIFT_ALPHA4,ATT='Coefficient alpha_4 (s-space)',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_ALPHA4',ier)
         ! System of equations
         CALL write_var_hdf5(fid,'THRIFT_MATLD',nsj-1,ntimesteps,ier,DBLVAR=THRIFT_MATLD,ATT='Matrix equation lower diagonal',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_MATLD',ier)
         CALL write_var_hdf5(fid,'THRIFT_MATMD',nsj,ntimesteps,ier,DBLVAR=THRIFT_MATMD,ATT='Matrix equation main diagonal',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_MATMD',ier)
         CALL write_var_hdf5(fid,'THRIFT_MATUD',nsj-1,ntimesteps,ier,DBLVAR=THRIFT_MATUD,ATT='Matrix equation upper diagonal',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_MATUD',ier)
         CALL write_var_hdf5(fid,'THRIFT_MATRHS',nsj,ntimesteps,ier,DBLVAR=THRIFT_MATRHS,ATT='Matrix equation RHS',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_MATRHS',ier)
         ! Fluxes
         CALL write_var_hdf5(fid,'THRIFT_GNEO',nion_prof+1,nsj,ntimesteps,ier,DBLVAR=THRIFT_GNEO,ATT='Neoclassical particle flux [m^-2 s^-1]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_GNEO',ier)
         CALL write_var_hdf5(fid,'THRIFT_QNEO',nion_prof+1,nsj,ntimesteps,ier,DBLVAR=THRIFT_QNEO,ATT='Neoclassical heat flux [W m^-2]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_QNEO',ier)
         ! Density, temperature and pressure
         CALL write_var_hdf5(fid,'THRIFT_DENS',nion_prof+1,nsj,ntimesteps,ier,DBLVAR=THRIFT_DENS,ATT='Density of each species [m^-3]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_DENS',ier)
         CALL write_var_hdf5(fid,'THRIFT_TEMP',nion_prof+1,nsj,ntimesteps,ier,DBLVAR=THRIFT_TEMP,ATT='Temperature of each species [eV]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_TEMP',ier)
         CALL write_var_hdf5(fid,'THRIFT_PRESS',nion_prof+1,nsj,ntimesteps,ier,DBLVAR=THRIFT_PRESS,ATT='Pressure of each species [Pa]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_PRESS',ier)
         CALL write_var_hdf5(fid,'THRIFT_FAST_ALPHAS_DENS',nsj,ntimesteps,ier,DBLVAR=THRIFT_FAST_ALPHAS_DENS,ATT='Density of fast alphas [m^-3]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_FAST_ALPHAS_DENS',ier)
         ! ECRH power
         CALL write_var_hdf5(fid,'THRIFT_DPECRHDV',nsj,ntimesteps,ier,DBLVAR=THRIFT_DPECRHDV,ATT='TRAVIS ECRH power deposition, dP/dV [W/m^3]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_DPECRHDV',ier)
         CALL write_var_hdf5(fid,'THRIFT_PECRH',nsj,ntimesteps,ier,DBLVAR=THRIFT_PECRH,ATT='TRAVIS ECRH power [W]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'THRIFT_PECRH',ier)
         !
         CALL close_hdf5(fid,ier)
         IF (ier /= 0) CALL handle_err(HDF5_CLOSE_ERR,'thrift_'//TRIM(id_string)//'.h5',ier)
#else
         WRITE(6,'(A)')  '   FILE: '//'thrift_'//TRIM(id_string)//'.bin'
         CALL safe_open(iunit,ier,'thrift_'//TRIM(id_string)//'.bin','replace','unformatted')
         ! Version
         WRITE(iunit,*) THRIFT_VERSION
         ! Logicals
         WRITE(iunit,*) lvmec, leccd, lnbcd, lohmic
         ! Integers
         WRITE(iunit,*) ntimesteps, nrho, npicard
         ! Floats
         WRITE(iunit,*) jtol, picard_factor
         ! 1D Floats
         WRITE(iunit,*) THRIFT_RHO
         WRITE(iunit,*) THRIFT_T
         ! 2D Floats
         WRITE(iunit,*) THRIFT_J
         WRITE(iunit,*) THRIFT_JBOOT
         WRITE(iunit,*) THRIFT_JECCD
         WRITE(iunit,*) THRIFT_JNBCD
         WRITE(iunit,*) THRIFT_JOHMIC
         WRITE(iunit,*) THRIFT_JPLASMA
         WRITE(iunit,*) THRIFT_JSOURCE

         WRITE(iunit,*) THRIFT_I
         WRITE(iunit,*) THRIFT_IBOOT
         WRITE(iunit,*) THRIFT_IECCD
         WRITE(iunit,*) THRIFT_INBCD
         WRITE(iunit,*) THRIFT_IOHMIC
         WRITE(iunit,*) THRIFT_IPLASMA
         WRITE(iunit,*) THRIFT_ISOURCE
         CLOSE(iunit)
#endif
      END IF

      
      IF(solve_plasma_equations .AND. myworkid == master) THEN
#if defined(LHDF5)
         ! Define stride for writing in file
         IF(dt_plasma_write <= dt_plasma_solver) THEN
            nwrite = 1
         ELSE
            nwrite = nint(dt_plasma_write/dt_plasma_solver)
         ENDIF
         Nt_write = (Nt_total_plasma_solver-1)/nwrite + 1
         ALLOCATE(write_idx(Nt_write))
         write_idx = [(1 + (i-1)*nwrite, i=1,Nt_write)]
         ! Open file
         CALL open_hdf5('plasma_solver_'//TRIM(id_string)//'.h5',fid,ier,LCREATE=.true.)
         IF (ier /= 0) CALL handle_err(HDF5_OPEN_ERR,'plasma_solver_'//TRIM(id_string)//'.h5',ier)
         ! Logicals
         CALL write_scalar_hdf5(fid,'add_NEO',ier,BOOVAR=add_NEO,ATT='add_NEO',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'add_NEO',ier)
         ! Integers
         CALL write_scalar_hdf5(fid,'Nt_plasma_grid',ier,INTVAR=Nt_write,ATT='Number of Time Steps Plasma Solver',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'Nt plasma grid',ier)
         CALL write_scalar_hdf5(fid,'Nr_plasma_grid',ier,INTVAR=Nr_plasma_solver,ATT='Number of Radial Gridpoints Plasma Solver',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'Nr plasma grid',ier)
         ! Grids
         CALL write_var_hdf5(fid,'rho_plasma_grid',Nr_plasma_solver,ier,DBLVAR=rho_plasma_grid,ATT='Rho grid [-]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'rho_plasma_grid',ier)
         CALL write_var_hdf5(fid,'r_plasma_grid',Nt_write,Nr_plasma_solver,ier,DBLVAR=r_plasma_grid(write_idx,:),ATT='r-grid [-]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'r_plasma_grid',ier)
         ! dV/dr
         CALL write_var_hdf5(fid,'dVdr',Nt_write,Nr_plasma_solver,ier,DBLVAR=dVdr_keep(write_idx,:),ATT='dV/dr [m^2]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'dVdr',ier)
         ! Zions
         CALL write_var_hdf5(fid,'Zions',nion_prof,ier,INTVAR=Zatom_prof,ATT='Ions charge number [-]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'Zions',ier)
         ! List of Species
         CALL write_var_hdf5(fid,'list_of_species',nion_prof+1,ier,STRVAR=list_of_species,ATT='List of Species',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'list_of_species',ier)
         ! Time arrays
         CALL write_var_hdf5(fid,'time_plasma_grid',Nt_write,ier,DBLVAR=time_plasma_grid(write_idx),ATT='Time grid [s]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'time_plasma_grid',ier)
         CALL write_var_hdf5(fid,'plasma_N',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=plasma_N_keep(:,write_idx,:),ATT='Density of each species [m^-3]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'plasma_N',ier)
         CALL write_var_hdf5(fid,'plasma_T',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=plasma_T_keep(:,write_idx,:),ATT='Temperature of each species [eV]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'plasma_T',ier)
         CALL write_var_hdf5(fid,'Dn_NEO',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=Dn_NEO(:,write_idx,:),ATT='Dn NEO particle diffusion coeff. [m^2/s]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'Dn_NEO',ier)
         CALL write_var_hdf5(fid,'cn_NEO',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=cn_NEO(:,write_idx,:),ATT='cn NEO particle convective velocity [m/s]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'cn_NEO',ier)
         CALL write_var_hdf5(fid,'Dp_NEO',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=Dp_NEO(:,write_idx,:),ATT='Dp NEO heat diffusion coeff. [m^2/s]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'Dp_NEO',ier)
         CALL write_var_hdf5(fid,'cp_NEO',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=cp_NEO(:,write_idx,:),ATT='cp NEO heat convective velocity [m/s]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'cp_NEO',ier)
         !
         CALL write_var_hdf5(fid,'Dp_total',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=Dp_total(:,write_idx,:),ATT='Total Dp heat diffusion coeff [m^2/s]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'Dp_total',ier)
         CALL write_var_hdf5(fid,'cp_total',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=cp_total(:,write_idx,:),ATT='Total cp heat convective velocity [m/s]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'cp_total',ier)
         !
         CALL write_var_hdf5(fid,'Dn_total',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=Dn_total(:,write_idx,:),ATT='Total Dn particle diffusion coeff.  [m^2/s]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'Dn_total',ier)
         CALL write_var_hdf5(fid,'cn_total',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=cn_total(:,write_idx,:),ATT='Total cn particle convective velocity [m/s]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'cn_total',ier)
         !! Neo fluxes (complete versions)
         CALL write_var_hdf5(fid,'G_NEO_complet',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=G_NEO_complet(:,write_idx,:),ATT='G NEO [m^-2 s^-1]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'G_NEO_complet',ier)
         CALL write_var_hdf5(fid,'Q_NEO_complet',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=Q_NEO_complet(:,write_idx,:),ATT='Q NEO [W/m^2]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'Q_NEO_complet',ier)
         ! N_fast_alphas
         CALL write_var_hdf5(fid,'N_fast_alphas',Nt_write,Nr_plasma_solver,ier,DBLVAR=N_fast_alphas(write_idx,:),ATT='Density of fast alphas [m^-3]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'N_fast_alphas',ier)
         ! Energy Sources
         CALL write_var_hdf5(fid,'S_radiated_power',Nt_write,Nr_plasma_solver,ier,DBLVAR=S_radiated_power(write_idx,:),ATT='Radiated Power [W/m^3]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'S_radiated_power',ier)
         CALL write_var_hdf5(fid,'S_alpha_power',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=S_alpha_power(:,write_idx,:),ATT='Alpha Power [W/m^3]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'S_alpha_power',ier)
         CALL write_var_hdf5(fid,'S_energy_ext',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=S_energy_ext(:,write_idx,:),ATT='External Power Source [W/m^3]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'S_energy_ext',ier)
         ! External Particle Source
         CALL write_var_hdf5(fid,'S_particle_ext',num_species,Nt_write,Nr_plasma_solver,ier,DBLVAR=S_particle_ext(:,write_idx,:),ATT='External Particle Source [part/(s.m^3)]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'S_particle_ext',ier)
         ! Electric Field
         CALL write_var_hdf5(fid,'plasma_Er',Nt_write,Nr_plasma_solver,ier,DBLVAR=plasma_Er(write_idx,:),ATT='Radial Electric Field [V/n]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'plasma_Er',ier)
         ! aminor, Baxis and iota2o3 (needed for ISS04)
         CALL write_var_hdf5(fid,'aminor',Nt_write,ier,DBLVAR=plasma_aminor(write_idx),ATT='aminor [m]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'aminor',ier)
         CALL write_var_hdf5(fid,'Baxis',Nt_write,ier,DBLVAR=plasma_Baxis(write_idx),ATT='Baxis [T]',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'Baxis',ier)
         CALL write_var_hdf5(fid,'iota2o3',Nt_write,ier,DBLVAR=plasma_iota2o3(write_idx),ATT='iota2o3',ATT_NAME='description')
         IF (ier /= 0) CALL handle_err(HDF5_WRITE_ERR,'iota2o3',ier)
         ! Close file
         CALL close_hdf5(fid,ier)
         IF (ier /= 0) CALL handle_err(HDF5_CLOSE_ERR,'plasma_solver_'//TRIM(id_string)//'.h5',ier)
         !
         DEALLOCATE(write_idx)
#endif  
         ! Close plasma_solver.log file
         CLOSE(unit=ilogplasma)
      END IF 

      RETURN
!----------------------------------------------------------------------
!     END SUBROUTINE
!----------------------------------------------------------------------
      END SUBROUTINE thrift_write

