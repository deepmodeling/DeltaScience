!-----------------------------------------------------------------------
!     Subroutine:    beams3d_init_vmec
!     Authors:       S. Lazerson (lazerson@pppl.gov)
!     Date:          04/25/2012
!     Description:   This subroutine reads the VMEC wout file and
!                    initializes the plasma fields.  This is achieved
!                    through utilization of a virtual casing principle.
!                    This is stil under development but working.
!-----------------------------------------------------------------------
      SUBROUTINE beams3d_init_vmec
!-----------------------------------------------------------------------
!     Libraries
!-----------------------------------------------------------------------
      USE stel_kinds, ONLY: rprec
      USE read_wout_mod
      USE vmec_utils
      USE virtual_casing_mod, pi2_vc => pi2
      USE beams3d_runtime
      USE beams3d_grid, ONLY: raxis_g => raxis, phiaxis, &
                                 zaxis_g => zaxis, nr, nphi, nz, &
                                 rmin, rmax, zmin, zmax, phimin, &
                                 phimax, vc_adapt_tol, B_R, B_Z, B_PHI,&
                                 TE_spl_s, NE_spl_s, TI_spl_s, &
                                 nte, nne, nti, TE, NE, TI, Vp_spl_s, S_ARR,&
                                 U_ARR, POT_ARR, POT_spl_s, nne, nte, nti, npot, &
                                 nomeg, OMEG_ARR,OMEG_spl_s,&
                                 ZEFF_spl_s, nzeff, ZEFF_ARR, req_axis, zeq_axis, &
                                 phiedge_eq, reff_eq, NI_spl_s, NI,&
                                 s_max,s_max_te, s_max_ne,s_max_zeff,s_max_ti,&
                                 s_max_pot, s_max_omeg
      USE beams3d_lines, ONLY: GFactor, ns_prof1, h1_prof
      USE wall_mod, ONLY: wall_load_mn
      USE mpi_params
      USE mpi_inc
!-----------------------------------------------------------------------
!     Local Variables
!          ier            Error Flag
!          iunit          File ID Number
!-----------------------------------------------------------------------
      IMPLICIT NONE
      INTEGER :: numprocs_local, mylocalid, mylocalmaster
      INTEGER :: MPI_COMM_LOCAL
      LOGICAL :: lnyquist, luse_vc, lcreate_wall, lverb_wall
      INTEGER :: ier, s, i, j, k, nu, nv, mystart, myend, mnmax_temp, u, v
      INTEGER :: nfailed, ifailed, nunconv
      ! Failures beyond this solved s are exterior points with no solution
      ! and are not reported; matches cyl2flx_log_smax so the warning and
      ! the -DDEBUG_CYL2FLX log describe the same set of points.
      REAL(rprec), PARAMETER :: s_unconv_max = 1.5_rprec
      INTEGER :: bcs1_s(2)
      INTEGER, ALLOCATABLE :: xn_temp(:), xm_temp(:), failed_index(:)
      LOGICAL, ALLOCATABLE :: retry_success(:)
      REAL :: br_vc, bphi_vc, bz_vc, xaxis_vc, yaxis_vc, zaxis_vc,&
              bx_vc, by_vc
      REAL(rprec) :: br, bphi, bz, sflx, uflx, xaxis, yaxis
      REAL(rprec), ALLOCATABLE :: retry_s(:), retry_u(:), retry_br(:),&
                                 retry_bphi(:), retry_bz(:)
      DOUBLE PRECISION, ALLOCATABLE :: mfact(:,:)
      DOUBLE PRECISION, ALLOCATABLE :: rmnc_temp(:,:),zmns_temp(:,:),&
                           bumnc_temp(:,:),bvmnc_temp(:,:),&
                           rmns_temp(:,:),zmnc_temp(:,:),&
                           bumns_temp(:,:),bvmns_temp(:,:)
!-----------------------------------------------------------------------
!     Begin Subroutine
!-----------------------------------------------------------------------
      ! Handle what we do
      luse_vc = ((lmgrid .or. lcoil) .and. .not.lplasma_only)
      lcreate_wall = (lplasma_only .and. .not. lvessel)

      ! Divide up Work
      mylocalid = myworkid
      cyl2flx_rank = myworkid   ! per-rank id for -DDEBUG_CYL2FLX logging
      numprocs_local = 1
      MPI_COMM_LOCAL = 0
#if defined(MPI_OPT)
      CALL MPI_COMM_DUP( MPI_COMM_SHARMEM, MPI_COMM_LOCAL, ierr_mpi)
      CALL MPI_COMM_RANK( MPI_COMM_LOCAL, mylocalid, ierr_mpi )              ! MPI
      CALL MPI_COMM_SIZE( MPI_COMM_LOCAL, numprocs_local, ierr_mpi )          ! MPI
#endif
      mylocalmaster = master
      bx_vc = 0.0; by_vc = 0.0; bz_vc = 0.0

      ! Open VMEC file
      IF (myworkid == master) THEN
         CALL read_wout_file(TRIM(id_string),ier)
         IF (ier /= 0) CALL handle_err(VMEC_WOUT_ERR,'beams3d_init_vmec',ier)
      END IF
      
#if defined(MPI_OPT)
      ! We do this to avoid multiple opens of wout file
      CALL MPI_BCAST(ns,1,MPI_INTEGER, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(mpol,1,MPI_INTEGER, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(ntor,1,MPI_INTEGER, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(nfp,1,MPI_INTEGER, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(mnyq,1,MPI_INTEGER, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(nnyq,1,MPI_INTEGER, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(mnmax,1,MPI_INTEGER, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(mnmax_nyq,1,MPI_INTEGER, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(lasym,1,MPI_LOGICAL, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(lthreed,1,MPI_LOGICAL, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(lwout_opened,1,MPI_LOGICAL, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(Aminor,1,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      IF (myworkid /= master) THEN
         ALLOCATE(vp(ns),phi(ns),iotaf(ns),phipf(ns))
         ALLOCATE(xm(mnmax),xn(mnmax),xm_nyq(mnmax_nyq),xn_nyq(mnmax_nyq))
         ALLOCATE(rmnc(mnmax,ns),zmns(mnmax,ns),lmns(mnmax,ns),bsupumnc(mnmax_nyq,ns),bsupvmnc(mnmax_nyq,ns))
         IF (lasym) ALLOCATE(rmns(mnmax,ns),zmnc(mnmax,ns),lmnc(mnmax,ns),bsupumns(mnmax_nyq,ns),bsupvmns(mnmax_nyq,ns))
      END IF
      CALL MPI_BCAST(vp,ns,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(phi,ns,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(phipf,ns,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(iotaf,ns,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(xm,mnmax,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(xn,mnmax,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(xm_nyq,mnmax_nyq,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(xn_nyq,mnmax_nyq,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(rmnc,ns*mnmax,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(zmns,ns*mnmax,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(lmns,ns*mnmax,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(bsupumnc,ns*mnmax_nyq,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      CALL MPI_BCAST(bsupvmnc,ns*mnmax_nyq,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      IF (lasym) THEN
         CALL MPI_BCAST(rmns,ns*mnmax,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
         CALL MPI_BCAST(zmnc,ns*mnmax,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
         CALL MPI_BCAST(lmnc,ns*mnmax,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
         CALL MPI_BCAST(bsupumns,ns*mnmax_nyq,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
         CALL MPI_BCAST(bsupvmns,ns*mnmax_nyq,MPI_DOUBLE_PRECISION, master, MPI_COMM_BEAMS,ierr_mpi)
      END IF
      phiedge_eq = phi(ns)
      reff_eq = Aminor
#endif

      ! Write info to screen
      IF (lverb) THEN
         WRITE(6,'(A)')               '----- VMEC Information -----'
         WRITE(6,'(A,A)')             '   FILE: ',TRIM(id_string)
         WRITE(6,'(A,F9.5,A,F9.5,A)') '   R       = [',rmin_surf,',',rmax_surf,']'
         WRITE(6,'(A,F8.5,A,F8.5,A)') '   Z       = [',-zmax_surf,',',zmax_surf,']'
         IF (ABS(Itor) > 1E8) THEN
            WRITE(6,'(A,F7.2,A,F7.2,A)') '   BETA    = ',betatot,';  I  = ',Itor*1E-9,' [GA]'
         ELSEIF (ABS(Itor) > 1E5) THEN
            WRITE(6,'(A,F7.2,A,F7.2,A)') '   BETA    = ',betatot,';  I  = ',Itor*1E-6,' [MA]'
         ELSEIF (ABS(Itor) > 1E2) THEN
            WRITE(6,'(A,F7.2,A,F7.2,A)') '   BETA    = ',betatot,';  I  = ',Itor*1E-3,' [kA]'
         ELSE
            WRITE(6,'(A,F7.2,A,F7.2,A)') '   BETA    = ',betatot,';  I  = ',Itor,' [A]'
         END IF
         WRITE(6,'(A,F7.2,A)')        '   AMINOR  = ',reff_eq,' [m]'
         WRITE(6,'(A,F7.2,A)')        '   PHIEDGE = ',phiedge_eq,' [Wb]'
         WRITE(6,'(A,F7.2,A)')        '   VOLUME  = ',Volume,' [m^3]'
      END IF

      ! Load the Vp Spline if using the beams
      ! Note in VMEC dV/ds = \int\int sqrt(g) dtheta dphi
      ! However VMEC integrates over u and v
      ! So Vp is missing a factor of 4*pi*pi
      ! Also is on the half grid
      vp(1) = 1.5*vp(2) - 0.5*vp(3) ! Both on half grid
      vp(2:ns-1) = 0.5*(vp(2:ns-1)+vp(3:ns)) ! Average to full grid
      vp(ns) = 2*vp(ns) - vp(ns-1) ! ns on half grid, ns-1 on full grid
      vp = vp*pi2*pi2
      bcs1_s=(/ 0, 0 /)
      CALL EZspline_init(Vp_spl_s,ns,bcs1_s,ier)
      IF (ier /=0) CALL handle_err(EZSPLINE_ERR,'beams3d_init_vmec',ier)
      Vp_spl_s%isHermite   = 1
      CALL EZspline_setup(Vp_spl_s,vp(1:ns),ier,EXACT_DIM=.true.)
      IF (ier /=0) CALL handle_err(EZSPLINE_ERR,'beams3d_init_vmec',ier)

      ! Calculate the axis values (need negative since we haven't flipped Kernel yet)
      IF (mylocalid == master) THEN
         DO i = 1, nphi
            req_axis(i) = 0
            zeq_axis(i) = 0
            DO u = 1, mnmax
               req_axis(i) = req_axis(i)+rmnc(u,1)*COS(-xn(u)*phiaxis(i))
               zeq_axis(i) = zeq_axis(i)+zmns(u,1)*SIN(-xn(u)*phiaxis(i))
            END DO
         END DO
         IF (lasym) THEN
            DO i = 1, nphi
               DO u = 1, mnmax
                  req_axis(i) = req_axis(i)+rmns(u,1)*SIN(-xn(u)*phiaxis(i))
                  zeq_axis(i) = zeq_axis(i)+zmnc(u,1)*COS(-xn(u)*phiaxis(i))
               END DO
            END DO
         END IF
      END IF


      ! If we ask for a plasma-only run and do not provide a vessel then make one.
      IF (lcreate_wall) THEN
         lvessel = .TRUE.  ! Do this so the other parts of the code know there is a vessel
         k = ns
         i = 120
         j = 180
         lverb_wall=.false.
         IF (lverb) WRITE(6,'(A)')        '   GENERATING WALL FROM BOUNDARY HARMONICS'
         IF (lasym) THEN
            CALL wall_load_mn(DBLE(rmnc(1:mnmax,k)),DBLE(zmns(1:mnmax,k)), &
               DBLE(xm),-DBLE(xn),mnmax,i,j,lverb_wall,MPI_COMM_LOCAL, &
               DBLE(rmns(1:mnmax,k)),DBLE(zmnc(1:mnmax,k)))
         ELSE
            CALL wall_load_mn(DBLE(rmnc(1:mnmax,k)),DBLE(zmns(1:mnmax,k)),DBLE(xm),-DBLE(xn),mnmax,i,j,lverb_wall,MPI_COMM_LOCAL)
         ENDIF
      END IF

      ! Initialize Virtual Casing
      IF (luse_vc) THEN
         nu = 8 * mpol + 1 
         nu = 2 ** CEILING(log(DBLE(nu))/log(2.0_rprec))
         nv = 8 * ntor + 1
         nv = 2 ** CEILING(log(DBLE(nv))/log(2.0_rprec))
         IF (nv < 128) nv = 128

         ! Handle Nyquist issues
         IF (SIZE(xm_nyq) > SIZE(xm)) THEN
            mnmax_temp = SIZE(xm_nyq)
            lnyquist = .true.
         ELSE
            mnmax_temp = mnmax
            lnyquist = .false.
         END IF
         ALLOCATE(xm_temp(mnmax_temp),xn_temp(mnmax_temp), STAT=ier)
         IF (ier /= 0) CALL handle_err(ALLOC_ERR,'XM_TEMP XN_TEMP',ier)
         ALLOCATE(rmnc_temp(mnmax_temp,2),zmns_temp(mnmax_temp,2),&
                  bumnc_temp(mnmax_temp,1),bvmnc_temp(mnmax_temp,1), STAT = ier)
         IF (ier /= 0) CALL handle_err(ALLOC_ERR,'RMNC_TEMP ZMNS_TEMP BUMNC_TEMP BVMNC_TEMP',ier)
         IF (lasym) ALLOCATE(rmns_temp(mnmax_temp,2),zmnc_temp(mnmax_temp,2),&
                     bumns_temp(mnmax_temp,1),bvmns_temp(mnmax_temp,1), STAT = ier)
         IF (ier /= 0) CALL handle_err(ALLOC_ERR,'RMNS_TEMP ZMNC_TEMP BUMNS_TEMP BVMNS_TEMP',ier)
         rmnc_temp = zero; zmns_temp =zero
         IF (lasym) THEN
            rmns_temp = zero
            zmnc_temp = zero
         END IF
         IF (lnyquist) THEN
            xm_temp = xm_nyq
            xn_temp = -xn_nyq/nfp  ! Because init_virtual_casing uses (mu+nv) not (mu-nv*nfp)
            IF(lverb) WRITE(6,'(A)')        '   NYQUIST DETECTED IN WOUT FILE!'
            DO u = 1,mnmax_temp
               DO v = 1, mnmax
                  IF ((xm(v) .eq. xm_nyq(u)) .and. (xn(v) .eq. xn_nyq(u))) THEN
                     rmnc_temp(u,1) = rmnc(v,ns-1)
                     zmns_temp(u,1) = zmns(v,ns-1)
                     rmnc_temp(u,2) = rmnc(v,ns)
                     zmns_temp(u,2) = zmns(v,ns)
                     IF (lasym) THEN
                        rmns_temp(u,1) = rmns(v,ns-1)
                        zmnc_temp(u,1) = zmnc(v,ns-1)
                        rmns_temp(u,2) = rmns(v,ns)
                        zmnc_temp(u,2) = zmnc(v,ns)
                     END IF
                  END IF
               END DO
            END DO
         ELSE
            xm_temp = xm
            xn_temp = -xn/nfp  ! Because init_virtual_casing uses (mu+nv) not (mu-nv*nfp)
            rmnc_temp(:,1) = rmnc(:,ns-1)
            zmns_temp(:,1) = zmns(:,ns-1)
            rmnc_temp(:,2) = rmnc(:,ns)
            zmns_temp(:,2) = zmns(:,ns)
            IF (lasym) THEN
               rmns_temp(:,1) = rmns(:,ns-1)
               zmnc_temp(:,1) = zmnc(:,ns-1)
               rmns_temp(:,2) = rmns(:,ns)
               zmnc_temp(:,2) = zmnc(:,ns)
            END IF
         ENDIF
         ! Get B onto full grid
         ALLOCATE(mfact(mnmax_temp,2))
         WHERE (MOD(NINT(REAL(xm_temp(:))),2) .eq. 0)
            mfact(:,1)= 1.5
            mfact(:,2)=-0.5
         ELSEWHERE
            mfact(:,1)= 1.5*SQRT((ns-1.0)/(ns-1.5))
            mfact(:,2)=-0.5*SQRT((ns-1.0)/(ns-2.5))
         ENDWHERE
         bumnc_temp(:,1) = mfact(:,1)*bsupumnc(:,ns) + mfact(:,2)*bsupumnc(:,ns-1)
         bvmnc_temp(:,1) = mfact(:,1)*bsupvmnc(:,ns) + mfact(:,2)*bsupvmnc(:,ns-1)
         IF (lasym) THEN
            bumns_temp(:,1) = mfact(:,1)*bsupumns(:,ns) + mfact(:,2)*bsupumns(:,ns-1)
            bvmns_temp(:,1) = mfact(:,1)*bsupvmns(:,ns) + mfact(:,2)*bsupvmns(:,ns-1)
            CALL init_virtual_casing(mnmax_temp,nu,nv,xm_temp,xn_temp,&
                                         rmnc_temp,zmns_temp,nfp,&
                                         RMNS=rmns_temp, ZMNC=zmnc_temp,&
                                         BUMNC=bumnc_temp,BVMNC=bvmnc_temp,&
                                         BUMNS=bumns_temp,BVMNS=bvmns_temp,&
                                         COMM=MPI_COMM_BEAMS)
            DEALLOCATE(rmns_temp,zmnc_temp)
            DEALLOCATE(bumns_temp,bvmns_temp)
         ELSE
            CALL init_virtual_casing(mnmax_temp,nu,nv,xm_temp,xn_temp,&
                                         rmnc_temp,zmns_temp,nfp,&
                                         BUMNC=bumnc_temp,BVMNC=bvmnc_temp,&
                                         COMM=MPI_COMM_BEAMS)
         END IF
         DEALLOCATE(mfact)
         DEALLOCATE(rmnc_temp,zmns_temp)
         DEALLOCATE(bumnc_temp,bvmnc_temp)
         
         adapt_tol = 0.0
         adapt_rel = vc_adapt_tol
         DEALLOCATE(xm_temp,xn_temp)
      END IF
      
      IF (lverb) THEN
         IF (luse_vc) CALL virtual_casing_info(6)
         CALL FLUSH(6)
      END IF
      
      ! Break up the Work
      CALL MPI_CALC_MYRANGE(MPI_COMM_LOCAL, 1, nr*nphi*nz, mystart, myend)

      ! Initialize the grids
      IF (mylocalid == mylocalmaster) THEN
         IF (.not. luse_vc) THEN
            B_R = 0.0; B_PHI=1.0; B_Z=0.0
         END IF
         TE = 0; NE = 0; TI=0; S_ARR=4.0; U_ARR=0; POT_ARR=0; ZEFF_ARR = 1; OMEG_ARR=0;
      END IF

#if defined(MPI_OPT)
      CALL MPI_BARRIER(MPI_COMM_LOCAL,ierr_mpi)
#endif

      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      !! Perform the lookup of VMEC B-field and S,U grid data
      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      IF (lverb) THEN
         WRITE(6,'(5X,A,I3.3,A)',ADVANCE='no') 'Plasma Field Lookup [',0,']%'
      END IF
      CALL FLUSH(6)
      sflx = 0.001
      uflx = 0.0
      DO s = mystart, myend
         i = MOD(s-1,nr)+1
         j = MOD(s-1,nr*nphi)/nr+1
         k = (s-1)/(nr*nphi)+1
         CALL GetBcyl(raxis_g(i),phiaxis(j),zaxis_g(k),&
                      br, bphi, bz, SFLX=sflx,UFLX=uflx,info=ier)
         !PRINT *,i,j,k,raxis_g(i),phiaxis(j),zaxis_g(k), br, bphi, bz, sflx,uflx,ier
         ! GetBcyl will return ier = 0,-1,or-3
         !   0 : Success
         !  -1 : Success but at reduced tolerance
         !  -3 : Failure (no B returned)
         ! If sucessfull save the data
         IF (ier .eq. 0) THEN
            ! Save Grid data
            S_ARR(i,j,k) = MAX(sflx,0.0)
            IF (uflx<0)  uflx = uflx+pi2
            U_ARR(i,j,k) = uflx
            ! Handle equilibrium data
            IF (sflx <=1.0) THEN ! Inside equilibrium
               B_R(i,j,k)   = br
               B_PHI(i,j,k) = bphi
               B_Z(i,j,k)   = bz
            ELSE IF (.not. luse_vc) THEN  ! Overwrite data outside if not VC
               B_R(i,j,k)   = br
               B_PHI(i,j,k) = bphi
               B_Z(i,j,k)   = bz
            END IF
         ELSE
            ! Flag non-convergence, but keep the solved s in the marker so
            ! the warning below can tell a near-plasma failure (worth
            ! acting on) from an exterior point that simply has no
            ! solution.  Every existing test on S_ARR only looks at the
            ! sign or at >=0, so encoding s here is transparent to them.
            ! Only ier=-1 is flagged: -3 means no solution exists there,
            ! which is the correct answer for an exterior point, and those
            ! cells keep their 4.0 initialisation.
            IF (ier == -1) S_ARR(i,j,k) = -1.0 - MAX(sflx,0.0)
            ! Reset the seed on BOTH failure codes.  sflx/uflx are INOUT
            ! and seed the next grid point, and on failure they hold
            ! wherever the diverged Newton stopped - so without this the
            ! worst seeds are the ones that propagate.
            sflx = 0.001
            uflx = 0.0
         END IF
         IF (MOD(s,nr) == 0) THEN
            IF (lverb) THEN
               CALL backspace_out(6,6)
               WRITE(6,'(A,I3,A)',ADVANCE='no') '[',INT((100.*s)/(myend-mystart+1)),']%'
            END IF
         END IF
         CALL FLUSH(6)
      END DO

#if defined(MPI_OPT)
      CALL MPI_BARRIER(MPI_COMM_LOCAL,ierr_mpi)
#endif

      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      !! Retry failed lookups from an interior-neighbor initial guess
      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      nfailed = 0
      DO s = mystart, myend
         i = MOD(s-1,nr)+1
         j = MOD(s-1,nr*nphi)/nr+1
         k = (s-1)/(nr*nphi)+1
         ! First update progress
         IF (MOD(s,nr) == 0) THEN
            IF (lverb) THEN
               CALL backspace_out(6,6)
               WRITE(6,'(A,I3,A)',ADVANCE='no') '[',INT((100.*s)/(myend-mystart+1)),']%'
            END IF
         END IF
         CALL FLUSH(6)
         ! Don't do edge points
         IF ((i==1) .or. (i==nr) .or. (k==1) .or. (k==nz)) CYCLE
         IF (S_ARR(i,j,k) < 0.0) nfailed = nfailed + 1
      END DO

      IF (nfailed > 0) THEN
         ALLOCATE(failed_index(nfailed),retry_success(nfailed))
         ALLOCATE(retry_s(nfailed),retry_u(nfailed),retry_br(nfailed),&
                  retry_bphi(nfailed),retry_bz(nfailed))
         retry_success = .false.
         ifailed = 0
         DO s = mystart, myend
            i = MOD(s-1,nr)+1
            j = MOD(s-1,nr*nphi)/nr+1
            k = (s-1)/(nr*nphi)+1
            IF ((i==1) .or. (i==nr) .or. (k==1) .or. (k==nz)) CYCLE
            IF (S_ARR(i,j,k) >= 0.0) CYCLE
            ifailed = ifailed + 1
            failed_index(ifailed) = s
            sflx = -1.0
            IF (S_ARR(i-1,j,k) >= 0.0 .and. S_ARR(i-1,j,k) <= 1.0) THEN
               sflx = S_ARR(i-1,j,k)
               uflx = U_ARR(i-1,j,k)
            ELSE IF (S_ARR(i+1,j,k) >= 0.0 .and. S_ARR(i+1,j,k) <= 1.0) THEN
               sflx = S_ARR(i+1,j,k)
               uflx = U_ARR(i+1,j,k)
            ELSE IF (S_ARR(i,j,k-1) >= 0.0 .and. S_ARR(i,j,k-1) <= 1.0) THEN
               sflx = S_ARR(i,j,k-1)
               uflx = U_ARR(i,j,k-1)
            ELSE IF (S_ARR(i,j,k+1) >= 0.0 .and. S_ARR(i,j,k+1) <= 1.0) THEN
               sflx = S_ARR(i,j,k+1)
               uflx = U_ARR(i,j,k+1)
            END IF
            IF (sflx < 0.0) CYCLE
            CALL GetBcyl(raxis_g(i),phiaxis(j),zaxis_g(k),&
                         br,bphi,bz,SFLX=sflx,UFLX=uflx,info=ier)
            IF (ier /= 0) CYCLE
            retry_success(ifailed) = .true.
            retry_s(ifailed) = MAX(sflx,0.0_rprec)
            retry_u(ifailed) = MODULO(uflx,pi2)
            retry_br(ifailed) = br
            retry_bphi(ifailed) = bphi
            retry_bz(ifailed) = bz
         END DO
      END IF

#if defined(MPI_OPT)
      CALL MPI_BARRIER(MPI_COMM_LOCAL,ierr_mpi)
#endif
      IF (nfailed > 0) THEN
         DO ifailed = 1, nfailed
            IF (.not. retry_success(ifailed)) CYCLE
            s = failed_index(ifailed)
            i = MOD(s-1,nr)+1
            j = MOD(s-1,nr*nphi)/nr+1
            k = (s-1)/(nr*nphi)+1
            S_ARR(i,j,k) = retry_s(ifailed)
            U_ARR(i,j,k) = retry_u(ifailed)
            B_R(i,j,k) = retry_br(ifailed)
            B_PHI(i,j,k) = retry_bphi(ifailed)
            B_Z(i,j,k) = retry_bz(ifailed)
         END DO
         DEALLOCATE(failed_index,retry_success,retry_s,retry_u,retry_br,&
                    retry_bphi,retry_bz)
      END IF
      
      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      !! Set S==-1 values to default
      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      ! S_ARR is only negative where GetBcyl returned ier=-1: the inverse
      ! map converged, but not to cyl2flx_ftol.  Points genuinely outside
      ! the plasma return -3 and keep the 4.0 initialisation, so this
      ! count is real non-convergence rather than vacuum.
      ! Only count failures at s < s_unconv_max.  Points further out are
      ! outside the plasma, where Newton cannot converge because no
      ! solution exists; flagging them is correct, not a problem, and
      ! counting them would make this warning fire on every healthy run.
      nunconv = 0
      IF (mylocalid == mylocalmaster) THEN
         nunconv = COUNT(S_ARR < 0.0 .and. S_ARR > -(1.0+s_unconv_max))
         WHERE(S_ARR < 0.0) S_ARR=4.0
      END IF
#if defined(MPI_OPT)
      CALL MPI_BARRIER(MPI_COMM_LOCAL,ierr_mpi)
#endif

      ! Centered Hermite derivatives need two exterior B support layers;
      ! flux labels, interior B, and wall coordinates remain unchanged.
      IF (lplasma_only) CALL beams3d_vmec_extend_exterior(&
         mystart,myend,MPI_COMM_LOCAL)

      IF (lverb .and. (nunconv > 0)) THEN
         WRITE(6,*)
         WRITE(6,'(5X,A,I0,A,F7.4,A)') 'WARNING: inverse map did not '// &
            'converge near the plasma in ', nunconv, ' grid cells (', &
            100.0*REAL(nunconv)/REAL(nr*nphi*nz), '% of grid)'
         WRITE(6,'(5X,A)') '         these are flagged S=4 and treated '// &
            'as outside the plasma;'
         WRITE(6,'(5X,A)') '         see CYL2FLX_FTOL, CYL2FLX_NITER, '// &
            'CYL2FLX_NRESTART, CYL2FLX_LBAIL_OUTSIDE'
         CALL FLUSH(6)
      END IF

      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      !! Evaluate the profile quantities on the background grid
      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      IF (lverb) THEN
         WRITE(6,*)
         WRITE(6,'(5X,A,I3.3,A)',ADVANCE='no') 'Profile Lookup [',0,']%'
      END IF
      CALL FLUSH(6)
      DO s = mystart, myend
         i = MOD(s-1,nr)+1
         j = MOD(s-1,nr*nphi)/nr+1
         k = (s-1)/(nr*nphi)+1
         sflx = S_ARR(i,j,k)
         sflx = MAX(sflx,0.0)
         ! Do the potential everwhere
         IF (npot > 0) CALL EZspline_interp(POT_spl_s,MIN(sflx,s_max_pot),POT_ARR(i,j,k),ier)
         IF (sflx <= s_max) THEN
            IF (nte > 0) CALL EZspline_interp(TE_spl_s,MIN(sflx,s_max_te),TE(i,j,k),ier)
            IF (nne > 0) CALL EZspline_interp(NE_spl_s,MIN(sflx,s_max_ne),NE(i,j,k),ier)
            IF (nti > 0) CALL EZspline_interp(TI_spl_s,MIN(sflx,s_max_ti),TI(i,j,k),ier)
            IF (nomeg > 0) CALL EZspline_interp(OMEG_spl_s,MIN(sflx,s_max_omeg),OMEG_ARR(i,j,k),ier)
            IF (nzeff > 0) THEN
               CALL EZspline_interp(ZEFF_spl_s,MIN(sflx,s_max_zeff),ZEFF_ARR(i,j,k),ier)
               DO u=1, NION
                  CALL EZspline_interp(NI_spl_s(u),MIN(sflx,s_max_zeff),NI(u,i,j,k),ier)
               END DO
            END IF
         END IF
         IF (MOD(s,nr) == 0) THEN
            IF (lverb) THEN
               CALL backspace_out(6,6)
               WRITE(6,'(A,I3,A)',ADVANCE='no') '[',INT((100.*s)/(myend-mystart+1)),']%'
            END IF
         END IF
         CALL FLUSH(6)
      END DO

      ! Fix ZEFF
      IF (mylocalid == mylocalmaster) WHERE(ZEFF_ARR < 1) ZEFF_ARR = 1

      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      !! Virtual casing if requested.
      !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
      IF (luse_vc) THEN
         IF (lverb) THEN
            WRITE(6,*)
            WRITE(6,'(5X,A,I3.3,A)',ADVANCE='no') 'Virtual Casing [',0,']%'
         END IF
         CALL FLUSH(6)
         DO s = mystart, myend
            i = MOD(s-1,nr)+1
            j = MOD(s-1,nr*nphi)/nr+1
            k = (s-1)/(nr*nphi)+1
            sflx = S_ARR(i,j,k)
            sflx = MAX(sflx,0.0)
            IF (sflx <= 1.0) CYCLE
            xaxis_vc = raxis_g(i)*cos(phiaxis(j))
            yaxis_vc = raxis_g(i)*sin(phiaxis(j))
            zaxis_vc = zaxis_g(k)
            adapt_rel = 0.0
            adapt_tol = vc_adapt_tol*sqrt(B_R(i,j,k)**2+B_PHI(i,j,k)**2+B_Z(i,j,k)**2)
            ier = 1
            CALL bfield_vc(xaxis_vc,yaxis_vc,zaxis_vc,bx_vc,by_vc,bz_vc,ier)
            IF (ier == 0) THEN
               br_vc   = bx_vc * cos(phiaxis(j)) + by_vc * sin(phiaxis(j))
               bphi_vc = by_vc * cos(phiaxis(j)) - bx_vc * sin(phiaxis(j))
               IF (ABS(br_vc) > 0)   B_R(i,j,k)   = B_R(i,j,k) + br_vc
               IF (ABS(bphi_vc) > 0) B_PHI(i,j,k) = B_PHI(i,j,k) + bphi_vc
               IF (ABS(bz_vc) > 0)   B_Z(i,j,k)   = B_Z(i,j,k) + bz_vc
            ELSE IF (ier > 1) THEN ! Only report real errors not failure to find tolerance errors
               WRITE(6,*) myworkid,mylocalid,i,j,k,ier
            END IF
            IF (MOD(s,nr) == 0) THEN
               IF (lverb) THEN
                  CALL backspace_out(6,6)
                  WRITE(6,'(A,I3,A)',ADVANCE='no') '[',INT((100.*s)/(myend-mystart+1)),']%'
               END IF
            END IF
            CALL FLUSH(6)
         END DO
      END IF
      
#if defined(MPI_OPT)
      CALL MPI_BARRIER(MPI_COMM_LOCAL,ierr_mpi)
#endif
      
      ! Free variables
      IF (luse_vc) CALL free_virtual_casing(MPI_COMM_BEAMS)

      ! Calculate Gfactor for mgrid
      IF (myworkid == master) THEN
         ! Only master has Gfactor
         ALLOCATE(Gfactor(ns_prof1))
         DO s = 1, ns_prof1
            sflx = MIN(REAL(s-0.5)/h1_prof,1.0)
            sflx = sflx*sflx
            CALL EZspline_interp(ZEFF_spl_s,sflx,uflx,ier)
            CALL vmec_ohkawa(sflx,uflx,Gfactor(s)) ! (1-l31)/Zeff
         END DO
      ENDIF

      ! Deallocations
      IF (myworkid == master) THEN
         CALL read_wout_deallocate
      ELSE
         lwout_opened = .FALSE.
         DEALLOCATE(vp,phi,phipf,iotaf)
         DEALLOCATE(xm,xn,xm_nyq,xn_nyq)
         DEALLOCATE(rmnc,zmns,lmns,bsupumnc,bsupvmnc)
         IF (lasym) DEALLOCATE(rmns,zmnc,lmnc,bsupumns,bsupvmns)
         DEALLOCATE(rzl_local)
      END IF
      
      IF (lverb) THEN
         WRITE(6,*)
         CALL FLUSH(6)
      END IF    

#if defined(MPI_OPT)
      CALL MPI_BARRIER(MPI_COMM_LOCAL,ierr_mpi)
      CALL MPI_COMM_FREE(MPI_COMM_LOCAL,ierr_mpi)
      CALL MPI_BARRIER(MPI_COMM_BEAMS,ierr_mpi)
      IF (ierr_mpi /=0) CALL handle_err(MPI_BARRIER_ERR,'beams3d_init_vmec',ierr_mpi)
#endif

      RETURN
!-----------------------------------------------------------------------
!     End Subroutine
!-----------------------------------------------------------------------    
      END SUBROUTINE beams3d_init_vmec

      SUBROUTINE beams3d_vmec_extend_exterior(mystart,myend,comm)
      USE stel_kinds, ONLY: rprec
      USE beams3d_grid, ONLY: S_ARR, B_R, B_PHI, B_Z
      USE mpi_inc
      IMPLICIT NONE
      INTEGER, INTENT(in) :: mystart, myend, comm
      INTEGER :: s, i, j, k, nsupport, isupport, ierr_mpi
      INTEGER, ALLOCATABLE :: support_index(:)
      LOGICAL :: success
      REAL(rprec) :: br, bphi, bz
      REAL(rprec), ALLOCATABLE :: support_br(:), support_bphi(:), support_bz(:)

      ALLOCATE(support_index(myend-mystart+1),support_br(myend-mystart+1),&
               support_bphi(myend-mystart+1),support_bz(myend-mystart+1))
      nsupport = 0
      DO s = mystart, myend
         CALL beams3d_vmec_support_index(s,i,j,k)
         IF (S_ARR(i,j,k) <= 1.0) CYCLE
         CALL beams3d_vmec_exterior_support(i,j,k,success,br,bphi,bz)
         IF (.not. success) CYCLE
         nsupport = nsupport + 1
         support_index(nsupport) = s
         support_br(nsupport) = br
         support_bphi(nsupport) = bphi
         support_bz(nsupport) = bz
      END DO

#if defined(MPI_OPT)
      CALL MPI_BARRIER(comm,ierr_mpi)
#endif
      IF (nsupport > 0) THEN
         DO isupport = 1, nsupport
            CALL beams3d_vmec_support_index(support_index(isupport),i,j,k)
            B_R(i,j,k) = support_br(isupport)
            B_PHI(i,j,k) = support_bphi(isupport)
            B_Z(i,j,k) = support_bz(isupport)
         END DO
      END IF
      DEALLOCATE(support_index,support_br,support_bphi,support_bz)
#if defined(MPI_OPT)
      CALL MPI_BARRIER(comm,ierr_mpi)
#endif
      END SUBROUTINE beams3d_vmec_extend_exterior

      SUBROUTINE beams3d_vmec_support_index(s,i,j,k)
      USE beams3d_grid, ONLY: nr, nphi
      IMPLICIT NONE
      INTEGER, INTENT(in) :: s
      INTEGER, INTENT(out) :: i, j, k
      i = MOD(s-1,nr)+1
      j = MOD(s-1,nr*nphi)/nr+1
      k = (s-1)/(nr*nphi)+1
      END SUBROUTINE beams3d_vmec_support_index

      SUBROUTINE beams3d_vmec_exterior_support(i,j,k,success,br,bphi,bz)
      USE stel_kinds, ONLY: rprec
      USE beams3d_grid, ONLY: nr, nz, raxis_g => raxis, zaxis_g => zaxis,&
                             S_ARR, B_R, B_PHI, B_Z
      IMPLICIT NONE
      INTEGER, INTENT(in) :: i, j, k
      LOGICAL, INTENT(out) :: success
      REAL(rprec), INTENT(out) :: br, bphi, bz
      INTEGER :: ndir
      LOGICAL :: found
      REAL(rprec) :: candidate(3), field_sum(3)

      success = .false.
      br = 0.0_rprec
      bphi = 0.0_rprec
      bz = 0.0_rprec
      field_sum = 0.0_rprec
      ndir = 0

      IF (i > 2) THEN
         CALL beams3d_vmec_support_pair(S_ARR(i-1,j,k),S_ARR(i-2,j,k),&
            raxis_g(i),raxis_g(i-1),raxis_g(i-2),&
            (/B_R(i-1,j,k),B_PHI(i-1,j,k),B_Z(i-1,j,k)/),&
            (/B_R(i-2,j,k),B_PHI(i-2,j,k),B_Z(i-2,j,k)/),found,candidate)
         IF (.not. found .and. i > 3) THEN
            IF (S_ARR(i-1,j,k) > 1.0) CALL beams3d_vmec_support_pair(&
               S_ARR(i-2,j,k),S_ARR(i-3,j,k),raxis_g(i),raxis_g(i-2),&
               raxis_g(i-3),(/B_R(i-2,j,k),B_PHI(i-2,j,k),B_Z(i-2,j,k)/),&
               (/B_R(i-3,j,k),B_PHI(i-3,j,k),B_Z(i-3,j,k)/),found,candidate)
         END IF
         CALL beams3d_vmec_add_support(candidate,found,field_sum,ndir)
      END IF

      IF (i < nr-1) THEN
         CALL beams3d_vmec_support_pair(S_ARR(i+1,j,k),S_ARR(i+2,j,k),&
            raxis_g(i),raxis_g(i+1),raxis_g(i+2),&
            (/B_R(i+1,j,k),B_PHI(i+1,j,k),B_Z(i+1,j,k)/),&
            (/B_R(i+2,j,k),B_PHI(i+2,j,k),B_Z(i+2,j,k)/),found,candidate)
         IF (.not. found .and. i < nr-2) THEN
            IF (S_ARR(i+1,j,k) > 1.0) CALL beams3d_vmec_support_pair(&
               S_ARR(i+2,j,k),S_ARR(i+3,j,k),raxis_g(i),raxis_g(i+2),&
               raxis_g(i+3),(/B_R(i+2,j,k),B_PHI(i+2,j,k),B_Z(i+2,j,k)/),&
               (/B_R(i+3,j,k),B_PHI(i+3,j,k),B_Z(i+3,j,k)/),found,candidate)
         END IF
         CALL beams3d_vmec_add_support(candidate,found,field_sum,ndir)
      END IF

      IF (k > 2) THEN
         CALL beams3d_vmec_support_pair(S_ARR(i,j,k-1),S_ARR(i,j,k-2),&
            zaxis_g(k),zaxis_g(k-1),zaxis_g(k-2),&
            (/B_R(i,j,k-1),B_PHI(i,j,k-1),B_Z(i,j,k-1)/),&
            (/B_R(i,j,k-2),B_PHI(i,j,k-2),B_Z(i,j,k-2)/),found,candidate)
         IF (.not. found .and. k > 3) THEN
            IF (S_ARR(i,j,k-1) > 1.0) CALL beams3d_vmec_support_pair(&
               S_ARR(i,j,k-2),S_ARR(i,j,k-3),zaxis_g(k),zaxis_g(k-2),&
               zaxis_g(k-3),(/B_R(i,j,k-2),B_PHI(i,j,k-2),B_Z(i,j,k-2)/),&
               (/B_R(i,j,k-3),B_PHI(i,j,k-3),B_Z(i,j,k-3)/),found,candidate)
         END IF
         CALL beams3d_vmec_add_support(candidate,found,field_sum,ndir)
      END IF

      IF (k < nz-1) THEN
         CALL beams3d_vmec_support_pair(S_ARR(i,j,k+1),S_ARR(i,j,k+2),&
            zaxis_g(k),zaxis_g(k+1),zaxis_g(k+2),&
            (/B_R(i,j,k+1),B_PHI(i,j,k+1),B_Z(i,j,k+1)/),&
            (/B_R(i,j,k+2),B_PHI(i,j,k+2),B_Z(i,j,k+2)/),found,candidate)
         IF (.not. found .and. k < nz-2) THEN
            IF (S_ARR(i,j,k+1) > 1.0) CALL beams3d_vmec_support_pair(&
               S_ARR(i,j,k+2),S_ARR(i,j,k+3),zaxis_g(k),zaxis_g(k+2),&
               zaxis_g(k+3),(/B_R(i,j,k+2),B_PHI(i,j,k+2),B_Z(i,j,k+2)/),&
               (/B_R(i,j,k+3),B_PHI(i,j,k+3),B_Z(i,j,k+3)/),found,candidate)
         END IF
         CALL beams3d_vmec_add_support(candidate,found,field_sum,ndir)
      END IF

      IF (ndir == 0) RETURN
      br = field_sum(1)/REAL(ndir,rprec)
      bphi = field_sum(2)/REAL(ndir,rprec)
      bz = field_sum(3)/REAL(ndir,rprec)
      success = .true.

      END SUBROUTINE beams3d_vmec_exterior_support

      SUBROUTINE beams3d_vmec_support_pair(flux1,flux2,x0,x1,x2,&
                                           field1,field2,success,field)
      USE stel_kinds, ONLY: rprec
      IMPLICIT NONE
      REAL(rprec), INTENT(in) :: flux1, flux2, x0, x1, x2
      REAL(rprec), INTENT(in) :: field1(3), field2(3)
      LOGICAL, INTENT(out) :: success
      REAL(rprec), INTENT(out) :: field(3)
      REAL(rprec) :: factor

      success = flux1 >= 0.0_rprec .and. flux1 <= 1.0_rprec .and. &
                flux2 >= 0.0_rprec .and. flux2 <= 1.0_rprec
      field = 0.0_rprec
      IF (.not. success) RETURN
      factor = (x0-x1)/(x1-x2)
      field = field1 + factor*(field1-field2)
      END SUBROUTINE beams3d_vmec_support_pair

      SUBROUTINE beams3d_vmec_add_support(candidate,success,field_sum,count)
      USE stel_kinds, ONLY: rprec
      IMPLICIT NONE
      REAL(rprec), INTENT(in) :: candidate(3)
      LOGICAL, INTENT(in) :: success
      REAL(rprec), INTENT(inout) :: field_sum(3)
      INTEGER, INTENT(inout) :: count
      IF (.not. success) RETURN
      field_sum = field_sum + candidate
      count = count + 1
      END SUBROUTINE beams3d_vmec_add_support
