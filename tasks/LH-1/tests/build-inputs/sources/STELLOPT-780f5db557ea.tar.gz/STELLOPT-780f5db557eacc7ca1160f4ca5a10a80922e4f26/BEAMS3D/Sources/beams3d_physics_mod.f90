!-----------------------------------------------------------------------
!     Module:        beams3d_physics_mod
!     Authors:       M. McMillan (matthew.mcmillan@my.wheaton.edu)
!     Date:          07/20/2012
!     Description:   This module contains the physics subroutines for
!                    manipulating particles and finding when to do so.
!-----------------------------------------------------------------------
MODULE beams3d_physics_mod

      !-----------------------------------------------------------------
      !     Libraries
      !-----------------------------------------------------------------
      USE stel_kinds, ONLY: rprec
      USE beams3d_runtime, ONLY: lneut, pi, pi2, dt, lverb, ADAS_ERR, &
                                 dt_save, lbbnbi, weight, ndt, &
                                 ndt_max, npoinc, lendt_m, te_col_min, &
                                 NION, NI_AUX_M, NI_AUX_Z, vll_start, charge_beams
      USE beams3d_lines, ONLY: R_lines, Z_lines, PHI_lines, &
                               vr_lines, vphi_lines, vz_lines, &
                               myline, mytdex, moment, ltherm, &
                               nparticles, vll_lines, &
                               moment_lines, mybeam, mycharge, myZ, &
                               mymass, myv_neut, rand_prob, &
                               cum_prob, tau, &
                               epower_prof, ipower_prof, &
                               end_state, fact_crit, fact_crit_pro, fact_pa, &
                               fact_vsound, fact_coul, fact_kick, &
                               ns_prof1, ns_prof2, ns_prof3, ns_prof4, &
                               ns_prof5, my_end, h1_prof, fact_crit_legacy
      USE beams3d_grid, ONLY: delta_t, MODB4D, OMEG4D, nomeg,&
                              phimax, TE4D, NE4D, TI4D, ZEFF4D, &
                              RHO4D, XRHO4D, YRHO4D, &
                              nr, nphi, nz, rmax, rmin, zmax, zmin, &
                              phimin, eps1, eps2, eps3, raxis, phiaxis,&
                              zaxis, U4D,nzeff, dexionT, dexionD, dexionHe3, &
                              hr, hp, hz, hri, hpi, hzi, &
                              B_kick_min, B_kick_max, E_kick, freq_kick, &
                              nsub_fullorbit, &
                              plasma_mass, NI5D, BR4D, BZ4D, BPHI4D,plasma_Zmean
      USE EZspline_obj
      USE EZspline
      USE adas_mod_parallel
      USE collision_operators, ONLY: COULOMB_LOG_NRL_COUNTERSTREAM,&
                                     V_CRITICAL, V_CRITICAL_WEILAND, &
                                     TAU_SPITZER
      USE fusion_mod, ONLY: DT_CROSS_SECTION, DD_CROSS_SECTION, &
                            DDHe3_CROSS_SECTION, DHe3_CROSS_SECTION
      USE mpi_params 

      !-----------------------------------------------------------------
      !     Module PARAMETERS
      !-----------------------------------------------------------------

      DOUBLE PRECISION, PRIVATE, PARAMETER :: electron_mass = 9.10938356D-31 !m_e
      DOUBLE PRECISION, PRIVATE, PARAMETER :: e_charge      = 1.60217662E-19 !e_c
      DOUBLE PRECISION, PRIVATE, PARAMETER :: sqrt_pi       = 1.7724538509   !pi^(1/2)
      DOUBLE PRECISION, PRIVATE, PARAMETER :: inv_sqrt2     = 0.7071067812   !1/sqrt(2)
      DOUBLE PRECISION, PRIVATE, PARAMETER :: mpome         = 5.44602984424355D-4 !e_c
      DOUBLE PRECISION, PRIVATE, PARAMETER :: inv_dalton    = 6.02214076208E+26 ! 1./AMU [1/kg]
      DOUBLE PRECISION, PRIVATE, PARAMETER :: inv_Ae    = 1.0/1836.1d0 ! AMU./electron_mass
      DOUBLE PRECISION, PRIVATE, PARAMETER :: inv_cspeed    = 3.3356409520E-09 ! 1./c [s/m]
      DOUBLE PRECISION, PRIVATE, PARAMETER :: zero          = 0.0D0 ! 0.0
      DOUBLE PRECISION, PRIVATE, PARAMETER :: half          = 0.5D0 ! 1/2
      DOUBLE PRECISION, PRIVATE, PARAMETER :: one           = 1.0D0 ! 1.0
      DOUBLE PRECISION, PRIVATE, PARAMETER :: eps_0 = 8.854187817E-12;
      DOUBLE PRECISION, PRIVATE, PARAMETER :: hbar = 1.054571817E-34;

      !-----------------------------------------------------------------
      !     SUBROUTINES
      !        BEAMS3D_PHYISCS(t,q) Slowing down and pitch angle
      !        BEAMS3D_FOLLOW_NEUT(t,q) Neutral particle following
      !-----------------------------------------------------------------
      CONTAINS

      !-----------------------------------------------------------------
      !     Function:      coll_op_nrl19
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          07/05/2023
      !     Description:   Slowing down calc using
      !                    Coulomb log as defined in NRL 2019 for all species
      !                    Calculationg method before 2024
      !-----------------------------------------------------------------
      FUNCTION coll_op_nrl19(ne_in,te_in,vbeta_in,Zeff_in)   result(slow_par)
         !--------------------------------------------------------------
         !     Input Parameters
         !          ne_in        Electron Density [m^-3]
         !          te_in        Electron Temperature [eV]
         !          vbeta_in     Normalized Particle Velocity [c]
         !          Zeff_in      Plasma effective charge [arb]
         !     Output Parameters
         !          slow_par(1)     Critical velocity vcrit [m/s]    
         !          slow_par(2)     Spitzer time tau_spit [s]    
         !          slow_par(3)     Pitch angle scattering factor [arb]        
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION :: slow_par(3)
         DOUBLE PRECISION, INTENT(in) :: ne_in, te_in, vbeta_in, Zeff_in
         DOUBLE PRECISION :: ne_cm,coulomb_log
         coulomb_log = COULOMB_LOG_NRL_COUNTERSTREAM(ne_in,te_in,vbeta_in,Zeff_in)
         slow_par(1) = V_CRITICAL(te_in)
         slow_par(2) = TAU_SPITZER(mymass,ne_in,te_in,myZ,coulomb_log)
         slow_par(3) = Zeff_in*fact_pa  
      END FUNCTION coll_op_nrl19

      !-----------------------------------------------------------------
      !     Function:      coll_op_nrl19_ie
      !     Authors:       D. Kulla (david.kulla@ipp.mpg.de)
      !     Date:          07/05/2023
      !     Description:   Slowing down calc using
      !                    Coulomb log as defined in NRL 2019 for ions
      !                    Coulomb log as defined in NRL 2019 for electrons
      !-----------------------------------------------------------------
      FUNCTION coll_op_nrl19_ie(ne_in,te_in,vbeta_in,Zeff_in)  result(slow_par)
         !--------------------------------------------------------------
         !     Input Parameters
         !          ne_in        Electron Density [m^-3]
         !          te_in        Electron Temperature [eV]
         !          vbeta_in     Normalized Particle Velocity [c]
         !          Zeff_in      Plasma effective charge [arb]
         !     Output Parameters
         !          slow_par(1)  Critical velocity vcrit [m/s]    
         !          slow_par(2)  Spitzer time tau_spit [s]    
         !          slow_par(3)  Pitch angle scattering factor [arb]  
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION :: slow_par(3)
         DOUBLE PRECISION, INTENT(in) :: ne_in, te_in, vbeta_in, Zeff_in
         DOUBLE PRECISION :: ne_cm, coulomb_loge, coulomb_logi
         coulomb_logi = COULOMB_LOG_NRL_COUNTERSTREAM(ne_in,te_in,vbeta_in,Zeff_in)
         coulomb_loge = log(1.09d11 * te_in/Zeff_in/sqrt(ne_cm))
         slow_par(1) = V_CRITICAL_WEILAND(te_in,coulomb_logi,coulomb_loge)
         slow_par(2) = TAU_SPITZER(mymass,ne_in,te_in,myZ,coulomb_loge)
         slow_par(3) = Zeff_in*fact_pa  
         RETURN
      END FUNCTION coll_op_nrl19_ie

      !-----------------------------------------------------------------
      !     Function:      coll_op_nubeam
      !     Authors:       D. Kulla (david.kulla@ipp.mpg.de)
      !     Date:          07/05/2023
      !     Description:   Slowing down calc using
      !                    Coulomb log as defined in NUBEAM code
      !                    (r8_coulog.f90).
      !-----------------------------------------------------------------
      FUNCTION coll_op_nubeam(ne_in,ni_in,te_in,ti_in,vbeta_in,Zeff_in,modb,speed_in) result(slow_par)
         !--------------------------------------------------------------
         !     Input Parameters
         !          ne_in        Electron Density [m^-3]
         !          ni_in        Ion Densities [m^-3]
         !          te_in        Electron Temperature [eV]
         !          ti_in        Electron Temperature [eV]
         !          Zeff_in      Plasma effective charge [arb]
         !     Output Parameters
         !          slow_par(1)  Critical velocity vcrit [m/s]    
         !          slow_par(2)  Spitzer time tau_spit [s]    
         !          slow_par(3)  Pitch angle scattering factor [arb]  
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION :: slow_par(3)
         DOUBLE PRECISION, INTENT(in) :: ne_in, te_in, ti_in, ni_in(NION),vbeta_in, Zeff_in, speed_in,modb
         INTEGER :: i
         DOUBLE PRECISION :: sm, omega2, vrel2,vrel2_part,bmincl,bminqu,bmax,bmin,coulomb_log, coulomb_loge, zi2_ai, zi2,myA
         ! Same formulation as NUBEAM internal calculation (r8_coulog.f90), different Units than usual: 
         !Z is in elementary charge, A is in amu, energy and temperature in keV.
         vrel2_part=speed_in**2/e_charge/inv_dalton
         sm=zero
         do i=1,COUNT(NI_AUX_Z>0)
            myA = NI_AUX_M(i)*inv_dalton
            omega2=1.74d0*NI_AUX_Z(i)**2/(myA)*ni_in(i) & 
                  +9.18d15*NI_AUX_Z(i)**2/(myA)**2*modb**2
            vrel2=9.58d7*(ti_in/(myA) + vrel2_part) !Assume same ti for all species
            sm=sm+omega2/vrel2
         end do
         myA = mymass*inv_dalton

         !Electrons A_e=1/1836.1
         omega2=1.74d0*1836.1*ne_in &
                +9.18d15*1836.1**2*modb**2
         vrel2=9.58d7*(te_in*1836.1 + vrel2_part)
         sm=sm+omega2/vrel2
         bmax=sqrt(one/sm)
         vrel2=9.58d7*(3.0*te_in*1836.1 + vrel2_part) !Different vrel for bmin calc                 
         bmincl=0.13793d0*abs(mycharge/e_charge)*(inv_Ae+myA)/(inv_Ae*myA*vrel2)
         bminqu=1.9121d-8*(myA+inv_Ae)/(inv_Ae*myA*sqrt(vrel2))
         bmin=max(bmincl,bminqu)
         coulomb_loge=log(bmax/bmin) !only last coulomb log is saved
         coulomb_loge = max(coulomb_loge,one)
         zi2_ai=zero
         zi2=zero

         do i=1,COUNT(NI_AUX_Z>0)
            vrel2=9.58d7*(3.0*ti_in/(NI_AUX_M(i)*inv_dalton) +  vrel2_part) !Assume same ti for all species
            bmincl=0.13793d0*abs(NI_AUX_Z(i)*mycharge/e_charge)*(NI_AUX_M(i)+mymass)/NI_AUX_M(i)/myA/vrel2
            bminqu=1.9121d-8*(NI_AUX_M(i)+mymass)/NI_AUX_M(i)/myA/sqrt(vrel2)
            bmin=max(bmincl,bminqu)
            coulomb_log=log(bmax/bmin) !only last coulomb log is saved - TODO: implement for multi-species
            coulomb_log = max(coulomb_log,one)
            zi2_ai = zi2_ai+ni_in(i) *NI_AUX_Z(i)**2/(NI_AUX_M(i)*inv_dalton) * coulomb_log
            zi2 = zi2+ni_in(i) *NI_AUX_Z(i)**2 * coulomb_log
            !WRITE(6,*) coulomb_log, coulomb_loge
         end do
         coulomb_log = max(coulomb_log,one)
      
         zi2_ai=zi2_ai/(ne_in*coulomb_loge)
         zi2=zi2/(ne_in*coulomb_loge)

         slow_par(1) = 5.33e4*SQRT(te_in) * (zi2_ai)**(1.0/3.0)
         slow_par(2) =6.32e8*myA/(myZ*myZ*coulomb_loge)*SQRT(te_in*te_in*te_in)/(ne_in*1.0e-6)
         slow_par(3) =zi2/zi2_ai/myA
         RETURN
      END FUNCTION coll_op_nubeam

      !-----------------------------------------------------------------
      !     Function:      beams3d_physics_gc
      !     Authors:       S. Lazerson (lazerson@pppl.gov)
      !                    M. McMillan (matthew.mcmillan@my.wheaton.edu)
      !     Date:          07/13/2012
      !     Description:   Particle slowing down and pitch angle
      !                    scattering for gyrocenters
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_physics_gc(t, q)
         !--------------------------------------------------------------
         !     Input Parameters
         !          t          Location along fieldline in t
         !          q            (q(1),q(2),q(3),q(4)) = (R,phi,Z,vll)
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: t
         DOUBLE PRECISION, INTENT(inout) :: q(4)
         !--------------------------------------------------------------
         !     Local Variables
         !        tau_spit The Spitzer characteristic time
         !        tau_spit_inv Helper 1/tau_spit
         !        v_crit       Critical velocity (transition to ion slowing)
         !        coulomb_log  Couloumb Logarithm (see NRL) 
         !--------------------------------------------------------------
         INTEGER        :: ier
         DOUBLE PRECISION    :: r_temp, phi_temp, z_temp, vll, te_temp, ne_temp, ti_temp, speed, newspeed, &
                          zeta, sigma, zeta_mean, zeta_o, v_s, tau_inv, tau_spit_inv, &
                          reduction, dve,dvi,ddve,ddvi, tau_spit, v_crit, coulomb_log, te_cube, &
                          inv_mymass, speed_cube, vcrit_cube, vfrac, modb, bphi_temp, s_temp, &
                          rho_temp, omeg_temp, binv, vrot_para, vrot_perp, &
                          vc3_tauinv, vbeta, zeff_temp,&
                          sm,omega2,vrel2,bmax,bmincl,bminqu,bmin,&
                          zdelth,zrang, factor_ion, factor_electron, speed3inv, speed2inv
         DOUBLE PRECISION :: Ebench  ! for ASCOT Benchmark
         DOUBLE PRECISION :: slow_par(3), ni_temp(NION)
         ! For splines
         INTEGER :: i,j,k, l
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)


         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------
      
         ier      = 0
         ! Setup position in a vll arrays
         r_temp   = q(1)
         phi_temp = MODULO(q(2), phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         z_temp   = q(3)
         vll      = q(4)

         ! Initialize values
         te_temp  = 0; ne_temp  = 0; ti_temp  = 0; zeff_temp=1;
         speed = 0; reduction = 0; modb=0;bphi_temp=0;omeg_temp=0;
         vrot_para=0;vrot_perp=0;binv=0

         tau_spit_inv = 0.0; v_crit   = 0.0; coulomb_log = 15
         tau_inv = 10.0; vcrit_cube = 0.0; vc3_tauinv = 0

         ! Check that we're inside the domain then proceed
         IF ((r_temp >= rmin-eps1) .and. (r_temp <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z_temp >= zmin-eps3) .and. (z_temp <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
            xparam = (r_temp - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z_temp - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            MODB4D(1,1,1,1),nr,nphi,nz)
            modb = fval(1)
            binv = one/modb
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            BPHI4D(1,1,1,1),nr,nphi,nz)
            bphi_temp = fval(1)            
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            TE4D(1,1,1,1),nr,nphi,nz)
            te_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            NE4D(1,1,1,1),nr,nphi,nz)
            ne_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            TI4D(1,1,1,1),nr,nphi,nz)
            ti_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            ZEFF4D(1,1,1,1),nr,nphi,nz)
            zeff_temp = max(fval(1),one)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            RHO4D(1,1,1,1),nr,nphi,nz)
            rho_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            OMEG4D(1,1,1,1),nr,nphi,nz)
            omeg_temp = fval(1)       
            DO l = 1, NION
               CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                  hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                  NI5D(1,1,1,1,l),nr,nphi,nz)
               ni_temp(l) = max(fval(1),zero) !Set to one to prevent NaN Zeff later on
            END DO

            !-----------------------------------------------------------
            !  Apply toroidal rotation
            !     vrot_para: Parallel rotation velocity [m/s]
            !     vrot_perp: Perpendicular rotation velocity [m/s]
            !     speed      Total particle speed [m/s]
            !-----------------------------------------------------------
            inv_mymass = one/mymass
            vrot_para = omeg_temp*r_temp*bphi_temp*binv
            vrot_perp = SQRT(max(omeg_temp*omeg_temp*r_temp*r_temp - vrot_para*vrot_para,zero))
            vll       = vll - vrot_para
            speed     = SQRT(max(vll*vll + 2*moment*modb*inv_mymass - vrot_perp*vrot_perp,zero))

            !-----------------------------------------------------------
            !  Helpers
            !     v_s       Local Sound Speed
            !     speed     Total particle speed
            !-----------------------------------------------------------
            v_s = fact_vsound*sqrt(ti_temp)
            vbeta = max(ABS(speed-v_s)*inv_cspeed,1E-6)

            !-----------------------------------------------------------
            !  Calculate Coulomb Logarithm
            !     te in eV and ne in cm^-3
            !-----------------------------------------------------------
            IF ((te_temp > te_col_min).and.(ne_temp > 0)) THEN
#if defined(B3D_COLLOP_NRL19IE)
               slow_par = coll_op_nrl19_ie(ne_temp,te_temp,vbeta,Zeff_temp)
#elif defined(B3D_COLLOP_NUBEAM)
               slow_par = coll_op_nubeam(ne_temp,ni_temp,te_temp,ti_temp,vbeta,Zeff_temp,modb,speed)
#else
               slow_par = coll_op_nrl19(ne_temp,te_temp,vbeta,Zeff_temp)
#endif
               vcrit_cube = slow_par(1)*slow_par(1)*slow_par(1)
               tau_spit_inv = one/slow_par(2)
               vc3_tauinv = vcrit_cube*tau_spit_inv
            ELSE !Dont evaluate collisions
               !q(4) = vll + vrot_para
               RETURN
            END IF

            !------------------------------------------------------------
            !  Velocity diffusion 
            !   https://doi.org/10.1103/PhysRev.107.1
            !   https://doi.org/10.1063/1.1694943
            !   https://doi.org/10.1016/0021-9991(81)90111-X
            !   https://doi.org/10.1016/j.cpc.2014.01.014
            !     speed3inv    v**-3 [m^3/s^3]
            !     speed2inv    v**-2 [m^3/s^3]
            !     ddve
            !------------------------------------------------------------
            ddve = zero; ddvi = zero; sigma = zero; zeta = zero;
            factor_ion = one; factor_electron = one
#if defined(B3D_VEL_DIFFUSION)
            speed3inv = 1.0/(speed*speed*speed)
            speed2inv = speed*speed3inv
            ddve=ABS(2*e_charge*dt*te_temp*inv_mymass*tau_spit_inv)
            ddvi=ABS(2*e_charge*dt*ti_temp*vcrit_cube*inv_mymass*speed3inv*tau_spit_inv)
            CALL gauss_rand(1,zeta)  ! A random from a standard normal (1,1)
            sigma = sqrt( ddve+ddvi) ! The standard deviation.
            ddve=zeta*ddve/sigma
            ddvi=zeta*ddvi/sigma
            factor_electron = ( 1.0 - 2.0*te_temp*inv_mymass*e_charge*speed2inv)
            factor_ion      = ( 1.0 +     ti_temp*inv_mymass*e_charge*speed2inv)
#endif
            !-----------------------------------------------------------
            !  Viscouse Velocity Reduction
            !     dve       Speed change due to electron slowing down 
            !     dvi       Speed change due to ion slowing down 
            !     reduction Total change in speed
            !     newspeed  New total speed
            !     vfrac     Ratio between new and old speed (helper) 
            !-----------------------------------------------------------
            dve   = factor_electron*speed*tau_spit_inv
            dvi   = factor_ion*vc3_tauinv/(speed*speed)
            reduction = (dve + dvi)*dt+sigma*zeta
            newspeed = speed - reduction                
            dve=dve+ddve
            dvi=dvi+ddvi
            vfrac = newspeed/speed
            !-----------------------------------------------------------
            !  Thermalize particle or adjust vll and moment
            !  Fowler et al. NF 1990 30 (6) 997--1010
            !-----------------------------------------------------------
            IF (newspeed < v_s) THEN  ! Thermalize
               dve       = dve/reduction
               dvi       = dvi/reduction
               reduction = (speed - v_s)/dt  ! Thermalize
               dve       = dve*reduction
               dvi       = dvi*reduction
               newspeed = speed - reduction*dt
               ltherm = .true.
               vfrac = newspeed/speed
               vll = vfrac*vll
               moment = max(half*mymass*(newspeed*newspeed - vll*vll + vrot_perp*vrot_perp)*binv,zero)
               q(4) = vll + vrot_para
               RETURN
            END IF           
            l = MAX(MIN(CEILING(rho_temp*h1_prof),ns_prof1),1)
            epower_prof(mybeam,l) = epower_prof(mybeam,l) + mymass*dve*dt*speed*weight(myline)
            ipower_prof(mybeam,l) = ipower_prof(mybeam,l) + mymass*dvi*dt*speed*weight(myline)
            vll = vfrac*vll
            moment = vfrac*vfrac*moment
            speed = newspeed
            !------------------------------------------------------------
            !  Pitch Angle Scattering
            !------------------------------------------------------------
            speed_cube = vc3_tauinv*slow_par(3)*dt/(speed*speed*speed) ! redefine as inverse
            zeta_o = vll/speed   ! Record the current pitch.
            CALL gauss_rand(1,zeta)  ! A random from a standard normal (1,1)
            sigma = sqrt( ABS((one-zeta_o*zeta_o)*speed_cube) ) ! The standard deviation.
            zeta_mean = zeta_o *(one - speed_cube )  ! The new mean in the distribution.
            zeta = zeta*sigma + zeta_mean  ! The new pitch angle.
            !!!The pitch angle MUST NOT go outside [-1,1] nor be NaN; but could happen accidentally with the distribution.
            zeta = MIN(MAX(zeta,-0.99999D+00),0.99999D+00)
            !Flip gaussian at boundary to prevent accumulation around pitch=1
            !zeta=zeta-SIGN(one,zeta)*MAX((ABS(zeta)-0.999D+00),zero)
            !Pitch angle scattering according to NUBEAM
            !sigma = sqrt(one-zeta_o*zeta_o) ! The standard deviation.
            !CALL RANDOM_NUMBER(zeta)
            !zdelth=SQRT(-2.0D+00*speed_cube*LOG(zeta))
            !CALL RANDOM_NUMBER(zrang)
            !zrang=zrang*pi2
            !zeta=SIN(zdelth)*cos(zrang)*sigma+COS(zdelth)*zeta_o
            vll = zeta*speed

            !------------------------------------------------------------
            !  Kick Model Scattering (old)
            !------------------------------------------------------------
            !IF (modb>=B_kick_min .and. modb<=B_kick_max) THEN
            !   zeta_o = vll/speed   ! Record the current pitch.
            !   zeta = zeta_o-zeta_o*(one-zeta_o*zeta_o)*dt*fact_kick*SQRT(ne_temp)/(modb*modb)
            !   vll = zeta*speed
            !END IF

            !------------------------------------------------------------
            !  Kick Model Scattering (new Energy, vll constant)
            !------------------------------------------------------------
            IF (modb>=B_kick_min .and. modb<=B_kick_max) THEN
              zeta_o = vll/speed   ! Record the current pitch.
              speed = speed*SQRT(one + fact_kick*modb*(1-zeta_o*zeta_o)*dt/SQRT(ne_temp))
            END IF

            !------------------------------------------------------------
            !  Final Moment and vll update (return q(4))
            !------------------------------------------------------------
            moment = half*mymass*(speed*speed - vll*vll + vrot_perp*vrot_perp)*binv
            q(4) = vll + vrot_para
         END IF

         RETURN

      END SUBROUTINE beams3d_physics_gc

      !-----------------------------------------------------------------
      !     Function:      beams3d_physics_fo
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          10/26/2021
      !     Description:   Particle slowing down and pitch angle
      !                    scattering for particles
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_physics_fo(t, q)
         !--------------------------------------------------------------
         !     Input Parameters
         !          t          Location along fieldline in t
         !          q            (q(1),q(2),q(3),q(4)) = (R,phi,Z,vll)
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: t
         DOUBLE PRECISION, INTENT(inout) :: q(6)
         !--------------------------------------------------------------
         !     Local Variables
         !        tau_spit The Spitzer characteristic time
         !        tau_spit_inv Helper 1/tau_spit
         !        v_crit       Critical velocity (transition to ion slowing)
         !        coulomb_log  Couloumb Logarithm (see NRL) 
         !--------------------------------------------------------------
         INTEGER        :: ier
         DOUBLE PRECISION    :: r_temp, phi_temp, z_temp, vll, te_temp, ne_temp, ti_temp, speed, newspeed, &
                          zeta, sigma, zeta_mean, zeta_o, v_s, tau_inv, tau_spit_inv, &
                          reduction, dve,dvi, tau_spit, v_crit, coulomb_log, te_cube, &
                          inv_mymass, speed_cube, vcrit_cube, vfrac, modb, s_temp, &
                          rho_temp, omeg_temp,&
                          vc3_tauinv, vbeta, zeff_temp, br_temp, bphi_temp, bz_temp, vperp, &
                          sm,omega2,vrel2,bmax,bmincl,bminqu,bmin, binv
         DOUBLE PRECISION :: Ebench  ! for ASCOT Benchmark
         DOUBLE PRECISION :: slow_par(3), ni_temp(NION)
         ! For splines
         INTEGER :: i,j,k, l
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------
      
         ier      = 0

         ! Setup position in a vll arrays
         r_temp   = q(1)
         phi_temp = MODULO(q(2), phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         z_temp   = q(3)

         ! Initialize values
         te_temp  = 0; ne_temp  = 0; ti_temp  = 0; zeff_temp=1;
         speed = 0; reduction = 0; 
         br_temp = 0; bphi_temp = 0; bz_temp = 0;

         tau_spit_inv = 0.0; v_crit   = 0.0; coulomb_log = 15
         tau_inv = 10.0; vcrit_cube = 0.0; vc3_tauinv = 0

         ! Check that we're inside the domain then proceed
         IF ((r_temp >= rmin-eps1) .and. (r_temp <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z_temp >= zmin-eps3) .and. (z_temp <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
            xparam = (r_temp - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z_temp - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            TE4D(1,1,1,1),nr,nphi,nz)
            te_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            NE4D(1,1,1,1),nr,nphi,nz)
            ne_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            TI4D(1,1,1,1),nr,nphi,nz)
            ti_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            ZEFF4D(1,1,1,1),nr,nphi,nz)
            zeff_temp = max(fval(1),one)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            RHO4D(1,1,1,1),nr,nphi,nz)
            rho_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            BR4D(1,1,1,1),nr,nphi,nz)
            br_temp = fval(1)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            OMEG4D(1,1,1,1),nr,nphi,nz)
            omeg_temp = fval(1)
            DO l = 1, NION
               CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                  hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                  NI5D(1,1,1,1,l),nr,nphi,nz)
               ni_temp(l) = max(fval(1),zero) !Set to one to prevent NaN Zeff later on
            END DO
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            BPHI4D(1,1,1,1),nr,nphi,nz)
            bphi_temp = fval(1)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            BZ4D(1,1,1,1),nr,nphi,nz)
            bz_temp = fval(1)

            !-----------------------------------------------------------
            !  Apply toroidal rotation
            !     Assumption is that only toroidal rotation
            !-----------------------------------------------------------
            q(5) = q(5) - omeg_temp*r_temp

            !-----------------------------------------------------------
            !  Helpers
            !     v_s       Local Sound Speed
            !     speed     Total particle speed
            !-----------------------------------------------------------
            modb = sqrt(br_temp*br_temp+bphi_temp*bphi_temp+bz_temp*bz_temp)
            binv = one/modb
            br_temp = br_temp*binv
            bphi_temp = bphi_temp*binv
            bz_temp = bz_temp*binv
            te_cube = te_temp * te_temp * te_temp
            inv_mymass = 1/mymass
            v_s = fact_vsound*sqrt(ti_temp)
            speed = sqrt(SUM(q(4:6)*q(4:6)))
            vbeta = max(ABS(speed-v_s)*inv_cspeed,1E-6)
            vll = (q(4)*br_temp+q(5)*bphi_temp+q(6)*bz_temp) 
            ! Make q vperp from this point forward
            q(4) = q(4) - vll*br_temp
            q(5) = q(5) - vll*bphi_temp
            q(6) = q(6) - vll*bz_temp

            !-----------------------------------------------------------
            !  Calculate Coulomb Logarithm
            !     te in eV and ne in cm^-3
            !-----------------------------------------------------------
            IF ((te_temp > te_col_min).and.(ne_temp > 0)) THEN
#if defined(B3D_COLLOP_NRL19IE)
               slow_par = coll_op_nrl19_ie(ne_temp,te_temp,vbeta,Zeff_temp)
#elif defined(B3D_COLLOP_NUBEAM)
               slow_par = coll_op_nubeam(ne_temp,ni_temp,te_temp,ti_temp,vbeta,Zeff_temp,modb,speed)
#else
               slow_par = coll_op_nrl19(ne_temp,te_temp,vbeta,Zeff_temp)
#endif
               vcrit_cube = slow_par(1)*slow_par(1)*slow_par(1)
               tau_spit_inv = one/slow_par(2)
               vc3_tauinv = vcrit_cube*tau_spit_inv
            ELSE 
               q(4)   = q(4) + vll*br_temp
               q(5)   = q(5) + vll*bphi_temp + omeg_temp*r_temp
               q(6)   = q(6) + vll*bz_temp
               RETURN
            END IF

            !-----------------------------------------------------------
            !  Viscouse Velocity Reduction
            !     v_s       Local Sound Speed
            !     speed     Total particle speed
            !     dve       Speed change due to electron slowing down 
            !     dvi       Speed change due to ion slowing down 
            !     reduction Total change in speed
            !     newspeed  New total speed
            !     vfrac     Ratio between new and old speed (helper) 
            !-----------------------------------------------------------
            dve   = speed*tau_spit_inv
            dvi   = vc3_tauinv/(speed*speed)
            reduction = dve + dvi
            newspeed = speed - reduction*dt
            vfrac = newspeed/speed

            !-----------------------------------------------------------
            !  Thermalize particle or adjust vll and moment
            !  Fowler et al. NF 1990 30 (6) 997--1010
            !-----------------------------------------------------------
            IF (newspeed < v_s) THEN  ! Thermalize
               dve       = dve/reduction
               dvi       = dvi/reduction
               reduction = (speed - v_s)/dt  ! Thermalize
               dve       = dve*reduction
               dvi       = dvi*reduction
               newspeed = speed - reduction*dt
               ltherm = .true.
               vfrac = newspeed/speed
               vll    =    vfrac*vll
               q(4:6) = q(4:6)*vfrac
               moment = half*(q(4)*q(4)+q(5)*q(5)+q(6)*q(6))*mymass*binv
               q(4)   = q(4) + vll*br_temp
               q(5)   = q(5) + vll*bphi_temp + omeg_temp*r_temp
               q(6)   = q(6) + vll*bz_temp
               RETURN
            END IF
            l = MAX(MIN(CEILING(rho_temp*h1_prof),ns_prof1),1)
            epower_prof(mybeam,l) = epower_prof(mybeam,l) + mymass*dve*dt*speed*weight(myline)
            ipower_prof(mybeam,l) = ipower_prof(mybeam,l) + mymass*dvi*dt*speed*weight(myline)
            vll = vfrac*vll
            q(4:6) = q(4:6)*vfrac
            speed = newspeed

            !------------------------------------------------------------
            !  Pitch Angle Scattering
            !------------------------------------------------------------
            speed_cube = vc3_tauinv*slow_par(3)*dt/(speed*speed*speed) ! redefine as inverse
            zeta_o = vll/speed   ! Record the current pitch.
            CALL gauss_rand(1,zeta)  ! A random from a standard normal (1,1)
            sigma = sqrt( ABS((1.0D0-zeta_o*zeta_o)*speed_cube) ) ! The standard deviation.
            zeta_mean = zeta_o *(1.0D0 - speed_cube )  ! The new mean in the distribution.
            zeta = zeta*sigma + zeta_mean  ! The new pitch angle.
            !!!The pitch angle MUST NOT go outside [-1,1] nor be NaN; but could happen accidentally with the distribution.
            zeta = MIN(MAX(zeta,-0.999D+00),0.999D+00)
            vll = zeta*speed

            !------------------------------------------------------------
            !  Kick Model Scattering
            !------------------------------------------------------------
            IF (modb>=B_kick_min .and. modb<=B_kick_max) THEN
              zeta_o = vll/speed   ! Record the current pitch.
              zeta = zeta_o-zeta_o*(one-zeta_o*zeta_o)*dt*fact_kick*SQRT(ne_temp)*binv*binv
              vll = zeta*speed
            END IF

            !------------------------------------------------------------
            !  Now update velocity
            !------------------------------------------------------------
            ! Normalize Vperp
            ! q(4:6) still holds the perpendicular vector for the pitch we had
            ! before scattering; without rescaling it the scattering changes
            ! |v| instead of rotating it.
            vperp = SQRT(SUM(q(4:6)*q(4:6)))
            q(4:6) = q(4:6)*sqrt(speed*speed-vll*vll)/vperp
            q(4) = q(4) + vll*br_temp
            q(5) = q(5) + vll*bphi_temp + omeg_temp*r_temp
            q(6) = q(6) + vll*bz_temp
            vll = (q(4)*br_temp+q(5)*bphi_temp+q(6)*bz_temp)
            speed = SQRT(SUM(q(4:6)*q(4:6)))
            moment = half*(speed*speed-vll*vll)*mymass*binv
         END IF

         RETURN

      END SUBROUTINE beams3d_physics_fo

      !-----------------------------------------------------------------
      !     Function:      beams3d_follow_neut
      !     Authors:       S. Lazerson (lazerson@pppl.gov)
      !                    M. McMillan (matthew.mcmillan@my.wheaton.edu)
      !     Date:          12/01/2018
      !     Description:   Follows a particle into the plasma,
      !                    calculates deposition, and follows to wall
      !                    or plasma domain.
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_follow_neut(t, q)
         !--------------------------------------------------------------
         !     Modules
         !--------------------------------------------------------------
         USE beams3d_grid
         USE beams3d_lines, ONLY: myline,xlast,ylast,zlast
         USE beams3d_runtime, ONLY: lvessel, to3, lplasma_only, &
                                    lvessel_beam, lsuzuki
         USE wall_mod, ONLY: collide, uncount_wall_hit

         !--------------------------------------------------------------
         !     Input Parameters
         !          t          Location along fieldline in t
         !          q            (q(1),q(2),q(3),q(4)) = (R,phi,Z,vll)
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: t
         DOUBLE PRECISION, INTENT(inout) :: q(4)

         !--------------------------------------------------------------
         !     Local Parameters
         !--------------------------------------------------------------
         INTEGER, PARAMETER :: num_depo = 256
         DOUBLE PRECISION, PARAMETER :: dl = 5D-3
         DOUBLE PRECISION, PARAMETER :: stepsize(3)=(/0.25,0.05,0.01/)

         !--------------------------------------------------------------
         !     Local variables
         !--------------------------------------------------------------
         LOGICAL          :: ltest
         INTEGER          :: ier, l, m
         DOUBLE PRECISION :: rinv, phi_temp, dt_local, ti_temp, ne_temp,&
                             s_temp, x0, y0, z0, xw, yw, zw, te_temp, Zeff_temp, &
                             rho_temp, rlim, zlim,vtor
         DOUBLE PRECISION :: qf(3),qs(3),qe(3)
         DOUBLE PRECISION :: rlocal(num_depo), plocal(num_depo), zlocal(num_depo)
         DOUBLE PRECISION :: tilocal(num_depo), telocal(num_depo), nelocal(num_depo)
         DOUBLE PRECISION :: zefflocal(num_depo)
         DOUBLE PRECISION :: nilocal(NION,num_depo)
         DOUBLE PRECISION :: tau_inv(num_depo), energy(num_depo)
         DOUBLE PRECISION :: sigvii(num_depo), sigvcx(num_depo), sigvei(num_depo)
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)
         ! For Suzuki
         INTEGER :: A_IN(NION), Z_IN(NION)
         DOUBLE PRECISION :: ni_in(NION)
         ! ADAS Helpers
         INTEGER :: myA

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------


         !--------------------------------------------------------------
         !     Energy
         !       Suzuki Model: keV/amu
         !       ADAS Model: keV/amu
         !       E(eV) = 0.5*m*v^2/e_c
         !       E(eV/amu) = E(eV) / (m/m_Dalton)
         !--------------------------------------------------------------
         vtor=0
         IF(nomeg>0) CALL beams3d_vtor(q,vtor)
         energy = (1D-3*half*(q(4)-vtor)**2)/(e_charge*inv_dalton)
         
         qf(1) = q(1)*cos(q(2))
         qf(2) = q(1)*sin(q(2))
         qf(3) = q(3)
         rlim=MAX(q(1),rmax)
         zlim=MAX(ABS(q(3)),ABS(zmin),ABS(zmax))
         !--------------------------------------------------------------
         !     Initialize Ionization here
         !--------------------------------------------------------------
         CALL RANDOM_NUMBER(rand_prob)
         cum_prob = one

         !--------------------------------------------------------------
         !     Follow neutral into plasma using subgrid
         !--------------------------------------------------------------
         end_state(myline) = 3 ! It's a neutral for now
         xlast = qf(1)
         ylast = qf(2)
         zlast = qf(3)
         x0 = qf(1); y0 = qf(2); z0 = qf(3)
         OUTER_A: DO l = 1, 3
            dt_local = stepsize(l)/q(4)
            INNER_A: DO
               qf = qf + myv_neut*dt_local
               q(1) = sqrt(qf(1)*qf(1)+qf(2)*qf(2))
               q(2) = ATAN2(qf(2),qf(1))
               q(3) = qf(3)
               t = t + dt_local
               phi_temp = MODULO(q(2), phimax)
               IF (phi_temp < 0) phi_temp = phi_temp + phimax
               IF ((q(1) >= rmin-eps1) .and. (q(1) <= rmax+eps1) .and. &
                   (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
                   (q(3) >= zmin-eps3) .and. (q(3) <= zmax+eps3)) THEN
                  i = MIN(MAX(COUNT(raxis < q(1)),1),nr-1)
                  j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
                  k = MIN(MAX(COUNT(zaxis < q(3)),1),nz-1)
                  xparam = (q(1) - raxis(i)) * hri(i)
                  yparam = (phi_temp - phiaxis(j)) * hpi(j)
                  zparam = (q(3) - zaxis(k)) * hzi(k)
                  rho_temp =1.5
                  CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                                  hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                                  RHO4D(1,1,1,1),nr,nphi,nz)
                  rho_temp = fval(1)
                  IF (rho_temp < one) EXIT
               END IF
               IF ((q(1) >= rlim) .or. (ABS(q(3)) >= zlim)) THEN
                  t = my_end+dt_local
                  end_state(myline) = 5 ! Debug
                  EXIT !It can happen that we collided with the wall while getting here
               END IF  ! We're outside the grid
            END DO INNER_A
            ! Take a step back
            qf = qf - myv_neut*dt_local
            t  =  t - dt_local
         END DO OUTER_A
         qs=qf

         !--------------------------------------------------------------
         !     Check to see if we hit the wall
         !--------------------------------------------------------------
         IF (lvessel_beam) THEN
            CALL collide(x0,y0,z0,qf(1),qf(2),qf(3),xw,yw,zw,ltest)
            IF (ltest) THEN
               q(1) = SQRT(qf(1)*qf(1)+qf(2)*qf(2))
               q(2) = ATAN2(qf(2),qf(1))
               q(3) = qf(3)
               end_state(myline) = 4
               CALL uncount_wall_hit              
               RETURN
            ELSE IF ((q(1) > 5*rmax)  .or. (q(1) < rmin)) THEN
               t = my_end+dt_local
               RETURN
            END IF
         END IF

         xlast = qf(1)
         ylast = qf(2)
         zlast = qf(3)

         !--------------------------------------------------------------
         !     Follow particle track out of plasma
         !--------------------------------------------------------------
         OUTER: DO l = 1, 3
            dt_local = stepsize(l)/q(4)
            INNER: DO
               qf = qf + myv_neut*dt_local
               q(1) = sqrt(qf(1)*qf(1)+qf(2)*qf(2))
               q(2) = ATAN2(qf(2),qf(1))
               q(3) = qf(3)
               phi_temp = MODULO(q(2), phimax)
               IF (phi_temp < 0) phi_temp = phi_temp + phimax
               ! Assume we're in grid and only want to bug out if we're outside the grid
               IF ((q(1) >= rmin-eps1) .and. (q(1) <= rmax+eps1) .and. &
                   (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
                   (q(3) >= zmin-eps3) .and. (q(3) <= zmax+eps3)) THEN
                  i = MIN(MAX(COUNT(raxis < q(1)),1),nr-1)
                  j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
                  k = MIN(MAX(COUNT(zaxis < q(3)),1),nz-1)
                  xparam = (q(1) - raxis(i)) * hri(i)
                  yparam = (phi_temp - phiaxis(j)) * hpi(j)
                  zparam = (q(3) - zaxis(k)) * hzi(k)
                  CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                                  hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                                  RHO4D(1,1,1,1),nr,nphi,nz)
                  rho_temp = fval(1)
                  IF (rho_temp > one) EXIT INNER
               ELSE
                  EXIT INNER
               END IF
            END DO INNER
            ! Take a step back
            qf = qf - myv_neut*dt_local
         END DO OUTER
         qe=qf + myv_neut*dt_local

         !--------------------------------------------------------------
         !     Setup deposition arrays
         !--------------------------------------------------------------
         rlocal(1) = SQRT(qs(1)*qs(1)+qs(2)*qs(2))
         plocal(1) = ATAN2(qs(2),qs(1))
         zlocal(1) = qs(3)
         rlocal(num_depo) = SQRT(qe(1)*qe(1)+qe(2)*qe(2))
         plocal(num_depo) = ATAN2(qe(2),qe(1))
         zlocal(num_depo) = qe(3)
         DO i = 2, num_depo-1
            qf = (i-1)*(qe-qs)/(REAL(num_depo-1)) + qs
            rlocal(i) = sqrt(qf(1)*qf(1)+qf(2)*qf(2))
            plocal(i) = atan2(qf(2),qf(1))
            zlocal(i) = qf(3)
         END DO
         plocal = MODULO(plocal, phimax) ! Dont need to check for negative then
         ! Compute temp/density along path
         DO l = 1, num_depo
            i = MIN(MAX(COUNT(raxis < rlocal(l)),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < plocal(l)),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < zlocal(l)),1),nz-1)
            xparam = (rlocal(l) - raxis(i)) * hri(i)
            yparam = (plocal(l) - phiaxis(j)) * hpi(j)
            zparam = (zlocal(l) - zaxis(k)) * hzi(k)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            TI4D(1,1,1,1),nr,nphi,nz)
            tilocal(l) = MAX(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            TE4D(1,1,1,1),nr,nphi,nz)
            telocal(l) = MAX(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            NE4D(1,1,1,1),nr,nphi,nz)
            nelocal(l) = MAX(fval(1),zero)
            DO m = 1, NION
               CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            NI5D(1,1,1,1,m),nr,nphi,nz)
               nilocal(m,l) = MAX(fval(1),one) !Set to one to prevent NaN Zeff later on
            END DO
         END DO
         tilocal = tilocal*1D-3
         telocal = telocal*1D-3
         tau_inv = zero
         
         !--------------------------------------------------------------
         !     USE Suzuki to calcualte ionization rates
         !     Note: 10^18<ne<10^21
         !           E(keV/amu)/100 < Te < E(keV/amu)/2
         !--------------------------------------------------------------
         IF (lsuzuki) THEN
            A_in = NINT(NI_AUX_M*inv_dalton)
            Z_in = NI_AUX_Z
            DO l = 1, num_depo
               nelocal(l)  = MAX(MIN(nelocal(l),1E21),1E18)
               telocal(l)  = MAX(MIN(telocal(l),energy(l)*0.5),energy(l)*0.01)
               ni_in = MAX(MIN(nilocal(:,l),1E21),1E18)
               CALL suzuki_sigma(NION,energy(l),nelocal(l),telocal(l),ni_in,A_in,Z_in,tau_inv(l))
            END DO
            tau_inv = tau_inv*nelocal*ABS(q(4))*1E-4 !cm^2 to m^2 for sigma
         !--------------------------------------------------------------
         !     USE ADAS to calcualte ionization rates
         !--------------------------------------------------------------

         ELSE
            ! Arguments to btsigv(irtype,beamchrg,eabeam,tatarg,n,izbeam,iztarg,btsigv, istat )hatom_btsigv.f90
            ! irtype 1:CX, 2:II
            ! beamchrg 1:neutral, 2:ion
            ! eabeam beam energy in keV/nucleon
            ! tatarg target energy in keV/nucleon
            ! n array size
            ! izbeam  Beam Z (always int)
            ! iztarg  Target Z (can be real)
            ! btsigv  cross section
            A_in = NINT(NI_AUX_M*inv_dalton)
            DO m = 1, NION
                CALL adas_btsigv(2,1,energy,tilocal,num_depo,myZ,A_in(m),sigvii,ier)  ! Ion Impact ionization cross-section term.
                CALL adas_btsigv(1,1,energy,tilocal,num_depo,myZ,A_in(m),sigvcx,ier)  ! Charge Exchange ionization cross-section term.
                tau_inv = tau_inv + (sigvii+sigvcx)*nilocal(m,:)
            END DO
            ! Arguments to sigvte(zneut,tevec,n1,sigv_adas,istat)
            ! zneut charge (=1)
            ! tevec electron temperature [keV]
            ! n1 array size
            ! This formula comes from the ADAS description of how to use the functions. (M. Gorelenkova)
            ! factor here is mp/me (assumes ion) Source NUBEAM: getsigs_adas.f, line 43
            telocal = telocal + to3*mpome*energy
            CALL adas_sigvte_ioniz(myZ,telocal,num_depo,sigvei,ier)        ! Electron Impact ionization cross-section term.
            tau_inv = tau_inv + sigvei*nelocal
         END IF

         !--------------------------------------------------------------
         !     Calculate Ionization
         !--------------------------------------------------------------
         dt_local = SQRT(SUM((qe-qs)*(qe-qs)))/((num_depo-1)*q(4))
         tau_inv = EXP(-dt_local*tau_inv)
         DO l = 2, num_depo-1
            cum_prob = cum_prob*tau_inv(l)
            IF (cum_prob < rand_prob) EXIT
         END DO
         qf = qs + myv_neut*dt_local*(l-1)
         t  =  t + dt_local*(l-1)
         q(1) = SQRT(qf(1)*qf(1)+qf(2)*qf(2))
         q(2) = ATAN2(qf(2),qf(1))
         q(3) = qf(3)
         IF (l < num_depo-1) THEN
            IF ( (rlocal(l) <= rmin) .or. (rlocal(l) >= rmax) .or. &
                 (zlocal(l) <= zmin) .or. (zlocal(l) >= zmax) ) THEN 
               t = my_end + dt_local             
               RETURN
            END IF
            i = MIN(MAX(COUNT(raxis < rlocal(l)),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < plocal(l)),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < zlocal(l)),1),nz-1)
            xparam = (rlocal(l) - raxis(i)) * hri(i)
            yparam = (plocal(l) - phiaxis(j)) * hpi(j)
            zparam = (zlocal(l) - zaxis(k)) * hzi(k)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            RHO4D(1,1,1,1),nr,nphi,nz)
            rho_temp = fval(1)
            lneut=.false.
            xlast = qf(1)
            ylast = qf(2)
            zlast = qf(3)         
            RETURN
         ELSE !If not deposited, move outside plasma (to s>1)
            qf=qe
         END IF

         !--------------------------------------------------------------
         !     Follow neutral to wall or domain (big steps fine)
         !--------------------------------------------------------------
         x0 = qf(1); y0 = qf(2); z0 = qf(3)
         dt_local = 0.25/q(4)  
         ltest = .FALSE.
         xlast = qf(1)
         ylast = qf(2)
         zlast = qf(3)
         end_state(myline) = 3
         DO
            qf = qf + myv_neut*dt_local
            t = t + dt_local
            IF (lvessel_beam) CALL collide(x0,y0,z0,qf(1),qf(2),qf(3),xw,yw,zw,ltest)
            IF (ltest) THEN
               q(1) = SQRT(qf(1)*qf(1)+qf(2)*qf(2))
               q(2) = ATAN2(qf(2),qf(1))
               q(3) = qf(3)
               t = my_end+dt_local
               CALL uncount_wall_hit             
               RETURN
            END IF
            !xlast = x0; ylast=y0; zlast=z0
            x0 = qf(1); y0 = qf(2); z0 = qf(3)
            q(1) = SQRT(qf(1)*qf(1)+qf(2)*qf(2))
            q(2) = ATAN2(qf(2),qf(1))
            q(3) = qf(3)
            IF ((q(1) > 2*rmax)  .or. (q(1) < rmin)) THEN
               t = my_end+dt_local                  
               RETURN
            END IF  ! We're outside the grid
         END DO    
         RETURN
      END SUBROUTINE beams3d_follow_neut

      !-----------------------------------------------------------------
      !     Function:      beams3d_ionize
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          06/20/2023
      !     Description:   Ionizes a particle relocating it to its
      !                    gyrocenter.
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_ionize(q)
         USE beams3d_grid

         !--------------------------------------------------------------
         !     Input Parameters
         !          q            (q(1),q(2),q(3),q(4)) = (R,phi,Z,vll)
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(4)

         !--------------------------------------------------------------
         !     Local variables
         !--------------------------------------------------------------
         INTEGER          :: ier
         DOUBLE PRECISION :: q6(6)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------
         lneut = .false.
         end_state(myline) = 0
         q6(1:3) = q(1:3)
         q6(4)   = myv_neut(1)*cos(q(2))+myv_neut(2)*sin(q(2))
         q6(5)   = myv_neut(2)*cos(q(2))-myv_neut(1)*sin(q(2))
         q6(6)   = myv_neut(3)
         CALL beams3d_part2gc(q6)
         q(1:4)  = q6(1:4) !R,phi,Z,vll
         RETURN

      END SUBROUTINE beams3d_ionize

      !-----------------------------------------------------------------
      !     Function:      beams3d_part2gc
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          06/27/2023
      !     Description:   Ionizes a particle relocating it to its
      !                    gyrocenter.
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_part2gc(q)
         USE beams3d_grid

         !--------------------------------------------------------------
         !     Input Parameters
         !          q            (1:6) = (R,phi,Z,vR,Vphi,Vz)
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(6)

         !--------------------------------------------------------------
         !     Local parameters
         !--------------------------------------------------------------
         REAL*8, PARAMETER :: one = 1

         !--------------------------------------------------------------
         !     Local variables
         !--------------------------------------------------------------
         INTEGER          :: ier
         DOUBLE PRECISION :: r_temp, phi_temp, z_temp, x, y, &
                             br_temp, bp_temp, bz_temp, modb_temp, &
                             bx_temp, by_temp, binv, &
                             rho(3), vperp, vx, vy, vz, vll
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------
         ! Handle inputs
         ier = 0
         phi_temp = MOD(q(2),phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         r_temp = q(1)
         z_temp = q(3)
         x = q(1)*cos(q(2))
         y = q(1)*sin(q(2))
         vx = q(4)*cos(q(2))-q(5)*sin(q(2))
         vy = q(4)*sin(q(2))+q(5)*cos(q(2))
         vz = q(6)


         ! Eval Spline
         i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
         j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
         k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
         xparam = (r_temp - raxis(i)) * hri(i)
         yparam = (phi_temp - phiaxis(j)) * hpi(j)
         zparam = (z_temp - zaxis(k)) * hzi(k)
         CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                         hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                         BR4D(1,1,1,1),nr,nphi,nz)
         br_temp = fval(1)
         CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                         hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                         BPHI4D(1,1,1,1),nr,nphi,nz)
         bp_temp = fval(1)
         CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                         hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                         BZ4D(1,1,1,1),nr,nphi,nz)
         bz_temp = fval(1)
         CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                         hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                         MODB4D(1,1,1,1),nr,nphi,nz)
         modb_temp = fval(1)
         bx_temp = br_temp*cos(q(2))-bp_temp*sin(q(2))
         by_temp = br_temp*sin(q(2))+bp_temp*cos(q(2))
         binv = one/modb_temp

         ! First calculate vll and vperp
         vll = ( vx * bx_temp + &
                  vy * by_temp + &
                  vz * bz_temp  ) * binv
         vperp = SQRT(ABS(vx*vx+vy*vy+vz*vz - vll*vll))

         ! F_em = q v x B
         ! rho is F_em norm
         rho(1) = vy*bz_temp - vz*by_temp
         rho(2) = vz*bx_temp - vx*bz_temp
         rho(3) = vx*by_temp - vy*bx_temp
         IF (mycharge < 0) rho = -rho
         rho = rho / SQRT(SUM(rho*rho))

         ! Now calculate the gyroradius
         !    rg = m * vperp / (q * B)
         !    vperp = sqrt(v.v-vll*vll)
         rho   = rho*mymass*vperp*binv/mycharge !Rg
         x     = x + rho(1)
         y     = y + rho(2)
         q(3)  = q(3)+rho(3)
         q(1)  = SQRT(x*x+y*y)
         q(2)  = ATAN2(y,x)
         q(4)  = vll
         q(5)  = 0
         q(6)  = 0

         ! Now calculate magnetic moment
         !    mu = m*vperp^2/(2*B)=m*(v.v-vll.vll)/(2*B)
         moment = 0.5*mymass*vperp*vperp*binv
         moment = MAX(moment,10*TINY(moment))

         RETURN

      END SUBROUTINE beams3d_part2gc

      !-----------------------------------------------------------------
      !     Function:      beams3d_neutralize_gc
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          06/27/2023
      !     Description:   Neutralizes a gryocenter
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_neutralize_gc(q)

         !--------------------------------------------------------------
         !     Input Parameters
         !          q            (q(1),q(2),q(3),q(4)) = (R,phi,Z,vll)
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(4)

         !--------------------------------------------------------------
         !     Local parameters
         !--------------------------------------------------------------
         DOUBLE PRECISION, PARAMETER :: zero = 0

         !--------------------------------------------------------------
         !     Local Variables
         !--------------------------------------------------------------
         INTEGER          :: ier
         DOUBLE PRECISION :: q6(6)
         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------
         q6(1:4) = q(1:4)
         q6(5) = moment
         q6(6) = zero
         CALL beams3d_gc2fo(q6)
         myv_neut(1) = q6(4)*cos(q6(2))-q6(5)*sin(q6(2))
         myv_neut(2) = q6(4)*sin(q6(2))+q6(5)*cos(q6(2))
         myv_neut(3) = q6(6)
         q(1:3) = q6(1:3)
         q(4) = SQRT(SUM(myv_neut*myv_neut))
         lneut = .TRUE.
         RETURN
      END SUBROUTINE beams3d_neutralize_gc

      !-----------------------------------------------------------------
      !     Function:      beams3d_gc2fo
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          10/22/2021
      !     Description:   Convert a gyrocenter to a full orbit.
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_gc2fo(q)
         USE beams3d_grid

         !--------------------------------------------------------------
         !     Input Parameters
         !          q          on input R,phi,Z,vll,moment
         !                     on exit  R,phi,Z,vR,Vphi,Vz
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(6)

         !--------------------------------------------------------------
         !     Local parameters
         !--------------------------------------------------------------
         DOUBLE PRECISION, PARAMETER :: zero = 0
         DOUBLE PRECISION, PARAMETER :: one = 1

         !--------------------------------------------------------------
         !     Local Variables
         !--------------------------------------------------------------
         INTEGER          :: ier
         DOUBLE PRECISION :: r_temp, phi_temp, z_temp, x, y, &
                             br_temp, bp_temp, bz_temp, modb_temp, &
                             bx_temp, by_temp, binv, phi2_temp,&
                             xg,yg,zg, vx, vy, theta, vll_temp, &
                             rho(3), rho2(3) , moment_temp, vperp, rg
         DOUBLE PRECISION, DIMENSION(3,3) :: rot_matrix
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------
         ! Handle inputs
         ier = 0
         phi2_temp = q(2)
         phi_temp = MOD(q(2),phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         r_temp = q(1)
         z_temp = q(3)
         vll_temp = q(4)
         moment_temp = q(5)

         ! Eval Spline
         i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
         j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
         k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
         xparam = (r_temp - raxis(i)) * hri(i)
         yparam = (phi_temp - phiaxis(j)) * hpi(j)
         zparam = (z_temp - zaxis(k)) * hzi(k)
         CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                         hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                         BR4D(1,1,1,1),nr,nphi,nz)
         br_temp = fval(1)
         CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                         hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                         BPHI4D(1,1,1,1),nr,nphi,nz)
         bp_temp = fval(1)
         CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                         hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                         BZ4D(1,1,1,1),nr,nphi,nz)
         bz_temp = fval(1)
         CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                         hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                         MODB4D(1,1,1,1),nr,nphi,nz)
         modb_temp = fval(1)
         bx_temp = br_temp*cos(q(2))-bp_temp*sin(q(2))
         by_temp = br_temp*sin(q(2))+bp_temp*cos(q(2))
         binv = one/modb_temp
         bx_temp = bx_temp*binv
         by_temp = by_temp*binv
         bz_temp = bz_temp*binv

         ! First we calc the gyroradius
         vperp = SQRT(2.*modb_temp*moment_temp/mymass)
         rg    = mymass*vperp/(mycharge*modb_temp)

         ! Create the perpendicular vector
         ! (BxZ)xB
         xg = -bx_temp*bz_temp*rg
         yg = -bz_temp*by_temp*rg
         zg = (by_temp*by_temp+bx_temp*bx_temp)*rg

         ! Now make the rotation matrix
         !https://en.wikipedia.org/wiki/Rotation_matrix#Rotation_matrix_from_axis_and_angle
         CALL RANDOM_NUMBER(theta)
         theta = (theta-0.5)*pi2
         rot_matrix(1,1) = cos(theta)+bx_temp*bx_temp*(1-cos(theta))
         rot_matrix(1,2) = bx_temp*by_temp*(1-cos(theta))-bz_temp*sin(theta)
         rot_matrix(1,3) = bx_temp*bz_temp*(1-cos(theta))+by_temp*sin(theta)
         rot_matrix(2,1) = by_temp*bx_temp*(1-cos(theta))+bz_temp*sin(theta)
         rot_matrix(2,2) = cos(theta)+by_temp*by_temp*(1-cos(theta))
         rot_matrix(2,3) = by_temp*bz_temp*(1-cos(theta))-bx_temp*sin(theta)
         rot_matrix(3,1) = bz_temp*bx_temp*(1-cos(theta))-by_temp*sin(theta)
         rot_matrix(3,2) = bz_temp*by_temp*(1-cos(theta))+bx_temp*sin(theta)
         rot_matrix(3,3) = cos(theta)+bz_temp*bz_temp*(1-cos(theta))

         ! Rotate
         q(1:3) =  MATMUL(rot_matrix,(/xg,yg,zg/))

         ! Make rg the perp vector
         xg = by_temp*q(3)-bz_temp*q(2)
         yg = bz_temp*q(1)-bx_temp*q(3)
         zg = bx_temp*q(2)-by_temp*q(1)
         rg = one/sqrt(xg*xg+yg*yg+zg*zg)

         ! Translate
         q(1:3) = q(1:3) + (/r_temp*cos(phi2_temp),r_temp*sin(phi2_temp),z_temp/)

         ! Get into R,phi
         r_temp = sqrt(q(1)*q(1)+q(2)*q(2))
         phi_temp = atan2(q(2),q(1))
         q(1) = r_temp
         q(2) = phi_temp

         ! Now handle the velocity
         vx = vll_temp*bx_temp + vperp*xg*rg
         vy = vll_temp*by_temp + vperp*yg*rg
         q(6) = vll_temp*bz_temp + vperp*zg*rg
         q(4) = vx*cos(phi_temp) + vy*sin(phi_temp)
         q(5) =-vx*sin(phi_temp) + vy*cos(phi_temp)

         RETURN

      END SUBROUTINE beams3d_gc2fo

      !-----------------------------------------------------------------
      !     Function:      beams3d_DTRATE
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          09/30/2020
      !     Description:   Calculates the D-T Reaction rate, assumes
      !                    50/50 n_D/n_T based on n_e. See:
      !                    H.-S. Bosch and G. M. Hale 1992 Nucl. Fusion 32 611
      !                    https://doi.org/10.1088/0029-5515/32/4/I07
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_DTRATE(q,reactrate)
         !--------------------------------------------------------------
         !     Input Parameters
         !          q            (q(1),q(2),q(3)) = (R,phi,Z)
         !          reactrate    Reaction rate (part/(m^3*s))
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(3)
         DOUBLE PRECISION, INTENT(out) :: reactrate

         !--------------------------------------------------------------
         !     Local Variables
         !        r_temp     Helpers (r,phi,z, ne, ti, ze)
         !        zeta       Fusion helper
         !        theta      Fusion helper
         !        eta        Fusion Helper
         !        i,j,k      Spline Grid indicies
         !        xparam     Spline subgrid factor [0,1] (yparam,zparam)
         !        ict        Spline output control
         !        fval       Spline output array
         !--------------------------------------------------------------
         DOUBLE PRECISION :: r_temp, z_temp, phi_temp, &
                             ti_temp, zeta, theta, eta, &
                             nd_temp, nt_temp
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         ! Setup position in a vll arrays
         r_temp   = q(1)
         phi_temp = MODULO(q(2), phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         z_temp   = q(3)

         ! Initialize values
         ti_temp = 0; nd_temp = 0; nt_temp = 0; reactrate = 0

         ! Check that we're inside the domain then proceed
         IF ((r_temp >= rmin-eps1) .and. (r_temp <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z_temp >= zmin-eps3) .and. (z_temp <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
            xparam = (r_temp - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z_temp - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            TI4D(1,1,1,1),nr,nphi,nz)
            ti_temp = max(fval(1),zero)
            ! Assume 1 and 2 are D and T
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            NI5D(1,1,1,1,dexionT),nr,nphi,nz)
            nd_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            NI5D(1,1,1,1,dexionD),nr,nphi,nz)
            nt_temp = max(fval(1),zero)
         ELSE
            RETURN
         END IF
         IF (ti_temp <= zero) RETURN ! Get out if ti small
         reactrate = DT_CROSS_SECTION(ti_temp)*nd_temp*nt_temp
         RETURN

      END SUBROUTINE beams3d_DTRATE

      !-----------------------------------------------------------------
      !     Function:      beams3d_DDTRATE
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          09/30/2020
      !     Description:   Calculates the D-D->T Reaction rate, assumes
      !                    50/50 n_D/n_T based on n_e. See:
      !                    H.-S. Bosch and G. M. Hale 1992 Nucl. Fusion 32 611
      !                    https://doi.org/10.1088/0029-5515/32/4/I07
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_DDTRATE(q,reactrate)
         !--------------------------------------------------------------
         !     Input Parameters
         !          q            (q(1),q(2),q(3)) = (R,phi,Z)
         !          reactrate    Reaction rate (part/(m^3*s))
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(3)
         DOUBLE PRECISION, INTENT(out) :: reactrate

         !--------------------------------------------------------------
         !     Local Variables
         !        r_temp     Helpers (r,phi,z, ne, ti, ze)
         !        zeta       Fusion helper
         !        theta      Fusion helper
         !        eta        Fusion Helper
         !        i,j,k      Spline Grid indicies
         !        xparam     Spline subgrid factor [0,1] (yparam,zparam)
         !        ict        Spline output control
         !        fval       Spline output array
         !--------------------------------------------------------------
         DOUBLE PRECISION :: r_temp, z_temp, phi_temp, &
                             ti_temp, zeta, theta, eta, &
                             nd_temp
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         ! Setup position in a vll arrays
         r_temp   = q(1)
         phi_temp = MODULO(q(2), phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         z_temp   = q(3)

         ! Initialize values
         ti_temp = 0; nd_temp = 0; reactrate = 0

         ! Check that we're inside the domain then proceed
         IF ((r_temp >= rmin-eps1) .and. (r_temp <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z_temp >= zmin-eps3) .and. (z_temp <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
            xparam = (r_temp - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z_temp - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            TI4D(1,1,1,1),nr,nphi,nz)
            ti_temp = max(fval(1),zero)
            ! Assume 1 and 2 are D and T
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            NI5D(1,1,1,1,dexionD),nr,nphi,nz)
            nd_temp = max(fval(1),zero)
         ELSE
            RETURN
         END IF
         IF (ti_temp <= zero) RETURN ! Get out if ti small

         reactrate = DD_CROSS_SECTION(ti_temp)*nd_temp*nd_temp*0.5

         RETURN

      END SUBROUTINE beams3d_DDTRATE

      !-----------------------------------------------------------------
      !     Function:      beams3d_DDHe3RATE
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          09/30/2020
      !     Description:   Calculates the D-D->He3 Reaction rate, assumes
      !                    50/50 n_D/n_T based on n_e. See:
      !                    H.-S. Bosch and G. M. Hale 1992 Nucl. Fusion 32 611
      !                    https://doi.org/10.1088/0029-5515/32/4/I07
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_DDHe3RATE(q,reactrate)
         !--------------------------------------------------------------
         !     Input Parameters
         !          q            (q(1),q(2),q(3)) = (R,phi,Z)
         !          reactrate    Reaction rate (part/(m^3*s))
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(3)
         DOUBLE PRECISION, INTENT(out) :: reactrate

         !--------------------------------------------------------------
         !     Local Variables
         !        r_temp     Helpers (r,phi,z, ne, ti, ze)
         !        zeta       Fusion helper
         !        theta      Fusion helper
         !        eta        Fusion Helper
         !        i,j,k      Spline Grid indicies
         !        xparam     Spline subgrid factor [0,1] (yparam,zparam)
         !        ict        Spline output control
         !        fval       Spline output array
         !--------------------------------------------------------------
         DOUBLE PRECISION :: r_temp, z_temp, phi_temp, nd_temp, &
                             ti_temp, zeta, theta, eta
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         ! Setup position in a vll arrays
         r_temp   = q(1)
         phi_temp = MODULO(q(2), phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         z_temp   = q(3)

         ! Initialize values
         ti_temp = 0; nd_temp = 0; reactrate = 0

         ! Check that we're inside the domain then proceed
         IF ((r_temp >= rmin-eps1) .and. (r_temp <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z_temp >= zmin-eps3) .and. (z_temp <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
            xparam = (r_temp - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z_temp - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            TI4D(1,1,1,1),nr,nphi,nz)
            ti_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            NI5D(1,1,1,1,dexionD),nr,nphi,nz)
            nd_temp = max(fval(1),zero)
         ELSE
            RETURN
         END IF
         IF (ti_temp <= zero) RETURN ! Get out if ti small

         reactrate = DDHe3_CROSS_SECTION(ti_temp)*nd_temp*nd_temp*0.5
         RETURN

      END SUBROUTINE beams3d_DDHe3RATE

      !-----------------------------------------------------------------
      !     Function:      beams3d_DHe3RATE
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          09/30/2020
      !     Description:   Calculates the D-D->He3 Reaction rate, assumes
      !                    50/50 n_D/n_T based on n_e. See:
      !                    H.-S. Bosch and G. M. Hale 1992 Nucl. Fusion 32 611
      !                    https://doi.org/10.1088/0029-5515/32/4/I07
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_DHe3RATE(q,reactrate)
         !--------------------------------------------------------------
         !     Input Parameters
         !          q            (q(1),q(2),q(3)) = (R,phi,Z)
         !          reactrate    Reaction rate (part/(m^3*s))
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(3)
         DOUBLE PRECISION, INTENT(out) :: reactrate

         !--------------------------------------------------------------
         !     Local Variables
         !        r_temp     Helpers (r,phi,z, ne, ti, ze)
         !        zeta       Fusion helper
         !        theta      Fusion helper
         !        eta        Fusion Helper
         !        i,j,k      Spline Grid indicies
         !        xparam     Spline subgrid factor [0,1] (yparam,zparam)
         !        ict        Spline output control
         !        fval       Spline output array
         !--------------------------------------------------------------
         DOUBLE PRECISION :: r_temp, z_temp, phi_temp, nd_temp, &
                             ti_temp, zeta, theta, eta, nHe3_temp
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         ! Setup position in a vll arrays
         r_temp   = q(1)
         phi_temp = MODULO(q(2), phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         z_temp   = q(3)

         ! Initialize values
         ti_temp = 0; nd_temp = 0; reactrate = 0

         ! Check that we're inside the domain then proceed
         IF ((r_temp >= rmin-eps1) .and. (r_temp <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z_temp >= zmin-eps3) .and. (z_temp <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
            xparam = (r_temp - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z_temp - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            TI4D(1,1,1,1),nr,nphi,nz)
            ti_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            NI5D(1,1,1,1,dexionD),nr,nphi,nz)
            nd_temp = max(fval(1),zero)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            NI5D(1,1,1,1,dexionHe3),nr,nphi,nz)
            nHe3_temp = max(fval(1),zero)
         ELSE
            RETURN
         END IF
         IF (ti_temp <= zero) RETURN ! Get out if ti small

         reactrate = DHe3_CROSS_SECTION(ti_temp)*nd_temp*nHe3_temp
         RETURN

      END SUBROUTINE beams3d_DHe3RATE

      !-----------------------------------------------------------------
      !     Function:      beams3d_MODB
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          09/30/2020
      !     Description:   Returns |B| at a point in space
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_MODB(q,B)
         !--------------------------------------------------------------
         !     Input Parameters
         !          q            (q(1),q(2),q(3)) = (R,phi,Z)
         !          B            Magnetic field magnitude ([T])
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(3)
         DOUBLE PRECISION, INTENT(out) :: B

         !--------------------------------------------------------------
         !     Local Variables
         !        r_temp     Helpers (r,phi,z)
         !        i,j,k      Spline Grid indicies
         !        xparam     Spline subgrid factor [0,1] (yparam,zparam)
         !        ict        Spline output control
         !        fval       Spline output array
         !--------------------------------------------------------------
         DOUBLE PRECISION :: r_temp, z_temp, phi_temp
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         ! Setup position in a vll arrays
         r_temp   = q(1)
         phi_temp = MODULO(q(2), phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         z_temp   = q(3)

         ! Initialize values
         B = zero

         ! Check that we're inside the domain then proceed
         IF ((r_temp >= rmin-eps1) .and. (r_temp <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z_temp >= zmin-eps3) .and. (z_temp <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
            xparam = (r_temp - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z_temp - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            MODB4D(1,1,1,1),nr,nphi,nz)
            B = max(fval(1),zero)
         ELSE
            RETURN
         END IF

         RETURN

      END SUBROUTINE beams3d_MODB

    
      !-----------------------------------------------------------------
      !     Function:      beams3d_VTOR
      !     Authors:       D. Kulla (david.kulla@ipp.mpg.de)
      !     Date:          03/12/2024
      !     Description:   Returns VTOR (OMEGA*R) at a point in space
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_VTOR(q,vtor)
         !--------------------------------------------------------------
         !     Input Parameters
         !          q            (q(1),q(2),q(3)) = (R,phi,Z)
         !          vtor         Toroidal rotation ([m/s])
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(3)
         DOUBLE PRECISION, INTENT(out) :: vtor

         !--------------------------------------------------------------
         !     Local Variables
         !        r_temp     Helpers (r,phi,z)
         !        i,j,k      Spline Grid indicies
         !        xparam     Spline subgrid factor [0,1] (yparam,zparam)
         !        ict        Spline output control
         !        fval       Spline output array
         !--------------------------------------------------------------
         DOUBLE PRECISION :: r_temp, z_temp, phi_temp
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         ! Setup position in a vll arrays
         r_temp   = q(1)
         phi_temp = MODULO(q(2), phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         z_temp   = q(3)

         ! Initialize values
         vtor = zero

         ! Check that we're inside the domain then proceed
         IF ((r_temp >= rmin-eps1) .and. (r_temp <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z_temp >= zmin-eps3) .and. (z_temp <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
            xparam = (r_temp - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z_temp - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            OMEG4D(1,1,1,1),nr,nphi,nz)
            vtor = fval(1)*r_temp
         ELSE
            RETURN
         END IF
         RETURN
      END SUBROUTINE beams3d_VTOR      

      !-----------------------------------------------------------------
      !     Function:      beams3d_BCYL
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          08/17/2022
      !     Description:   Returns Br, Bphi, Bz
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_BCYL(r,phi,z,Br,Bphi,Bz)
         !--------------------------------------------------------------
         !     Input Parameters
         !         r, phi, z     Cylindrical coordiantes
         !     Output Parameters
         !         Br, Bphi, Bz  Magnetic field components
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(IN) :: r, phi, z
         DOUBLE PRECISION, INTENT(OUT) :: Br, Bphi, Bz

         !--------------------------------------------------------------
         !     Local Variables
         !        phi_temp     Helpers (r,phi,z)
         !        i,j,k      Spline Grid indicies
         !        xparam     Spline subgrid factor [0,1] (yparam,zparam)
         !        ict        Spline output control
         !        fval       Spline output array
         !--------------------------------------------------------------
         DOUBLE PRECISION :: phi_temp
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         ! Setup position in a vll arrays
         phi_temp = MODULO(phi, phimax)

         ! Initialize values
         Br = zero
         Bphi = zero
         Bz = zero

         ! Check that we're inside the domain then proceed
         IF ((r >= rmin-eps1) .and. (r <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z >= zmin-eps3) .and. (z <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z),1),nz-1)
            xparam = (r - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            BR4D(1,1,1,1),nr,nphi,nz)
            Br = fval(1)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            BPHI4D(1,1,1,1),nr,nphi,nz)
            Bphi = fval(1)
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            BZ4D(1,1,1,1),nr,nphi,nz)
            Bz = fval(1)
         ELSE
            RETURN
         END IF

         RETURN

      END SUBROUTINE beams3d_BCYL

      !-----------------------------------------------------------------
      !     Function:      beams3d_BCART
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          09/26/2023
      !     Description:   Returns Bx, By, Bz
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_BCART(x,y,z,Bx,By,Bz)
         !--------------------------------------------------------------
         !     Input Parameters
         !         r, phi, z     Cylindrical coordiantes
         !     Output Parameters
         !         Br, Bphi, Bz  Magnetic field components
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(IN) :: x, y, z
         DOUBLE PRECISION, INTENT(OUT) :: Bx, By, Bz

         !--------------------------------------------------------------
         !     Local Variables
         !        phi_temp     Helpers (r,phi,z)
         !--------------------------------------------------------------
         DOUBLE PRECISION :: r_temp, phi_temp, Br_temp, Bphi_temp

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         ! Cartesian coordiantes to cylindrical
         r_temp = sqrt(x*x+y*y)
         phi_temp = atan2(y,x)

         ! Call cylindrical routine
         CALL beams3d_BCYL(r_temp,phi_temp,z,Br_temp,Bphi_temp,Bz)

         ! Cyl vectors to cartesian
         Bx = Br_temp*cos(phi_temp)-Bphi_temp*sin(phi_temp)
         By = Br_temp*sin(phi_temp)+Bphi_temp*cos(phi_temp)

         RETURN

      END SUBROUTINE beams3d_BCART

      !-----------------------------------------------------------------
      !     Function:      beams3d_SFLX
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          09/30/2020
      !     Description:   Returns normalized toroidal flux at a point
      !                    in space.
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_SFLX(q,S)
         !--------------------------------------------------------------
         !     Input Parameters
         !          q    (q(1),q(2),q(3)) = (R,phi,Z)
         !          S    Backbround grid flux
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(3)
         DOUBLE PRECISION, INTENT(out) :: S

         !--------------------------------------------------------------
         !     Local Variables
         !        r_temp     Helpers (r,phi,z)
         !        i,j,k      Spline Grid indicies
         !        xparam     Spline subgrid factor [0,1] (yparam,zparam)
         !        ict        Spline output control
         !        fval       Spline output array
         !--------------------------------------------------------------
         DOUBLE PRECISION :: r_temp, z_temp, phi_temp
         DOUBLE PRECISION :: RHO
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         ! Setup position in a vll arrays
         r_temp   = q(1)
         phi_temp = MODULO(q(2), phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         z_temp   = q(3)

         ! Initialize values
         S = 2

         ! Check that we're inside the domain then proceed
         IF ((r_temp >= rmin-eps1) .and. (r_temp <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z_temp >= zmin-eps3) .and. (z_temp <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
            xparam = (r_temp - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z_temp - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            RHO4D(1,1,1,1),nr,nphi,nz)
            RHO = max(fval(1),zero)
            S = RHO*RHO
         END IF

         RETURN

      END SUBROUTINE beams3d_SFLX

      !-----------------------------------------------------------------
      !     Function:      beams3d_SUFLX
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          09/28/2023
      !     Description:   Returns normalized toroidal flux and
      !                    poloidal angle at a given point in space.
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_SUFLX(q,S,U)
         !--------------------------------------------------------------
         !     Input Parameters
         !          q    (q(1),q(2),q(3)) = (R,phi,Z)
         !          S    Backbround grid normalized flux
         !          U    Backbround grid poloidal angle
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(3)
         DOUBLE PRECISION, INTENT(out) :: S
         DOUBLE PRECISION, INTENT(out) :: U

         !--------------------------------------------------------------
         !     Local Variables
         !        r_temp     Helpers (r,phi,z)
         !        i,j,k      Spline Grid indicies
         !        xparam     Spline subgrid factor [0,1] (yparam,zparam)
         !        ict        Spline output control
         !        fval       Spline output array
         !--------------------------------------------------------------
         DOUBLE PRECISION :: r_temp, z_temp, phi_temp
         DOUBLE PRECISION :: RHO
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         ! Setup position in a vll arrays
         r_temp   = q(1)
         phi_temp = MODULO(q(2), phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         z_temp   = q(3)

         ! Initialize values
         S = 2; U = 0

         ! Check that we're inside the domain then proceed
         IF ((r_temp >= rmin-eps1) .and. (r_temp <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z_temp >= zmin-eps3) .and. (z_temp <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
            xparam = (r_temp - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z_temp - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            RHO4D(1,1,1,1),nr,nphi,nz)
            RHO = max(fval(1),zero)
            S = RHO*RHO
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            U4D(1,1,1,1),nr,nphi,nz)
            U = fval(1)
         END IF

         RETURN

      END SUBROUTINE beams3d_SUFLX

      !-----------------------------------------------------------------
      !     Function:      beams3d_suv2rzp
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          03/07/2021
      !     Description:   Returns R and Z given s,u,v coordinate
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_suv2rzp(s,u,v,r_out,z_out,phi_out)
         !--------------------------------------------------------------
         !     Input Parameters
         !          s            Normalized Toroidal Flux
         !          u            Poloidal Angle
         !          v            Toroidal Angle
         !          r_out        Major Radius Distance R
         !          z_out        Vertical Distance Z
         !          phi_out      Toroidal Angle
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: s
         DOUBLE PRECISION, INTENT(inout) :: u
         DOUBLE PRECISION, INTENT(inout) :: v
         DOUBLE PRECISION, INTENT(inout) :: r_out
         DOUBLE PRECISION, INTENT(inout) :: z_out
         DOUBLE PRECISION, INTENT(out) :: phi_out

         !--------------------------------------------------------------
         !     Local Variables
         !        residual   Residual Error
         !--------------------------------------------------------------
         INTEGER          :: n
         DOUBLE PRECISION :: s0, u0, residual, detJ, delR, delZ, fnorm, &
                             factor, x, y, x0, y0, x_term, y_term, dxdR, dxdZ, dydR, dydZ
         DOUBLE PRECISION :: rho, rho0, xrho0, yrho0
         DOUBLE PRECISION :: xrho_term, yrho_term

         ! For splines
         INTEGER :: i,j,k, ier
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,1,1,1,0,0,0,0/)
         REAL*8 :: fvalx(1,4),fvaly(1,4) !(f,df/fR,df/dphi,dfdZ)
         REAL*8 :: fvalxrho(1,4),fvalyrho(1,4) !(f,df/fR,df/dphi,dfdZ)


         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         !Begin Newton Method
         residual = 1.0
         factor = 1.0
         IF (r_out<0) r_out = raxis(1)+(raxis(nr)-raxis(1))*.75
         
         ! PHI does not change
         phi_out = MOD(v,MAXVAL(phiaxis))
         j = MIN(MAX(COUNT(phiaxis < phi_out),1),nphi-1)
         yparam = (phi_out - phiaxis(j)) * hpi(j)

         ! Adjust u
         u = MOD(u,pi2)
         rho = sqrt(s)

         x0 = s * COS(u)
         y0 = s * SIN(U)
         xrho0 = rho * COS(u)
         yrho0 = rho * SIN(u)

         fnorm = MAX(x0*x0+y0*y0,1E-5)
         fnorm = 1./fnorm
         n = 1

         ! Loop Basically a NEWTON's METHOD
         !  F(R,Z) = (s0-s(R,Z))*(u0-u(R,Z))
         !  dF/dR  = -ds/dR*(u0-u(R,Z))-du/dR*(s0-s(R,Z))
         !  dF/dZ  = -ds/dZ*(u0-u(R,Z))-du/dZ*(s0-s(R,Z))
         DO WHILE (residual > 1.0E-9 .and. n<1000)
            i = MIN(MAX(COUNT(raxis < r_out),1),nr-1)
            k = MIN(MAX(COUNT(zaxis < z_out),1),nz-1)
            xparam = (r_out - raxis(i)) * hri(i)
            zparam = (z_out - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fvalxrho,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            XRHO4D(1,1,1,1),nr,nphi,nz)
            CALL R8HERM3FCN(ict,1,1,fvalyrho,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            YRHO4D(1,1,1,1),nr,nphi,nz)

            xrho_term   = xrho0 - fvalxrho(1,1)
            yrho_term   = yrho0 - fvalyrho(1,1)
            
            detJ = fvalxrho(1,2) * fvalyrho(1,4) - fvalyrho(1,2) * fvalxrho(1,4)
            detJ = MAX(detJ,0.0001) !Upper bound for step size as detJ enters in denominator
            delR = -(-xrho_term*fvalyrho(1,4) + yrho_term*fvalxrho(1,4))/detJ
            delZ = -( xrho_term*fvalyrho(1,2) - yrho_term*fvalxrho(1,2))/detJ

            delR = MIN(MAX(delR,-hr(1)),hr(1))
            delZ = MIN(MAX(delZ,-hz(1)),hz(1))

            residual = (xrho_term*xrho_term+yrho_term*yrho_term)*fnorm
            !WRITE(6,*) '----- ',s,rho,u,s0,rho0,u0,r_out,z_out,residual,tau,delR,delZ

            IF (residual < 0.01) THEN !"Damping" of oscillation
               delR = delR*0.5
               delZ = delZ*0.5
            END IF

            r_out = MAX(MIN(r_out + delR*factor,raxis(nr)),raxis(1))
            z_out = MAX(MIN(z_out + delZ*factor,zaxis(nz)),zaxis(1))
            !WRITE(6,*) '----- ',s,u,s0,u0,r_out,z_out,residual
            n=n+1
         END DO

 !        IF (n>=500) PRINT *,s,u,fnorm,residual


         RETURN

      END SUBROUTINE beams3d_suv2rzp

      !-----------------------------------------------------------------
      !     Function:      beams3d_fbounce
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          10/24/2020
      !     Description:   Calculates pseudo bounce frequency.
      !                    Uses large aspect ratio cicular cross
      !                    sction formulation.
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_fbounce(q,mu,mass,fbounce)
         !--------------------------------------------------------------
         !     Input Parameters
         !          q            (q(1),q(2),q(3)) = (R,phi,Z)
         !          mu           Magnetic moment (J/T)
         !          mass         Particle mass (kg)
         !          fbounce      Reaction rate (part/(m^3*s))
         !--------------------------------------------------------------
         IMPLICIT NONE
         DOUBLE PRECISION, INTENT(inout) :: q(3)
         DOUBLE PRECISION, INTENT(inout) :: mu
         DOUBLE PRECISION, INTENT(inout) :: mass
         DOUBLE PRECISION, INTENT(out) :: fbounce

         !--------------------------------------------------------------
         !     Local Variables
         !        r_temp     Helpers (r,phi,z)
         !        i,j,k      Spline Grid indicies
         !        xparam     Spline subgrid factor [0,1] (yparam,zparam)
         !        ict        Spline output control
         !        fval       Spline output array
         !--------------------------------------------------------------
         DOUBLE PRECISION :: r_temp, z_temp, phi_temp, vperp, R0, Z0, r
         ! For splines
         INTEGER :: i,j,k
         REAL*8 :: xparam, yparam, zparam
         INTEGER, parameter :: ict(8)=(/1,0,0,0,0,0,0,0/)
         REAL*8 :: fval(1)

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------

         ! Setup position in a vll arrays
         r_temp   = q(1)
         phi_temp = MODULO(q(2), phimax)
         IF (phi_temp < 0) phi_temp = phi_temp + phimax
         z_temp   = q(3)

         ! Initialize values
         fbounce = zero
         R0      = (raxis(nr)-raxis(1))*half+raxis(1)
         Z0      = (zaxis(nr)-zaxis(1))*half+zaxis(1)
         r       = SQRT((r_temp-R0)*(r_temp-R0)+(z_temp-Z0)*(z_temp-Z0))

         ! Check that we're inside the domain then proceed
         IF ((r_temp >= rmin-eps1) .and. (r_temp <= rmax+eps1) .and. &
             (phi_temp >= phimin-eps2) .and. (phi_temp <= phimax+eps2) .and. &
             (z_temp >= zmin-eps3) .and. (z_temp <= zmax+eps3)) THEN
            i = MIN(MAX(COUNT(raxis < r_temp),1),nr-1)
            j = MIN(MAX(COUNT(phiaxis < phi_temp),1),nphi-1)
            k = MIN(MAX(COUNT(zaxis < z_temp),1),nz-1)
            xparam = (r_temp - raxis(i)) * hri(i)
            yparam = (phi_temp - phiaxis(j)) * hpi(j)
            zparam = (z_temp - zaxis(k)) * hzi(k)
            ! Evaluate the Splines
            CALL R8HERM3FCN(ict,1,1,fval,i,j,k,xparam,yparam,zparam,&
                            hr(i),hri(i),hp(j),hpi(j),hz(k),hzi(k),&
                            MODB4D(1,1,1,1),nr,nphi,nz)
            !vperp = SQRT(2*mu*fval(1)/mass)
            !fbounce = vperp*SQRT(half*r/R0)/(R0*pi2) ! assume q=1
            fbounce = SQRT(r*mu*fval(1)/(mass*R0*R0*R0*pi2*pi2))
         ELSE
            RETURN
         END IF

         RETURN

      END SUBROUTINE beams3d_fbounce

      !-----------------------------------------------------------------
      !     Function:      beams3d_calc_dt
      !     Authors:       S. Lazerson (samuel.lazerson@ipp.mpg.de)
      !     Date:          08/17/2022
      !     Description:   Calculates the timestep using using the
      !                    Gyrofreqency
      !-----------------------------------------------------------------
      SUBROUTINE beams3d_calc_dt(type,r,phi,z,dt_out)
         !--------------------------------------------------------------
         !     Input Parameters
         !          dt      Timestep
         !--------------------------------------------------------------
         IMPLICIT NONE
         INTEGER, INTENT(IN) :: type
         DOUBLE PRECISION, INTENT(IN) :: r, phi, z
         DOUBLE PRECISION, INTENT(OUT) :: dt_out

         !--------------------------------------------------------------
         !     Local Variables
         !        freq_bounce Approx bounce frequency
         !--------------------------------------------------------------
         DOUBLE PRECISION :: vll, B, dt_temp
         DOUBLE PRECISION :: q(3)

         ! Substeps per gyroperiod, from the NSUB_FULLORBIT namelist variable.

         !--------------------------------------------------------------
         !     Begin Subroutine
         !--------------------------------------------------------------


         IF (TYPE==1) THEN
            vll = ABS(vll_start(myline))
            dt_temp = lendt_m/vll
         ELSEIF (TYPE==2) THEN
            ! Get B-field
            q(1)=r; q(2) = phi; q(3)=z
            CALL beams3d_MODB(q,B)
            ! Calc Velocity
            dt_temp = (pi2*mymass)/(mycharge*B*nsub_fullorbit)
         END IF
        
         ! Place bounds on dt
         dt_temp = MAX(dt_temp,1D-10)
         dt_temp = MIN(dt_temp,10D-8)

         ! Handle negative dt
         dt_temp = SIGN(dt_temp,my_end)

         ! Calculate number of integration timesteps per output timestep
         ndt_max = CEILING(my_end/(dt_temp*NPOINC))
          
         ! Adjust dt to match ndt_max
         dt_out = my_end/(ndt_max*NPOINC)

         RETURN

      END SUBROUTINE beams3d_calc_dt
	  
END MODULE beams3d_physics_mod
