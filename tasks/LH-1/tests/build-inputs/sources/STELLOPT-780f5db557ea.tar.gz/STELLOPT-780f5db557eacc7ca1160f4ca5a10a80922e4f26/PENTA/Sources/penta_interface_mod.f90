!-----------------------------------------------------------------------
!     Module:        PENTA_INTERFACE_MOD
!     Authors:       S. Lazerson
!     Date:          10/16/2022
!     Description:   Module provides a subroutine based interface to
!                    the PENTA code.
!-----------------------------------------------------------------------
MODULE PENTA_INTERFACE_MOD
!-----------------------------------------------------------------------
!     Libraries
!-----------------------------------------------------------------------
   USE penta_kind_mod

!-----------------------------------------------------------------------
!     Module Variables
!-----------------------------------------------------------------------
   IMPLICIT NONE

   INTEGER(iknd), PARAMETER :: NUM_ROOTS_MAX = 10_iknd
   INTEGER(iknd), PARAMETER :: NUM_ION_MAX = 20_iknd

   LOGICAL ::  input_is_Er, log_interp, use_quanc8, read_U2_file, &
      flux_cap, output_QoT_vs_Er, Add_Spitzer_to_D33, use_beam, &
      save_all_ambipolar_roots, save_fluxes_vs_Er
   INTEGER(iknd) ::  num_Er_test, numKsteps, kord_pprof, keord, kcord, &
      numargs, js, i_append, num_species, num_ion_species, Smax, &
      iocheck, ie, ind_X, ind_A, ispec1, min_ind, iroot, num_roots
   REAL(rknd) ::  Kmin, Kmax, epsabs, epsrel, Er_min, Er_max, B_Eprl, &
      U2, vth_e, loglambda, Er_test, abs_Er, min_Er, eaEr_o_kTe, cmin, &
      cmax, emin, emax, sigma_par, sigma_par_Spitzer, J_BS, Er_min_Vcm, Er_max_Vcm
   REAL(rknd), DIMENSION(NUM_ION_MAX) ::  Z_ion_init, miomp_init
   REAL(rknd), DIMENSION(NUM_ROOTS_MAX) ::  Er_roots
   REAL(rknd), DIMENSION(:), ALLOCATABLE :: ion_mass, Z_ion, vth_i, &
      charges, dens, masses, temps, vths, dTdrs, dndrs, Xvec, Avec, &
      Flows, Gammas, QoTs, xt_c, xt_e, Gamma_e_vs_Er, QoT_e_vs_Er, &
      Er_test_vals, Jprl_ambi, sigma_par_ambi, sigma_par_Spitzer_ambi, &
      J_BS_ambi
   REAL(rknd), DIMENSION(:,:), ALLOCATABLE :: lmat, Dspl_D11, Dspl_D13, &
      Dspl_D31, Dspl_D33, Dspl_Dex, Dspl_Dua, Dspl_Drat, Dspl_Drat2, &
      Dspl_logD11, Dspl_logD33, cmesh, gamma_i_vs_er, QoT_i_vs_Er, &
      Flows_ambi, gammas_ambi, QoTs_ambi, Jprl_parts, upol, utor
   REAL(rknd), DIMENSION(:,:,:), ALLOCATABLE :: L_A1, L_A2, L_A3
   REAL(rknd), DIMENSION(:,:), ALLOCATABLE :: L_n, L_T, L_Er
   REAL(rknd), DIMENSION(:,:), ALLOCATABLE :: R_n, R_T, R_Er
   REAL(rknd), DIMENSION(:,:,:), ALLOCATABLE :: L_n_ambi, L_T_ambi, L_Er_ambi
   REAL(rknd), DIMENSION(:,:,:), ALLOCATABLE :: R_n_ambi, R_T_ambi, R_Er_ambi
   LOGICAL, DIMENSION(:), ALLOCATABLE :: root_type
   CHARACTER(LEN=10) :: Method
   CHARACTER(LEN=100) :: arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, &
      arg9, coeff_ext, run_ident, pprof_char, fpos, fstatus, str_num, &
      Er_root_type
   REAL(rknd), DIMENSION(:),   ALLOCATABLE :: Ka_array, exp_Ka_array
   REAL(rknd), DIMENSION(:,:), ALLOCATABLE :: cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix
   REAL(rknd), DIMENSION(:,:), ALLOCATABLE :: sonine_poly
   ! Precomputed K-space weight arrays updated each time abs_Er changes via penta_set_energy_weights
   REAL(rknd), DIMENSION(:,:), ALLOCATABLE :: &
      energy_weights_Drat_K15, &  ! Dspl_Drat, K_exp=1.5: flows RHS1 + fluxes Na_1k
      energy_weights_Drat_K25, &  ! Dspl_Drat, K_exp=2.5: flows RHS2 + QoTs Na_2k
      energy_weights_DUa_K15,  &  ! Dspl_DUa,  K_exp=1.5: flows LHS
      energy_weights_Dex_K15,  &  ! Dspl_Dex,  K_exp=1.5: fluxes L11
      energy_weights_Dex_K25,  &  ! Dspl_Dex,  K_exp=2.5: fluxes L12 + QoTs L21
      energy_weights_Dex_K35      ! Dspl_Dex,  K_exp=3.5: QoTs L22

!-----------------------------------------------------------------------
!     Module Namelists
!-----------------------------------------------------------------------
   NAMELIST /ion_params/ num_ion_species, Z_ion_init, miomp_init
   NAMELIST /run_params/ input_is_Er, log_interp, use_quanc8, &
      read_U2_file, Add_Spitzer_to_D33, num_Er_test, numKsteps, &
      kord_pprof, keord, kcord, Kmin, Kmax, epsabs, epsrel, Method, &
      flux_cap, output_QoT_vs_Er, use_beam, Er_min_Vcm, Er_max_Vcm, &
      save_all_ambipolar_roots, save_fluxes_vs_Er, Er_root_type

!-----------------------------------------------------------------------
!     SUBROUTINES
!-----------------------------------------------------------------------
   CONTAINS

   SUBROUTINE init_penta_input
      IMPLICIT NONE
      input_is_Er          = .TRUE.
      log_interp           = .TRUE.
      use_quanc8           = .FALSE.
      read_U2_file         = .FALSE.
      flux_cap             = .TRUE.
      output_QoT_vs_Er     = .FALSE.
      Add_Spitzer_to_D33   = .TRUE.
      use_beam             = .FALSE.
      num_Er_test          = 501_iknd
      numKsteps            = 10000_iknd
      kord_pprof           = 3_iknd
      keord                = 2_iknd
      kcord                = 2_iknd
      Kmin                 = 1.0E-5_rknd
      Kmax                 = 2.0E+1_rknd
      epsabs               = 1.0E-8_rknd
      epsrel               = 1.0E-6_rknd
      sigma_par            = 0.0E+0_rknd
      sigma_par_Spitzer    = 0.0E+0_rknd
      J_BS                 = 0.0E+0_rknd
      method               = 'SN'
      Er_min_Vcm           = -250.0_rknd
      Er_max_Vcm           =  250.0_rknd
      save_all_ambipolar_roots = .FALSE.
      save_fluxes_vs_Er = .FALSE.
      num_ion_species   = 1
      Z_ion_init        = 1.0
      miomp_init        = 1.0
      Er_root_type      = 'ion_root'
      RETURN
   END SUBROUTINE init_penta_input

   SUBROUTINE bcast_penta_input(main_thread, mpi_communicator,ierr_mpi)
      USE mpi_inc
      IMPLICIT NONE
      INTEGER, INTENT(in) :: main_thread
      INTEGER, INTENT(inout) :: mpi_communicator
      INTEGER, INTENT(out) :: ierr_mpi
      ierr_mpi = 0
#if defined(MPI_OPT)
      CALL MPI_BCAST(num_ion_species,          1, MPI_INTEGER,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(num_species,              1, MPI_INTEGER,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(Z_ion_init,     NUM_ION_MAX, MPI_DOUBLE_PRECISION, main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(miomp_init,     NUM_ION_MAX, MPI_DOUBLE_PRECISION, main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(input_is_Er,              1, MPI_LOGICAL,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(log_interp,               1, MPI_LOGICAL,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(use_quanc8,               1, MPI_LOGICAL,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(read_U2_file,             1, MPI_LOGICAL,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(flux_cap,                 1, MPI_LOGICAL,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(output_QoT_vs_Er,         1, MPI_LOGICAL,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(Add_Spitzer_to_D33,       1, MPI_LOGICAL,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(use_beam,                 1, MPI_LOGICAL,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(save_all_ambipolar_roots, 1, MPI_LOGICAL,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(save_fluxes_vs_Er,        1, MPI_LOGICAL,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(num_Er_test,              1, MPI_INTEGER,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(numKsteps,                1, MPI_INTEGER,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(kord_pprof,               1, MPI_INTEGER,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(keord,                    1, MPI_INTEGER,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(kcord,                    1, MPI_INTEGER,          main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(Kmin,                     1, MPI_DOUBLE_PRECISION, main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(Kmax,                     1, MPI_DOUBLE_PRECISION, main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(epsabs,                   1, MPI_DOUBLE_PRECISION, main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(epsrel,                   1, MPI_DOUBLE_PRECISION, main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(sigma_par,                1, MPI_DOUBLE_PRECISION, main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(sigma_par_Spitzer,        1, MPI_DOUBLE_PRECISION, main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(J_BS,                     1, MPI_DOUBLE_PRECISION, main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(Er_min_Vcm,               1, MPI_DOUBLE_PRECISION, main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(Er_max_Vcm,               1, MPI_DOUBLE_PRECISION, main_thread, mpi_communicator, ierr_mpi)
      CALL MPI_BCAST(method,                  10, MPI_CHARACTER,        main_thread, mpi_communicator, ierr_mpi)
#endif
      RETURN
   END SUBROUTINE bcast_penta_input

   SUBROUTINE penta_set_ion_params(num_ion_in, Z_ion_in, miomp_in)
      IMPLICIT NONE
      INTEGER, INTENT(in) :: num_ion_in
      REAL(rknd), DIMENSION(NUM_ION_MAX), INTENT(in) ::  Z_ion_in
      REAL(rknd), DIMENSION(NUM_ION_MAX), INTENT(in) ::  miomp_in
      num_ion_species = num_ion_in
      Z_ion_init = Z_ion_in
      miomp_init = miomp_in
      ! Electrons + ions  (added here because the function where this used to be defined [read_ion_params_namelist] is no longer called) AC 11/2024
      num_species = num_ion_species + 1_iknd
      RETURN
   END SUBROUTINE penta_set_ion_params

   !! This subroutine is not called since in THRIFT we read the ions data from the h5 file
   SUBROUTINE read_penta_ion_params_namelist(filename,istat)
      USE safe_open_mod
      IMPLICIT NONE
      CHARACTER(*), INTENT(in) :: filename
      INTEGER, INTENT(inout) :: istat
      LOGICAL :: lexist
      INTEGER :: iunit
      CHARACTER(LEN=1000) :: line
      istat = 0; iunit = 12
      INQUIRE(FILE=TRIM(filename),EXIST=lexist)
      IF (.not.lexist) stop 'Could not find input file'
      CALL safe_open(iunit,istat,TRIM(filename),'old','formatted')
      IF (istat /= 0) THEN
         WRITE(6,'(A)') 'ERROR opening file: ',TRIM(filename)
         CALL FLUSH(6)
         STOP
      END IF
      READ(iunit,NML=ion_params,IOSTAT=istat)
      IF (istat /= 0) THEN
         WRITE(6,'(A)') 'ERROR reading PENTA ion_params namelist from file: ',TRIM(filename)
         backspace(iunit)
         read(iunit,fmt='(A)') line
         write(6,'(A)') 'Invalid line in namelist: '//TRIM(line)
         CALL FLUSH(6)
         STOP
      END IF
      CLOSE(iunit)
      ! Electrons + ions
      num_species = num_ion_species + 1_iknd
      RETURN
   END SUBROUTINE read_penta_ion_params_namelist

   SUBROUTINE write_ion_params_nml(iunit)
      IMPLICIT NONE
      INTEGER(iknd), INTENT(inout) :: iunit
      CHARACTER(LEN=*), PARAMETER :: outint  = "(2X,A,1X,'=',1X,I0)"
      INTEGER(iknd) :: k
      WRITE(iunit,'(A)') '&ION_PARAMS'
      !WRITE(iunit,'(A)') '!----------------------------------------------------------------'
      WRITE(iunit,outint) 'NUM_ION_SPECIES',num_ion_species
      WRITE(iunit,"(2X,A,1X,'=',4(1X,ES22.12E3))") 'Z_ION_INIT',(Z_ion_init(k), k=1,num_ion_species)
      WRITE(iunit,"(2X,A,1X,'=',4(1X,ES22.12E3))") 'MIOMP_INIT',(miomp_init(k), k=1,num_ion_species)
      WRITE(iunit,'(A)') '/'
   END SUBROUTINE write_ion_params_nml

   SUBROUTINE write_ion_params_namelist_byfile(filename)
      USE safe_open_mod
      IMPLICIT NONE
      CHARACTER(LEN=*), INTENT(in) :: filename
      INTEGER(iknd) :: iunit, istat
      LOGICAL :: lexists
      
      iunit = 100
      istat = 0
      INQUIRE(FILE=TRIM(filename),exist=lexists)
      IF (lexists) THEN
         CALL safe_open(iunit,istat,TRIM(filename),'old','formatted', access_in='append')
         !OPEN(unit=iunit, file=TRIM(filename),iostat=istat, status="old", position="append")
      ELSE
         CALL safe_open(iunit,istat,TRIM(filename),'replace','formatted')
         !OPEN(unit=iunit, file=TRIM(filename),iostat=istat, status="new")
      END IF
      IF (istat .ne. 0) RETURN
      CALL write_ion_params_nml(iunit)
      CLOSE(iunit)

      RETURN
   END SUBROUTINE write_ion_params_namelist_byfile

   SUBROUTINE read_penta_run_params_namelist(filename,istat)
      USE safe_open_mod
      IMPLICIT NONE
      CHARACTER(*), INTENT(in) :: filename
      INTEGER, INTENT(inout) :: istat
      LOGICAL :: lexist
      INTEGER :: iunit
      CHARACTER(LEN=1000) :: line
      istat = 0; iunit = 12
      INQUIRE(FILE=TRIM(filename),EXIST=lexist)
      IF (.not.lexist) stop 'Could not find input file'
      CALL safe_open(iunit,istat,TRIM(filename),'old','formatted')
      IF (istat /= 0) THEN
         WRITE(6,'(A)') 'ERROR opening file: ',TRIM(filename)
         CALL FLUSH(6)
         STOP
      END IF
      READ(iunit,NML=run_params,IOSTAT=istat)
      IF (istat /= 0) THEN
         WRITE(6,'(A)') 'ERROR reading PENTA run_params namelist from file: ',TRIM(filename)
         backspace(iunit)
         read(iunit,fmt='(A)') line
         write(6,'(A)') 'Invalid line in namelist: '//TRIM(line)
         CALL FLUSH(6)
         STOP
      END IF
      CALL tolower(Er_root_type)
      CLOSE(iunit)
      RETURN
   END SUBROUTINE read_penta_run_params_namelist

   SUBROUTINE write_run_params_nml(iunit)
      IMPLICIT NONE
      INTEGER(iknd), INTENT(inout) :: iunit
      CHARACTER(LEN=*), PARAMETER :: outboo  = "(2X,A,1X,'=',1X,L1)"
      CHARACTER(LEN=*), PARAMETER :: outint  = "(2X,A,1X,'=',1X,I0)"
      CHARACTER(LEN=*), PARAMETER :: outdbl  = "(2X,A,1X,'=',1X,ES22.14)"
      CHARACTER(LEN=*), PARAMETER :: outstr  = "(2X,A,1X,'=',1X,'''',A,'''')"
      INTEGER(iknd) :: k
      WRITE(iunit,'(A)') '&RUN_PARAMS'
      WRITE(iunit,outboo) 'INPUT_IS_ER',input_is_er
      WRITE(iunit,outboo) 'LOG_INTERP',log_interp
      WRITE(iunit,outboo) 'USE_QUANC8',use_quanc8
      WRITE(iunit,outboo) 'READ_U2_FILE',read_U2_file
      WRITE(iunit,outboo) 'ADD_SPITZER_TO_D33',Add_Spitzer_to_D33
      WRITE(iunit,outboo) 'FLUX_CAP',flux_cap
      WRITE(iunit,outboo) 'OUTPUT_QOT_VS_ER',output_QoT_vs_Er
      WRITE(iunit,outboo) 'USE_BEAM',use_beam
      WRITE(iunit,outint) 'NUM_ER_TEST',num_Er_test
      WRITE(iunit,outint) 'NUMKSTEPS',numksteps
      WRITE(iunit,outint) 'KORD_PPROF',kord_pprof
      WRITE(iunit,outint) 'KEORD',keord
      WRITE(iunit,outint) 'KCORD',kcord
      WRITE(iunit,outdbl) 'KMIN',kmin
      WRITE(iunit,outdbl) 'KMAX',kmax
      WRITE(iunit,outdbl) 'EPSABS',epsabs
      WRITE(iunit,outdbl) 'EPSREL',epsrel
      WRITE(iunit,outstr) 'METHOD',TRIM(method)
      WRITE(iunit,outstr) 'ER_ROOT_TYPE',TRIM(Er_root_type)
      WRITE(iunit,'(A)') '/'
   END SUBROUTINE write_run_params_nml

   SUBROUTINE write_run_params_namelist_byfile(filename)
      USE safe_open_mod
      IMPLICIT NONE
      CHARACTER(LEN=*), INTENT(in) :: filename
      INTEGER(iknd) :: iunit, istat
      LOGICAL :: lexists
      
      iunit = 100
      istat = 0
      INQUIRE(FILE=TRIM(filename),exist=lexists)
      IF (lexists) THEN
         CALL safe_open(iunit,istat,TRIM(filename),'old','formatted', access_in='append')
         !OPEN(unit=iunit, file=TRIM(filename),iostat=istat, status="old", position="append")
      ELSE
         CALL safe_open(iunit,istat,TRIM(filename),'replace','formatted')
         !OPEN(unit=iunit, file=TRIM(filename),iostat=istat, status="new")
      END IF
      IF (istat .ne. 0) RETURN
      CALL write_run_params_nml(iunit)
      CLOSE(iunit)

      RETURN
   END SUBROUTINE write_run_params_namelist_byfile

   SUBROUTINE penta_init_commandline
      IMPLICIT NONE
      CALL GETCARG(1, arg1, numargs)
      IF (numargs .NE. 9) THEN
         Write(6,'(A)') 'ERROR Incorrect number of input arguments, see penta.f90 for details'
         CALL FLUSH(6)
         STOP
      END IF
      CALL GETCARG(2, arg2, numargs)
      CALL GETCARG(3, arg3, numargs)
      CALL GETCARG(4, arg4, numargs)
      CALL GETCARG(5, arg5, numargs)
      CALL GETCARG(6, arg6, numargs)
      CALL GETCARG(7, arg7, numargs)
      CALL GETCARG(8, arg8, numargs)
      CALL GETCARG(9, arg9, numargs)

      READ(arg2,*) Er_min
      READ(arg3,*) Er_max
      READ(arg4,*) js
      READ(arg5,*) i_append
      READ(arg8,*) B_Eprl
      READ(arg9,*) Smax
      coeff_ext  = TRIM(ADJUSTL(arg1))
      run_ident  = TRIM(ADJUSTL(arg6))
      pprof_char = TRIM(ADJUSTL(arg7))
      RETURN
   END SUBROUTINE penta_init_commandline

   SUBROUTINE penta_set_commandline(Er_min_in,Er_max_in,js_in,i_append_in,B_Eprl_in,Smax_in,ext_in,run_in,pprof_in)
      IMPLICIT NONE
      REAL(rknd), INTENT(IN) :: Er_min_in
      REAL(rknd), INTENT(IN) :: Er_max_in
      INTEGER(iknd), INTENT(IN) :: js_in
      INTEGER(iknd), INTENT(IN) :: i_append_in
      REAL(rknd), INTENT(IN) :: B_Eprl_in
      INTEGER(iknd), INTENT(IN) :: Smax_in
      CHARACTER(LEN=*), INTENT(IN) :: ext_in
      CHARACTER(LEN=*), INTENT(IN) :: run_in
      CHARACTER(LEN=*), INTENT(IN) :: pprof_in
      Er_min   = Er_min_in
      Er_max   = Er_max_in
      js       = js_in
      i_append = i_append_in
      B_Eprl   = B_Eprl_in
      Smax     = Smax_in
      coeff_ext  = TRIM(ADJUSTL(ext_in))
      run_ident  = TRIM(ADJUSTL(run_in))
      pprof_char = TRIM(ADJUSTL(pprof_in))
      RETURN
   END SUBROUTINE penta_set_commandline

   SUBROUTINE penta_allocate_species
      USE pprof_pass, ONLY: ni, Ti, dnidr, dTidr
      IMPLICIT NONE
      ALLOCATE(ni(num_ion_species))
      ALLOCATE(Ti(num_ion_species))          ! Ion profile info
      ALLOCATE(dnidr(num_ion_species))
      ALLOCATE(dTidr(num_ion_species))
      ALLOCATE(Z_ion(num_ion_species))
      ALLOCATE(ion_mass(num_ion_species)) ! Ion parameters
      ALLOCATE(vth_i(num_ion_species))
      ALLOCATE(charges(num_species))                             ! Parameters for
      ALLOCATE(dens(num_species))                                !  all species
      ALLOCATE(vths(num_species)) 
      ALLOCATE(masses(num_species))
      ALLOCATE(Temps(num_species))
      ALLOCATE(dTdrs(num_species))
      ALLOCATE(dndrs(num_species))
      ALLOCATE(lmat((Smax+1)*num_species,(Smax+1)*num_species))  ! Clas. fric.coeffs
      ALLOCATE(Xvec(num_species*2+1))
      ALLOCATE(Avec(num_species*3))        ! Thermo. Force vecs.
      ALLOCATE(Flows((Smax+1)*num_species))                      ! Prl flow moments
      ALLOCATE(Gammas(num_species))                              ! Rad fluxes
      ALLOCATE(QoTs(num_species))                                ! Rad energy fluxes

      ALLOCATE(L_A1(num_species,num_species,Smax+1))
      ALLOCATE(L_A2(num_species,num_species,Smax+1))
      ALLOCATE(L_A3(num_species,num_species,Smax+1))

      ALLOCATE(L_n(num_species,num_species))
      ALLOCATE(L_T(num_species,num_species))
      ALLOCATE(L_Er(num_species,num_species))

      ALLOCATE(R_n(num_species,num_species))
      ALLOCATE(R_T(num_species,num_species))
      ALLOCATE(R_Er(num_species,num_species))
      
      RETURN
   END SUBROUTINE penta_allocate_species

   SUBROUTINE penta_allocate_dkescoeff
      USE coeff_var_pass, ONLY: num_c, num_e
      IMPLICIT NONE
      ALLOCATE(xt_c(num_c + kcord))
      ALLOCATE(xt_e(num_e + keord))
      ALLOCATE(Dspl_D11(num_c,num_e))
      ALLOCATE(Dspl_D13(num_c,num_e))
      ALLOCATE(Dspl_D31(num_c,num_e))
      ALLOCATE(Dspl_D33(num_c,num_e))
      ALLOCATE(Dspl_Dex(num_c,num_e))
      ALLOCATE(Dspl_Drat(num_c,num_e)) 
      ALLOCATE(Dspl_Drat2(num_c,num_e)) 
      ALLOCATE(Dspl_DUa(num_c,num_e))  
      ALLOCATE(Dspl_logD11(num_c,num_e))
      ALLOCATE(Dspl_logD33(num_c,num_e))
      ALLOCATE(cmesh(num_c,num_e))
      RETURN
   END SUBROUTINE penta_allocate_dkescoeff

   SUBROUTINE penta_deallocate_species
      USE pprof_pass, ONLY: ni, Ti, dnidr, dTidr
      IMPLICIT NONE
      IF (ALLOCATED(ni)) DEALLOCATE(ni)
      IF (ALLOCATED(ti)) DEALLOCATE(ti)
      IF (ALLOCATED(dnidr)) DEALLOCATE(dnidr)
      IF (ALLOCATED(dTidr)) DEALLOCATE(dTidr)
      IF (ALLOCATED(Z_ion)) DEALLOCATE(Z_ion)
      IF (ALLOCATED(ion_mass)) DEALLOCATE(ion_mass)
      IF (ALLOCATED(vth_i)) DEALLOCATE(vth_i)
      IF (ALLOCATED(charges)) DEALLOCATE(charges)
      IF (ALLOCATED(dens)) DEALLOCATE(dens)
      IF (ALLOCATED(vths)) DEALLOCATE(vths)
      IF (ALLOCATED(masses)) DEALLOCATE(masses)
      IF (ALLOCATED(Temps)) DEALLOCATE(Temps)
      IF (ALLOCATED(dTdrs)) DEALLOCATE(dTdrs)
      IF (ALLOCATED(dndrs)) DEALLOCATE(dndrs)
      IF (ALLOCATED(lmat)) DEALLOCATE(lmat)
      IF (ALLOCATED(Xvec)) DEALLOCATE(Xvec)
      IF (ALLOCATED(Avec)) DEALLOCATE(Avec)
      IF (ALLOCATED(Flows)) DEALLOCATE(Flows)
      IF (ALLOCATED(Gammas)) DEALLOCATE(Gammas)
      IF (ALLOCATED(QoTs)) DEALLOCATE(QoTs)
      IF (ALLOCATED(Gamma_i_vs_Er)) DEALLOCATE(Gamma_i_vs_Er)
      IF (ALLOCATED(Gamma_e_vs_Er)) DEALLOCATE(Gamma_e_vs_Er)
      IF (ALLOCATED(Er_test_vals)) DEALLOCATE(Er_test_vals)
      IF (ALLOCATED(QoT_i_vs_Er)) DEALLOCATE(QoT_i_vs_Er)
      IF (ALLOCATED(QoT_e_vs_Er)) DEALLOCATE(QoT_e_vs_Er)
      IF (ALLOCATED(Gammas_ambi)) DEALLOCATE(Gammas_ambi)
      IF (ALLOCATED(QoTs_ambi)) DEALLOCATE(QoTs_ambi)
      IF (ALLOCATED(Flows_ambi)) DEALLOCATE(Flows_ambi)
      IF (ALLOCATED(Jprl_ambi)) DEALLOCATE(Jprl_ambi)
      IF (ALLOCATED(Jprl_parts)) DEALLOCATE(Jprl_parts)
      IF (ALLOCATED(J_BS_ambi)) DEALLOCATE(J_BS_ambi)
      IF (ALLOCATED(sigma_par_ambi)) DEALLOCATE(sigma_par_ambi)
      IF (ALLOCATED(sigma_par_Spitzer_ambi)) DEALLOCATE(sigma_par_Spitzer_ambi)
      IF (ALLOCATED(utor)) DEALLOCATE(utor)
      IF (ALLOCATED(upol)) DEALLOCATE(upol)
      IF (ALLOCATED(root_type)) DEALLOCATE(root_type)
      IF (ALLOCATED(L_A1)) DEALLOCATE(L_A1)
      IF (ALLOCATED(L_A2)) DEALLOCATE(L_A2)
      IF (ALLOCATED(L_A3)) DEALLOCATE(L_A3)
      IF (ALLOCATED(L_n)) DEALLOCATE(L_n)
      IF (ALLOCATED(L_T)) DEALLOCATE(L_T)
      IF (ALLOCATED(L_Er)) DEALLOCATE(L_Er)
      IF (ALLOCATED(R_n)) DEALLOCATE(R_n)
      IF (ALLOCATED(R_T)) DEALLOCATE(R_T)
      IF (ALLOCATED(R_Er)) DEALLOCATE(R_Er)
      !
      IF (ALLOCATED(L_n_ambi)) DEALLOCATE(L_n_ambi)
      IF (ALLOCATED(L_T_ambi)) DEALLOCATE(L_T_ambi)
      IF (ALLOCATED(L_Er_ambi)) DEALLOCATE(L_Er_ambi)
      IF (ALLOCATED(R_n_ambi)) DEALLOCATE(R_n_ambi)
      IF (ALLOCATED(R_T_ambi)) DEALLOCATE(R_T_ambi)
      IF (ALLOCATED(R_Er_ambi)) DEALLOCATE(R_Er_ambi)

      RETURN
   END SUBROUTINE penta_deallocate_species

   SUBROUTINE penta_allocate_fluxes_vs_Er

      IF(ALLOCATED(Gamma_i_vs_er)) DEALLOCATE(Gamma_i_vs_er)
      ALLOCATE(Gamma_i_vs_Er(num_Er_test,num_ion_species))       ! Ion flux vs Er

      IF(ALLOCATED(Gamma_e_vs_Er)) DEALLOCATE(Gamma_e_vs_Er)
      ALLOCATE(Gamma_e_vs_Er(num_Er_test))                       ! Electron flux vs Er

      IF(ALLOCATED(Er_test_vals)) DEALLOCATE(Er_test_vals)
      ALLOCATE(Er_test_vals(num_Er_test))                        ! Er to loop over

      IF ( output_QoT_vs_Er ) THEN
         IF(ALLOCATED(QoT_i_vs_Er)) DEALLOCATE(QoT_i_vs_Er)
         ALLOCATE(QoT_i_vs_Er(num_Er_test,num_ion_species))       ! Ion flux vs Er

         IF(ALLOCATED(QoT_e_vs_Er)) DEALLOCATE(QoT_e_vs_Er)
         ALLOCATE(QoT_e_vs_Er(num_Er_test))                       ! Electron flux vs Er
      ENDIF

      RETURN

   END SUBROUTINE penta_allocate_fluxes_vs_Er

   SUBROUTINE penta_deallocate_dkescoeff
      USE penta_functions_mod, ONLY: work0,work1
      IMPLICIT NONE
      IF (ALLOCATED(xt_c)) DEALLOCATE(xt_c)
      IF (ALLOCATED(xt_e)) DEALLOCATE(xt_e)
      IF (ALLOCATED(Dspl_D11)) DEALLOCATE(Dspl_D11)
      IF (ALLOCATED(Dspl_D13)) DEALLOCATE(Dspl_D13)
      IF (ALLOCATED(Dspl_D31)) DEALLOCATE(Dspl_D31)
      IF (ALLOCATED(Dspl_D33)) DEALLOCATE(Dspl_D33)
      IF (ALLOCATED(Dspl_Dex)) DEALLOCATE(Dspl_Dex)
      IF (ALLOCATED(Dspl_Drat)) DEALLOCATE(Dspl_Drat)
      IF (ALLOCATED(Dspl_Drat2)) DEALLOCATE(Dspl_Drat2)
      IF (ALLOCATED(Dspl_DUa)) DEALLOCATE(Dspl_DUa)
      IF (ALLOCATED(Dspl_logD11)) DEALLOCATE(Dspl_logD11)
      IF (ALLOCATED(Dspl_logD33)) DEALLOCATE(Dspl_logD33)
      IF (ALLOCATED(cmesh)) DEALLOCATE(cmesh)
      IF (ALLOCATED(work0)) DEALLOCATE(work0)
      IF (ALLOCATED(work1)) DEALLOCATE(work1)
      IF (ALLOCATED(energy_weights_Drat_K15)) DEALLOCATE(energy_weights_Drat_K15)
      IF (ALLOCATED(energy_weights_Drat_K25)) DEALLOCATE(energy_weights_Drat_K25)
      IF (ALLOCATED(energy_weights_DUa_K15))  DEALLOCATE(energy_weights_DUa_K15)
      IF (ALLOCATED(energy_weights_Dex_K15))  DEALLOCATE(energy_weights_Dex_K15)
      IF (ALLOCATED(energy_weights_Dex_K25))  DEALLOCATE(energy_weights_Dex_K25)
      IF (ALLOCATED(energy_weights_Dex_K35))  DEALLOCATE(energy_weights_Dex_K35)
      IF (ALLOCATED(Ka_array))           DEALLOCATE(Ka_array)
      IF (ALLOCATED(exp_Ka_array))       DEALLOCATE(exp_Ka_array)
      IF (ALLOCATED(cmulK_matrix))       DEALLOCATE(cmulK_matrix)
      IF (ALLOCATED(log_cmulK_matrix))   DEALLOCATE(log_cmulK_matrix)
      IF (ALLOCATED(oneOverVa_matrix))   DEALLOCATE(oneOverVa_matrix)
      IF (ALLOCATED(sonine_poly))        DEALLOCATE(sonine_poly)
      RETURN
   END SUBROUTINE penta_deallocate_dkescoeff

   SUBROUTINE penta_read_input_files(lvmec,lpprof,ldkes,lbeam,lU2)
      USE vmec_var_pass, ONLY: roa_surf, arad, Bsq
      USE pprof_pass
      USE coeff_var_pass, ONLY: D11_mat, cmul, num_c
      USE phys_const, ONLY: p_mass, elem_charge, e_mass
      USE read_input_file_mod
      IMPLICIT NONE
      LOGICAL, INTENT(IN) :: lvmec
      LOGICAL, INTENT(IN) :: lpprof
      LOGICAL, INTENT(IN) :: ldkes
      LOGICAL, INTENT(IN) :: lbeam
      LOGICAL, INTENT(IN) :: lU2
      IF (lvmec) CALL read_vmec_file_2(js,run_ident)
      IF (lpprof) CALL read_pprof_file(pprof_char,num_ion_species,roa_surf,arad,kord_pprof)
      IF (ldkes) CALL read_dkes_star_files(coeff_ext,Add_Spitzer_to_D33,Bsq)
      IF (lbeam) THEN
         IF (use_beam) THEN
            CALL read_beam_file(roa_surf,kord_pprof)
         ELSE
            beam_force = 0._rknd
         ENDIF
      ENDIF
      ! Optionally read file containing <U**2> info.  Else this is 
      ! calculated from the D11* coefficient at high nu/v and Er=0.
      IF (lU2) THEN
         IF ( read_U2_file) THEN
            CALL read_Utilde2_file(roa_surf,U2,kord_pprof)
         ELSE
            U2=1.5d0*D11_mat(num_c,1)/cmul(num_c);
         ENDIF
      ENDIF
      ! Change Er test range to V/cm if necessary
      IF ( .not. input_is_Er) THEN
         Er_min = Er_min * Te / arad
         Er_max = Er_max * Te / arad
      ENDIF
      ! Assign ion parameters
      Z_ion    = Z_ion_init(1:num_ion_species)
      ion_mass = miomp_init(1:num_ion_species) * p_mass
      ! Calculate thermal velocities 
      vth_i = Dsqrt(2._rknd*Ti*elem_charge/ion_mass)
      vth_e = Dsqrt(2._rknd*Te*elem_charge/e_mass)
      ! Calculate Coulomb logarithm
      IF ( Te > 50._rknd ) THEN
        loglambda = 25.3_rknd - 1.15_rknd*Dlog10(ne/1.e6_rknd) + 2.3_rknd*Dlog10(Te)
      ELSE
        loglambda = 23.4_rknd - 1.15_rknd*Dlog10(ne/1.e6_rknd) + 3.45_rknd*Dlog10(Te)
      ENDIF
      ! Assign arrays of parameters for all species (charge, mass, n, T, v_th, dTdr)
      charges=elem_charge*(/-1._rknd,Z_ion/)
      dens=(/ne, ni/)
      masses=(/e_mass, ion_mass/)
      Temps=(/Te,Ti/)
      vths=(/vth_e,vth_i/)
      dTdrs=(/dTedr,dTidr/)
      dndrs=(/dnedr,dnidr/)
      RETURN
   END SUBROUTINE penta_read_input_files

   SUBROUTINE penta_set_eq_data(rho,A_in,R_in,Vp_in,chip_in,phip_in,iota_in,bth_in,bze_in,Bsq_in)
      USE vmec_var_pass
      IMPLICIT NONE
      REAL(rknd), INTENT(IN) :: rho
      REAL(rknd), INTENT(IN) :: A_in
      REAL(rknd), INTENT(IN) :: R_in
      REAL(rknd), INTENT(IN) :: Vp_in
      REAL(rknd), INTENT(IN) :: chip_in
      REAL(rknd), INTENT(IN) :: phip_in
      REAL(rknd), INTENT(IN) :: iota_in
      REAL(rknd), INTENT(IN) :: bth_in
      REAL(rknd), INTENT(IN) :: bze_in
      REAL(rknd), INTENT(IN) :: Bsq_in
      REAL(rknd) :: TWOPI
      TWOPI = 8*ATAN(1.0_rknd)
      roa_surf = rho
      arad = A_in
      Rmajor = R_in
      r_surf = roa_surf*arad
      chip = chip_in
      psip = phip_in
      iota = iota_in
      btheta = bth_in
      bzeta = bze_in
      Bsq = Bsq_in
      vol_p = Vp_in
      ! Note that vp from VMEC comes normalized by 4pi^2
      ! Therefore we need to denormalize it
      vol_p = TWOPI*TWOPI*vol_p
      ! vp_vmec is ~dV/ds, but what we want is dVdr=dVds*dsdr
      ! Since PENTA uses r/a=sqrt(s), then dVdr=dVds*2*r/a^2 
      vol_p = vol_p * 2.0_rknd*r_surf/arad**2
      !Same for psip and chip: need to convert d/ds to d/dr
      psip = psip * 2.0_rknd*r_surf/arad**2
      chip = chip * 2.0_rknd*r_surf/arad**2
      !psip and chip are used to compute flows in theta and zeta direction (see penta.f90)
      !It is assumed that psip and chip are normalized by 2pi
      !So need to do it here:
      psip = psip / TWOPI
      chip = chip / TWOPI
      ! For the SN formulation this is the think to do, but not for the the other formulations...
      b0 = dsqrt(Bsq)
      RETURN
   END SUBROUTINE penta_set_eq_data

   SUBROUTINE penta_set_pprof(ne_in,dnedr_in,te_in,dtedr_in,ni_in,dnidr_in,ti_in,dtidr_in)
      USE pprof_pass
      IMPLICIT NONE
      REAL(rknd), INTENT(IN) :: ne_in
      REAL(rknd), INTENT(IN) :: dnedr_in
      REAL(rknd), INTENT(IN) :: te_in
      REAL(rknd), INTENT(IN) :: dtedr_in
      REAL(rknd), DIMENSION(num_ion_species), INTENT(IN) :: ni_in
      REAL(rknd), DIMENSION(num_ion_species), INTENT(IN) :: dnidr_in
      REAL(rknd), DIMENSION(num_ion_species), INTENT(IN) :: ti_in
      REAL(rknd), DIMENSION(num_ion_species), INTENT(IN) :: dtidr_in
      ne    = ne_in
      dnedr = dnedr_in
      te    = te_in
      dtedr = dtedr_in
      ni    = ni_in
      dnidr = dnidr_in
      ti    = ti_in
      dtidr = dtidr_in
      RETURN
   END SUBROUTINE penta_set_pprof

   SUBROUTINE penta_set_DKES_star(nc,ne,cmul_in,efield_in,D11_in,D13_in,D33_in)
      USE vmec_var_pass, ONLY: Bsq
      USE coeff_var_pass
      IMPLICIT NONE
      INTEGER(iknd), INTENT(in) :: nc,ne
      REAL(rknd), DIMENSION(nc), INTENT(IN) :: cmul_in
      REAL(rknd), DIMENSION(ne), INTENT(IN) :: efield_in
      REAL(rknd), DIMENSION(nc,ne), INTENT(IN) :: D11_in
      REAL(rknd), DIMENSION(nc,ne), INTENT(IN) :: D13_in
      REAL(rknd), DIMENSION(nc,ne), INTENT(IN) :: D33_in
      INTEGER :: je, ic
      REAL(rknd) :: D33_Spitzer
      num_c = nc
      num_e = ne
      IF (ALLOCATED(cmul)) DEALLOCATE(cmul)
      IF (ALLOCATED(efield)) DEALLOCATE(efield)
      IF (ALLOCATED(D11_mat)) DEALLOCATE(D11_mat)
      IF (ALLOCATED(D13_mat)) DEALLOCATE(D13_mat)
      IF (ALLOCATED(D31_mat)) DEALLOCATE(D31_mat)
      IF (ALLOCATED(D33_mat)) DEALLOCATE(D33_mat)
      ALLOCATE(cmul(num_c))
      ALLOCATE(efield(num_e))
      ALLOCATE(D11_mat(num_c,num_e))
      ALLOCATE(D13_mat(num_c,num_e))
      ALLOCATE(D31_mat(num_c,num_e))
      ALLOCATE(D33_mat(num_c,num_e))
      cmul = cmul_in
      efield = efield_in
      D11_mat = D11_in
      D13_mat = D13_in
      D33_mat = D33_in
      ! Create D31 using Onsager symmetry
      D31_mat = -D13_mat
      IF (Add_Spitzer_to_D33) THEN
         DO je = 1, num_e
            DO ic = 1, num_c
               ! Calculate D33* Spitzer = (2/3)*<B**2>/cmul
               D33_Spitzer = (2._rknd/3._rknd)*Bsq/cmul(ic)
               ! Calculate D33*(Physical)=D33*(Spitzer)-D33*
               D33_mat(ic,je) = D33_Spitzer - D33_mat(ic,je)
            ENDDO
         ENDDO
      END IF
   END SUBROUTINE penta_set_DKES_star

   SUBROUTINE penta_set_beam(beam_force_in)
      Use pprof_pass, ONLY: beam_force
      IMPLICIT NONE
      REAL(rknd), INTENT(IN) :: beam_force_in
      beam_force = beam_force_in
      RETURN
   END SUBROUTINE penta_set_beam

   SUBROUTINE penta_set_U2(U2_in)
      USE coeff_var_pass, ONLY: D11_mat,cmul,num_c
      IMPLICIT NONE
      REAL(rknd), INTENT(IN), OPTIONAL :: U2_in
      U2=1.5d0*D11_mat(num_c,1)/cmul(num_c)
      IF (PRESENT(U2_in)) U2 = U2_in
      RETURN
   END SUBROUTINE penta_set_U2

   SUBROUTINE penta_fit_DXX_coef
      USE coeff_var_pass
      USE vmec_var_pass, ONLY: Bsq
      USE penta_subroutines, ONLY: fit_coeffs_faster
      USE penta_functions_mod, ONLY: work0, work1
      IMPLICIT NONE

      ! Calculate fitting parameters to the D##* coefficients
      Call fit_coeffs_faster(cmul,efield,num_c,num_e,D11_mat,log_interp, &
         kcord,keord,xt_c,xt_e,Dspl_D11,cmin,cmax,emin,emax)
      Call fit_coeffs_faster(cmul,efield,num_c,num_e,D13_mat,log_interp, &
         kcord,keord,xt_c,xt_e,Dspl_D13,cmin,cmax,emin,emax)
      Call fit_coeffs_faster(cmul,efield,num_c,num_e,D31_mat,log_interp, &
         kcord,keord,xt_c,xt_e,Dspl_D31,cmin,cmax,emin,emax)
      Call fit_coeffs_faster(cmul,efield,num_c,num_e,D33_mat,log_interp, &
         kcord,keord,xt_c,xt_e,Dspl_D33,cmin,cmax,emin,emax)

      ! Fit log(D*) for D11 and D33
      Call fit_coeffs_faster(cmul,efield,num_c,num_e,LOG(D11_mat),log_interp, &
         kcord,keord,xt_c,xt_e,Dspl_logD11,cmin,cmax,emin,emax)
      Call fit_coeffs_faster(cmul,efield,num_c,num_e,LOG(D33_mat),log_interp, &
         kcord,keord,xt_c,xt_e,Dspl_logD33,cmin,cmax,emin,emax)

      ! Fit radial transport coefficients specific to different methods
      SELECT CASE (Method)
         CASE ('SN')
            ! Calculate fits to D31*/D33*  (Drat)
            CALL fit_coeffs_faster(cmul,efield,num_c,num_e, &
               D31_mat/D33_mat, &
               log_interp,kcord,keord,xt_c,xt_e,Dspl_Drat,     &
               cmin,cmax,emin,emax)
            ! Calculate fits to (D31*)**2/D33*   (Drat2)
            CALL fit_coeffs_faster(cmul,efield,num_c,num_e, &
               D31_mat*D31_mat/D33_mat, &
               log_interp,kcord,keord,xt_c,xt_e,Dspl_Drat2,     &
               cmin,cmax,emin,emax)
            cmesh = Spread(cmul,2,num_e)
            ! Calculate coefficient for Ua term  (DUa)
            CALL fit_coeffs_faster(cmul,efield,num_c,num_e, &
               (2._rknd*Bsq/(3._rknd*D33_mat) - cmesh), &
               log_interp,kcord,keord,xt_c,xt_e,Dspl_DUa,     &
               cmin,cmax,emin,emax)
            ! Calculate coefficient for radial flux  (Capped term)  (Dex)
            ! Also, do not allow for negative coefficients
            CALL fit_coeffs_faster(cmul,efield,num_c,num_e, &
               Max(D11_mat-(2._rknd/3._rknd)*cmesh*U2+D31_mat*D31_mat/D33_mat, &
               0._rknd),log_interp,kcord,keord,xt_c,xt_e,Dspl_Dex,     &
               cmin,cmax,emin,emax)
        CASE DEFAULT 
          STOP 'Error: Can only use SN method!'
      ENDSELECT

      ! These are the work arrays used by db2val in intfun_fast
      IF( .NOT. ALLOCATED(work1)) ALLOCATE(work1(keord))
      IF( .NOT. ALLOCATED(work0)) ALLOCATE(work0(3_iknd*max(kcord,keord)))

      RETURN
   END SUBROUTINE penta_fit_DXX_coef

   SUBROUTINE penta_screen_info
      USE PENTA_subroutines, ONLY: lscreen_penta
      IMPLICIT NONE
      lscreen_penta = .FALSE.
      If ( i_append == 0 ) Then
         lscreen_penta = .TRUE.
         WRITE(6,'(A)') ""
         WRITE(6,'(A)') "Welcome to PENTA3, please note the following settings:"
         WRITE(6,'(A)')
         WRITE(6,'(A,I3)') ' Number of ion species: ',num_ion_species
         IF ( input_is_Er ) THEN
            WRITE(6,'(A)') 'Interpreting input range as Er (V/cm)'
         ELSE
            WRITE(6,'(A)') 'Interpreting input range as e<a>Er/kTe'
         ENDIF
         IF ( log_interp ) THEN
            WRITE(6,'(A)') 'Performing logarithmic interpolation in Er, cmul'
         ELSE
            WRITE(6,'(A)') 'Performing linear interpolation in Er,cmul'
         ENDIF
         IF ( use_quanc8 ) THEN
            WRITE(6,'(A,2(A,E10.4))')                           &
               ' Using quanc8 integrator with tolerances: ',     &
               'abs: ',epsabs,' rel: ', epsrel
         ELSE
            WRITE(6,'(A,i6,A)') ' Using ',numKsteps,            &
               ' point integral approximation'
         ENDIF
         WRITE(6,'(a,2(" ",e15.4))') ' K range on convolution integral: ', &
            Kmin, Kmax
         IF ( Add_Spitzer_to_D33) &
            WRITE(6,'(A)') 'Adding collisional (Spitzer) portion to D33 coefficient'
         IF ( flux_cap ) &
            WRITE(6,'(A)') 'Enforcing minimum radial diffusion coefficient = 0'
         WRITE(6,'(A,I2)') ' Number of terms in Sonine expansion: ', Smax+1
         SELECT CASE (Method)
            CASE ('T')
               WRITE(6,'(A)') 'Using Taguchi Method'
            CASE ('SN')
               WRITE(6,'(A)') 'Using Sugama-Nishimura Method'
            CASE ('MBT')
               WRITE(6,'(A)') 'Using Maassberg-Beidler-Turkin Method'
            CASE ('DKES')
               WRITE(6,'(A)') 'Using DKES Method'
            CASE DEFAULT
               Write(6,'(3A)') ' Error: ''', Trim(Adjustl(Method)), &
                  ''' is not a valid Method'
               STOP 'Error: Exiting, method select error in penta.f90 (1)'
         END SELECT  
         WRITE(6,'(A)') ""
         WRITE(6,'(A)') " <r>/<a>","   Er root(s) (V/cm)"
      ENDIF
      RETURN
   END SUBROUTINE penta_screen_info

   SUBROUTINE penta_open_output(file_ext)
      USE safe_open_mod
      USE io_unit_spec
      IMPLICIT NONE
      CHARACTER(LEN=*), INTENT(IN), OPTIONAL :: file_ext
      INTEGER :: istat
      CHARACTER(LEN=256) :: local_ext
      istat = 0
      fstatus = "unknown"
      fpos = "SEQUENTIAL"

      ! Create local extension
      IF (PRESENT(file_ext)) THEN
         local_ext = "."//TRIM(file_ext)
      ELSE
         local_ext = ''
      END IF

      IF(save_all_ambipolar_roots) THEN
         CALL safe_open(iu_flux_out, istat, "fluxes_vs_roa"//TRIM(local_ext), &
            Trim(Adjustl(fstatus)), 'formatted',&
            access_in=Trim(Adjustl(fpos)))
      END IF

      IF(save_fluxes_vs_Er) THEN
         CALL safe_open(iu_fvEr_out, istat, "fluxes_vs_Er"//TRIM(local_ext), &
            Trim(Adjustl(fstatus)), 'formatted',&
            access_in=Trim(Adjustl(fpos)))
      END IF

      RETURN
   END SUBROUTINE penta_open_output

   SUBROUTINE penta_lmat_matrix
      USE PENTA_subroutines, ONLY : define_friction_coeffs
      ! Define matrix of friction coefficients (lmat)
      Call define_friction_coeffs(masses,charges,vths,Temps,dens,loglambda, &
                            num_species,Smax,lmat)
      RETURN
   END SUBROUTINE penta_lmat_matrix

   SUBROUTINE penta_set_integration_arrays
      USE penta_functions_mod
      IMPLICIT NONE

      IF(.NOT. ALLOCATED(Ka_array)) ALLOCATE(Ka_array(numKsteps))
      IF(.NOT. ALLOCATED(exp_Ka_array)) ALLOCATE(exp_Ka_array(numKsteps))
      IF(.NOT. ALLOCATED(cmulK_matrix)) ALLOCATE(cmulK_matrix(num_species,numKsteps))
      IF(.NOT. ALLOCATED(log_cmulK_matrix)) ALLOCATE(log_cmulK_matrix(num_species,numKsteps))
      IF(.NOT. ALLOCATED(oneOverVa_matrix)) ALLOCATE(oneOverVa_matrix(num_species,numKsteps))
      IF(.NOT. ALLOCATED(sonine_poly)) ALLOCATE(sonine_poly(0:Smax,numKsteps))
      IF(.NOT. ALLOCATED(energy_weights_Drat_K15)) ALLOCATE(energy_weights_Drat_K15(num_species,numKsteps))
      IF(.NOT. ALLOCATED(energy_weights_Drat_K25)) ALLOCATE(energy_weights_Drat_K25(num_species,numKsteps))
      IF(.NOT. ALLOCATED(energy_weights_DUa_K15))  ALLOCATE(energy_weights_DUa_K15(num_species,numKsteps))
      IF(.NOT. ALLOCATED(energy_weights_Dex_K15))  ALLOCATE(energy_weights_Dex_K15(num_species,numKsteps))
      IF(.NOT. ALLOCATED(energy_weights_Dex_K25))  ALLOCATE(energy_weights_Dex_K25(num_species,numKsteps))
      IF(.NOT. ALLOCATED(energy_weights_Dex_K35))  ALLOCATE(energy_weights_Dex_K35(num_species,numKsteps))
      CALL calc_integration_arrays(num_species,Smax,Temps,dens,vths,charges,masses,loglambda,Kmin,Kmax,numKsteps, &
                  cmin,cmax,emin,emax,Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix,sonine_poly)

   END SUBROUTINE penta_set_integration_arrays

   SUBROUTINE penta_set_energy_weights
      USE penta_functions_mod, ONLY : compute_energy_weights
      USE coeff_var_pass, ONLY: num_c, num_e
      IMPLICIT NONE
      INTEGER(iknd) :: ispec
      DO ispec = 1, num_species
         energy_weights_Drat_K15(ispec,:) = compute_energy_weights(1.5_rknd,ispec,numKsteps,abs_Er, &
            num_species,log_interp,Dspl_Drat,xt_c,xt_e,cmin,cmax,emin,emax,num_c,num_e,kcord,keord, &
            Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix)
            !
         energy_weights_Drat_K25(ispec,:) = compute_energy_weights(2.5_rknd,ispec,numKsteps,abs_Er, &
            num_species,log_interp,Dspl_Drat,xt_c,xt_e,cmin,cmax,emin,emax,num_c,num_e,kcord,keord, &
            Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix)
            !
         energy_weights_DUa_K15(ispec,:)  = compute_energy_weights(1.5_rknd,ispec,numKsteps,abs_Er, &
            num_species,log_interp,Dspl_DUa,xt_c,xt_e,cmin,cmax,emin,emax,num_c,num_e,kcord,keord, &
            Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix)
            !
         energy_weights_Dex_K15(ispec,:)  = compute_energy_weights(1.5_rknd,ispec,numKsteps,abs_Er, &
            num_species,log_interp,Dspl_Dex,xt_c,xt_e,cmin,cmax,emin,emax,num_c,num_e,kcord,keord, &
            Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix)
            !
         energy_weights_Dex_K25(ispec,:)  = compute_energy_weights(2.5_rknd,ispec,numKsteps,abs_Er, &
            num_species,log_interp,Dspl_Dex,xt_c,xt_e,cmin,cmax,emin,emax,num_c,num_e,kcord,keord, &
            Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix)
            !
         energy_weights_Dex_K35(ispec,:)  = compute_energy_weights(3.5_rknd,ispec,numKsteps,abs_Er, &
            num_species,log_interp,Dspl_Dex,xt_c,xt_e,cmin,cmax,emin,emax,num_c,num_e,kcord,keord, &
            Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix)
      END DO
      RETURN
   END SUBROUTINE penta_set_energy_weights

   SUBROUTINE penta_run_2_efield
      USE vmec_var_pass
      USE pprof_pass
      USE phys_const
      USE io_unit_spec
      USE coeff_var_pass
      USE penta_math_routines_mod, ONLY: rlinspace
      USE penta_functions_mod
      USE PENTA_subroutines, ONLY: form_xvec
      IMPLICIT NONE
      LOGICAL :: is_open

      Call penta_allocate_fluxes_vs_Er

      ! Define array of Er values to test [V/m]
      Er_test_vals = rlinspace(Er_min,Er_max,num_Er_test)*100._rknd

      ! Check for Er=0, doesn't work for log interpolation
      min_Er = Minval(Dabs(Er_test_vals),DIM=1) 
      If ((log_interp .EQV. .true. ) .AND. ( Dabs(min_Er) <= elem_charge ))  Then
         min_ind = Minloc(Dabs(Er_test_vals),DIM=1)
         If ( min_ind == Num_Er_test ) Then 
            Er_test_vals(min_ind) = Er_test_vals(min_ind - 1)/2._rknd
         Else
            Er_test_vals(min_ind) = Er_test_vals(min_ind + 1)/2._rknd
         EndIf
         ! Write(*,'(a,i4,a,f10.3)') 'Cannot use Er=0 with log_interp, using Er(',  &
            ! min_ind, ') = ', Er_test_vals(min_ind)
      EndIf
      ! Loop over Er to get fluxes as a function of Er
      Do ie = 1,num_Er_test
         Er_test = Er_test_vals(ie)
         abs_Er = Abs(Er_test)

         ! Form thermodynamic force vector (Xvec)
         Call form_Xvec(Er_test,Z_ion,B_Eprl,num_ion_species,Xvec)

         ! Form alternate thermodynamic force vector (Avec)
         Do ispec1 = 1,num_species
            ind_X = (ispec1-1)*2 + 1
            ind_A = (ispec1-1)*3 + 1

            Avec(ind_A)   = -Xvec(ind_X) / (Temps(ispec1)*elem_charge) &
               - 2.5_rknd*dTdrs(ispec1)/Temps(ispec1)
            Avec(ind_A+1)   = -Xvec(ind_X+1) / (Temps(ispec1)*elem_charge)
            Avec(ind_A+2)   = Xvec(num_species*2+1)*charges(ispec1) &
               * B0/(Temps(ispec1)*elem_charge*Sqrt(Bsq)) + &
               beam_force/(Temps(ispec1)*elem_charge*dens(ispec1))
         Enddo

         ! Precompute energy weight arrays for this Er value
         CALL penta_set_energy_weights

         ! Select the appropriate algorithm and calculate the flows and fluxes
         SELECT CASE (Method)
            Case ('SN')                    
               ! Flows = calc_flows_SN_fast(num_species,Smax,abs_Er,Temps,dens,vths,charges,  &
               !    masses,loglambda,B0,use_quanc8,Kmin,Kmax,numKsteps,log_interp,       &
               !    cmin,cmax,emin,emax,xt_c,xt_e,Dspl_Drat,Dspl_DUa,num_c,num_e,kcord,  &
               !    keord,Avec,lmat,sigma_par,sigma_par_Spitzer,J_BS,L_A1,L_A2,L_A3, &
               !    Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix,sonine_poly)    
               Flows = calc_flows_SN_interface(num_species,Smax,numKsteps,Temps,dens,vths,charges,  &
                  masses,loglambda,B0,Avec,lmat,sigma_par,sigma_par_Spitzer,J_BS,L_A1,L_A2,L_A3, &
                  sonine_poly,energy_weights_Drat_K15,energy_weights_Drat_K25,energy_weights_DUa_K15)                                            
               ! Gammas = calc_fluxes_SN_fast(num_species,Smax,abs_Er,Temps,dens,vths,charges,&
               !   masses,loglambda,use_quanc8,Kmin,Kmax,numKsteps,log_interp,cmin,cmax, &
               !   emin,emax,xt_c,xt_e,Dspl_Drat,Dspl_Drat2,Dspl_Dex,Dspl_logD11,        &
               !   Dspl_D31,num_c,num_e,kcord,keord,Avec,Bsq,lmat,Flows,U2,dTdrs,        &
               !   dndrs,flux_cap,L_A1,L_A2,L_A3,L_n,L_T,L_Er, &
               !    Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix,sonine_poly)  
               Gammas = calc_fluxes_SN_interface(num_species,Smax,numKsteps,Temps,dens,vths,charges,  &
                  masses,loglambda,Bsq,lmat,Flows,U2,dTdrs,dndrs,flux_cap,Avec,L_A1,L_A2,L_A3,   &
                  L_n,L_T,L_Er,sonine_poly,energy_weights_Drat_K15,energy_weights_Dex_K15,energy_weights_Dex_K25)
               ! If ( output_QoT_vs_Er .EQV. .true. ) Then
               !    QoTs = calc_QoTs_SN(num_species,Smax,abs_Er,Temps,dens,vths,charges,  &
               !       masses,loglambda,use_quanc8,Kmin,Kmax,numKsteps,log_interp,cmin,    &
               !       cmax,emin,emax,xt_c,xt_e,Dspl_Drat,Dspl_Drat2,Dspl_Dex,Dspl_logD11, &
               !       Dspl_D31,num_c,num_e,kcord,keord,Avec,Bsq,lmat,Flows,U2,dTdrs,      &
               !       dndrs,flux_cap,L_A1,L_A2,L_A3,R_n,R_T,R_Er)  
               ! Endif    
            Case Default
               Stop 'Can only use SN method!'
         END SELECT

         Gamma_e_vs_Er(ie)   = Gammas(1)
         Gamma_i_vs_Er(ie,:) = Gammas(2:num_species)

         ! Write fluxes vs Er
         INQUIRE(unit=iu_fvEr_out, opened=is_open)
         IF(save_fluxes_vs_Er .AND. is_open) THEN
            Write(str_num,*) num_ion_species + 2  ! Convert num to string
            Write(iu_fvEr_out,'(f7.4,' // trim(adjustl(str_num)) // '(" ",e15.7))') &
               roa_surf,Er_test/100._rknd,Gamma_e_vs_Er(ie),Gamma_i_vs_Er(ie,:)
         END IF

      Enddo !efield loop
      RETURN
   END SUBROUTINE penta_run_2_efield

   SUBROUTINE penta_run_3_find_roots
      USE PENTA_subroutines, ONLY: find_Er_roots
      IMPLICIT NONE
      INTEGER :: flag_roots
      INTEGER(iknd) :: additional_roots
      ! Check for only one Er test value -- this is then used to evaluate the ambipolar fluxes QQ
      !If ( num_Er_test  == 1 ) Then
      !  Er_roots = Er_test_vals

      additional_roots = 100
      flag_roots = 100 ! value larger than zero to enter the while loop

      DO WHILE(flag_roots>0)

         ! Find the ambipolar root(s) from gamma_e = sum(Z*gamma_i)
         Call find_Er_roots(gamma_e_vs_Er,gamma_i_vs_Er,Er_test_vals,Z_ion, &
            num_Er_test,num_ion_species,Er_roots,num_roots,flag_roots)
         
         If( flag_roots==1 ) THEN
            ! case where Er_min, Er_max must change
            Er_min = Er_min - 50.0_rknd
            Er_max = Er_max + 50.0_rknd
            num_Er_test = num_Er_test + additional_roots
            IF ( i_append == 0 ) THEN
               WRITE(6,'(A,F7.2,A,F7.2,A,F7.2,A,F7.2,A)') '[Er_min,Er_max] changed from [', Er_min+50.0_rknd, ',', Er_max-50.0_rknd, &
                                 '] to [', Er_min, ',', Er_max, ']'
               WRITE(6,'(A,I4,A,I4)') 'num_Er_test increased from ', num_Er_test-additional_roots, ' to ', num_Er_test
               WRITE(6,'(A)') ' '
            END IF
            CALL PENTA_RUN_2_EFIELD
         Elseif( flag_roots==2 ) THEN
            ! case where numEr must increase
            num_Er_test = num_Er_test + additional_roots
            WRITE(6,'(A,I4,A,I4)') 'num_Er_test increased from ', num_Er_test-additional_roots, ' to ', num_Er_test
            CALL PENTA_RUN_2_EFIELD
         EndIf
      
      END DO

      ! Set Er_Vcm to the new values so that in the next call to penta_interface_mod these values will be used and not the ones
      ! defined in the namelist
      Er_min_Vcm = Er_min
      Er_max_Vcm = Er_max

      RETURN
   END SUBROUTINE penta_run_3_find_roots

   SUBROUTINE penta_run_4_ambipolar
      USE vmec_var_pass
      USE phys_const
      USE coeff_var_pass
      USE penta_functions_mod
      USE PENTA_subroutines, ONLY: form_xvec
      IMPLICIT NONE

      ! Allocate arrays according to number of ambipolar roots
      Allocate(Flows_ambi((Smax+1)*num_species,num_roots)) ! Parallel flow moments
      Allocate(Gammas_ambi(num_species,num_roots))         ! Rad. particle fluxes
      Allocate(QoTs_ambi(num_species,num_roots))           ! Rad. energy fluxes
      Allocate(Jprl_ambi(num_roots))                       ! Parallel current density
      Allocate(J_BS_ambi(num_roots))                       ! BS current density
      Allocate(sigma_par_ambi(num_roots))                  ! Parallel conductivity
      Allocate(sigma_par_Spitzer_ambi(num_roots))          ! Spitzer Parallel conductivity
      Allocate(Jprl_parts(num_species,num_roots))          ! Par. curr. dens. per spec.
      Allocate(upol(num_species,num_roots))                ! fsa contra pol flow
      Allocate(utor(num_species,num_roots))                ! fsa contra tor flow
      Allocate(L_n_ambi(num_roots,num_species,num_species))
      Allocate(L_T_ambi(num_roots,num_species,num_species))
      Allocate(L_Er_ambi(num_roots,num_species,num_species))
      Allocate(R_n_ambi(num_roots,num_species,num_species))
      Allocate(R_T_ambi(num_roots,num_species,num_species))
      Allocate(R_Er_ambi(num_roots,num_species,num_species))

      ! Evaluate fluxes and flows at the ambipolar Er
      Do iroot = 1_iknd, num_roots

         Er_test = Er_roots(iroot)
         abs_Er = Dabs(Er_test)

         ! Form thermodynamic force vector (Xvec)
         Call form_Xvec(Er_test,Z_ion,B_Eprl,num_ion_species,Xvec)

         ! Form alternate thermodynamic force vector (Avec)
         Do ispec1 = 1,num_species
            ind_X = (ispec1-1)*2 + 1
            ind_A = (ispec1-1)*3 + 1

            Avec(ind_A)   = -Xvec(ind_X) / (Temps(ispec1)*elem_charge) &
               - 2.5_rknd*dTdrs(ispec1)/Temps(ispec1)
            Avec(ind_A+1)   = -Xvec(ind_X+1) / (Temps(ispec1)*elem_charge)
            Avec(ind_A+2)   = Xvec(num_species*2+1)*charges(ispec1) &
               * B0/(Temps(ispec1)*elem_charge*Sqrt(Bsq))
         Enddo

         ! Precompute energy weight arrays for this Er value
         CALL penta_set_energy_weights

         ! Select the appropriate algorithm and calculate the flows and fluxes
         SELECT CASE (Method)
            Case ('SN')
               ! Calculate array of parallel flow moments 
               ! Flows_ambi(:,iroot) = calc_flows_SN_fast(num_species,Smax,abs_Er,Temps,dens,&
               !    vths,charges,masses,loglambda,B0,use_quanc8,Kmin,Kmax,numKsteps,    &
               !    log_interp,cmin,cmax,emin,emax,xt_c,xt_e,Dspl_Drat,Dspl_DUa,num_c,  &
               !    num_e,kcord,keord,Avec,lmat,sigma_par,sigma_par_Spitzer,J_BS,L_A1,L_A2,L_A3, &
               !    Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix,sonine_poly)     
               Flows_ambi(:,iroot) = calc_flows_SN_interface(num_species,Smax,numKsteps,Temps,dens,  &
                  vths,charges,masses,loglambda,B0,Avec,lmat,sigma_par,sigma_par_Spitzer,J_BS,   &
                  L_A1,L_A2,L_A3,sonine_poly,energy_weights_Drat_K15,energy_weights_Drat_K25,    &
                  energy_weights_DUa_K15)                                          
               ! Calculate array of radial particle fluxes
               ! Gammas_ambi(:,iroot) = calc_fluxes_SN_fast(num_species,Smax,abs_Er,Temps,   &
               !   dens,vths,charges,masses,loglambda,use_quanc8,Kmin,Kmax,numKsteps,   &
               !   log_interp,cmin,cmax,emin,emax,xt_c,xt_e,Dspl_Drat,Dspl_Drat2,       &
               !   Dspl_Dex,Dspl_logD11,Dspl_D31,num_c,num_e,kcord,keord,Avec,Bsq,      &
               !   lmat,Flows_ambi(:,iroot),U2,dTdrs,dndrs,flux_cap,L_A1,L_A2,L_A3,     &
               !   L_n,L_T,L_Er, &
               !   Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix,sonine_poly) 
               Gammas_ambi(:,iroot) = calc_fluxes_SN_interface(num_species,Smax,numKsteps,Temps,dens,&
                  vths,charges,masses,loglambda,Bsq,lmat,Flows_ambi(:,iroot),U2,dTdrs,dndrs,     &
                  flux_cap,Avec,L_A1,L_A2,L_A3,L_n,L_T,L_Er,sonine_poly,                         &
                  energy_weights_Drat_K15,energy_weights_Dex_K15,energy_weights_Dex_K25)
               ! Calculate array of radial energy fluxes
               ! QoTs_ambi(:,iroot) = calc_QoTs_SN_fast(num_species,Smax,abs_Er,Temps,dens,  &
               !   vths,charges,masses,loglambda,use_quanc8,Kmin,Kmax,numKsteps,        &
               !   log_interp,cmin,cmax,emin,emax,xt_c,xt_e,Dspl_Drat,Dspl_Drat2,       &
               !   Dspl_Dex,Dspl_logD11,Dspl_D31,num_c,num_e,kcord,keord,Avec,Bsq,      &
               !   lmat,Flows_ambi(:,iroot),U2,dTdrs,dndrs,flux_cap,L_A1,L_A2,L_A3,     &
               !   R_n,R_T,R_Er, &
               !   Ka_array,exp_Ka_array,cmulK_matrix,log_cmulK_matrix,oneOverVa_matrix,sonine_poly)
               QoTs_ambi(:,iroot) = calc_QoTs_SN_interface(num_species,Smax,numKsteps,Temps,dens,    &
                  vths,charges,masses,loglambda,Bsq,lmat,Flows_ambi(:,iroot),U2,dTdrs,dndrs,     &
                  flux_cap,Avec,L_A1,L_A2,L_A3,R_n,R_T,R_Er,sonine_poly,                         &
                  energy_weights_Drat_K25,energy_weights_Dex_K25,energy_weights_Dex_K35)

               sigma_par_ambi(iroot) = sigma_par
               sigma_par_Spitzer_ambi(iroot) = sigma_par_Spitzer
               J_BS_ambi(iroot) = J_BS
               !
               L_n_ambi(iroot,:,:) = L_n
               L_T_ambi(iroot,:,:) = L_T
               L_Er_ambi(iroot,:,:) = L_Er
               !
               R_n_ambi(iroot,:,:) = R_n
               R_T_ambi(iroot,:,:) = R_T
               R_Er_ambi(iroot,:,:) = R_Er
            Case Default
               Stop 'Can only use SN method!'
         ENDSELECT

         ! Calculate parallel current density
         Jprl_parts(:,iroot) = dens*charges*Sqrt(Bsq) *         &
            Flows_ambi(1:(num_species-1)*(Smax+1)+1:Smax+1,iroot)
         Jprl_ambi(iroot) = Sum(Jprl_parts(:,iroot))

         ! Calculate flow components
         upol(:,iroot) = chip*(4._rknd*pi*pi/vol_p)*(                 &
            Flows_ambi(1:(num_species-1)*(Smax+1)+1:Smax+1,iroot) - &
            bzeta*Xvec(1:(num_species-1)*2+1:2)/(charges*chip*Bsq))
         utor(:,iroot) = psip*(4._rknd*pi*pi/vol_p)*(                 &
            Flows_ambi(1:(num_species-1)*(Smax+1)+1:Smax+1,iroot) + &
            btheta*Xvec(1:(num_species-1)*2+1:2)/(charges*psip*Bsq))

      END DO ! Ambipolar root loop
      RETURN
   END SUBROUTINE penta_run_4_ambipolar

   SUBROUTINE penta_run_5_cleanup(lscreen)
      USE io_unit_spec
      USE pprof_pass
      USE vmec_var_pass
      IMPLICIT NONE
      LOGICAL :: is_open
      LOGICAL, INTENT(IN) :: lscreen
      ! First write output files
      ! Loop over ambipolar Er for writing output files
      INQUIRE(unit=iu_flux_out, opened=is_open)
      IF(save_all_ambipolar_roots .AND. is_open) THEN
         Do iroot = 1_iknd, num_roots
            Er_test = Er_roots(iroot)
            eaEr_o_kTe = arad*Er_test/Te
            ! Write fluxes to file "fluxes_vs_roa"
            Write(str_num,*) 2*num_species + 3
            Write(iu_flux_out,'(f7.3,' // Trim(Adjustl(str_num)) // '(" ",e15.7),' // 'i4)') &
            roa_surf,Er_test/100._rknd,J_BS_ambi(iroot),Gammas_ambi(1,iroot),  &
            QoTs_ambi(1,iroot),Gammas_ambi(2:num_species,iroot),  &
            QoTs_ambi(2:num_species,iroot), 1.0_rknd/sigma_par_ambi(iroot), &
            merge(1_iknd,0_iknd, root_type(iroot))
         EndDo ! Ambipolar root loop
      END IF

      ! Write screen output
      IF (lscreen) THEN
         write(str_num,*) num_roots
         write(*,'(f7.3,' // trim(adjustl(str_num)) // '(" ",e15.4))') & 
         roa_surf,er_roots(1:num_roots)/100._rknd
      END IF

      ! DEALLOCATE
      CALL penta_deallocate_species
      CALL penta_deallocate_dkescoeff

      ! Close output files
      Close(iu_flux_out)
      Close(iu_fvEr_out)
   END SUBROUTINE penta_run_5_cleanup

   SUBROUTINE penta_merge_ambipolar_files(ns_dkes,proc_string,mytime)

      USE safe_open_mod

      IMPLICIT NONE
      INTEGER :: ierr, iunit_merged, iunit_read, k
      INTEGER, INTENT(IN) :: ns_dkes
      REAL(rknd), INTENT(IN) :: mytime
      CHARACTER(LEN=32), INTENT(IN) :: proc_string
      CHARACTER(LEN=32) :: temp_str
      CHARACTER(LEN=256) :: input_filename, output_filename, line
      iunit_merged = 25
      iunit_read = 35

      output_filename = 'ambipolar_roots.' // TRIM(proc_string)

      !open merged file
      CALL safe_open(iunit_merged, ierr, output_filename, "replace", 'formatted')
      if (ierr /= 0) then
         print *, "Error opening output file ambipolar_roots_fluxes"
         stop
      end if

      !write header of merged file
      Write(iunit_merged,'("*",/,"t [s]")')
      Write(iunit_merged,'(f11.3)') mytime
      Write(iunit_merged,'("r/a    Er[V/cm]    J_BS [Am**-2]    ",  &
            "Gamma_e [m**-2s**-1]   Q_e/T_e [m**-2s**-1]     ",         &
            "Gamma_i [m**-2s**-1]   Q_i/T_i [m**-2s**-1]   etapar [Ohm.m]   root_type")')

      !Loop through files
      Do k=1,ns_dkes

         WRITE(temp_str,'(i4.4)') k
         input_filename = "fluxes_vs_roa." // TRIM(proc_string) // '_k' // TRIM(temp_str)

        ! Open the input file for reading
        CALL safe_open(iunit_read, ierr, input_filename, 'old', 'formatted')
        if (ierr /= 0) then
            print *, "ERROR opening input file:", input_filename
            cycle
        end if
      
         ! Read all lines from the input file and append to the output file
         do
            read(iunit_read, "(A)", iostat=ierr) line
            if (ierr /= 0) exit  ! Exit loop on end-of-file or error
            write(iunit_merged, "(A)") trim(line)
         end do

         ! close and delete k files
         close(iunit_read, status='delete', iostat=ierr)
         if (ierr /= 0) STOP 'Error closing/deleting k file'

      End Do

      close(iunit_merged)


   END SUBROUTINE penta_merge_ambipolar_files

   SUBROUTINE penta_merge_fluxes_vs_Er_files(ns_dkes,proc_string,mytime)

      USE safe_open_mod

      IMPLICIT NONE
      INTEGER :: ierr, iunit_merged, iunit_read, k
      INTEGER, INTENT(IN) :: ns_dkes
      REAL(rknd), INTENT(IN) :: mytime
      CHARACTER(LEN=32), INTENT(IN) :: proc_string
      CHARACTER(LEN=32) :: temp_str
      CHARACTER(LEN=256) :: input_filename, output_filename, line
      iunit_merged = 25
      iunit_read = 35

      output_filename = 'fluxes_vs_Er.' // TRIM(proc_string)

      !open merged file
      CALL safe_open(iunit_merged, ierr, output_filename, "replace", 'formatted')
      if (ierr /= 0) then
         print *, "Error opening output file fluxes_vs_Er"
         stop
      end if

      !write header of merged file
      Write(iunit_merged,'("*",/,"t [s]")')
      Write(iunit_merged,'(f11.3)') mytime
      Write(iunit_merged,'("*",/,"r/a   Er[V/cm]   Gamma_e [m**-2s**-1] ",&
             "   Gamma_i [m**-2s**-1]")')

      !Loop through files
      Do k=1,ns_dkes

         WRITE(temp_str,'(i4.4)') k
         input_filename = "fluxes_vs_Er." // TRIM(proc_string) // '_k' // TRIM(temp_str)

         ! Open the input file for reading
         CALL safe_open(iunit_read, ierr, input_filename, 'old', 'formatted')
         if (ierr /= 0) then
            print *, "ERROR opening input file:", input_filename
            cycle
         end if
      
         ! Read all lines from the input file and append to the output file
         do
            read(iunit_read, "(A)", iostat=ierr) line
            if (ierr /= 0) exit  ! Exit loop on end-of-file or error
            write(iunit_merged, "(A)") trim(line)
         end do

         ! close and delete k files
         close(iunit_read, status='delete', iostat=ierr)
         if (ierr /= 0) STOP 'Error closing/deleting k file'

      End Do

      close(iunit_merged)

   END SUBROUTINE penta_merge_fluxes_vs_Er_files

   SUBROUTINE root_analysis(which_root)
      ! The array root_type indicates if the ambipolar root is set or not with .TRUE. or .FALSE.

      IMPLICIT NONE

      CHARACTER(len=*), INTENT(IN) :: which_root
      INTEGER(iknd) :: i, j, idx_ion_root, idx_electron_root, one, zero, idx_closest_to_zero, selected_idx
      REAL(rknd), DIMENSION(num_Er_test) :: Jr
      REAL(rknd) :: temp_sum, electron_root, ion_root, integral, Er_closest_to_zero, best_neg
      LOGICAL :: cond_A, cond_B

      IF( mod(num_roots,2) == 0) THEN
         STOP 'ERROR: an even number of roots was found. This is non-physical...'
      END IF

      IF(ALLOCATED(root_type)) DEALLOCATE(root_type)
      ALLOCATE(root_type(num_roots))

      root_type = .FALSE.

      IF( num_roots ==1 ) THEN
         root_type(1) = .TRUE.
      ELSE IF(num_roots==3) THEN
         
         !Er_roots are ordered
         IF(trim(adjustl(which_root)) == 'ion_root') THEN
            root_type(1) = .TRUE. 
         ELSE IF(trim(adjustl(which_root)) == 'electron_root') THEN
            root_type(3) = .TRUE.
         ELSE
            STOP 'Only ion_root and electron_root are possible which_root'
         END IF
         
      ELSE IF(num_roots==5) THEN
         ! There are 2 possibilities:
         ! possibility_1 = ['extra_stable_root','unstable_root2','ion_root','unstable_root','electron_root']
         ! possibility_2 = ['ion_root','unstable_root','electron_root','unstable_root2','extra_stabe_root']
         !
         ! Use criterium: ion_root is the negative root closest to Er=0
         idx_closest_to_zero = MINLOC( ABS(Er_roots), 1 ) 
         Er_closest_to_zero = Er_roots(idx_closest_to_zero)

         cond_A = Er_closest_to_zero > 0
         cond_B = idx_closest_to_zero >= 3 !2
                
         IF( (cond_A .AND. cond_B) .OR. (.NOT. cond_A  .AND. cond_B) ) THEN
            root_type(3) = .TRUE. !possibility_1
         ELSE
            root_type(1) = .TRUE. !possibility_2
         END IF

      ELSE IF(num_roots>5) THEN
         ! Use criterium: 
         ! The ion_root can only be root idx 1,3,5,...,num_roots-2
         ! Out of these entries, we pick the one where Er<0 and that is closest to Er=0; 
         ! if out of the candidates there are no negative Er, then pick the positive one closest to Er=0.

         selected_idx = -1
         best_neg = -huge(1.0_rknd)

         ! Loop over allowed indices: 1,3,5,...,num_roots-2
         ! Note that Er_roots is already sorted
         DO i = 1, num_roots-2, 2
            IF (Er_roots(i) < 0.0) THEN
               ! Keep the negative closest to zero
               IF (Er_roots(i) > best_neg) THEN
                  best_neg = Er_roots(i)
                  selected_idx = i
               END IF
            END IF
         END DO
         
         ! If no idx was selected is because all possible ion roots are positive... then choose smallest positive
         IF (selected_idx < 0) THEN
            selected_idx = 1
         END IF

         root_type(selected_idx) = .TRUE.


         ! ! DEPRECATED: Maxwell construction criterium
         ! electron_root = MAXVAL(Er_roots(1:num_roots),1)
         ! ion_root = MINVAL(Er_roots(1:num_roots),1)
         ! ! Find the index in Er_test_vals closest to electron_root and ion_root
         ! idx_electron_root = MINLOC( ABS(Er_test_vals-electron_root), 1 )
         ! idx_ion_root = MINLOC( ABS(Er_test_vals-ion_root), 1 )
         ! ! Compute integrals
         ! integral = SUM( Jr(idx_ion_root:idx_electron_root)*(Er_test_vals(2)-Er_test_vals(1)) )
         ! ! Set root type
         ! IF(integral>0) THEN
         !    root_type(1) = .TRUE.
         ! ELSE
         !    root_type(5) = .TRUE.
         ! ENDIF

      ELSE
         STOP 'ERROR: number of roots different than 1,3,5,7,etc how is it possible??'
      END IF



   END SUBROUTINE root_analysis

   SUBROUTINE interpolate_from_penta(nrho_penta,rho_penta,y_penta,nrho_out,rho_out,y_out,isHermite,useLog,preventNeg)
      ! This subroutine is an aider to thrift_penta, where a bunch of splines are done from the penta grid onto
      ! the thrift and plasma solver grids
      ! ASSUMES: that rho_penta does not have rho=0 nor rho=1, and so a linear extrapolation is done
      ! useLog is useful to intepolate non-negative quantities that span several orders of magnitude
      ! if preventNeg is .true. then all negative values are clamped to 0.0
      USE EZspline
      USE EZspline_obj
      IMPLICIT NONE

      INTEGER(iknd), INTENT(IN) :: nrho_penta, nrho_out
      REAL(rknd), DIMENSION(nrho_penta), INTENT(IN) :: rho_penta,y_penta
      REAL(rknd), DIMENSION(nrho_out), INTENT(IN) :: rho_out
      REAL(rknd), DIMENSION(nrho_out), INTENT(OUT) :: y_out
      INTEGER, INTENT(IN) :: isHermite
      LOGICAL, INTENT(IN) :: useLog
      LOGICAL, INTENT(IN), OPTIONAL :: preventNeg
      !
      INTEGER :: ier
      INTEGER :: bcs0(2)
      REAL(rknd), ALLOCATABLE :: rho_temp(:),y_temp(:)
      TYPE(EZspline1_r8) :: y_spl

      ALLOCATE(rho_temp(nrho_penta+2),y_temp(nrho_penta+2))

      ! Assumes that tho_penta does not have rho=0 and rho=1 points
      rho_temp(1)        = 0.0
      rho_temp(2:nrho_penta+1) = rho_penta
      rho_temp(nrho_penta+2)   = 1.0
      !
      y_temp(2:nrho_penta+1)   = y_penta
      y_temp(1)                = y_temp(2) - (y_temp(3)-y_temp(2)) * rho_temp(2) / (rho_temp(3)-rho_temp(2))
      y_temp(nrho_penta+2)     = y_penta(nrho_penta-1) + (y_penta(nrho_penta)-y_penta(nrho_penta-1)) * (1-rho_penta(nrho_penta-1)) / (rho_penta(nrho_penta)-rho_penta(nrho_penta-1))

      ! Spline
      bcs0=(/ 0, 0/)
      CALL EZspline_init(y_spl,nrho_penta+2,bcs0,ier)
      y_spl%x1        = rho_temp
      y_spl%isHermite = isHermite

      IF(useLog) THEN
         ! Make sure there are no negative values getting into the log!
         WHERE (y_temp .LE. 0.0_rknd) y_temp = 1.0E-20_rknd
         !
         CALL EZspline_setup(y_spl,LOG(y_temp),ier,EXACT_DIM=.true.)
         CALL EZspline_interp(y_spl,nrho_out,rho_out,y_out,ier)
         y_out = EXP(y_out)
      ELSE
         CALL EZspline_setup(y_spl,y_temp,ier,EXACT_DIM=.true.)
         CALL EZspline_interp(y_spl,nrho_out,rho_out,y_out,ier)
      END IF

      CALL EZspline_free(y_spl,ier)

      DEALLOCATE(rho_temp,y_temp)

      IF(PRESENT(preventNeg)) THEN
         IF(preventNeg) THEN
            WHERE (y_out .LE. 0.0_rknd) y_out = 1.0E-20_rknd
         END IF
      END IF

   END SUBROUTINE interpolate_from_penta

   Subroutine call_PENTA_surface( &
     nion_prof,ncstar,nestar, &
     Matom_prof, Zatom_prof, &
     ne,dnedrho,te,dtedrho,ni,dnidrho,ti,dtidrho, &
     eq_Aminor, eq_Rmajor, vp, chip, phip, iota, btheta, bzeta, bsq, &
     DKES_K_surf, rho_k_surf, &
     DKES_NUSTAR, DKES_ERSTAR, DKES_D11_surf, DKES_D31_surf, DKES_D33_surf, &
     Er_min_Vcm_in, Er_max_Vcm_in, EparB_surf, Er_k_surf, Er_root_type_in, look_for_ambipolar, &
     JBS_surf, Er_surf, Dn_surf, cn_surf, Dp_surf, cp_surf &
     )
      ! Computes the ambipolar root and neoclassical transport coefficients on a
      ! SINGLE DKES surface -- i.e. the body of call_PENTA's "DO k = 1,ns_dkes"
      ! loop, duplicated here as a standalone entry point. This lets independent
      ! surfaces be evaluated by independent OS processes (e.g. from Python's
      ! multiprocessing/concurrent.futures), since PENTA's module-level (SAVE)
      ! state is NOT safe to share across concurrent calls in the same process.
      ! Note: this does NOT include the final interpolation onto output_rho
      ! (see interpolate_from_PENTA), which needs every surface gathered first
      ! and should be done once, serially, by the caller.

      USE phys_const, ONLY: p_mass, elem_charge

      Implicit None

      Integer, Intent(in) :: nion_prof,ncstar,nestar
      Real(rknd), Dimension(nion_prof), Intent(in) :: Matom_prof
      Integer, Dimension(nion_prof), Intent(in) :: Zatom_prof
      Real(rknd), Intent(in) :: ne, dnedrho, te, dtedrho
      Real(rknd), Dimension(nion_prof), Intent(in) :: ni, dnidrho, ti, dtidrho
      Real(rknd), Intent(in) :: eq_Aminor, eq_Rmajor
      Real(rknd), Intent(in) :: vp, chip, phip, iota, btheta, bzeta, bsq
      Integer, Intent(in) :: DKES_K_surf
      Real(rknd), Intent(in) :: rho_k_surf
      Real(rknd), Dimension(ncstar), Intent(in) :: DKES_NUSTAR
      Real(rknd), Dimension(nestar), Intent(in) :: DKES_ERSTAR
      Real(rknd), Dimension(ncstar,nestar), Intent(in) ::  DKES_D11_surf, DKES_D31_surf, DKES_D33_surf
      Real(rknd), Intent(in) :: Er_min_Vcm_in, Er_max_Vcm_in
      Real(rknd), Intent(in) :: Er_k_surf, EparB_surf
      Character(Len=100) :: Er_root_type_in
      Logical, Intent(in) :: look_for_ambipolar
      Real(rknd), Intent(out) :: JBS_surf, Er_surf
      Real(rknd), Dimension(nion_prof+1), Intent(out) :: Dn_surf, cn_surf, Dp_surf, cp_surf

      ! Locals
      Integer :: i, j

      ! Set run_params defaults (input_is_Er, log_interp, flux_cap, Add_Spitzer_to_D33, ...).
      ! These are never read from a namelist on this call path, so without this call they
      ! would keep whatever value the uninitialized module variables happen to have.
      CALL init_penta_input

      ! PENTA
      CALL PENTA_SET_ION_PARAMS(nion_prof, DBLE(Zatom_prof), Matom_prof/p_mass)
      CALL PENTA_SET_COMMANDLINE(Er_min_Vcm_in,Er_max_Vcm_in,DKES_K_surf,1,EparB_surf,1,'','','')
      CALL PENTA_ALLOCATE_SPECIES
      CALL PENTA_SET_EQ_DATA(rho_k_surf,eq_Aminor,eq_Rmajor,vp,chip,phip,iota,btheta,bzeta,bsq)
      CALL PENTA_SET_PPROF(ne,dnedrho/eq_Aminor,te,dtedrho/eq_Aminor,ni,dnidrho/eq_Aminor,ti,dtidrho/eq_Aminor)
      ! MAKE CORRECTIONS ON D31 AND D33 -- values coming from DKES2 miss Bsq factors (see J. Lore documentation)
      CALL PENTA_SET_DKES_STAR(ncstar,nestar,DKES_NUSTAR(1:ncstar),DKES_ERSTAR(1:nestar), &
            DKES_D11_surf, DKES_D31_surf*SQRT(bsq), DKES_D33_surf*bsq)
      CALL PENTA_SET_BEAM(0.0_rknd) ! Zero becasue we don't read
      CALL PENTA_SET_U2() ! Leave blank for default value
      CALL PENTA_READ_INPUT_FILES(.FALSE.,.FALSE.,.FALSE.,.FALSE.,.FALSE.)
      ! CALL PENTA_SCREEN_INFO
      CALL PENTA_ALLOCATE_DKESCOEFF
      CALL PENTA_FIT_DXX_COEF
      CALL PENTA_LMAT_MATRIX
      CALL PENTA_SET_INTEGRATION_ARRAYS

      ! Only search new ambipolar Er solution if look_for_ambipolar = true
      IF(.NOT. look_for_ambipolar) THEN
            ! Need to define num_roots and set Er_roots
            num_roots = 1
            Er_roots(1) = Er_k_surf
      ELSE
            ! Now the basic steps
            CALL PENTA_RUN_2_EFIELD
            CALL PENTA_RUN_3_FIND_ROOTS
      END IF

      CALL PENTA_RUN_4_AMBIPOLAR

      ! The call to ROOT_ANALYSIS sets the array 'root_type' which decides which root to pick
      ! The criterium is to pick the 'ion_root'
      CALL ROOT_ANALYSIS(TRIM(Er_root_type_in))

      ! Using root_type, pick the ambipolar root that will be saved by THRIFT
      DO i=1,num_roots
        IF(root_type(i)) THEN
          JBS_surf = J_BS_ambi(i)
          Er_surf = Er_roots(i)
          ! NEO particle transport coefficients
          Dn_surf = (/ (-L_n_ambi(i,j,j), j=1,nion_prof+1) /)
          cn_surf = MATMUL(L_T_ambi(i,:,:),elem_charge*dTdrs) / dens + Er_surf*SUM(L_Er_ambi(i,:,:),dim=2) / dens
          ! NEO heat transport coefficients
          Dp_surf = (/ (-R_T_ambi(i,j,j), j=1,nion_prof+1) /) * elem_charge*Temps / dens
          cp_surf = MATMUL(R_n_ambi(i,:,:),dndrs)/dens - MATMUL(R_T_ambi(i,:,:),(elem_charge*Temps/dens)*dndrs)/dens &
                            + Er_surf*SUM(R_Er_ambi(i,:,:),dim=2) / dens
          EXIT
        ENDIF
      END DO

      CALL PENTA_RUN_5_CLEANUP(.FALSE.)

   End Subroutine call_PENTA_surface

   Subroutine call_PENTA_interpolate( &
     ns_dkes,nion_prof,output_nrho, &
     rho_k, Er_PENTA, Dn_PENTA, cn_PENTA, Dp_PENTA, cp_PENTA, &
     output_rho, &
     output_Er, output_Dn, output_cn, output_Dp, output_cp &
     )
      ! Interpolates the per-surface ambipolar root and neoclassical transport
      ! coefficients (as computed by call_PENTA_surface, one call per DKES
      ! surface, then gathered by the caller into arrays indexed by k) from the
      ! DKES radial grid (rho_k) onto output_rho. This mirrors exactly the
      ! interpolation block at the end of call_PENTA, duplicated here as a
      ! standalone entry point. It is a cheap operation (a handful of 1D
      ! splines) meant to run once, serially, after all surfaces have been
      ! gathered -- it is NOT a candidate for parallelization.
      Implicit None

      Integer, Intent(in) :: ns_dkes,nion_prof,output_nrho
      Real(rknd), Dimension(ns_dkes), Intent(in) :: rho_k, Er_PENTA
      Real(rknd), Dimension(nion_prof+1,ns_dkes), Intent(in) :: Dn_PENTA, cn_PENTA, Dp_PENTA, cp_PENTA
      Real(rknd), Dimension(output_nrho), Intent(in) :: output_rho
      Real(rknd), Dimension(output_nrho), Intent(out) :: output_Er
      Real(rknd), Dimension(nion_prof+1,output_nrho), Intent(out) :: output_Dn, output_cn, output_Dp, output_cp

      ! Locals
      Integer :: jspecies

      CALL interpolate_from_PENTA(nrho_penta=ns_dkes, rho_penta=rho_k, y_penta=Er_PENTA,\
                              nrho_out=output_nrho, rho_out=output_rho, y_out=output_Er,\
                              isHermite=1, useLog=.FALSE.)
      !
      DO jspecies=1,(nion_prof+1)
         CALL interpolate_from_PENTA(nrho_penta=ns_dkes, rho_penta=rho_k, y_penta=Dn_PENTA(jspecies,:),\
                     nrho_out=output_nrho, rho_out=output_rho, y_out=output_Dn(jspecies,:),\
                     isHermite=1, useLog=.FALSE.)
         !
         CALL interpolate_from_PENTA(nrho_penta=ns_dkes, rho_penta=rho_k, y_penta=cn_PENTA(jspecies,:),\
                           nrho_out=output_nrho, rho_out=output_rho, y_out=output_cn(jspecies,:),\
                           isHermite=1, useLog=.FALSE.)
         !
         CALL interpolate_from_PENTA(nrho_penta=ns_dkes, rho_penta=rho_k, y_penta=Dp_PENTA(jspecies,:),\
                           nrho_out=output_nrho, rho_out=output_rho, y_out=output_Dp(jspecies,:),\
                           isHermite=1, useLog=.FALSE., preventNeg = .TRUE.)
         !
         CALL interpolate_from_PENTA(nrho_penta=ns_dkes, rho_penta=rho_k, y_penta=cp_PENTA(jspecies,:),\
                           nrho_out=output_nrho, rho_out=output_rho, y_out=output_cp(jspecies,:),\
                           isHermite=1, useLog=.FALSE.)
      END DO

   End Subroutine call_PENTA_interpolate

   Subroutine call_PENTA( &
     ns_dkes,ncstar,nestar,nion_prof,output_nrho, &
     Matom_prof, Zatom_prof, &
     ne,dnedrho,te,dtedrho,ni,dnidrho,ti,dtidrho, &
     eq_Aminor, eq_Rmajor, vp, chip, phip, iota, btheta, bzeta, bsq, &
     DKES_K, rho_k, &
     DKES_NUSTAR, DKES_ERSTAR, DKES_D11, DKES_D31, DKES_D33, &
     Er_min_Vcm_in, Er_max_Vcm_in, EparB, Er_k, Er_root_type_in, look_for_ambipolar, &
     output_rho, &
     output_Er, output_Dn, output_cn, output_Dp, output_cp &
     )

      USE phys_const, ONLY: p_mass, elem_charge

      Implicit None

      Integer, Intent(in) :: ns_dkes,ncstar,nestar,nion_prof,output_nrho
      Real(rknd), Dimension(nion_prof), Intent(in) :: Matom_prof
      Integer, Dimension(nion_prof), Intent(in) :: Zatom_prof
      Real(rknd), Dimension(ns_dkes), Intent(in) :: ne, dnedrho, te, dtedrho
      Real(rknd), Dimension(ns_dkes,nion_prof), Intent(in) :: ni, dnidrho, ti, dtidrho
      Real(rknd), Intent(in) :: eq_Aminor, eq_Rmajor
      Real(rknd), Dimension(ns_dkes), Intent(in) :: vp, chip, phip, iota, btheta, bzeta, bsq
      Integer, Dimension(ns_dkes), Intent(in) :: DKES_K
      Real(rknd), Dimension(ns_dkes), Intent(in) :: rho_k
      Real(rknd), Dimension(ncstar), Intent(in) :: DKES_NUSTAR
      Real(rknd), Dimension(nestar), Intent(in) :: DKES_ERSTAR
      Real(rknd), Dimension(ns_dkes,ncstar,nestar), Intent(in) ::  DKES_D11, DKES_D31, DKES_D33
      Real(rknd), Intent(in) :: Er_min_Vcm_in, Er_max_Vcm_in
      Real(rknd), Dimension(ns_dkes), Intent(in) :: Er_k, EparB
      Character(Len=100) :: Er_root_type_in
      Logical, Intent(in) :: look_for_ambipolar
      Real(rknd), Dimension(output_nrho), Intent(in) :: output_rho
      Real(rknd), Dimension(output_nrho), Intent(out) :: output_Er
      Real(rknd), Dimension(nion_prof+1,output_nrho), Intent(out) :: output_Dn, output_cn, output_Dp, output_cp

      ! Locals
      Integer :: k, i, j, jspecies
      REAL(rknd), DIMENSION(:), ALLOCATABLE :: JBS_PENTA, etapar_PENTA, Er_PENTA
      REAL(rknd), DIMENSION(:,:), ALLOCATABLE :: GNEO_PENTA, QNEO_PENTA, GNEO_temp, QNEO_temp
      REAL(rknd), DIMENSION(:,:), ALLOCATABLE :: Dn_PENTA, cn_PENTA, Dn_temp, cn_temp
      REAL(rknd), DIMENSION(:,:), ALLOCATABLE :: Dp_PENTA, cp_PENTA, Dp_temp, cp_temp

      ALLOCATE(JBS_PENTA(ns_dkes),Er_PENTA(ns_dkes))
      ALLOCATE(Dn_PENTA(nion_prof+1,ns_dkes),cn_PENTA(nion_prof+1,ns_dkes))
      ALLOCATE(Dp_PENTA(nion_prof+1,ns_dkes),cp_PENTA(nion_prof+1,ns_dkes))

      ! Set run_params defaults (input_is_Er, log_interp, flux_cap, Add_Spitzer_to_D33, ...).
      ! These are never read from a namelist on this call path, so without this call they
      ! would keep whatever value the uninitialized module variables happen to have.
      CALL init_penta_input

      DO k = 1,ns_dkes
        ! PENTA
        CALL PENTA_SET_ION_PARAMS(nion_prof, DBLE(Zatom_prof), Matom_prof/p_mass)
        CALL PENTA_SET_COMMANDLINE(Er_min_Vcm_in,Er_max_Vcm_in,DKES_K(k),1,EparB(k),1,'','','')
        CALL PENTA_ALLOCATE_SPECIES
        CALL PENTA_SET_EQ_DATA(rho_k(k),eq_Aminor,eq_Rmajor,vp(k),chip(k),phip(k),iota(k),btheta(k),bzeta(k),bsq(k))
        CALL PENTA_SET_PPROF(ne(k),dnedrho(k)/eq_Aminor,te(k),dtedrho(k)/eq_Aminor,ni(k,:),dnidrho(k,:)/eq_Aminor,ti(k,:),dtidrho(k,:)/eq_Aminor)
        ! MAKE CORRECTIONS ON D31 AND D33 -- values coming from DKES2 miss Bsq factors (see J. Lore documentation)
        CALL PENTA_SET_DKES_STAR(ncstar,nestar,DKES_NUSTAR(1:ncstar),DKES_ERSTAR(1:nestar), &
              DKES_D11(k,:,:), DKES_D31(k,:,:)*SQRT(bsq(k)), DKES_D33(k,:,:)*bsq(k))
        CALL PENTA_SET_BEAM(0.0_rknd) ! Zero becasue we don't read
        CALL PENTA_SET_U2() ! Leave blank for default value
        CALL PENTA_READ_INPUT_FILES(.FALSE.,.FALSE.,.FALSE.,.FALSE.,.FALSE.)
        ! CALL PENTA_SCREEN_INFO
        CALL PENTA_ALLOCATE_DKESCOEFF
        CALL PENTA_FIT_DXX_COEF
        CALL PENTA_LMAT_MATRIX
        CALL PENTA_SET_INTEGRATION_ARRAYS

        ! Only search new ambipolar Er solution if look_for_ambipolar = true
        IF(.NOT. look_for_ambipolar) THEN
              ! Need to define num_roots and set Er_roots
              num_roots = 1
              Er_roots(1) = Er_k(k)
        ELSE
              ! Now the basic steps
              CALL PENTA_RUN_2_EFIELD
              CALL PENTA_RUN_3_FIND_ROOTS
        END IF

        CALL PENTA_RUN_4_AMBIPOLAR

        ! The call to ROOT_ANALYSIS sets the array 'root_type' which decides which root to pick
        ! The criterium is to pick the 'ion_root'
        CALL ROOT_ANALYSIS(TRIM(Er_root_type_in))

        ! Using root_type, pick the ambipolar root that will be saved by THRIFT
        DO i=1,num_roots
          IF(root_type(i)) THEN
            JBS_PENTA(k) = J_BS_ambi(i)
            ! etapar_PENTA(k) = 1.0_rknd / sigma_par_ambi(i)
            Er_PENTA(k) = Er_roots(i)
            ! NEO fluxes
            ! GNEO_PENTA(:,k) = Gammas_ambi(:,i)
            ! QNEO_PENTA(:,k) = QoTs_ambi(:,i) * Temps * elem_charge
            ! NEO particle transport coefficients
            Dn_PENTA(:,k) = (/ (-L_n_ambi(i,j,j), j=1,nion_prof+1) /)
            cn_PENTA(:,k) = MATMUL(L_T_ambi(i,:,:),elem_charge*dTdrs) / dens + Er_PENTA(k)*SUM(L_Er_ambi(i,:,:),dim=2) / dens
            ! NEO heat transport coefficients
            Dp_PENTA(:,k) = (/ (-R_T_ambi(i,j,j), j=1,nion_prof+1) /) * elem_charge*Temps / dens
            cp_PENTA(:,k) = MATMUL(R_n_ambi(i,:,:),dndrs)/dens - MATMUL(R_T_ambi(i,:,:),(elem_charge*Temps/dens)*dndrs)/dens &
                              + Er_PENTA(k)*SUM(R_Er_ambi(i,:,:),dim=2) / dens
            EXIT
          ENDIF
        END DO

        CALL PENTA_RUN_5_CLEANUP(.FALSE.)
      END DO

      ! Interpolations onto output_rho
      ! CALL interpolate_from_PENTA(nrho_penta=ns_dkes, rho_penta=rho_k, y_penta=JBS_PENTA,\
      !                             nrho_out=nsj, rho_out=output_rho, y_out=output_JBS,\
      !                             isHermite=1, useLog=.FALSE.)
      !
      CALL interpolate_from_PENTA(nrho_penta=ns_dkes, rho_penta=rho_k, y_penta=Er_PENTA,\
                              nrho_out=output_nrho, rho_out=output_rho, y_out=output_Er,\
                              isHermite=1, useLog=.FALSE.)
      !
      DO jspecies=1,(nion_prof+1)
         CALL interpolate_from_PENTA(nrho_penta=ns_dkes, rho_penta=rho_k, y_penta=Dn_PENTA(jspecies,:),\
                     nrho_out=output_nrho, rho_out=output_rho, y_out=output_Dn(jspecies,:),\
                     isHermite=1, useLog=.FALSE.)
         !
         CALL interpolate_from_PENTA(nrho_penta=ns_dkes, rho_penta=rho_k, y_penta=cn_PENTA(jspecies,:),\
                           nrho_out=output_nrho, rho_out=output_rho, y_out=output_cn(jspecies,:),\
                           isHermite=1, useLog=.FALSE.)
         !
         CALL interpolate_from_PENTA(nrho_penta=ns_dkes, rho_penta=rho_k, y_penta=Dp_PENTA(jspecies,:),\
                           nrho_out=output_nrho, rho_out=output_rho, y_out=output_Dp(jspecies,:),\
                           isHermite=1, useLog=.FALSE., preventNeg = .TRUE.)
         !
         CALL interpolate_from_PENTA(nrho_penta=ns_dkes, rho_penta=rho_k, y_penta=cp_PENTA(jspecies,:),\
                           nrho_out=output_nrho, rho_out=output_rho, y_out=output_cp(jspecies,:),\
                           isHermite=1, useLog=.FALSE.)
      END DO

   End Subroutine call_PENTA

END MODULE PENTA_INTERFACE_MOD