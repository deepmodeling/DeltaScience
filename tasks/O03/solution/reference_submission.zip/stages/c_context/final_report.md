# C preexperiment reference

All structured records are serialized from audited real preexperiment artifacts.
