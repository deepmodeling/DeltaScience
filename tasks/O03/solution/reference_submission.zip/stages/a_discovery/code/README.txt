Generated from the audited O03 preexperiment chain by build_preexperiment_reference.py.
